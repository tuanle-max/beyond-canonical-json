# BCJ-V21 Corrective Release Candidate

Verify (from repo root):
```
python verify_v20_r5b_evidence.py .
```
Corpora: R4 temporal, R5/R5A alias, R5B E4/membership, KAT. Sources: corrected Python/Go + boo_r4. No blanket license granted. Do not claim universal correctness or independent replication.
