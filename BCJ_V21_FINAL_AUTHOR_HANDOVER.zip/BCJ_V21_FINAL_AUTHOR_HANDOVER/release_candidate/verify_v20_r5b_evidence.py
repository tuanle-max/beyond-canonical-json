import hashlib, json, pathlib, sys
def h(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def node(l, r): return hashlib.sha256(b"\x01" + bytes.fromhex(l) + bytes.fromhex(r)).hexdigest()
def rec(ds):
    if len(ds) == 0: return hashlib.sha256(b"\x02\x00").hexdigest()
    if len(ds) == 1: return ds[0]
    k = 1
    while k * 2 < len(ds): k *= 2
    return node(rec(ds[:k]), rec(ds[k:]))
def main(d):
    d = pathlib.Path(d); pr = []
    for tag in ("PY", "GO"):
        rows = [json.loads(l) for l in open(d / ("E4_" + tag + "_RAW.jsonl"), encoding="utf-8") if l.strip()]
        ok = sum(1 for r in rows if rec(r["leaf_digests"]) == r["root"] and len(r["leaf_digests"]) == r["leaf_count"])
        print(tag, "batches", len(rows), "root_recompute_ok", ok)
        if ok != len(rows) or len(rows) != 18: pr.append(tag)
    kat = [json.loads(l) for l in open(d / "COMMITMENT_V3_KAT.P03FINAL.jsonl", encoding="utf-8") if l.strip()]
    kok = 0
    for v in kat:
        if all(hashlib.sha256(bytes.fromhex(p)).hexdigest() == dd for p, dd in zip(v["leaf_preimages"], v["leaf_digests"])) and \
           all(node(n["left"], n["right"]) == n["digest"] for n in v["internal_nodes"]) and rec(v["leaf_digests"]) == v["recursive_root"]:
            kok += 1
    print("KAT", len(kat), "recompute_ok", kok)
    if kok != 10 or len(kat) != 10: pr.append("KAT")
    print(json.dumps({"problems": pr}, indent=2))
    return 0 if not pr else 1
if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
