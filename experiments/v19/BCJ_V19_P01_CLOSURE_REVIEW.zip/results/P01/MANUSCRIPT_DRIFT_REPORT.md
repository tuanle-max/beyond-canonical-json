# MANUSCRIPT_DRIFT_REPORT — OI-01 (P01-R2)

## Candidate hashes (see MANUSCRIPT_HASHES.json for the machine record)
| candidate | sha256 |
|---|---|
| `tex/v18.tex` (working, untracked) | `68d8c560…` |
| `tex/MANUSCRIPT_SSOT.tex` (working, modified) | `213f6e57…` |
| `tex/MANUSCRIPT_SSOT.tex` (HEAD committed) | `4ca98530…` |
| `tex/manuscript.tex` (working) | `7c29aeb3…` |

## What each file is
- `tex/manuscript.tex` (`7c29aeb3…`) = the frozen **LNNS** campaign manuscript (E0–E5). Not in scope
  for this reconciliation; kept separate. Matches `FREEZE.md::manuscript_tex_sha`.
- `tex/MANUSCRIPT_SSOT.tex` @ HEAD (`4ca98530…`) = the frozen **IEEE Access** SSOT revision (G4),
  matches `FREEZE.md::ssot_tex_sha`.
- `tex/MANUSCRIPT_SSOT.tex` @ working (`213f6e57…`) = the Lead's **uncommitted** camera-ready edits
  (working tree, +214 diff lines vs HEAD).
- `tex/v18.tex` (`68d8c560…`) = the **new v19 upgrade manuscript** (untracked), +940 changed lines vs
  `MANUSCRIPT_SSOT.tex` @ working.

## Difference classification (high level)
- **Scientific/numerical:** the frozen numerical results (J01/G2/E5/CR-0006 counts, root
  `4d487975…`, pid `d7deab47…`, vcommit `b5642feb`) are **unchanged** between the manuscripts; they
  are the same frozen campaign numbers. The differences are prose re-scoping (obligations O1–O5,
  quotient/root propositions, evidence-level S/I/E framing, the "V2/V3 Level-E roadmap").
- **Methodology:** v18 adds the admission-aware metric definitions (`S_E`,`S_D`,`Cov_U`), the matched
  baseline arms table, and the validation roadmap appendix.
- **Limitations:** v18 foregrounds the missing per-leg admission aggregate and the M4 D_K− gap.
- **Editorial/author metadata:** v18 is single-author (`Minh Tuan Le`, Hanoi Open University, grant
  MHN2026-CT01-03); `MANUSCRIPT_SSOT.tex` working has the Lead's author identities/grant edits.

## Decision required (OI-01 → BLOCKED_AUTHOR_DECISION)
The reviewed-manuscript digest is **not** independently available in the repository; the values above
are computed candidates. The Author Lead must confirm the authoritative v19 SSOT digest. Candidate:
`68d8c56078d8342785d882301e0703f4116d6c71381de1518a5afe099a85abf7` (`tex/v18.tex`).

Nothing was overwritten or discarded: all four candidates remain on disk; content snapshots are
captured in `MANUSCRIPT_HASHES.json` + `MANUSCRIPT_DRIFT.diff`.