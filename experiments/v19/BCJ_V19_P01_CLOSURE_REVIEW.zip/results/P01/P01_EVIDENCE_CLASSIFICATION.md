# P01_EVIDENCE_CLASSIFICATION

- P01 is **Level S — simulator / legacy-replay evidence**.
- Evidence kind: `NEW_LEGACY_REPLAY (K-v1 frozen contract)` — a deterministic replay of the authored
  `jcommon` oracle over the frozen J01 corpus. It is **not**:
  - independent end-to-end semantic interoperability (Level E);
  - a separately authored oracle or implementation;
  - archived original execution (the historical campaign had **no** per-leg admission logs).
- Supported claims: internal consistency of the frozen K-v1 transform on 330 cases (coverage,
  pair success, fail-closed abstention). Not supported: external adjudication of business semantics,
  malformed-input rejection coverage (M4 = NOT_EVALUATED), or any population/deployment-risk inference.
- M4 invalid-input rejection: `NOT_EVALUATED` (zero D_K− cases).
- M6 unsafe admission: applies to the 30-case D_K? cohort only; do not generalize to malformed/prohibited.