# P01_ORACLE_INDEPENDENCE_AUDIT — Task D

## Finding: P01 is a SELF-REFERENTIAL replay (no independent oracle)

`scripts/jcommon.py` contains **both**:
- the business oracle `beta()` / `typed()` (produces the observed admission + canonical output), and
- the case builders `equiv_pair()`, `nonequiv_pair()`, `ambiguous_case()` that embed the fault-family
  semantics used to label the frozen J01 corpus.

The frozen expected labels in `derived/results/j01_cases.json` were produced by `jcommon`
(`build_j01_cases`), and P01's observed outputs were produced by the **same module** (`jcommon.typed`).
There is **no language-separated or independently authored oracle** for the J-block. The Rust BOO
(`crates/boo`) is for the K-12/E9 canon-drift campaign, **not** the J01–J04 profile.

Consequence: the expected partition (D_K+/D_K?) and the observed admission derive from one authored
codebase; P01 therefore demonstrates **internal consistency**, not independent semantic validation.

## Dependency graph (P01_J01_ORACLE_DEPENDENCIES.json)
- Expected labels ← `jcommon.build_j01_cases` + `equiv_pair/nonequiv_pair/ambiguous_case` (frozen in `j01_cases.json`).
- Observed admission ← `jcommon.typed` → `jcommon.beta` → `parse_ts/parse_minor/currency_of/beneficiary_of`.
- Both share: `jcommon.canonical`, `parse_ts`, `parse_minor`, `currency_of`, `beneficiary_of`, `unicode` (NFKC).
- No artifact existed that independently adjudicated labels; the 50-case "lead adjudication" record is
  described in the manuscript but not present as a machine artifact in this tree.

## Classification
- **P01 = Level S (simulator / legacy-replay), NOT Level E.** It is not independent cross-implementation
  semantic evidence; it is a self-consistent replay of the authored contract over the frozen corpus.
- The absence of oracle conflicts does **not** establish oracle correctness.

## Affected claims / downgrade
- "M1–M7 = 100%/150/150/…" are reported only as **archive-level internal-consistency** statistics, not
  as independently-adjudicated semantic correctness. The label must not be upgraded to Level E or V3.

## Proposed remediation (do not implement now)
Independent adjudication requires (a) an out-of-code normative spec (P02 K-v2) and (b) a separately
authored oracle/implementation (P03 Implementation B) that reads only the contract, then compares
admission and canonical bytes stage-by-stage.