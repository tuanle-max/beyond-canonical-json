# P01 mutation / negative-verification report

- missing_occurrence: DETECTED -> occurrence_count,duplicate_or_missing_occurrence,unsafe_admission_denominator
- duplicate_occurrence: DETECTED -> occurrence_count,incorrect_partition,modified_admission
- incorrect_partition: DETECTED -> incorrect_partition,modified_admission,unsafe_admission_denominator
- modified_admission: DETECTED -> modified_admission,equiv_pair_success,modified_summary_numerator
- modified_canonical_digest: DETECTED -> equiv_pair_success,modified_summary_numerator
- pair_success_despite_rejection: DETECTED -> modified_admission,equiv_pair_success,modified_summary_numerator
- incorrect_coverage_denominator: DETECTED -> incorrect_coverage_denominator
- M4_reported_100pct: DETECTED -> M4_reported_100pct
- incorrect_unsafe_denominator: DETECTED -> unsafe_admission_denominator
- modified_summary_numerator: DETECTED -> modified_summary_numerator
- incorrect_degenerate_baseline: DETECTED -> incorrect_degenerate_baseline
- checksum_regenerated_modified_numerator: DETECTED -> modified_summary_numerator

checksum-regenerated case is detected semantically (recompute), not via digest comparison.
