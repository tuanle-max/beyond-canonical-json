# P01 — Admission-Aware Semantic Audit (REPORT)

Run `P01-R1` · `NEW_LEGACY_REPLAY` of the frozen K-v1 contract (`scripts/jcommon.py`).

## Result (independently recomputed from per-leg output)
- Test units **330** (150 equivalent + 150 distinct + 30 ambiguous).
- Input occurrences **630** (600 pair legs + 30 singles); unique raw inputs **630** (no duplicates).
- Unique admissible inputs **600**; prohibited/malformed **0**; underspecified **30**.

| Metric | Result | Target |
|---|---|---|
| M1 unique valid-input coverage | **600/600 (100%)** | 100% |
| M2 equivalent-pair success | **150/150** | 150/150 |
| M3 distinct-pair success | **150/150** | 150/150 |
| M4 invalid-input rejection | **N/A** (0 D_K− cases) | N/A |
| M5 underspecified abstention | **30/30** | 30/30 |
| M6 unsafe admission | **0/30** | 0 |
| M7 false rejection | **0/600** | 0 |
| internal errors | **0** | 0 |

## Degenerate baselines (metric-design validation)
- B-REJECT-ALL: coverage 0, S_E 0, S_D 0 (as required).
- B-CONSTANT: coverage 100%, S_E 100%, S_D 0, unsafe admission 30/30 exposed (as required).

## Findings / limitations (retained, not hidden)
- **M4 is N/A**: the frozen J01 set contains **zero** prohibited/malformed (`D_K−`) inputs; the 30 ambiguous
  cases are `D_K?` (underspecified → abstention), not `D_K−` (malformed → rejection). This confirms the
  manuscript limitation: "the 30 ambiguous cases are not a comprehensive malformed-input test."
- **No oracle conflicts**: no identical raw bytes with conflicting partition labels.
- This is a **replay** of the frozen contract, not the original historical execution; admission metrics
  (M1–M7) were not previously computed.

## Process acceptance
- All 330 units accounted for (630 occurrences traced to per-leg JSONL).
- Metrics regenerated from raw per-leg log by `experiments/v19/scripts/p01_admission.py`.
- No rejection treated as canonical equality (rejection = `None`, never equal bytes).
- Degenerate controls produced their mathematically expected results.

## Gate: PASS (process + scientific)
Next phase P02 (K-v2 normative contract) requires Author-Lead approval of domain decisions (OI-06).