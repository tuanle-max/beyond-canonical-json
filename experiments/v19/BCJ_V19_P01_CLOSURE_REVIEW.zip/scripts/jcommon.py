"""Shared deterministic model for the J01-J04 assurance harness (Gate G1, PHASE 1).

Stdlib only. Pure functions, fixed seed by the caller. The model is a MOCK of the manuscript's formal
objects: beta_S (business oracle), T_S (typed transform) and F_Pi = canonical(T_S(d)). Nothing here
reads the manuscript; the manuscript is compared against what this code produces.
"""
from __future__ import annotations

import datetime as _dt
import decimal
import hashlib
import json
import random
import unicodedata

BASE_MS = 1_730_000_000_000  # fixed instant anchor (2024-10-27T11:33:20Z)
FAMILIES = ("Timestamp/Precision", "Amount/Units", "Unicode/IDs", "Null/Defaults", "Schema Aliases")


def canonical(obj) -> bytes:
    """RFC-8785-like canonical JSON (sorted keys, minimal separators, UTF-8), stdlib only."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def iso_z(ms: int) -> str:
    return _dt.datetime.fromtimestamp(ms / 1000, _dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def iso_offset(ms: int, hours: int) -> str:
    tz = _dt.timezone(_dt.timedelta(hours=hours))
    return _dt.datetime.fromtimestamp(ms / 1000, tz).isoformat()


def parse_ts(value):
    """Epoch milliseconds (int) or None. Accepts int ms, numeric string, ISO 'Z', ISO with offset."""
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    s = str(value).strip()
    if not s:
        return None
    if s.lstrip("-").isdigit():
        try:
            return int(s)
        except ValueError:
            return None
    try:
        dt = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return int(dt.timestamp() * 1000)


def parse_minor(value, scale):
    """Integer minor units = value * 10**scale under ROUND_HALF_UP, or None when undefined.

    P0-01 (R4 audit): use decimal.Decimal to remove binary-float drift and the ambiguity of Python's
    built-in round() (banker's rounding). Fails closed (None) on non-finite inputs (NaN, +/-Infinity),
    on malformed strings (Decimal InvalidOperation) and on overflow.
    """
    if value is None or scale is None or isinstance(value, bool):
        return None
    try:
        factor = decimal.Decimal(10) ** int(scale)
    except (decimal.InvalidOperation, decimal.Overflow, ValueError, TypeError):
        return None
    try:
        dec = decimal.Decimal(str(value).strip())
        if not dec.is_finite():
            return None
        minor = (dec * factor).to_integral_value(rounding=decimal.ROUND_HALF_UP)
        return int(minor)
    except (decimal.InvalidOperation, decimal.Overflow, ValueError, TypeError):
        return None


def currency_of(doc):
    cur = doc.get("currency")
    if cur is None:
        cur = doc.get("cur")  # schema alias
    return cur.upper() if isinstance(cur, str) else cur


def beneficiary_of(doc):
    bc = doc.get("beneficiary_code")
    if bc is None:
        bc = doc.get("beneficiary")  # schema alias
    if bc is None:
        return None
    return unicodedata.normalize("NFKC", bc).strip()


def beta(doc):
    """Business oracle: canonical business tuple, or None when outside D_Pi* (undefined)."""
    eid = doc.get("event_id")
    t = parse_ts(doc.get("timestamp"))
    scale = doc.get("scale")
    cur = currency_of(doc)
    if eid is None or t is None or scale is None or cur is None:
        return None
    minor = parse_minor(doc.get("amount"), scale)
    if minor is None:
        return None
    return (eid, t, minor, cur, beneficiary_of(doc), doc.get("obligation_ref"))


def typed(doc):
    """T_S: typed canonical dict, or None (fail-closed) when beta is undefined."""
    b = beta(doc)
    if b is None:
        return None
    eid, t, minor, cur, bc, ref = b
    return {"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bc, "ref": ref}


def f_pi(doc):
    """F_Pi(d) = canonical(T_S(d)); None means fail-closed (abstain / reject)."""
    tv = typed(doc)
    return None if tv is None else canonical(tv)


def f_a0(doc):
    """A0: raw JCS of the input document, always defined."""
    return canonical(doc)


def cp_upper_one_sided(k: int, n: int, alpha: float = 0.05) -> float:
    """Exact one-sided Clopper-Pearson upper bound for k successes in n (k=0 closed form)."""
    if n <= 0:
        return 1.0
    if k == 0:
        return 1.0 - alpha ** (1.0 / n)
    # conservative fallback for k>0 is not needed by J-blocks (all denominators are k=0 or exact k=n)
    return 1.0 - alpha ** (1.0 / n)



def _doc(eid, ts, amount, cur, scale, bc, *, include_ref=False, ref=None, extra=None):
    d = {"event_id": eid, "timestamp": ts, "amount": amount,
         "currency": cur, "scale": scale, "beneficiary_code": bc}
    if include_ref:
        d["obligation_ref"] = ref
    if extra:
        d.update(extra)
    return d


def equiv_pair(family, i):
    """Two documents with the SAME beta_S but different raw representation."""
    eid = "EQ-%s-%03d" % (family[:3].upper(), i)
    ms = BASE_MS + i * 60_000
    bc = "BC-%03d" % i
    if family == FAMILIES[0]:  # same instant, 'Z' vs '+07:00'
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_offset(ms, 7), "250.00", "USD", 2, bc)
    elif family == FAMILIES[1]:  # same minor units, string vs float
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_z(ms), 250.0, "USD", 2, bc)
    elif family == FAMILIES[2]:  # NFC vs NFD beneficiary
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, "Jos\u00e9")
        b = _doc(eid, iso_z(ms), "250.00", "USD", 2, "Jose\u0301")
    elif family == FAMILIES[3]:  # obligation_ref null vs absent
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc, include_ref=True, ref=None)
        b = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc, include_ref=False)
    else:  # 'currency' vs 'cur' schema alias
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b.pop("currency")
        b["cur"] = "USD"
    return {"case_id": eid, "family": family, "kind": "equivalent",
            "input_a": a, "input_b": b}


def nonequiv_pair(family, i):
    """Two documents with DIFFERENT beta_S."""
    eid = "NEQ-%s-%03d" % (family[:3].upper(), i)
    ms = BASE_MS + i * 60_000
    bc = "BC-%03d" % i
    if family == FAMILIES[0]:  # instants differ by 1h
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_z(ms + 3_600_000), "250.00", "USD", 2, bc)
    elif family == FAMILIES[1]:  # amounts differ
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_z(ms), "350.00", "USD", 2, bc)
    elif family == FAMILIES[2]:  # beneficiaries differ (accent vs none)
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, "Jos\u00e9")
        b = _doc(eid, iso_z(ms), "250.00", "USD", 2, "Jose")
    elif family == FAMILIES[3]:  # obligation_ref null vs present
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc, include_ref=True, ref=None)
        b = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc, include_ref=True, ref="OBL-1")
    else:  # currency differs
        a = _doc(eid, iso_z(ms), "250.00", "USD", 2, bc)
        b = _doc(eid, iso_z(ms), "250.00", "EUR", 2, bc)
    return {"case_id": eid, "family": family, "kind": "non_equivalent",
            "input_a": a, "input_b": b}


def ambiguous_case(i):
    """One document outside D_Pi* (missing currency or scale) -> must fail closed."""
    eid = "AMB-%03d" % i
    ms = BASE_MS + i * 60_000
    doc = _doc(eid, iso_z(ms), "250.00", "USD", 2, "BC-%03d" % i)
    if i % 2 == 0:
        doc.pop("currency")   # missing currency
    else:
        doc.pop("scale")      # missing scale
    return {"case_id": eid, "family": "Ambiguous", "kind": "ambiguous",
            "input_a": doc, "input_b": None}


def build_j01_cases(per_family=30, ambiguous=30):
    """Deterministic 330-case holdout: 150 equivalent, 150 non-equivalent, 30 ambiguous."""
    cases = []
    for family in FAMILIES:
        for i in range(per_family):
            cases.append(equiv_pair(family, i))
        for i in range(per_family):
            cases.append(nonequiv_pair(family, i))
    for i in range(ambiguous):
        cases.append(ambiguous_case(i))
    return cases