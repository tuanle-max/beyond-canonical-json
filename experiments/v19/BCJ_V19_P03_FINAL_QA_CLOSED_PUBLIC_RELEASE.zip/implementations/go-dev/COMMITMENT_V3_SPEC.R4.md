# COMMITMENT_V3_SPEC.R4 (candidate, NOT frozen)

leaf_v3 = SHA256(0x00 || 0x03 || pid_sem_v2[32] || construction_digest[32] || canonical_record_bytes)
node    = SHA256(0x01 || left[32] || right[32])
Root([]) = SHA256(bytes.fromhex("0200"))  (binds no identity; checkpoints bind separately)

Tree = RFC 9162 recursive-split shape (k = largest power of two < n); NOT claimed fully RFC 9162 compliant.
Batch policy (bound in construction_manifest_v3.R4.CANDIDATE.json): admitted records only, record order,
duplicates = repeated leaf, missing record = batch fail, index = tree placement (not hashed), rejected excluded,
counts kept outside root.

Two independent root paths (see COMMITMENT_V3_KAT.R4.jsonl): recursive largest-power-of-two split and a streaming
frontier/stack algorithm; roots MUST be equal. Reordering / changed pid / changed construction MUST give a different root.

Candidates: pid_sem_v2 = 71287e74981877e3290daae6ffa9b560d30e3618330594820f92995f98da8da5
            construction_digest = d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d