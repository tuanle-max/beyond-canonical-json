# Docker execution commands (Agent B, executed)

Image pinned by digest: golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db

Module setup (inside container, persisted to go-dev via mount):
    go mod init boo
    go mod edit -require=golang.org/x/text@v0.19.0 -require=github.com/gowebpki/jcs@v1.0.1
    go mod tidy
    go mod verify        # all modules verified

Build + test:
    go build ./...        # ok
    go run . selftest     # overall_pass true, norm_version 15.0.0

CLI:
    go run . adjudicate records.jsonl per_input.jsonl
    go run . commit batch.json commit.json
