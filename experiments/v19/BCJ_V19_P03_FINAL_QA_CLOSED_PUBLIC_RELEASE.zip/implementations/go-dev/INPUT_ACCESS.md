# Input access inventory (Agent B)

Accessed (go-dev only): NORMATIVE_CONTRACT.R4.md, FIELD_SEMANTICS.csv, ERROR_TAXONOMY.yaml,
SUPPORTED_CURRENCY_SCALE_REGISTRY.json, semantic_manifest_v2.R4.CANDIDATE.json, COMMITMENT_V3_SPEC.R4.md,
construction_manifest_v3.R4.CANDIDATE.json, go.mod, go.sum.

NOT accessed: Python implementation, reference oracle, independent J01 expected, J01 corpus, evaluator
fixtures, P04 held-out evidence.

Isolation: filesystem-scoped workspace (procedural); no OS sandbox claimed. Compiled/executed inside the
authorized pinned Docker image (Windows host compiler blocked by policy).
