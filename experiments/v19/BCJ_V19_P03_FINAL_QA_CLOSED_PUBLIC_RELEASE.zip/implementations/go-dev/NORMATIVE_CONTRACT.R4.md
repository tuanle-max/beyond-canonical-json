# NORMATIVE_CONTRACT.R4 — K-v2 (P02-R4 candidate; NOT frozen)

CANDIDATE. Candidate identifiers are NOT authoritative. Precedence: this file wins over all others; contradictions removed.

## R4-01 closures
### Currency
`currency` ∈ registry exactly, uppercase `^[A-Z]{3}$`. **No silent uppercasing.** Lowercase/other → `UNSUPPORTED_CURRENCY` (REJECT_PROHIBITED). Alias `cur` identical rules.

### Beneficiary (required)
Missing or JSON null → `MISSING_BENEFICIARY` (ABSTAIN_UNDERSPECIFIED). Non-string (Num/bool/list/object) → `FIELD_TYPE_MALFORMED` (REJECT_MALFORMED). No `str()` coercion, no trimming, no case folding. Empty string `""` after NFC → `FIELD_TYPE_MALFORMED`. C0/C1 control chars or unpaired surrogate → `UNICODE_MALFORMED`. NFC only on admitted strings (Unicode 15.0.0 normative; runtime version recorded separately).

### Scale
Must be a JSON **integer token** (`Num(kind=int)`, no sign/`.`/`e`). Boolean/decimal/string → `SCALE_MALFORMED` (REJECT_MALFORMED). Must equal registry[currency] else `SCALE_MISMATCH` (REJECT_PROHIBITED).

### Timestamp
Calendar: proleptic Gregorian, year 0001–9999. Grammar: `YYYY-MM-DD[T ]HH:MM:SS(.f{1,6})?(Z|±hh:mm)` — seconds mandatory; fraction (1–6 digits) optional only with seconds; offset minutes ∈ {00,15,30,45}. Integer epoch-ms token (`Num(kind=int)`) also accepted directly. **Numeric strings are NOT integer tokens** → `TIMESTAMP_MALFORMED`. No tz → `TIMESTAMP_MISSING_TZ` (ABSTAIN). Leap second `:60`, bad calendar, bad offset → `TIMESTAMP_MALFORMED`. Out of safe range → `TIMESTAMP_OUT_OF_RANGE`. Exact integer arithmetic (no float), sub-ms floor toward −∞.

### Admission precedence (deterministic, field-order independent)
Category rank: MALFORMED(0) > PROHIBITED(1) > ABSTAIN(2). Within category, lowest `REASON_RANK` wins. EXECUTION outcomes `INTERNAL_ERROR`/`TIMEOUT` are NOT normative rejections.

### Reason taxonomy (`ERROR_TAXONOMY.yaml`; rank within category)
MALFORMED: JSON_MALFORMED, DUPLICATE_KEY, UNICODE_MALFORMED, TIMESTAMP_MALFORMED, SCALE_MALFORMED, EVENT_ID_MALFORMED, FIELD_TYPE_MALFORMED, AMOUNT_MALFORMED.
PROHIBITED: NEGATIVE_AMOUNT, MONETARY_OVERFLOW, UNSUPPORTED_CURRENCY, SCALE_MISMATCH, UNKNOWN_FIELD, ALIAS_CONFLICT, TIMESTAMP_OUT_OF_RANGE.
ABSTAIN: MISSING_BENEFICIARY, MISSING_EVENT_ID, MISSING_CURRENCY, MISSING_SCALE, MISSING_AMOUNT, MISSING_TIMESTAMP, TIMESTAMP_MISSING_TZ.

## Monetary lexical grammar (closed)
`amount` accepts Num(int) token | Num(dec) token | string. `DECIMAL := (0|[1-9][0-9]*)(\.[0-9]{1,6})?`. No grouping, no exponent, no sign, no leading zeros (except `0`), max int digits 16, max frac 6, max token len 24. Negative (`-`) → `NEGATIVE_AMOUNT`; `-0`/`-0.00` → `NEGATIVE_AMOUNT`. Bool → `AMOUNT_MALFORMED`. Whitespace inside → `AMOUNT_MALFORMED`. minor = exact Decimal×10^scale, ROUND_HALF_UP (prec 60), then `0 ≤ minor ≤ MAX_SAFE_INTEGER` else `MONETARY_OVERFLOW`.

## Output
`{eid, t, minor, cur, bc, ref}` (ref null|null-string). Integers validated within safe range after normalization, before JCS.

## Batch policy (construction identity, R4-07)
Admitted records only; ordered descriptor = list position; duplicates = repeated leaf; rejected/abstained excluded and counted separately in batch accounting; missing record → batch fails; index = tree placement (not hashed).