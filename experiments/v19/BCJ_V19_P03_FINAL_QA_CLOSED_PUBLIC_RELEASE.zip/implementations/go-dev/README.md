# Agent B — Go raw-to-root implementation (frozen initial)

Independent Go implementation of the frozen K-v2 contract: raw JSON bytes -> commitment root.
Uses only `go-dev/` normative inputs. No Python source, oracle, J01 corpus, evaluator fixtures, or P04 accessed.

## Environment (pinned Docker)
- Image: `golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db` (linux/amd64)
- go1.23.12 · golang.org/x/text v0.19.0 (norm.Version **15.0.0**) · github.com/gowebpki/jcs v1.0.1

## Build / run (Docker)
    docker run --rm -v "$PWD/experiments/v19/implementations/go-dev:/work" -w /work \
      golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db \
      bash -c "go run . selftest"

Adjudicate a JSONL (`{"record_id","raw_b64","pid_sem","construction_digest"}`):

    ... bash -c "go run . adjudicate records.jsonl per_input.jsonl"

Commit an ordered batch (`{"batch_id","pid_sem","construction_digest","records":[{"record_id","raw_b64"}]}`):

    ... bash -c "go run . commit batch.json commit.json"

## Implementation
- Hand-written strict JSON parser: UTF-8 validation, **duplicate-key detection**, **numeric-token preservation**
  (int vs decimal lexeme), surrogate-pair decoding with unpaired-surrogate rejection, control-char rejection.
- Exact monetary via `math/big` integer string arithmetic (ROUND_HALF_UP), never float64.
- Exact timestamp arithmetic via `time` (sub-ms floor, missing-tz, leap/calendar validation, safe range).
- Field-scoped NFC (`beneficiary_code`) via x/text `norm.NFC`.
- Typed business object → RFC 8785 via `jcs` (integers, no float). Distinct typed/eligible/canonical stages.
- Commitment-v3: leaf `0x00||0x03||pid||cd||bytes`, node `0x01||L||R`, empty `0x02||0x00`, recursive split.

## Dev tests
`selftest`: 9/9 adjudication cases pass; commitment empty/single/odd3/even4. See `DEV_TEST_RESULTS.json`.
Cross-implementation note: commitment roots for identical canonical records match Agent A exactly
(empty `99be5efb…`, single `966c4b0e…`, odd3 `9679558f…`, even4 `e1b975e6…`).

## Frozen identifiers
pid_sem_v2 = `caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429`
construction_digest = `d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d`
