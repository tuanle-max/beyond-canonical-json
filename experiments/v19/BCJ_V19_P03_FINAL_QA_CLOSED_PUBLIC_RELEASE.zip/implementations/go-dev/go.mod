module boo

go 1.23.12

require (
	github.com/gowebpki/jcs v1.0.1
	golang.org/x/text v0.19.0
)
