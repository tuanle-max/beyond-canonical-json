// Agent-B Go implementation of frozen K-v2: raw JSON bytes -> commitment root. Independent of Python/oracle.
package main

import (
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"math/big"
	"os"
	"regexp"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
	"unicode/utf8"

	"github.com/gowebpki/jcs"
	"golang.org/x/text/unicode/norm"
)

const MAXS int64 = 9007199254740991

var REG = map[string]int{"USD": 2, "EUR": 2, "VND": 0}

type Num struct {
	Lex string
	Int bool
}

// K: 0 null, 1 bool, 2 num, 3 str, 4 obj
type V struct {
	K   int
	S   string
	N   Num
	B   bool
	O   map[string]V
	Bad bool
}

type pem struct{ code string }

func (e *pem) Error() string { return e.code }

type ps struct {
	b   []byte
	i   int
	bad bool
}

func (p *ps) ws() {
	for p.i < len(p.b) {
		c := p.b[p.i]
		if c == ' ' || c == '\t' || c == '\n' || c == '\r' {
			p.i++
		} else {
			break
		}
	}
}

func (p *ps) val() (V, error) {
	p.ws()
	if p.i >= len(p.b) {
		return V{}, &pem{"JSON_MALFORMED"}
	}
	switch p.b[p.i] {
	case '{':
		return p.obj()
	case '"':
		p.bad = false
		s, e := p.str()
		return V{K: 3, S: s, Bad: p.bad}, e
	case 't':
		return p.lit("true", V{K: 1, B: true})
	case 'f':
		return p.lit("false", V{K: 1, B: false})
	case 'n':
		return p.lit("null", V{K: 0})
	default:
		return p.num()
	}
}

func (p *ps) lit(w string, v V) (V, error) {
	if len(p.b)-p.i >= len(w) && string(p.b[p.i:p.i+len(w)]) == w {
		p.i += len(w)
		return v, nil
	}
	return V{}, &pem{"JSON_MALFORMED"}
}

func (p *ps) obj() (V, error) {
	p.i++
	m := map[string]V{}
	p.ws()
	if p.i < len(p.b) && p.b[p.i] == '}' {
		p.i++
		return V{K: 4, O: m}, nil
	}
	for {
		p.ws()
		if p.i >= len(p.b) || p.b[p.i] != '"' {
			return V{}, &pem{"JSON_MALFORMED"}
		}
		k, e := p.str()
		if e != nil {
			return V{}, e
		}
		p.ws()
		if p.i >= len(p.b) || p.b[p.i] != ':' {
			return V{}, &pem{"JSON_MALFORMED"}
		}
		p.i++
		v, e := p.val()
		if e != nil {
			return V{}, e
		}
		if _, dup := m[k]; dup {
			return V{}, &pem{"DUPLICATE_KEY"}
		}
		m[k] = v
		p.ws()
		if p.i >= len(p.b) {
			return V{}, &pem{"JSON_MALFORMED"}
		}
		if p.b[p.i] == ',' {
			p.i++
			continue
		}
		if p.b[p.i] == '}' {
			p.i++
			break
		}
		return V{}, &pem{"JSON_MALFORMED"}
	}
	return V{K: 4, O: m}, nil
}

func (p *ps) str() (string, error) {
	if p.b[p.i] != '"' {
		return "", &pem{"JSON_MALFORMED"}
	}
	p.i++
	var sb strings.Builder
	for p.i < len(p.b) {
		c := p.b[p.i]
		if c == '"' {
			p.i++
			return sb.String(), nil
		}
		if c == '\\' {
			p.i++
			if p.i >= len(p.b) {
				return "", &pem{"JSON_MALFORMED"}
			}
			e := p.b[p.i]
			p.i++
			switch e {
			case '"':
				sb.WriteByte('"')
			case '\\':
				sb.WriteByte('\\')
			case '/':
				sb.WriteByte('/')
			case 'b':
				sb.WriteByte('\b')
			case 'f':
				sb.WriteByte('\f')
			case 'n':
				sb.WriteByte('\n')
			case 'r':
				sb.WriteByte('\r')
			case 't':
				sb.WriteByte('\t')
			case 'u':
				if p.i+4 > len(p.b) {
					return "", &pem{"UNICODE_MALFORMED"}
				}
				h, err := strconv.ParseUint(string(p.b[p.i:p.i+4]), 16, 32)
				if err != nil {
					return "", &pem{"UNICODE_MALFORMED"}
				}
				p.i += 4
				r := rune(h)
				if r >= 0xD800 && r <= 0xDBFF {
					if p.i+6 <= len(p.b) && p.b[p.i] == '\\' && p.b[p.i+1] == 'u' {
						l, err := strconv.ParseUint(string(p.b[p.i+2:p.i+6]), 16, 32)
						if err == nil && l >= 0xDC00 && l <= 0xDFFF {
							p.i += 6
							sb.WriteRune(utf16.DecodeRune(r, rune(l)))
							continue
						}
					}
					p.bad = true
					sb.WriteRune(0xFFFD)
					continue
				}
				if r >= 0xDC00 && r <= 0xDFFF {
					p.bad = true
					sb.WriteRune(0xFFFD)
					continue
				}
				sb.WriteRune(r)
			default:
				return "", &pem{"JSON_MALFORMED"}
			}
			continue
		}
		if c < 0x20 {
			return "", &pem{"JSON_MALFORMED"}
		}
		r, size := utf8.DecodeRune(p.b[p.i:])
		if r == utf8.RuneError && size == 1 {
			return "", &pem{"UNICODE_MALFORMED"}
		}
		sb.WriteRune(r)
		p.i += size
	}
	return "", &pem{"JSON_MALFORMED"}
}

func (p *ps) num() (V, error) {
	s := p.i
	for p.i < len(p.b) {
		c := p.b[p.i]
		if c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E' || (c >= '0' && c <= '9') {
			p.i++
		} else {
			break
		}
	}
	lex := string(p.b[s:p.i])
	if lex == "" {
		return V{}, &pem{"JSON_MALFORMED"}
	}
	return V{K: 2, N: Num{Lex: lex, Int: !strings.ContainsAny(lex, ".eE")}}, nil
}

func parse(b []byte) (V, error) {
	if !utf8.Valid(b) {
		return V{}, &pem{"UNICODE_MALFORMED"}
	}
	p := &ps{b: b}
	v, err := p.val()
	if err != nil {
		return V{}, err
	}
	p.ws()
	if p.i != len(p.b) {
		return V{}, &pem{"JSON_MALFORMED"}
	}
	if v.K != 4 {
		return V{}, &pem{"JSON_MALFORMED"}
	}
	return v, nil
}

var (
	RE_EID = regexp.MustCompile(`^[A-Za-z0-9_-]{1,256}$`)
	RE_REF = regexp.MustCompile(`^[\x20-\x7E]{1,256}$`)
	RE_AMT = regexp.MustCompile(`^(?:0|[1-9][0-9]*)(?:\.[0-9]{1,6})?$`)
	RE_INT = regexp.MustCompile(`^-?(?:0|[1-9][0-9]*)$`)
	RE_TS  = regexp.MustCompile(`^([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?(Z|[+-][0-9]{2}:[0-9]{2})$`)
	RE_TSN = regexp.MustCompile(`^([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.[0-9]{1,6})?$`)
)

func pow10(n int) *big.Int { return new(big.Int).Exp(big.NewInt(10), big.NewInt(int64(n)), nil) }

func minorOf(lex string, scale int) (int64, string) {
	parts := strings.SplitN(lex, ".", 2)
	ip := parts[0]
	fp := ""
	if len(parts) == 2 {
		fp = parts[1]
	}
	f := len(fp)
	bi, ok := new(big.Int).SetString(ip+fp, 10)
	if !ok {
		return 0, "AMOUNT_MALFORMED"
	}
	diff := scale - f
	if diff >= 0 {
		bi.Mul(bi, pow10(diff))
	} else {
		div := pow10(-diff)
		q := new(big.Int)
		r := new(big.Int)
		q.QuoRem(bi, div, r)
		if new(big.Int).Lsh(r, 1).Cmp(div) >= 0 {
			q.Add(q, big.NewInt(1))
		}
		bi = q
	}
	if !bi.IsInt64() {
		return 0, "MONETARY_OVERFLOW"
	}
	m := bi.Int64()
	if m > MAXS {
		return 0, "MONETARY_OVERFLOW"
	}
	return m, ""
}

var cats = map[string]int{}
var ranks = map[string]int{}

func init() {
	order := []string{"JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED", "SCALE_MALFORMED",
		"EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED", "NEGATIVE_AMOUNT", "MONETARY_OVERFLOW",
		"UNSUPPORTED_CURRENCY", "SCALE_MISMATCH", "UNKNOWN_FIELD", "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE",
		"MISSING_BENEFICIARY", "MISSING_EVENT_ID", "MISSING_CURRENCY", "MISSING_SCALE", "MISSING_AMOUNT",
		"MISSING_TIMESTAMP", "TIMESTAMP_MISSING_TZ"}
	malf := map[string]bool{"JSON_MALFORMED": true, "DUPLICATE_KEY": true, "UNICODE_MALFORMED": true, "TIMESTAMP_MALFORMED": true,
		"SCALE_MALFORMED": true, "EVENT_ID_MALFORMED": true, "FIELD_TYPE_MALFORMED": true, "AMOUNT_MALFORMED": true}
	proh := map[string]bool{"NEGATIVE_AMOUNT": true, "MONETARY_OVERFLOW": true, "UNSUPPORTED_CURRENCY": true,
		"SCALE_MISMATCH": true, "UNKNOWN_FIELD": true, "ALIAS_CONFLICT": true, "TIMESTAMP_OUT_OF_RANGE": true}
	for i, r := range order {
		ranks[r] = i
		if malf[r] {
			cats[r] = 0
		} else if proh[r] {
			cats[r] = 1
		} else {
			cats[r] = 2
		}
	}
}

func catName(c int) string {
	if c == 0 {
		return "REJECT_MALFORMED"
	}
	if c == 1 {
		return "REJECT_PROHIBITED"
	}
	return "ABSTAIN_UNDERSPECIFIED"
}

func hasSurrogate(s string) bool {
	for _, r := range s {
		if r >= 0xD800 && r <= 0xDFFF {
			return true
		}
	}
	return false
}

func hasCtrl(s string) bool {
	for _, r := range s {
		if r < 0x20 || (r >= 0x7F && r <= 0x9F) {
			return true
		}
	}
	return false
}

var allowed = map[string]bool{"event_id": true, "timestamp": true, "amount": true, "currency": true, "cur": true,
	"scale": true, "beneficiary_code": true, "beneficiary": true, "obligation_ref": true}

type result struct {
	Decision string
	Reason   string
	Typed    []byte
	EID      string
	T        int64
	Minor    int64
	Cur      string
	Bc       string
	Ref      interface{}
}

func tsMs(v V) (int64, string) {
	if v.K == 1 {
		return 0, "TIMESTAMP_MALFORMED"
	}
	if v.K == 2 && v.N.Int {
		i, err := strconv.ParseInt(v.N.Lex, 10, 64)
		if err != nil || i < -MAXS || i > MAXS {
			return 0, "TIMESTAMP_OUT_OF_RANGE"
		}
		return i, ""
	}
	if v.K != 3 {
		return 0, "TIMESTAMP_MALFORMED"
	}
	m := RE_TS.FindStringSubmatch(v.S)
	if m == nil {
		n := RE_TSN.FindStringSubmatch(v.S)
		if n == nil {
			return 0, "TIMESTAMP_MALFORMED"
		}
		y, _ := strconv.Atoi(n[1]); mo, _ := strconv.Atoi(n[2]); d, _ := strconv.Atoi(n[3])
		H, _ := strconv.Atoi(n[4]); M, _ := strconv.Atoi(n[5]); S, _ := strconv.Atoi(n[6])
		t := time.Date(y, time.Month(mo), d, H, M, S, 0, time.UTC)
		if t.Year() != y || int(t.Month()) != mo || t.Day() != d || t.Hour() != H {
			return 0, "TIMESTAMP_MALFORMED"
		}
		return 0, "TIMESTAMP_MISSING_TZ"
	}
	y, _ := strconv.Atoi(m[1]); mo, _ := strconv.Atoi(m[2]); d, _ := strconv.Atoi(m[3])
	H, _ := strconv.Atoi(m[4]); M, _ := strconv.Atoi(m[5]); S, _ := strconv.Atoi(m[6])
	if S > 59 {
		return 0, "TIMESTAMP_MALFORMED"
	}
	nsec := 0
	if m[7] != "" {
		fr := m[7]
		for len(fr) < 6 {
			fr += "0"
		}
		ns, _ := strconv.Atoi(fr)
		nsec = ns * 1000
	}
	off := 0
	if m[8] != "Z" {
		oh, _ := strconv.Atoi(m[8][1:3]); om, _ := strconv.Atoi(m[8][4:6])
		if oh > 23 || (om != 0 && om != 15 && om != 30 && om != 45) {
			return 0, "TIMESTAMP_MALFORMED"
		}
		off = oh*3600 + om*60
		if m[8][0] == '-' {
			off = -off
		}
	}
	loc := time.FixedZone("", off)
	t := time.Date(y, time.Month(mo), d, H, M, S, nsec, loc)
	if t.Year() != y || int(t.Month()) != mo || t.Day() != d || t.Hour() != H {
		return 0, "TIMESTAMP_MALFORMED"
	}
	ms := t.Unix()*1000 + int64(t.Nanosecond()/1000000)
	if ms < -MAXS || ms > MAXS {
		return 0, "TIMESTAMP_OUT_OF_RANGE"
	}
	return ms, ""
}

func ev(o map[string]V) result {
	iss := []string{}
	add := func(r string) { iss = append(iss, r) }
	for k := range o {
		if !allowed[k] {
			add("UNKNOWN_FIELD")
		}
	}
	if cv, ok1 := o["currency"]; ok1 && cv.K == 3 {
		if av, ok2 := o["cur"]; ok2 && av.K == 3 && av.S != cv.S {
			add("ALIAS_CONFLICT")
		}
	}
	if bv, ok1 := o["beneficiary_code"]; ok1 && bv.K == 3 {
		if av, ok2 := o["beneficiary"]; ok2 && av.K == 3 && norm.NFC.String(av.S) != norm.NFC.String(bv.S) {
			add("ALIAS_CONFLICT")
		}
	}
	if b1, ok := o["beneficiary_code"]; ok && b1.Bad {
		add("UNICODE_MALFORMED")
	}
	if b2, ok := o["beneficiary"]; ok && b2.Bad {
		add("UNICODE_MALFORMED")
	}
	eid := ""
	if evv, ok := o["event_id"]; !ok || evv.K == 0 {
		add("MISSING_EVENT_ID")
	} else if evv.Bad || evv.K != 3 || hasSurrogate(evv.S) || !RE_EID.MatchString(evv.S) {
		add("EVENT_ID_MALFORMED")
	} else {
		eid = evv.S
	}
	var t int64
	if tv, ok := o["timestamp"]; !ok || tv.K == 0 {
		add("MISSING_TIMESTAMP")
	} else if tt, e := tsMs(tv); e != "" {
		add(e)
	} else {
		t = tt
	}
	find := func(c, a string) (V, bool) {
		if v, ok := o[c]; ok && v.K != 0 {
			return v, true
		}
		if v, ok := o[a]; ok && v.K != 0 {
			return v, true
		}
		return V{}, false
	}
	cur := ""
	if cv, has := find("currency", "cur"); !has {
		add("MISSING_CURRENCY")
	} else if cv.K != 3 {
		add("UNSUPPORTED_CURRENCY")
	} else if _, ok := REG[cv.S]; !ok {
		add("UNSUPPORTED_CURRENCY")
	} else {
		cur = cv.S
	}
	scal := -1
	hasScale := false
	if sv, ok := o["scale"]; !ok || sv.K == 0 {
		add("MISSING_SCALE")
	} else if sv.K != 2 || !sv.N.Int || !RE_INT.MatchString(sv.N.Lex) {
		add("SCALE_MALFORMED")
	} else {
		scal, _ = strconv.Atoi(sv.N.Lex)
		hasScale = true
	}
	if hasScale {
		if cur != "" {
			if scal != REG[cur] {
				add("SCALE_MISMATCH")
			}
		} else if scal < 0 || scal > 6 {
			add("SCALE_MISMATCH")
		}
	}
	var minor int64
	amtOK := false
	lex := ""
	if av, ok := o["amount"]; !ok || av.K == 0 {
		add("MISSING_AMOUNT")
	} else if av.K == 1 {
		add("AMOUNT_MALFORMED")
	} else {
		if av.K == 2 {
			lex = av.N.Lex
		} else if av.K == 3 {
			lex = av.S
		}
		if lex == "" {
			add("AMOUNT_MALFORMED")
		} else if strings.HasPrefix(lex, "-") {
			add("NEGATIVE_AMOUNT")
		} else if len(lex) > 24 || !RE_AMT.MatchString(lex) || len(strings.SplitN(lex, ".", 2)[0]) > 16 {
			add("AMOUNT_MALFORMED")
		} else {
			amtOK = true
		}
	}
	if amtOK && scal >= 0 && cur != "" && scal == REG[cur] {
		if m, e := minorOf(lex, scal); e != "" {
			add(e)
		} else {
			minor = m
		}
	}
	bc := ""
	if bv, has := find("beneficiary_code", "beneficiary"); !has {
		add("MISSING_BENEFICIARY")
	} else if bv.K != 3 {
		add("FIELD_TYPE_MALFORMED")
	} else if bv.Bad || hasSurrogate(bv.S) {
		add("UNICODE_MALFORMED")
	} else {
		n := norm.NFC.String(bv.S)
		if n == "" {
			add("FIELD_TYPE_MALFORMED")
		} else if hasSurrogate(n) || hasCtrl(n) {
			add("UNICODE_MALFORMED")
		} else {
			bc = n
		}
	}
	var ref interface{}
	if rv, ok := o["obligation_ref"]; ok && rv.K != 0 {
		if rv.K != 3 || hasSurrogate(rv.S) || !RE_REF.MatchString(rv.S) {
			add("FIELD_TYPE_MALFORMED")
		} else {
			ref = rv.S
		}
	}
	if len(iss) > 0 {
		bi := 0
		for i, r := range iss {
			if cats[r] < cats[iss[bi]] || (cats[r] == cats[iss[bi]] && ranks[r] < ranks[iss[bi]]) {
				bi = i
			}
		}
		b := iss[bi]
		return result{Decision: catName(cats[b]), Reason: b}
	}
	obj := map[string]interface{}{"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bc, "ref": ref}
	raw, _ := json.Marshal(obj)
	canon, err := jcs.Transform(raw)
	if err != nil {
		return result{Decision: "INTERNAL_ERROR", Reason: "INTERNAL_ERROR"}
	}
	return result{Decision: "ACCEPT", Typed: canon, EID: eid, T: t, Minor: minor, Cur: cur, Bc: bc, Ref: ref}
}

func hexEnc(b []byte) string {
	const h = "0123456789abcdef"
	o := make([]byte, len(b)*2)
	for i, c := range b {
		o[i*2] = h[c>>4]
		o[i*2+1] = h[c&15]
	}
	return string(o)
}

func hexDec(s string) ([]byte, error) {
	if len(s)%2 != 0 {
		return nil, fmt.Errorf("odd hex")
	}
	n := len(s) / 2
	o := make([]byte, n)
	for i := 0; i < n; i++ {
		v, err := strconv.ParseUint(s[i*2:i*2+2], 16, 8)
		if err != nil {
			return nil, err
		}
		o[i] = byte(v)
	}
	return o, nil
}

func adjudicate(raw []byte) result {
	v, err := parse(raw)
	if err != nil {
		if pe, ok := err.(*pem); ok {
			return result{Decision: catName(cats[pe.code]), Reason: pe.code}
		}
		return result{Decision: "INTERNAL_ERROR", Reason: "INTERNAL_ERROR"}
	}
	return ev(v.O)
}

func leafOf(canon []byte, pid, cd string) []byte {
	pb, _ := hexDec(pid)
	cb, _ := hexDec(cd)
	h := sha256.New()
	h.Write([]byte{0x00, 0x03})
	h.Write(pb)
	h.Write(cb)
	h.Write(canon)
	return h.Sum(nil)
}

func nodeOf(l, r []byte) []byte {
	h := sha256.New()
	h.Write([]byte{0x01})
	h.Write(l)
	h.Write(r)
	return h.Sum(nil)
}

func rootOf(leaves [][]byte) ([]byte, []map[string]string) {
	n := len(leaves)
	if n == 0 {
		e := sha256.Sum256([]byte{0x02, 0x00})
		return e[:], []map[string]string{}
	}
	if n == 1 {
		return leaves[0], []map[string]string{}
	}
	k := 1
	for k*2 < n {
		k *= 2
	}
	L, ln := rootOf(leaves[:k])
	R, rn := rootOf(leaves[k:])
	pre := append(append([]byte{0x01}, L...), R...)
	nd := map[string]string{"left": hexEnc(L), "right": hexEnc(R), "preimage_hex": hexEnc(pre), "digest": hexEnc(nodeOf(L, R))}
	nodes := append([]map[string]string{nd}, ln...)
	nodes = append(nodes, rn...)
	return nodeOf(L, R), nodes
}

func readLines(p string) []string {
	b, _ := os.ReadFile(p)
	var out []string
	for _, l := range strings.Split(string(b), "\n") {
		if strings.TrimSpace(l) != "" {
			out = append(out, l)
		}
	}
	return out
}

func doAdj(in, out string) {
	var sb strings.Builder
	for _, line := range readLines(in) {
		var j struct {
			RecordID string `json:"record_id"`
			RawB64   string `json:"raw_b64"`
			Pid      string `json:"pid_sem"`
			Cd       string `json:"construction_digest"`
		}
		json.Unmarshal([]byte(line), &j)
		raw, _ := base64.StdEncoding.DecodeString(j.RawB64)
		r := adjudicate(raw)
		rec := map[string]interface{}{"record_id": j.RecordID, "admission": r.Decision, "execution_status": "OK",
			"semantic_profile_digest": j.Pid, "construction_digest": j.Cd}
		if r.Reason != "" {
			rec["reason_code"] = r.Reason
		} else {
			rec["reason_code"] = nil
		}
		if r.Decision == "ACCEPT" {
			ch := hexEnc(r.Typed)
			s := sha256.Sum256(r.Typed)
			rec["canonical_bytes_hex"] = ch
			rec["canonical_sha256"] = hexEnc(s[:])
			rec["typed_business_object"] = json.RawMessage(r.Typed)
			rec["eligible_json"] = json.RawMessage(r.Typed)
			pb, _ := hexDec(j.Pid)
			cb, _ := hexDec(j.Cd)
			full := append(append(append([]byte{0x00, 0x03}, pb...), cb...), r.Typed...)
			rec["leaf_preimage_hex"] = hexEnc(full)
			rec["leaf_digest"] = hexEnc(leafOf(r.Typed, j.Pid, j.Cd))
		}
		b, _ := json.Marshal(rec)
		sb.Write(b)
		sb.WriteByte('\n')
	}
	os.WriteFile(out, []byte(sb.String()), 0644)
}

func doCommit(in, out string) {
	var j struct {
		BatchID string `json:"batch_id"`
		Pid     string `json:"pid_sem"`
		Cd      string `json:"construction_digest"`
		ExpectedIDs []string `json:"expected_ids"`
		Records []struct {
			RecordID string `json:"record_id"`
			RawB64   string `json:"raw_b64"`
		} `json:"records"`
	}
	b, _ := os.ReadFile(in)
	json.Unmarshal(b, &j)
	suppliedCount := map[string]int{}
	for _, r := range j.Records {
		suppliedCount[r.RecordID]++
	}
	var missing []string
	if j.ExpectedIDs != nil {
		need := map[string]int{}
		for _, e := range j.ExpectedIDs {
			need[e]++
		}
		for k, v := range need {
			if d := v - suppliedCount[k]; d > 0 {
				for i := 0; i < d; i++ {
					missing = append(missing, k)
				}
			}
		}
	}
	if len(missing) > 0 {
		outj := map[string]interface{}{"batch_id": j.BatchID, "status": "BATCH_FAILED", "missing_required": missing,
			"admitted": []string{}, "rejected": []string{}, "abstained": []string{}, "leaf_count": 0,
			"leaf_digests": []string{}, "internal_nodes": []map[string]string{}, "root": nil,
			"semantic_profile_digest": j.Pid, "construction_digest": j.Cd}
		ob, _ := json.Marshal(outj)
		os.WriteFile(out, append(ob, '\n'), 0644)
		return
	}
	var leaves [][]byte
	var acc, rej, abst []string
	for _, r := range j.Records {
		raw, _ := base64.StdEncoding.DecodeString(r.RawB64)
		res := adjudicate(raw)
		if res.Decision == "ACCEPT" {
			leaves = append(leaves, leafOf(res.Typed, j.Pid, j.Cd))
			acc = append(acc, r.RecordID)
		} else if res.Decision == "ABSTAIN_UNDERSPECIFIED" {
			abst = append(abst, r.RecordID)
		} else {
			rej = append(rej, r.RecordID)
		}
	}
	rt, nodes := rootOf(leaves)
	ls := []string{}
	for _, l := range leaves {
		ls = append(ls, hexEnc(l))
	}
	outj := map[string]interface{}{"batch_id": j.BatchID, "status": "OK", "admitted": acc, "rejected": rej, "abstained": abst,
		"leaf_count": len(leaves), "leaf_digests": ls, "internal_nodes": nodes, "root": hexEnc(rt),
		"semantic_profile_digest": j.Pid, "construction_digest": j.Cd}
	ob, _ := json.Marshal(outj)
	os.WriteFile(out, append(ob, '\n'), 0644)
}

func selftest() int {
	PID := "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
	CD := "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
	cases := []struct{ id, raw, dec, rea string }{
		{"valid", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}`, "ACCEPT", ""},
		{"missing_beneficiary", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2}`, "ABSTAIN_UNDERSPECIFIED", "MISSING_BENEFICIARY"},
		{"unknown_field", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"B","x":1}`, "REJECT_PROHIBITED", "UNKNOWN_FIELD"},
		{"neg_amount", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"-1.00","currency":"USD","scale":2,"beneficiary_code":"B"}`, "REJECT_PROHIBITED", "NEGATIVE_AMOUNT"},
		{"bad_amt", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1e3","currency":"USD","scale":2,"beneficiary_code":"B"}`, "REJECT_MALFORMED", "AMOUNT_MALFORMED"},
		{"missing_tz", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"B"}`, "ABSTAIN_UNDERSPECIFIED", "TIMESTAMP_MISSING_TZ"},
		{"dup_key", `{"event_id":"A","event_id":"B"}`, "REJECT_MALFORMED", "DUPLICATE_KEY"},
		{"lower_currency", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"usd","scale":2,"beneficiary_code":"B"}`, "REJECT_PROHIBITED", "UNSUPPORTED_CURRENCY"},
		{"nfc", `{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"Jose\u0301"}`, "ACCEPT", ""},
	}
	fails := 0
	res := []map[string]interface{}{}
	for _, c := range cases {
		r := adjudicate([]byte(c.raw))
		ok := r.Decision == c.dec && r.Reason == c.rea
		if !ok {
			fails++
		}
		res = append(res, map[string]interface{}{"case": c.id, "expected": []string{c.dec, c.rea}, "observed": []string{r.Decision, r.Reason}, "pass": ok})
	}
	leaves := [][]byte{}
	for _, id := range []string{"EV-1", "EV-2", "EV-3", "EV-4"} {
		raw := []byte(`{"event_id":"` + id + `","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B"}`)
		if r := adjudicate(raw); r.Decision == "ACCEPT" {
			leaves = append(leaves, leafOf(r.Typed, PID, CD))
		}
	}
	commit := map[string]interface{}{}
	for _, pair := range []struct {
		name string
		n    int
	}{{"empty", 0}, {"single", 1}, {"odd3", 3}, {"even4", 4}} {
		rt, nodes := rootOf(leaves[:pair.n])
		commit[pair.name] = map[string]interface{}{"leaf_count": pair.n, "root": hexEnc(rt), "nodes": len(nodes)}
	}
	out := map[string]interface{}{"adjudication": res, "adjudication_fails": fails, "commitment": commit,
		"norm_version": norm.Version, "overall_pass": fails == 0}
	ob, _ := json.MarshalIndent(out, "", "  ")
	fmt.Println(string(ob))
	if fails == 0 {
		return 0
	}
	return 1
}

func main() {
	a := os.Args[1:]
	if len(a) < 1 {
		fmt.Println("usage: boo adjudicate|commit|selftest ...")
		os.Exit(2)
	}
	switch a[0] {
	case "adjudicate":
		doAdj(a[1], a[2])
	case "commit":
		doCommit(a[1], a[2])
	case "selftest":
		os.Exit(selftest())
	}
}