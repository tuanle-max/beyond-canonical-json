# Input access inventory (Agent A)

Accessed (python-dev only):
- NORMATIVE_CONTRACT.R4.md
- FIELD_SEMANTICS.csv
- ERROR_TAXONOMY.yaml
- SUPPORTED_CURRENCY_SCALE_REGISTRY.json
- semantic_manifest_v2.R4.CANDIDATE.json
- COMMITMENT_V3_SPEC.R4.md
- construction_manifest_v3.R4.CANDIDATE.json
- PYTHON_REQUIREMENTS_LOCK.txt

NOT accessed: reference oracle (r3/r4/r4a_oracle), independent J01 adjudicator, independent J01
expected evidence, J01 source corpus, Go implementation, P04 held-out evidence, parent evaluator artifacts.

Isolation: filesystem-scoped workspace (procedural). No OS sandbox claimed.
