# Agent A — Python raw-to-root implementation (frozen initial)

Implements the frozen K-v2 contract from raw JSON bytes to commitment-v3 root. Uses only
`python-dev/` normative inputs (contract, field semantics, error taxonomy, registry, semantic
manifest, commitment spec, construction manifest, dependency lock). No oracle / J01 / evaluator /
Go source was accessed.

## Environment
Python 3.12.9 · unicodedata 15.0.0 · rfc8785 0.1.3 · decimal (C)

## Files
- `boo.py` — implementation + CLI
- `dev_tests.py` — development tests (spec-derived)
- `DEV_TEST_RESULTS.json` — actual dev test output
- `DEPENDENCY_LOCK.txt`, `ENV.json`, `INPUT_ACCESS.md`, `SHA256SUMS`

## Frozen identifiers
- pid_sem_v2 = `caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429`
- construction_digest = `d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d`

## CLI
Adjudicate a JSONL of records (each line: `{"record_id","raw_b64","pid_sem","construction_digest"}`):

    python boo.py adjudicate --in records.jsonl --out per_input.jsonl

Commit an ordered batch (`{"batch_id","pid_sem","construction_digest","records":[{"record_id","raw_b64"}]}`):

    python boo.py commit --in batch.json --out commit.json

## Output
`adjudicate`: record_id, admission, reason_code, execution_status, typed_business_object,
eligible_json, canonical_bytes_hex, canonical_sha256, leaf_preimage_hex, leaf_digest,
semantic_profile_digest, construction_digest.
`commit`: batch_id, admitted/rejected/abstained, leaf_count, leaf_digests, internal_nodes, root,
semantic_profile_digest, construction_digest.

Typed-object and eligible-JSON stages are explicitly distinct fields (currently equal by contract).
Numeric lexemes preserved via token wrapper; no binary-float monetary intermediates. NFC scoped to
`beneficiary_code`. Deterministic admission precedence MALFORMED > PROHIBITED > ABSTAIN.

## Dev tests
`python dev_tests.py` → `overall_pass: true` (9 adjudication cases + empty/singleton/odd3/even4 commitment).
