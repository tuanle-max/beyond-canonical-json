"""Agent-A Python implementation of the frozen K-v2 contract: raw JSON bytes -> commitment root.
Independent of any reference oracle / evaluator artifacts. Uses only python-dev normative inputs."""
import json, re, hashlib, sys, argparse, unicodedata, datetime as dt, base64
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

MAXS = 9007199254740991; MINS = -MAXS
REG = {"USD": 2, "EUR": 2, "VND": 0}
EID = re.compile(r"[A-Za-z0-9_-]{1,256}"); REF = re.compile(r"[\x20-\x7E]{1,256}")
AMT = re.compile(r"(?:0|[1-9][0-9]*)(?:\.[0-9]{1,6})?"); INT = re.compile(r"-?(?:0|[1-9][0-9]*)")
TS = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?(Z|[+-][0-9]{2}:[0-9]{2})")
TSN = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.[0-9]{1,6})?")
ALLOWED = {"event_id", "timestamp", "amount", "currency", "cur", "scale", "beneficiary_code", "beneficiary", "obligation_ref"}
ORDER = ["JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED", "SCALE_MALFORMED",
         "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED", "NEGATIVE_AMOUNT", "MONETARY_OVERFLOW",
         "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH", "UNKNOWN_FIELD", "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE",
         "MISSING_BENEFICIARY", "MISSING_EVENT_ID", "MISSING_CURRENCY", "MISSING_SCALE", "MISSING_AMOUNT",
         "MISSING_TIMESTAMP", "TIMESTAMP_MISSING_TZ"]
RANK = {r: i for i, r in enumerate(ORDER)}
MALF = {"JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED", "SCALE_MALFORMED",
        "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED"}
PROH = {"NEGATIVE_AMOUNT", "MONETARY_OVERFLOW", "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH", "UNKNOWN_FIELD",
        "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE"}


def cat(r):
    return "REJECT_MALFORMED" if r in MALF else ("REJECT_PROHIBITED" if r in PROH else "ABSTAIN_UNDERSPECIFIED")


CATR = {"REJECT_MALFORMED": 0, "REJECT_PROHIBITED": 1, "ABSTAIN_UNDERSPECIFIED": 2}
_A = object()


class Tok:
    __slots__ = ("lex", "kind")

    def __init__(s, l, k):
        s.lex = l; s.kind = k


class Dup(Exception):
    pass


def hook(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise Dup()
        d[k] = v
    return d


def const(c):
    raise ValueError()


def parse(raw):
    try:
        s = raw.decode("utf-8")
    except UnicodeDecodeError:
        return None, "UNICODE_MALFORMED"
    try:
        o = json.loads(s, object_pairs_hook=hook, parse_int=lambda x: Tok(x, "int"),
                       parse_float=lambda x: Tok(x, "dec"), parse_constant=const)
    except Dup:
        return None, "DUPLICATE_KEY"
    except ValueError:
        return None, "JSON_MALFORMED"
    if not isinstance(o, dict):
        return None, "JSON_MALFORMED"
    return o, None


def hs(s):
    return any(0xD800 <= ord(c) <= 0xDFFF for c in s)


def ctl(s):
    return any(ord(c) < 0x20 or 0x7F <= ord(c) <= 0x9F for c in s)


EP = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)


def ts(v):
    if isinstance(v, bool):
        return None, "TIMESTAMP_MALFORMED"
    if isinstance(v, Tok) and v.kind == "int":
        i = int(v.lex)
        return (i, None) if MINS <= i <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")
    if isinstance(v, Tok) or not isinstance(v, str):
        return None, "TIMESTAMP_MALFORMED"
    m = TS.fullmatch(v)
    if not m:
        n = TSN.fullmatch(v)
        if not n:
            return None, "TIMESTAMP_MALFORMED"
        try:
            dt.datetime(int(n.group(1)), int(n.group(2)), int(n.group(3)), int(n.group(4)), int(n.group(5)), int(n.group(6)))
        except ValueError:
            return None, "TIMESTAMP_MALFORMED"
        return None, "TIMESTAMP_MISSING_TZ"
    y, mo, d, H, M, S, f, off = m.groups()
    if int(S) > 59:
        return None, "TIMESTAMP_MALFORMED"
    if off == "Z":
        tr = dt.timedelta(0)
    else:
        oh, om = int(off[1:3]), int(off[4:6])
        if oh > 23 or om not in (0, 15, 30, 45):
            return None, "TIMESTAMP_MALFORMED"
        tr = (1 if off[0] == "+" else -1) * dt.timedelta(hours=oh, minutes=om)
    try:
        loc = dt.datetime(int(y), int(mo), int(d), int(H), int(M), int(S), int((f or "0").ljust(6, "0")), tzinfo=dt.timezone(tr))
    except (ValueError, OverflowError):
        return None, "TIMESTAMP_MALFORMED"
    dl = loc.astimezone(dt.timezone.utc) - EP
    ms = (dl.days * 86400 * 10**6 + dl.seconds * 10**6 + dl.microseconds) // 1000
    return (ms, None) if MINS <= ms <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")


def al(lex, sc):
    if lex.startswith("-"):
        return None, "NEGATIVE_AMOUNT"
    if len(lex) > 24 or not AMT.fullmatch(lex) or len(lex.split(".")[0]) > 16:
        return None, "AMOUNT_MALFORMED"
    with localcontext() as c:
        c.prec = 60
        m = int((Decimal(lex) * (Decimal(10) ** sc)).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return (m, None) if 0 <= m <= MAXS else (None, "MONETARY_OVERFLOW")


def _al(doc, c, a, norm, issues):
    x = doc.get(c, _A); y = doc.get(a, _A)
    px = x is not _A and x is not None; py = y is not _A and y is not None
    if px and py:
        if isinstance(x, str) and isinstance(y, str):
            if norm(x) != norm(y):
                issues.append("ALIAS_CONFLICT"); return _A
            return x
        return x
    if py:
        return y
    if px:
        return x
    return _A


def evaluate(o):
    iss = []
    for k in o:
        if k not in ALLOWED:
            iss.append("UNKNOWN_FIELD")
    eid = o.get("event_id", _A)
    if eid is _A or eid is None:
        iss.append("MISSING_EVENT_ID")
    elif not isinstance(eid, str) or hs(eid) or not EID.fullmatch(eid):
        iss.append("EVENT_ID_MALFORMED")
    t = None; tv = o.get("timestamp", _A)
    if tv is _A or tv is None:
        iss.append("MISSING_TIMESTAMP")
    else:
        t, te = ts(tv)
        if te:
            iss.append(te)
    cur = _al(o, "currency", "cur", lambda z: z, iss)
    if cur is _A or cur is None:
        iss.append("MISSING_CURRENCY"); cur = None
    elif not isinstance(cur, str) or cur not in REG:
        iss.append("UNSUPPORTED_CURRENCY"); cur = None
    sc = o.get("scale", _A); scl = None
    if sc is _A or sc is None:
        iss.append("MISSING_SCALE")
    elif not (isinstance(sc, Tok) and sc.kind == "int" and INT.fullmatch(sc.lex)):
        iss.append("SCALE_MALFORMED")
    else:
        scl = int(sc.lex)
    if scl is not None:
        if cur is not None:
            if scl != REG[cur]:
                iss.append("SCALE_MISMATCH")
        elif scl not in (0, 1, 2, 3, 4, 5, 6):
            iss.append("SCALE_MISMATCH")
    am = o.get("amount", _A); minor = None; ok = False; lex = None
    if am is _A or am is None:
        iss.append("MISSING_AMOUNT")
    elif isinstance(am, bool):
        iss.append("AMOUNT_MALFORMED")
    else:
        lex = am.lex if isinstance(am, Tok) else (am if isinstance(am, str) else None)
        if lex is None:
            iss.append("AMOUNT_MALFORMED")
        elif lex.startswith("-"):
            iss.append("NEGATIVE_AMOUNT")
        elif len(lex) > 24 or not AMT.fullmatch(lex) or len(lex.split(".")[0]) > 16:
            iss.append("AMOUNT_MALFORMED")
        else:
            ok = True
    if ok and scl is not None and cur is not None and scl == REG[cur]:
        minor, me = al(lex, scl)
        if me:
            iss.append(me)
    nfc = lambda x: unicodedata.normalize("NFC", x) if isinstance(x, str) else x
    for _bn in ("beneficiary_code", "beneficiary"):
        _av = o.get(_bn, _A)
        if isinstance(_av, str) and any(0xD800 <= ord(c) <= 0xDFFF for c in _av):
            iss.append("UNICODE_MALFORMED")
    bc = _al(o, "beneficiary_code", "beneficiary", nfc, iss); bcv = None
    if bc is _A or bc is None:
        iss.append("MISSING_BENEFICIARY")
    elif not isinstance(bc, str):
        iss.append("FIELD_TYPE_MALFORMED")
    elif hs(bc):
        iss.append("UNICODE_MALFORMED")
    else:
        n = unicodedata.normalize("NFC", bc)
        if n == "":
            iss.append("FIELD_TYPE_MALFORMED")
        elif hs(n) or ctl(n):
            iss.append("UNICODE_MALFORMED")
        else:
            bcv = n
    ref = o.get("obligation_ref", _A); refv = None
    if ref is not _A and ref is not None:
        if not isinstance(ref, str) or hs(ref) or not REF.fullmatch(ref):
            iss.append("FIELD_TYPE_MALFORMED")
        else:
            refv = ref
    if iss:
        best = min(iss, key=lambda r: (CATR[cat(r)], RANK[r]))
        return {"decision": cat(best), "reason_code": best, "execution_status": "OK", "typed": None, "eligible": None, "canonical_hex": None}
    typed = {"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bcv, "ref": refv}
    inb = rfc8785.dumps(typed)
    return {"decision": "ACCEPT", "reason_code": None, "execution_status": "OK", "typed": typed, "eligible": typed, "canonical_hex": inb.hex()}


def adjudicate(raw):
    o, e = parse(raw)
    if e:
        return {"decision": cat(e), "reason_code": e, "execution_status": "OK", "typed": None, "eligible": None, "canonical_hex": None}
    return evaluate(o)


def leaf(canon, pid, cd):
    return hashlib.sha256(b"\x00\x03" + bytes.fromhex(pid) + bytes.fromhex(cd) + canon).digest()


def node(l, r):
    return hashlib.sha256(b"\x01" + l + r).digest()


def root(leaves):
    n = len(leaves)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest(), []
    if n == 1:
        return leaves[0], []
    k = 1
    while k * 2 < n:
        k *= 2
    L, ln = root(leaves[:k]); R, rn = root(leaves[k:])
    nd = {"left": L.hex(), "right": R.hex(), "preimage_hex": (b"\x01" + L + R).hex(), "digest": node(L, R).hex()}
    return node(L, R), [nd] + ln + rn


def _b(x):
    return base64.b64decode(x)


def cmd_adj(ns):
    out = open(ns.out, "w", encoding="utf-8")
    for line in open(ns.inp, encoding="utf-8"):
        if not line.strip():
            continue
        j = json.loads(line)
        r = adjudicate(_b(j["raw_b64"]))
        rec = {"record_id": j.get("record_id"), "admission": r["decision"], "reason_code": r["reason_code"],
               "execution_status": r["execution_status"], "typed_business_object": r["typed"],
               "eligible_json": r["eligible"], "canonical_bytes_hex": r["canonical_hex"],
               "canonical_sha256": hashlib.sha256(bytes.fromhex(r["canonical_hex"])).hexdigest() if r["canonical_hex"] else None,
               "semantic_profile_digest": j.get("pid_sem"), "construction_digest": j.get("construction_digest")}
        if r["canonical_hex"]:
            pre = b"\x00\x03" + bytes.fromhex(j["pid_sem"]) + bytes.fromhex(j["construction_digest"]) + bytes.fromhex(r["canonical_hex"])
            rec["leaf_preimage_hex"] = pre.hex(); rec["leaf_digest"] = hashlib.sha256(pre).hexdigest()
        else:
            rec["leaf_preimage_hex"] = None; rec["leaf_digest"] = None
        out.write(json.dumps(rec, sort_keys=True) + "\n")
    out.close()


def cmd_commit(ns):
    b = json.load(open(ns.inp, encoding="utf-8"))
    pid = b["pid_sem"]; cd = b["construction_digest"]
    exp = b.get("expected_ids")
    supplied = [r["record_id"] for r in b["records"]]
    if exp is not None:
        from collections import Counter as _C
        _need = _C(exp); _have = _C(supplied)
        missing = []
        for _k in _need:
            _d = _need[_k] - _have.get(_k, 0)
            if _d > 0:
                missing += [_k] * _d
        if missing:
            open(ns.out, "w", encoding="utf-8").write(json.dumps({"batch_id": b.get("batch_id"), "status": "BATCH_FAILED",
                "missing_required": missing, "admitted": [], "rejected": [], "abstained": [], "leaf_count": 0,
                "leaf_digests": [], "internal_nodes": [], "root": None, "semantic_profile_digest": pid,
                "construction_digest": cd}, sort_keys=True) + "\n")
            return
    leaves = []; acc = []; rej = []; abst = []
    for r in b["records"]:
        res = adjudicate(_b(r["raw_b64"]))
        if res["decision"] == "ACCEPT":
            leaves.append(leaf(bytes.fromhex(res["canonical_hex"]), pid, cd)); acc.append(r["record_id"])
        elif res["decision"] == "ABSTAIN_UNDERSPECIFIED":
            abst.append(r["record_id"])
        else:
            rej.append(r["record_id"])
    rt, nodes = root(leaves)
    open(ns.out, "w", encoding="utf-8").write(json.dumps({
        "batch_id": b.get("batch_id"), "status": "OK", "admitted": acc, "rejected": rej, "abstained": abst,
        "leaf_count": len(leaves), "leaf_digests": [l.hex() for l in leaves], "internal_nodes": nodes,
        "root": rt.hex(), "semantic_profile_digest": pid, "construction_digest": cd}, sort_keys=True) + "\n")


def main(argv=None):
    p = argparse.ArgumentParser(prog="boo")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("adjudicate"); a.add_argument("--in", dest="inp", required=True); a.add_argument("--out", required=True); a.set_defaults(f=cmd_adj)
    c = sub.add_parser("commit"); c.add_argument("--in", dest="inp", required=True); c.add_argument("--out", required=True); c.set_defaults(f=cmd_commit)
    ns = p.parse_args(argv); ns.f(ns)


if __name__ == "__main__":
    main()