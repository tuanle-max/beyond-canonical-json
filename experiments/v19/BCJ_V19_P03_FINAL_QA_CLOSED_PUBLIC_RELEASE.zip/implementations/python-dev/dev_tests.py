"""Development tests (Agent A) derived from the frozen normative contract. Not evaluator fixtures."""
import sys, json, hashlib
sys.path.insert(0, ".")
import boo

PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
BASE = ('{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}').encode()


def adj(raw):
    return boo.adjudicate(raw)


CASES = [
    ("valid", BASE, "ACCEPT", None),
    ("missing_beneficiary", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2}', "ABSTAIN_UNDERSPECIFIED", "MISSING_BENEFICIARY"),
    ("unknown_field", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"B","x":1}', "REJECT_PROHIBITED", "UNKNOWN_FIELD"),
    ("neg_amount", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"-1.00","currency":"USD","scale":2,"beneficiary_code":"B"}', "REJECT_PROHIBITED", "NEGATIVE_AMOUNT"),
    ("bad_amt", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1e3","currency":"USD","scale":2,"beneficiary_code":"B"}', "REJECT_MALFORMED", "AMOUNT_MALFORMED"),
    ("missing_tz", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"B"}', "ABSTAIN_UNDERSPECIFIED", "TIMESTAMP_MISSING_TZ"),
    ("dup_key", b'{"event_id":"A","event_id":"B"}', "REJECT_MALFORMED", "DUPLICATE_KEY"),
    ("lower_currency", b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"usd","scale":2,"beneficiary_code":"B"}', "REJECT_PROHIBITED", "UNSUPPORTED_CURRENCY"),
    ("nfc", ('{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"Jose\\u0301"}').encode(), "ACCEPT", None),
]

fails = 0
res = []
for cid, raw, ed, er in CASES:
    r = adj(raw)
    ok = r["decision"] == ed and r["reason_code"] == er
    fails += (not ok)
    res.append({"case": cid, "expected": [ed, er], "observed": [r["decision"], r["reason_code"]], "pass": ok})

# commitment construction across batch sizes
sizes = {}
for label, ids in [("empty", []), ("single", [1]), ("odd3", [1, 2, 3]), ("even4", [1, 2, 3, 4])]:
    leaves = []
    for i in ids:
        raw = ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B"}' % i).encode()
        r = adj(raw)
        assert r["decision"] == "ACCEPT", r
        leaves.append(boo.leaf(bytes.fromhex(r["canonical_hex"]), PID, CD))
    rt, nodes = boo.root(leaves)
    sizes[label] = {"leaf_count": len(leaves), "root": rt.hex(), "nodes": len(nodes),
                    "single_ok": (len(leaves) == 1 and rt.hex() == leaves[0].hex()) if len(leaves) == 1 else True,
                    "empty_ok": (rt.hex() == hashlib.sha256(b"\x02\x00").hexdigest()) if len(leaves) == 0 else True}

out = {"adjudication": res, "adjudication_fails": fails, "commitment": sizes,
       "overall_pass": fails == 0}
print(json.dumps(out, indent=2))
sys.exit(0 if fails == 0 else 1)