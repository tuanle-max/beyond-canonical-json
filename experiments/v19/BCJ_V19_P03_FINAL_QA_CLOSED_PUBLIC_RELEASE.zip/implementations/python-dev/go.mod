module p03smoke

go 1.27.3

require (
	github.com/gowebpki/jcs v1.0.1 // indirect
	golang.org/x/text v0.19.0 // indirect
)
