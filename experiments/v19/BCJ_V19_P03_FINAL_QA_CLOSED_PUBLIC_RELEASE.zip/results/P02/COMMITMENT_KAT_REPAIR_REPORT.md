# COMMITMENT_KAT_REPAIR_REPORT (WP-A)

- Defective preflight KAT preserved as historical evidence.
- Corrected cardinalities: empty=0, single=1, two=2, three=3, five=5, duplicate=3, ordered=5, permutation=5.
- Full leaf preimages (0x00||0x03||pid||cd||bytes), leaf digests, internal-node preimages+digests, recursive+stack roots.
- Empty batch records empty-root preimage 0x0200.
- Permutation case = same multiset, different sequence, different root.
- changed_pid / changed_construction vary exactly one factor; roots differ from 2-leaf base.
- All leaves recomputed from preimages; all roots recomputed from recomputed leaves.
