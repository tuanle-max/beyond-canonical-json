# COMMITMENT_V3_SPEC.DRAFT — candidate leaf v3 (NOT validated, NOT frozen)

Resolves the P03 dependency: independent raw-to-root reconstruction needs a frozen construction spec
BEFORE P03 implementation. This is a design-level candidate only.

## Digests (both 32 bytes, detached)
- `pid_sem_v2 = SHA256(JCS(semantic_manifest_v2))` — semantic identity (detached; not in payload).
- `construction_digest = SHA256(JCS(construction_manifest_v3))` — construction identity (detached; not in payload).

## Leaf v3 (candidate)
```
leaf_v3 = SHA256( 0x00 || 0x03 || pid_sem_v2[32] || construction_digest[32] || canonical_record_bytes )
```
Field widths fixed: domain tag 2 bytes (`0x00 0x03`), then 32 + 32, then variable canonical bytes.

## Tree and batching
- Hash: SHA-256. Internal node: `SHA256(0x01 || left[32] || right[32])` (leaf/internal domain-separated).
- Ordering: leaf order = frozen ordered batch descriptor (explicit, not insertion-order-dependent).
- Empty tree: `root = SHA256(0x02 || 0)` (defined constant), documented.
- Odd leaf count: last node promoted/duplicated per RFC-9162-style rule — **exactly** as frozen in the
  batch descriptor; specify promotion vs duplication explicitly before freeze (candidate: RFC-9162 promote).
- Single leaf: `root = leaf_v3` (documented special case).
- Duplicate admissible records: preserved as distinct leaves (position-bound); not deduplicated.
- Ancillary inputs: none beyond the leaf prefix and ordering (v2 salts if any must be specified; historical
  v2 used no per-leaf salt in the J-block replay).
- Length encoding: not required (fixed-width prefix; canonical bytes are JCS self-delimiting).

## Frozen constraints
- Historical v2 construction (`0x00 0x02 || pid_sem || v_commit`) and its roots (`4d487975…`) remain
  **frozen and unchanged**; v3 is a new version.
- P05 will evaluate authenticated checkpoint / trusted-policy verification against the approved construction.
- Do NOT implement or execute v3 during P02-R2.