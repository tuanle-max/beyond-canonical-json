# COMMITMENT_V3_SPEC.R3 — K-v2 construction (candidate, NOT frozen)

## Leaf v3
```
leaf_v3 = SHA256(0x00 || 0x03 || pid_sem_v2[32] || construction_digest[32] || canonical_record_bytes)
```
## Internal node
```
node = SHA256(0x01 || left[32] || right[32])
```
## Tree shape — RFC 9162 recursive split (for n>1)
`k = largest power of two strictly smaller than n`; `Root(L)=node(Root(L[0:k]), Root(L[k:n]))`; `Root([leaf])=leaf`;
`Root([])=SHA256(bytes.fromhex("0200"))`. Do not hash a leaf digest again; do not duplicate the final leaf.
The empty-root constant does NOT bind semantic/construction identity — authenticated checkpoints bind those separately.
**Not "RFC 9162 compliant"**: this is the RFC 9162 recursive *tree-shape rule* with a custom domain-separated leaf and empty-root.

## Ordering / batch
- Ordered batch descriptor: explicit list of admitted records in record order; leaf index = placement in the ordered tree (not hashed into the leaf).
- Duplicates: identical duplicate records -> identical leaf hashes; positions represented by placement.
- Rejected/abstained records EXCLUDED from the admitted-record root; admission accounting kept separately (batch-level counts), not inside the root. Missing records -> batch fails closed.

## Digests
`pid_sem_v2` (candidate `fe5bb956…`) and `construction_digest` (candidate `424f2620c582ac68efa7ce8c4d165070c74c73b91db352d4aaca57411e2985ed`) are detached; neither appears inside its own manifest.

## Known-answer roots
See `COMMITMENT_V3_KAT.jsonl` (empty, single, 2, 3, 5 leaves, duplicates, reorder, changed pid, changed construction; two independent root paths agree).