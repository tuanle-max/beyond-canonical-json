# CONTRACT_APPROVAL_SHEET — K-v2 (post Author-Lead policy approval)

| ID | Decision | Author Lead policy | Status |
|---|---|---|---|
| D-02 | Leap seconds | REJECT (`:60`) | APPROVED |
| D-03 | Negative amounts | PROHIBIT (+ explicit negative-zero) | APPROVED |
| D-04 | Monetary equivalence | QUANTIZED payable amount + currency | APPROVED |
| D-05 | Unicode | FIELD-SCOPED NFC (intentional NFKC->NFC change) | APPROVED |
| D-06 | Null/absence | FIELD-SPECIFIC (obligation_ref null==absent) | APPROVED |
| D-07 | Alias conflict | REJECT | APPROVED |
| D-08 | Duplicate keys | REJECT (before parse) | APPROVED |
| D-09 | Numeric lexical | ACCEPT exact decimal tokens (no float64) | APPROVED |
| D-10 | Timestamp resolution | INTEGER EPOCH MS | APPROVED |
| D-11 | Currency scale | FIXED per currency registry | APPROVED |
| D-12 | Unknown fields | CLOSED SCHEMA | APPROVED |

Recorded as Author-Lead-approved (directive BCJ-V19-P02-R2). Contract freeze still PENDING Experiment Lead
review of the completed R2 spec; `pid_sem_v2` NOT published. See CONTRACT_DECISION_REGISTER.csv.