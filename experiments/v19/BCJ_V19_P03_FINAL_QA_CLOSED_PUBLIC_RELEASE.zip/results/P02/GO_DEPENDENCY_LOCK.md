# Go dependency lock (declared; go.sum pending Stage 1)
- toolchain: go1.27.3 windows/amd64 (verified via `go version`)
- golang.org/x/text v0.19.0 (NFC/UAX#15)
- github.com/gowebpki/jcs v1.0.1 (JCS RFC 8785)
Status: DECLARED, not `go mod download`-verified in Stage 0 (no build executed).
