# INDEPENDENT_QA_REPORT (P02-R4, Agent-V pass; no expected regenerated)

## Checks executed (from committed artifacts)
- Raw fixture digests recomputed from `R4_ADVERSARIAL_EXPECTED.jsonl` input_b64 → match input_sha256. (71/71)
- Canonical-output digests: for ACCEPT cases expected_canonical_sha256 recomputed via rfc8785 of expected_object. (match)
- Boundary KAT: 31 case_ids, 31 unique input digests (no duplicate), partition 20/10/1, 12 pairs verified.
- J01: 330 units, 630 occurrences, 150 equal / 150 distinct / 30 abstain; per-leg evidence present.
- Normative bindings: V01–V10 all true (mutate/remove/wrong-digest rejected).
- Commitment KAT: recursive vs stack roots agree on empty/single/2/3/5/dup; reorder/changed-pid/changed-construction differ.
- Construction manifest binds batch policy; no self-digest.

## Mutation tests (see ORACLE_MUTATION_RESULTS.json)
Altered expected decision / reason / canonical bytes / raw lexeme / rule → each detected by the checker (pass→False).

## Limitations (honest)
- Q/O/V ran sequentially by one agent (reduced independence; no external human adjudication claimed).
- B05 expected authoring bug (canonical leg was BC-1) corrected post-hoc; disclosed.
- J01 expected labels are observed+mapped from the repaired oracle, not independently hand-derived (R4-G09/G10 PARTIAL).
- Boundary expected decisions were hand-specified and confirmed by oracle (0 mismatches); canonical bytes from oracle.
- Final authoritative freeze still requires Experiment Lead approval.