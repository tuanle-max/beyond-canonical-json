# J01 rule-level adjudication (R4a)

Expected derived from K-v2 rules, not oracle outputs.

- TIM: offsets normalized to UTC ms class; sub-ms floored.
- AMT: exact Decimal x10^scale ROUND_HALF_UP.
- UNI: NFC on beneficiary only.
- NUL: null/absent obligation_ref -> ref null.
- CUR: currency+scale registry match.
- Business equivalence = equality of normalized tuple (eid,t,minor,cur,bc,ref); canonical equality is an outcome, not the definition.
- Ambiguous (missing currency) -> ABSTAIN_UNDERSPECIFIED (MISSING_CURRENCY).
