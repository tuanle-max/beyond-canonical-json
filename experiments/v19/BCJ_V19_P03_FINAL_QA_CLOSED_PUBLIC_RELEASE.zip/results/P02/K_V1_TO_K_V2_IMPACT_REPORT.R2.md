# K-V1 → K-V2 IMPACT REPORT (R2)

## Semantic-policy vs corpus vs byte compatibility (separate axes)
- **Semantic-policy compatibility** (intentional changes): D-02 leap second reject, D-03 negative prohibit,
  D-04 quantized equivalence, D-05 NFKC→NFC, D-07 alias conflict reject, D-08 duplicate-key reject,
  D-11 fixed currency scale, D-12 closed schema. These are **not** behavior-preserving merely because the
  frozen J01 corpus does not exercise them.
- **Corpus-level expected compatibility** (J01 330 units): unchanged — J01 uses whole minor units,
  valid timestamps, USD/EUR, no negative amounts, no duplicate keys, no unknown fields.
- **Byte-output compatibility**: unchanged for J01 (same `t`,`minor`,`cur`,`bc`,`ref`).

## 30 float-valued legacy inputs (TASK R2-02)
The frozen J01 corpus contains pair legs stored as JSON numeric values (e.g. EQ-AMO-000 leg B `amount: 250.0`)
that Python's `json` parses as float. The R1 draft wrongly rejected floats while claiming no J01 change.
Resolution:
- The stored corpus is **parsed JSON objects**, not original lexical byte streams. Reconstructed serialized
  bytes are NOT original captured JSON.
- R2 normative rule (D-09): a decimal-number token such as `250.0` is interpreted **exactly** as decimal
  `250.0`; no float64 intermediate. Therefore `250.0` -> 25000 minor at scale 2, matching leg A `"250.00"`.
- 30 such occurrences are reconciled: they are admissible (D_K+) and business-equivalent to their string
  partner. Legacy reconstruction: `json.dumps(obj, sort_keys=True)` per doc; raw-input digest = sha256 of
  that serialization; original lexical bytes: **not available** (documented boundary).
- Not executed against any P03 implementation; this is normative analysis only.