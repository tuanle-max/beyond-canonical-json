# K-V1 → K-V2 IMPACT REPORT (draft)

- **Expected admission change:** none for the 330 frozen J01 units under the recommended (PRESERVE/CLARIFY)
  decisions — timestamp (tz required) and monetary (scale-2 half-up) and null/absent and alias behaviors
  are already implemented in K-v1; the draft makes them explicit without changing outcomes.
- **Potential admission change:** only via D-03 (reject negatives) and D-04 (equivalence after rounding).
  Both would affect *new* boundary cases, not the frozen 330 (all amounts are whole minor units, all
  benign). If D-03 = reject, `"-100.50"` moves from `accepted/computed` to `REJECT_MALFORMED`.
- **Potential equivalence change:** D-04-B (quantized) may map distinct pre-rounding values to one
  payable amount (documented O4 risk). This must be accepted explicitly before it becomes normative.
- **Distinction change:** none expected on the frozen distinct pairs under the recommended decisions.
- **Unsupported legacy assumptions:** (1) unknown fields are silently ignored in K-v1; the draft preserves
  this but flags it for future CLI binding; (2) duplicate keys are silently discarded by `json.loads`;
  the draft requires parser-level duplicate rejection (new parser requirement, no J01 impact).
- **No historical labels were changed; no K-v2 labels are frozen.**