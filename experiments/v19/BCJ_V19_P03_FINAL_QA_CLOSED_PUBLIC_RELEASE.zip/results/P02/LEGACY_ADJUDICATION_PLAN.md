# LEGACY_ADJUDICATION_PLAN (Layer B)

Goal: independent, contract-derived expected labels for the frozen J01 units, so P03 is not validated
against the same authored oracle.

## Procedure
1. For each fault family (Timestamp, Amount, Unicode, Null, Alias) and the Ambiguous cohort, write a
   rule-level adjudication purely from `NORMATIVE_CONTRACT.R2.md` (not from `jcommon.py`).
2. Instantiate expected labels per case from the frozen `j01_cases.json` (inputs only), computing the
   expected typed object and eligible JSON via an independent reference (hand/spec), never via `jcommon`.
3. Lock labels and record them in `ORACLE_RATIONALES.jsonl` (P03 deliverable) before any P03 run.
4. For repeated template cases, the rule-level adjudication + independently checkable instantiation suffices;
   Author Lead reviews representative examples.
5. Retain historical labels separately (no overwrite); report agreement/disagreement between historical and
   independently adjudicated labels as a finding.

## Disclosures
- Adjudicator authored by the same research team (correlated-specification risk).
- No external third-party human adjudication is claimed unless it actually occurs.
- The 30 float-valued legacy legs (EQ-AMO-*) are adjudicated under D-09 (exact decimal token), expected D_K+.

## Deliverables (P03 stage)
- `ORACLE_RATIONALES.jsonl`, `LEGACY_LABEL_ADJUDICATION.csv`, disagreement report.