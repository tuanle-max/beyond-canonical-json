# MANIFEST_BINDING_AUDIT

- `semantic_manifest_v2.CANDIDATE.json` is a **complete** normative payload: no empty `field_rules`, every
  fault family addressed (timestamp, monetary, unicode, null, alias, parser, currency-scale, output model).
- **No self-reference:** the manifest payload deliberately does **NOT** contain its own `pid_sem_v2`.
  If a digest is needed, it is emitted as a **detached** attestation (`pid_sem_v2 = sha256(JCS(manifest))`)
  computed outside the payload.
- Separation of identities:
  - Semantic identity: `pid_sem_v2` (detached, over the complete manifest).
  - Implementation provenance: `pid_prov` (library/runtime versions; NOT bound into leaves historically).
  - Construction identity: `construction_digest` (see COMMITMENT_V3_SPEC.DRAFT.md).
  - Review/approval metadata: `EXECUTION_STATUS.yaml` (workflow), NOT part of the semantic payload.
- Workflow fields (DRAFT/PENDING/approval timestamps) are excluded from the manifest payload so approval
  status cannot alter semantic identity.
- JCS eligibility: the candidate manifest is ASCII-clean JSON with string/number/object/array values only
  (RFC-8785 eligible). Digest NOT yet computed/published (pending EL review of the completed R2 contract).
- Verification: `MANIFEST_BINDING_AUDIT` recompute step (planned) will assert `sha256(JCS(payload))` is
  stable and that no digest field appears inside the payload. Confirmed here by inspection: no `pid_sem*`
  or `*digest` self-field is present in the payload.