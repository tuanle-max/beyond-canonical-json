# NORMATIVE_CONTRACT.DRAFT — K-v2 (P02-R1, NOT frozen)

Status: **DRAFT for Author Lead review.** No decision here is normative until `CONTRACT_APPROVAL_SHEET.md`
records human approval. K-v1 (historical `M_sem` with three rule names) is frozen and unchanged.

## Scope and principle
The contract specifies what each admitted input *means* (types, lexical grammar, normalized typed
representation, eligible JSON, equivalence, rejection/abstention) so a second implementation team can
build `T_S`/`beta_K` without reading `scripts/jcommon.py`. Decisions are grouped
PRESERVE_K_V1 / CLARIFY / INTENTIONAL_CHANGE / UNRESOLVED_DOMAIN_DECISION.

## F1 — Timestamp (`timestamp`)
- Field: `timestamp`. Required. Accepted raw types: integer epoch-ms, or ISO-8601 string.
- Grammar: `YYYY-MM-DD[T ]HH:MM[:SS][.fraction][Z|±hh:mm]`.
- Timezone: REQUIRED (explicit `Z`/offset). Missing timezone -> ABSTAIN (underspecified), never assume UTC/local.
- UTC normalization: instants are compared as epoch-ms; `+07:00` vs `Z` for the same instant are business-equivalent.
- Offset bounds: `-23:59..+23:59`; offset-minute `00|15|30|45` accepted.
- Calendar validity: parse must reject impossible dates (e.g. `2026-02-30`) -> REJECT_MALFORMED (D_K-).
- Fractional seconds: accepted up to 6 digits; excess precision beyond ms is truncated (CLARIFY: truncation does not change the instant at ms resolution, so business meaning is preserved).
- Leap seconds: `:60` -> REJECT_MALFORMED unless a documented policy is approved (UNRESOLVED_DOMAIN_DECISION).
- Output: `YYYY-MM-DDTHH:MM:SS.mmmZ` (epoch-ms re-rendered in UTC).
- Equivalence: equal epoch-ms <=> equal business instant. Distinct epoch-ms => distinct.
- Examples (equiv): `2026-01-01T07:00:00+07:00` ≡ `2026-01-01T00:00:00Z`.
- Examples (distinct): `...T00:00:00Z` vs `...T00:00:01Z`.
- Examples (underspecified): no timezone. Examples (malformed): `2026-02-30`, offset `+99:00`.

## F2 — Monetary (`amount`, `scale`, `currency`/`cur`)
- Field: `amount`; required. Scale: `scale` (integer minor-unit exponent); required. Currency: `currency` (canonical) / `cur` (alias); required.
- Accepted raw `amount` types: string or integer; **floats rejected** (REJECT_MALFORMED) to keep the pre-image exact.
- Lexical grammar: `^\d{1,3}(\.\d{3})*$` (grouped) or `^\d+(\.\d{1,6})?$`; comma variants accepted under declared locale grammar.
- Conversion: minor units = `Decimal(amount) * 10^scale`, ROUND_HALF_UP to integer minor units.
- Scale bounds: `0..6`. Overflow beyond safe range -> REJECT_MALFORMED.
- Scientific notation: rejected. `NaN`/`Infinity`/`-Infinity`: rejected (REJECT_MALFORMED).
- Signs: **negative amounts policy is an UNRESOLVED_DOMAIN_DECISION** (historical K-v1 `parse_minor` computes negative minor units; the manuscript notes negative amounts "may be prohibited").
- **CRITICAL equivalence decision (needs Author Lead):** business equivalence is defined by either
  *A* exact pre-rounding decimal value, or *B* quantized payable amount after rounding.
  Under *B*, `"2.675"`, `"2.674999"` (if admitted) and `"2.6750"` map to the same 268; under *A* they
  may be distinct classes and rounding could collapse them (O4 risk). **Recommendation: B**, consistent
  with the historical two-decimal half-up rule, but NOT auto-approved.
- Eligible JSON output: integer minor units (`268`).
- Examples: `"2.675"` -> 268; `"2.685"` -> 269; `"0.005"` -> 1 (scale 2) / 5 (scale 3); `"NaN"` -> reject.

## F3 — Unicode / identifiers
- NFC applies to human-readable text fields: `beneficiary_code`, `beneficiary` (alias). **Not** to
  opaque identifiers, cryptographic values, or case-sensitive business keys (PRESERVE exact identity).
- `event_id`, `obligation_ref` (when an opaque key), `payer_id`, `ingestion_auth_tag` -> exact identity
  (no NFC, no case folding).
- Invalid Unicode / unpaired surrogates -> REJECT_MALFORMED (D_K-); control characters -> REJECT.
- Whitespace: leading/trailing trimmed on text fields; internal whitespace preserved.
- Unicode dependency: pin `unicodedata` version + Python build in `pid_prov`.
- Example (NFC correct): `"José"` ≡ `"Jose\u0301"`. Example (preserve): two distinct opaque ids that
  differ only by normalization must remain distinct.

## F4 — Null / absence / defaults
- For each field: `event_id/amount/timestamp/currency(scale)` required (null or absent -> underspecified/malformed as per field).
- `obligation_ref`: **null and absence are equivalent** (historical K-v1 behavior, PRESERVE); an explicit
  default is NOT inserted for a missing `obligation_ref`.
- No global "null->missing" rewriting: null is only equivalent to absence for fields the contract says so.
- `beneficiary_code` present-but-null -> underspecified (canonical is null vs the aliased `beneficiary`).
- Distinct business states must not be collapsed by a default (e.g., a missing `obligation_ref` must not
  be defaulted to a specific reference).

## F5 — Schema aliases, parser validity
- Aliases: `currency` <-> `cur` (equivalent when both equal); `beneficiary_code` <-> `beneficiary`.
- Canonical field name: `currency`, `beneficiary_code` (PRESERVE K-v1 behavior).
- Conflicting aliases (both present with different values) -> REJECT (D_K-), not last-write-wins.
- Unknown fields -> CLARIFY: historical K-v1 ignores unknown fields; preserve-but-document.
- Duplicate JSON keys -> REJECT (must be detected before object parsing discards the earlier value).
- Malformed JSON / invalid UTF-8 / unsupported numeric repr -> REJECT_MALFORMED.

## Output model (eligible JSON)
`T_S` output object with fixed keys: `{"eid","t","minor","cur","bc","ref"}` (field order canonicalized by
RFC-8785 JCS). `F_Π = JCS(E(T_S(d)))`; `None` (fail-closed) for D_K- or D_K?.

## Rejection vs abstention
- D_K+ -> output required. D_K- -> REJECT (malformed/prohibited). D_K? -> ABSTAIN (underspecified).
- No silent mapping of D_K- or D_K? to a canonical form.