# NORMATIVE_CONTRACT.R2 — K-v2 (P02-R2 corrected draft; NOT frozen)

Corrects P02-R1. Author Lead policies D-02..D-12 are APPROVED (see EXECUTION_STATUS.yaml). This file is
still DRAFT; `pid_sem_v2` is not published. K-v1 remains frozen/unchanged.

## F2 (corrected) — Monetary semantics
**Authoritative** minor units = `int(ROUND_HALF_UP(Decimal(amount) * 10**scale))`, computed with exact
decimal arithmetic (no binary float64 intermediate). P02-R1 erroneously claimed 2.674999→268; it is **267**.

Normative known-answer vectors (scale 2):
| raw | minor |
|---|---|
| 2.674999 | 267 |
| 2.675 | 268 |
| 2.6750 | 268 |
| 2.680 | 268 |
| 2.685 | 269 |
| 0.005 | 1 |
| 0.004999 | 0 |
| 0.00 | 0 |

Lexical policy (D-09): accept decimal strings and raw JSON decimal-number tokens; **do not** route
tokens through float64. Decimal separator = `.`; grouping separator `,`/`.` only under an explicit
declared grouping form (no locale inference); max fractional precision = 6; leading zeros allowed;
`+` sign rejected; `-` sign -> REJECT_PROHIBITED (D-03); negative zero `-0`, `-0.00` -> REJECT_PROHIBITED;
scientific notation rejected; whitespace not permitted inside the token. Token `250.0` is interpreted as
exactly decimal 250.0 (not float). If the intended interpretation cannot be established deterministically,
fail closed (REJECT_MALFORMED).
**Equivalence (D-04) = QUANTIZED PAYABLE AMOUNT + currency** after authorized half-up; distinction
preservation is defined over business-equivalence classes after quantization, not over pre-rounding values.

## F1 (corrected) — Timestamp semantics
- `eligible_json.t = integer epoch milliseconds` (business resolution = 1 ms, D-10). ISO rendering is diagnostic only.
- Textual timestamps REQUIRE an explicit timezone (`Z` or `±hh:mm`); missing tz -> ABSTAIN (D-01).
- Grammar: `YYYY-MM-DD[T ]HH:MM[:SS][.f{1..6}](Z|±hh:mm)`; seconds optional; `T` or space separator.
- Offset bounds `-23:59..+23:59`; offset minutes in {00,15,30,45}. Calendar-invalid dates -> REJECT_MALFORMED.
- Fractional seconds: up to 6 digits; sub-millisecond is clamped to the ms class (floor toward the epoch start
  of the ms). Contract preserves equivalence at ms resolution, NOT the exact instant.
- Leap second `:60` -> REJECT_MALFORMED (D-02). Pre-epoch integers allowed if within int64; else REJECT.
- Integer epoch-ms input accepted directly (no tz requirement for the integer form).
- Equal instants across offsets are equivalent; distinct ms classes are distinct.

## F3 (corrected) — Unicode / identifiers (D-05 intentional NFKC→NFC change)
- NFC applies ONLY to `beneficiary_code` (and its alias `beneficiary`).
- Opaque ids preserved exactly: `event_id`, `obligation_ref` (opaque key), `payer_id`, `ingestion_auth_tag`.
- Unpaired surrogate / invalid encoding -> REJECT_MALFORMED. Control characters -> REJECT.
- Examples: NFC `José`==`Jose\u0301`; fullwidth `Ａ` != ASCII `A` (NFC does not fold compatibility);
  circled `①` != `1`; ligature `ﬁ` != `fi`; opaque ids distinct.
- Pin Unicode semantic version; record `unicodedata`/runtime provenance separately in `pid_prov`.

## F4 — Null / absence (D-06 field-specific)
- `obligation_ref`: null == absent (same business state). Not applied globally.
- Required fields (`event_id`,`timestamp`,`amount`,`currency`,`scale`): null or absent -> ABSTAIN (missing)
  or REJECT per field table. No default insertion.

## F5 — Aliases / parser (D-07, D-08, D-12)
- Aliases: `currency`<->`cur`, `beneficiary_code`<->`beneficiary`. Conflicting alias values -> REJECT_PROHIBITED.
- Duplicate JSON keys -> REJECT_MALFORMED (detected before object parsing).
- Closed schema (D-12): unknown business fields -> REJECT_PROHIBITED; only an enumerated metadata allowlist
  may be ignored and is declared outside the business-equivalence relation.
- Malformed JSON / invalid UTF-8 / unsupported numeric syntax -> REJECT_MALFORMED.

## Admission precedence
When a record violates several rules, the outcome follows the precedence in ERROR_TAXONOMY.yaml:
REJECT_MALFORMED > REJECT_PROHIBITED > ABSTAIN_UNDERSPECIFIED > INTERNAL_ERROR > TIMEOUT. Deterministic, not field-order dependent.

## Currency-scale (D-11)
Fixed scale per currency via SUPPORTED_CURRENCY_SCALE_REGISTRY.json (USD:2, EUR:2, VND:0). Input `scale`
must equal the registry value, else SCALE_MISMATCH; unknown currency -> UNSUPPORTED_CURRENCY.