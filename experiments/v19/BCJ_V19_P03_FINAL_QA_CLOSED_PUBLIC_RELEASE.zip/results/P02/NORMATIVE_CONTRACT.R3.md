# NORMATIVE_CONTRACT.R3 — K-v2 (P02-R3 consolidated candidate; NOT frozen)

Supersedes P02-R2 draft. Author-Lead policies D-02..D-12 applied. `pid_sem_v2` is CANDIDATE only, not published.

## Normative artifacts (binding targets; hashed in NORMATIVE_ARTIFACT_BINDINGS.json)
- This contract: `NORMATIVE_CONTRACT.R3.md` (UTF-8, LF). Precedence: on any contradiction, **this file wins**; duplicates are removed, not tolerated.
- `FIELD_SEMANTICS.csv` (authoritative field model).
- `ERROR_TAXONOMY.yaml` (reason codes + precedence).
- `SUPPORTED_CURRENCY_SCALE_REGISTRY.json` (currency→scale).

## Input model (closed schema, D-12)
Required: `event_id`, `timestamp`, `amount`, `currency`, `scale`, `beneficiary_code`.
Optional: `obligation_ref`.
Aliases: `currency`<->`cur`; `beneficiary_code`<->`beneficiary`.
Unsupported (NOT part of this profile): `payer_id`, `ingestion_auth_tag`. They are unknown fields -> REJECT_PROHIBITED (or an explicitly allowlisted non-semantic metadata map outside business equivalence). They are removed from the "supported opaque identifiers" concept.

## Identifiers
- `event_id`: grammar `^[A-Za-z0-9_-]{1,256}$`; exact identity; no normalization.
- `obligation_ref`: opaque, `^[\x20-\x7E]{1,256}$` (printable ASCII); exact identity; NFC NOT applied.

## Timestamp (D-01, D-02, D-10)
- Business value `t` = integer epoch **milliseconds**, `MIN_SAFE_INTEGER <= t <= MAX_SAFE_INTEGER`.
- Textual grammar: `YYYY-MM-DD[T ]HH:MM[:SS][.f{1,6}](Z|±hh:mm)`; timezone REQUIRED for textual; `T` or single space between date/time.
- Offset `-23:59..+23:59`, offset minutes in {00,15,30,45}.
- Sub-millisecond: floor toward the start of the ms class. Equivalence is at ms resolution (NOT the exact instant).
- Leap second `:60` -> REJECT_MALFORMED. Calendar-invalid -> REJECT_MALFORMED. Pre-epoch integers allowed within safe range.
- Integer epoch-ms token accepted directly (no tz needed).

## Monetary (D-03, D-04, D-09, D-11)
- `amount` accepts: decimal string | raw JSON decimal-number token | JSON integer token.
- **No binary float64 intermediate.** Tokens are parsed to exact Decimal from their lexeme.
- Grammar (no locale inference): `DECIMAL := INTEGER [ "." FRACTION ]`; `INTEGER := "0" | [1-9][0-9]*`; `FRACTION := [0-9]{1,6}`. Decimal separator = `.`. **Grouping prohibited** (no `,` or `.` thousands separators) — the frozen J01 corpus uses no grouping.
- Max integer digits 16; max fraction digits 6; max token length 24. Leading zeros allowed only for `0.xxx`. Optional `+` NOT allowed; `-` -> REJECT_PROHIBITED (D-03). Negative zero (`-0`, `-0.00`) -> REJECT_PROHIBITED. Scientific notation -> REJECT_MALFORMED. Booleans -> REJECT_MALFORMED. Whitespace inside token -> REJECT_MALFORMED.
- Minor units = exact `Decimal(amount) * 10**scale`, **ROUND_HALF_UP** to integer, using a context with sufficient precision (set `decimal.getcontext().prec` high; do not rely on default 28). `0 <= minor <= MAX_SAFE_INTEGER` else REJECT_PROHIBITED (MONETARY_OVERFLOW).
- Equivalence (D-04) = **quantized payable amount + currency** (post-rounding class).
- Currency: `^[A-Z]{3}$` (uppercase ISO-4217); `scale` must equal registry (USD=2, EUR=2, VND=0) else SCALE_MISMATCH.

## Unicode (D-05)
- NFC applies ONLY to `beneficiary_code` (and alias `beneficiary`). Opaque ids (`event_id`, `obligation_ref`) preserved exactly.
- Normative Unicode version: **NFC as defined by UAX #15, Unicode 15.0.0** (pinned). Implementation `unicodedata` version recorded separately in provenance (never part of semantic identity).
- Unpaired surrogate / invalid UTF-8 -> REJECT_MALFORMED. Control characters (C0/C1) -> REJECT_MALFORMED.
- This is an **intentional NFKC->NFC change** vs K-v1.

## Null / absence (D-06)
- `obligation_ref`: null and absent are the SAME business state; eligible JSON emits `"ref": null`. No implementation may omit `ref` while another emits null.
- Required fields: null -> ABSTAIN_UNDERSPECIFIED (treated as missing).

## Aliases / conflicts (D-07, D-08)
- Both canonical+alias present with equal normalized value -> accepted (canonical value used).
- Both present with different (post-normalization) values -> REJECT_PROHIBITED (ALIAS_CONFLICT).
- Alias-only input accepted; canonical-only accepted; null alias treated as absent.
- Duplicate JSON keys -> REJECT_MALFORMED (detected before object parsing).

## Output model
`{ "eid": <event_id>, "t": <int ms>, "minor": <int>, "cur": <currency>, "bc": <NFC beneficiary>, "ref": <string|null> }`
All integers within safe-integer range, validated AFTER normalization and BEFORE JCS serialization. JCS (RFC 8785) produces eligible canonical bytes.

## Admission vs execution
- Input-domain outcomes: `REJECT_MALFORMED`, `REJECT_PROHIBITED`, `ABSTAIN_UNDERSPECIFIED`.
- Execution outcomes: `INTERNAL_ERROR`, `TIMEOUT` — NOT counted as successful fail-closed admission.
- Precedence (deterministic, independent of field order): MALFORMED > PROHIBITED > ABSTAIN > INTERNAL > TIMEOUT.

## Safe integers (R3-02)
`MAX_SAFE_INTEGER = 9007199254740991`; `MIN_SAFE_INTEGER = -9007199254740991`. Monetary `0<=minor<=MAX`; timestamp `MIN<=t<=MAX`. Out-of-range exact integers -> REJECT_PROHIBITED (MONETARY_OVERFLOW / TIMESTAMP_OUT_OF_RANGE), never rounded/saturated/wrapped/float-converted. This is a scoped interoperability policy; RFC 8785 is not claimed to universally forbid larger integers.