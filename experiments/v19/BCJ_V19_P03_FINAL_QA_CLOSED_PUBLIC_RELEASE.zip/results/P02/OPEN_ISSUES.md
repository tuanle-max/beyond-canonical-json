# OPEN_ISSUES (P02-R3)

| id | issue | disposition |
|---|---|---|
| OI-01 | manuscript SSOT | CLOSED (v18.tex frozen @40376da, blob==68d8c560) |
| OI-02 | per-leg admission logs | MITIGATED (P01 replay) |
| OI-06 | K-v2 contract freeze | DRAFT complete; **awaiting Experiment Lead review**; pid_sem_v2 CANDIDATE only |
| OI-09 | boundary KAT size | 25 units (< 40 target; 40 not mandatory; genuine coverage prioritized) |
| OI-10 | oracle externality | AI-adjudicated under same research team (correlated-spec risk); no external human adjudication claimed |
| OI-11 | commitment-v3 validation | spec + KAT only; not validated against an implementation |
| governance | P01 pre-gate execution | RECORDED (PROCESS_DEVIATION_REPORT.md); retrospective Level S accepted |

P03/P04 remain UNAUTHORIZED. Do not start implementation; do not use implementation output as oracle.