# ORACLE_INDEPENDENCE_PLAN (P02-R2) — for P03

P01 is self-referential (labels + outputs from `jcommon`). P03 expected evidence MUST be derived from the
normative contract, not from Implementation A or B outputs.

## Layer A — normative known-answer vectors
For the R2 boundary suite, expected values (admission, partition, reason code, typed object, eligible JSON,
pairwise equivalence/distinction) are derived **by hand from NORMATIVE_CONTRACT.R2.md**, not by running any
implementation. `P02_BOUNDARY_ORACLE_RATIONALES.R2.jsonl` records the normative rationale per case.

## Layer B — legacy J01 adjudication
Rule-level normative adjudication of the 5 fault families + 30 ambiguous; case instantiation is checkable
against the frozen fixtures. The adjudicator MUST NOT import `jcommon.py` or either P03 implementation.
Historical labels are retained **separately** and never overwritten.

## Independence requirements
- Expected labels derived from the contract, locked before P03 execution.
- Correlated-specification risk disclosed: adjudicator authored by the same research team.
- Do not claim external human adjudication unless it occurs.
- P03 implementations must not feed the oracle (no runtime-oracle consumption).

## Evidence wiring
- `P02_BOUNDARY_VECTORS.R2.jsonl` = Layer A expected admission/partition/decision.
- `P02_BOUNDARY_ORACLE_RATIONALES.R2.jsonl` = Layer A rationale.
- `LEGACY_ADJUDICATION_PLAN.md` = Layer B procedure.
- P03 compares implementation traces against these LOCKED expectations, stage by stage (L0–L7).