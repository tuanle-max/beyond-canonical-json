# P01_CLOSURE_REPORT (Task R2-12)

P01 is NOT re-executed. Original raw/derived results preserved.

## Checksum correction
- Prior P01 `SHA256SUMS` had a stale/missing `status.json` entry (12/13 reviewed). This closure produces a
  **revision-specific** checksum manifest `P01_REVISION_SHA256SUMS` over the current reconciliation artifacts,
  excluding the manifest itself (no self-reference) and excluding SHA256SUMS (no self-reference). Every entry
  is verified by recomputation.
- The original historical P01 per-leg JSONL and summary JSON are unchanged.

## Raw-input digest semantics (explicit boundary)
`raw_sha256` in `P01/raw/J01_PER_LEG_RESULTS.jsonl` = sha256 of `json.dumps(doc, sort_keys=True)` — i.e. a
**reconstructed serialization** of the parsed input object, NOT original captured JSON byte streams. Disclosed.

## Added mutation test (incorrect_pair_relationship)
The prior report listed "pair_success_despite_rejection" but not a distinct "incorrect pair relationship" test.
Added and executed in `p01_closure_mutation.py`; result: see `P01_CLOSURE_MUTATION_RESULT.json`.

## Packaging
Small closure package `BCJ_V19_P01_CLOSURE_REVIEW.zip` (does not duplicate large historical archives; large
inputs are referenced by exact path + full sha256 in `P01_CLOSURE_REPORT.md` references and SSOT_LOCK.yaml).