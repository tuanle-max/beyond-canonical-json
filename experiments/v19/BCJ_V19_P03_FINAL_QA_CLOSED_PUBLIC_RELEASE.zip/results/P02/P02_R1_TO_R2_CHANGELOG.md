# P02_R1_TO_R2_CHANGELOG

- R2-01: corrected monetary example — 2.674999 -> **267** (not 268); added normative KAT table; specified
  exact-decimal lexical grammar (no float64), grouping/locale, max precision, signs, negative-zero, sci-notation.
- R2-02: reconciled 30 float-valued legacy legs (e.g. EQ-AMO-000 b `250.0`) under D-09; documented legacy
  reconstruction boundary (parsed objects, not original bytes).
- R2-03: timestamp output type fixed to `eligible_json.t = integer epoch ms`; sub-ms clamped to ms class;
  leap-second reject; int64 range; explicit tz for textual only.
- R2-04: currency-scale registry (USD:2, EUR:2, VND:0); scale mismatch -> SCALE_MISMATCH; prevents 100-vs-100 collision.
- R2-05: Unicode reclassified as INTENTIONAL NFKC->NFC (field-scoped), not clarification; opaque preserved.
- R2-06: FIELD_SEMANTICS.csv; admission precedence (MALFORMED>PROHIBITED>ABSTAIN>INTERNAL>TIMEOUT); error taxonomy.
- R2-07: boundary suite rebuilt from COMPLETE valid base records + parser cases as raw bytes (base64/hex).
- R2-08: ORACLE_INDEPENDENCE_PLAN + LEGACY_ADJUDICATION_PLAN (Layer A/B).
- R2-09: complete semantic manifest candidate; no self-digest; workflow fields excluded.
- R2-10: COMMITMENT_V3_SPEC.DRAFT + construction_manifest_v3.DRAFT (P03 dependency resolved at design level).
- R2-11: decision register regenerated via csv.writer — uniform 16 columns, D-01..D-12, proper quoting (G18).
- R2-12: P01 closure — revision checksum manifest, raw-digest semantics disclosed, added incorrect-pair-relationship test.
- R2-13: governance updated (P01 retrospective APPROVED_LEVEL_S; OI-01 CLOSED; P03/P04 unauthorized).