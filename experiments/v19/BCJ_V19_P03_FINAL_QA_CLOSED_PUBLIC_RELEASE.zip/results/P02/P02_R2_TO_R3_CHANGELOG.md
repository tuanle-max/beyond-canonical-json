# P02_R2_TO_R3_CHANGELOG
- R3-01: replaced placeholder refs with real SHA-256 bindings (UTF-8/LF) for contract, field semantics, error taxonomy, currency registry; manifest has no self-digest; V01–V08 executed (all PASS).
- R3-02: safe-integer policy (MAX/MIN_SAFE_INTEGER); monetary 0..MAX; timestamp MIN..MAX; out-of-range -> REJECT_PROHIBITED; KAT K22.
- R3-03: monetary grammar closed (no grouping, no float64, no exponent, max 16 int/6 frac/24 len); KAT K08–K17.
- R3-04: single field model — beneficiary_code now REQUIRED; payer_id/ingestion_auth_tag UNSUPPORTED; obligation_ref emits `"ref": null`; event_id/obligation_ref grammars; admission vs execution separated.
- R3-05/R3-06: boundary KAT (25 units, complete expected outputs) + 12 pairs; independent J01 adjudication (330 units, 150/150/150/30) via r3_oracle.py (no jcommon).
- R3-07: COMMITMENT_V3_SPEC.R3 (RFC-9162 recursive tree, custom leaf/empty-root); COMMITMENT_V3_KAT (two root paths agree); explicit promotion (not duplication).
- R3-08: compatibility separated into 5 axes; commitment-v3 roots differ from v2 by construction.
- R3-09: P03 execution plan + metric dictionary + P04 isolation.
- Gate matrix P02_GATE_MATRIX.R3.csv; candidate identifiers remain CANDIDATE (not published).