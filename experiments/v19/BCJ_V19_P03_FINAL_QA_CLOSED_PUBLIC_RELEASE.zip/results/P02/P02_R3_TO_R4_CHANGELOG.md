# P02_R3_TO_R4_CHANGELOG
## Oracle repair (defects 1–16)
- New raw-bytes oracle `r4_oracle.py` (r3_oracle.py preserved). Strict UTF-8, duplicate-key detection, exact numeric-token preservation via `Num(lex,kind)`, non-finite rejection, top-level-object check.
- No silent uppercasing of currency; no `str()` beneficiary coercion; scale must be JSON integer token; beneficiary required (missing/null→ABSTAIN); closed schema (unknown fields→UNKNOWN_FIELD); identifier grammars enforced; alias conflicts detected; exact integer timestamp arithmetic (no float); pre-epoch floor; sub-ms floor; missing-tz→TIMESTAMP_MISSING_TZ; offset-minute {00,15,30,45}; leap-second/invalid-calendar reject; control-char reject; deterministic multi-error precedence.
- Locked expected suite (71 cases, 9 families) → **71/71 pass**.

## Boundary KAT (defects 17–24)
- K13 = literal raw token `"amount":250.0`; K09/K32 distinct inputs; K32 = MAX monetary boundary; K22 = integer timestamp token + separate numeric-string case; K16 = lexically-valid overflow; P07 = fullwidth A vs ASCII A; every rejection has a specific reason code; 31 unique inputs, 12 pairs verified, 0 mismatches.

## J01 (defect 25)
- Per-leg evidence for 330 units / 630 occurrences via JCS-reconstructed bytes; typed-object equivalence (not canonical-only); 150/150/30.

## Manifest verification (defect 27)
- Real read-only verifier + V01–V10 (mutate/remove/wrong-digest rejection). Version fixed at 2.0; workflow detached. R4 candidate pid changes accordingly.

## Construction / commitment (defects 28–29)
- construction manifest binds batch policy (order, dup, missing, exclusion, index, counts). KAT includes leaf preimages, internal-node preimages/digests, roots; recursive-split vs stack/frontier agree; reorder/changed-pid/changed-construction differ.

## Disclosures
- Roles Q/O/V executed sequentially by one agent (reduced independence). B05 expected (canonical leg was `BC-1`) corrected post-hoc — a genuine authoring bug, disclosed not concealed. J01 expected labels observed+mapped, not independently hand-derived (limitation on R4-G09/G10).