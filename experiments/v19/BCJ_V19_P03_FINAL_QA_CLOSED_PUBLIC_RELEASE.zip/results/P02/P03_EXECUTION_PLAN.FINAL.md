# P03_EXECUTION_PLAN.FINAL

- Contract: NORMATIVE_CONTRACT.R4.md (final candidate). Identifiers: see FINAL_CANDIDATE_IDENTIFIER_REPORT.json.
- Impls: Python (A) and Go (B), raw-bytes->root, no shared semantic code.
- Corpora: E1 J01 (frozen, 630 occ), E2 boundary KAT (final), E3 R4(71)+R4a(21) as regression, E4 batches {1,2,3,4,5,7,8,16,31,32}.
- Stages L0..L7 with attribution categories per directive.
- GATED: Stage 1 requires Experiment Lead approval.
