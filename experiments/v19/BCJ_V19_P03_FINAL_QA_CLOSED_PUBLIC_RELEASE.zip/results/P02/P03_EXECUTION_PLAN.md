# P03_EXECUTION_PLAN (design lock; do NOT start implementation)

## Implementations
- **A = Python**, **B = Go**. Both implement the same frozen K-v2 contract.
- Must NOT share: semantic decision functions, generated transform code, oracle, commitment-tree code, or one implementation's outputs.
- May share: normative specs, input schema, approved public conformance vectors, generic crypto/stdlib algorithms.

## Stages compared (per case)
L0 admission · L1 typed object · L2 eligible JSON · L3 JCS bytes · L4 profile/construction metadata · L5 leaf · L6 ordered batch · L7 root. Record earliest divergent stage + attribution label.

## Correctness vs agreement
- Cross-implementation agreement is reported SEPARATELY from correctness against the normative oracle (`J01_K_V2_ADJUDICATION.jsonl`, `P02_BOUNDARY_KAT.R3.jsonl`).
- Agreement alone does not establish correctness.

## Batches
Sizes {1,2,3,4,5,7,8,16,31,32}; single/odd/even trees; duplicates; reorder; distinct construction versions. Frozen tree shape = COMMITMENT_V3_SPEC.R3.

## Gates before P03 runs
Contract frozen by EL; construction frozen; oracle labels locked; P04 isolation enforced. None of these are yet satisfied.