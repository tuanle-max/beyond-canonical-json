# P03_ISOLATION_RECORD (Stage 0 planning)

- Agent A (Python) and Agent B (Go) receive only P03_IMPLEMENTATION_ALLOWLIST.json items.
- Neither receives oracle source, independent J01 expected, the other's source, or P04.
- Agent V receives both frozen sources + locked expected, after initial source commits are frozen.
- STAGE 0: no implementations created; isolation not yet technically enforced (disclosed).
