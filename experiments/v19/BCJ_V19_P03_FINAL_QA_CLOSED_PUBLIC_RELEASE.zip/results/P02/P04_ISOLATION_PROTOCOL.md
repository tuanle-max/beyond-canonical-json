# P04_ISOLATION_PROTOCOL (design only; P04 NOT executed)

- Held-out labels and expected outputs are NOT exposed to implementation agents (A or B).
- P04 cases are NOT used to tune the K-v2 contract or either implementation.
- Implementation agents receive only: the frozen contract, public conformance vectors, and the boundary KAT.
- Held-out corpus, expectations, and the P04 runner live in a separate access scope; no implementation
  code imports or reads them.
- Any contract/implementation change requires a new run id; if a P04 case influenced a fix, that case
  becomes regression testing, not held-out.
- P04 execution is UNAUTHORIZED until Experiment Lead approval after P03.