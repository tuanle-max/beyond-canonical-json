# R4A_ORACLE_REPAIR_REPORT

## Static findings → fixes (r4a_oracle.py; r4_oracle.py preserved)
| # | finding | fix | status |
|---|---|---|---|
|1|unpaired surrogates accepted|explicit 0xD800–0xDFFF reject|FIXED (S01,S02,S04,S05; old crashes on S01/S02)|
|2|regex `$` accepts trailing newline|`fullmatch` on all lexical rules|FIXED (L01–L05)|
|3|monetary grammar tied to scale|grammar validated independently of scale|FIXED (M01, grammar run)|
|4|huge/negative scale reaches Decimal|scale validated vs registry before exp|FIXED (M04,M05)|
|5|calendar-boundary astimezone raises|exact arithmetic + Overflow/Value catch → TIMESTAMP_MALFORMED|FIXED (T01/T02 accept, boundary catch)|
|6|string sentinel collides with input|unique `object()` sentinel + `is` checks|FIXED (S04)|
|7 (WP2)|J01 expected derived from oracle|independent oracle-free adjudicator|FIXED (J01 630/630 agree)|
|8|J01 lacks canonical bytes/rationale|full per-leg evidence + rule rationale|FIXED|
|9|lock absent from archive|lock included in Commit B package|FIXED|
|10|verifier semantic-only|complete verify_review_package.py|FIXED|
|11|INTERNAL_ERROR as rejection|structured execution_status; rejected ≠ execution|FIXED|
|12|resource bounds|scale/amount bounded before arithmetic|FIXED|

## Confirmation (executable)
- Old r4_oracle reproduces **12/21** corrective defects (`R4A_COUNTEREXAMPLE_REPRO.json`), incl. unhandled `CanonicalizationError` on escaped surrogates.
- Repaired oracle: **R4a corrective 21/21**, **R4 regression replay 71/71**, **0 exceptions**.
- J01 independent vs observed: **630/630** admission/reason/business/eligible/canonical; pair 150/150, 150/150, 30/30; compatibility unchanged.

## Disclosures
Roles Q/O/V sequential, same agent (reduced independence). Expected suite locked at commit **6457fc12** before oracle repair (solution committed after). R4 chronology limitation preserved (R4 expected/repair shared a commit); R4a is prospective only.