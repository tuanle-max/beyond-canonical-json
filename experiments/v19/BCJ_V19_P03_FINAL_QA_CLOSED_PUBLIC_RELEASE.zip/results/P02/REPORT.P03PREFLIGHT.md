# P03 Stage-0 Preflight — REPORT (K-v2 NOT authoritative)

## Executed (Stage 0 only)
- **Env pinned (actual runtime):** Python 3.12.9, unicodedata **15.0.0** (matches normative; prior "14.0.0" note was wrong), rfc8785 0.1.3, decimal=C, Go **go1.27.3**. (`PYTHON_REQUIREMENTS_LOCK.txt`, `GO_DEPENDENCY_LOCK.md`, `UNICODE_RUNTIME_VERIFICATION.json`, `UNICODE_CONFORMANCE_RESULTS.json` — partial NFC, disclosed.)
- **Taxonomy synced (P03-00B):** `ERROR_TAXONOMY.yaml` rewritten to canonical codes (JSON_MALFORMED, ALIAS_CONFLICT, MISSING_BENEFICIARY, MONETARY_OVERFLOW, TIMESTAMP_OUT_OF_RANGE, SCALE_MALFORMED, EVENT_ID_MALFORMED, FIELD_TYPE_MALFORMED); execution failures separated. Normative payload changed → semantic manifest rebuilt → **candidate pid = `caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429`**; cd unchanged `d1e46eb5…`; commitment KAT regenerated (recursive vs stack still agree).
- **Verifier strengthened (P03-00C):** requires lock + non-empty artifact map, recomputes pid/cd, J01 corpus + reconstructed-input + canonical digests, exact counts (630 legs / 600 / 30 / 300 pairs), **replays R4 71 + R4a 21**, recomputes commitment roots from preimages, no `.get("agree",True)`. Fresh-extraction **exit 0**.
- **Mutations (P03-00D):** 7/7 DETECTED incl. missing lock, empty map, wrong pid, commitment preimage, raw lexeme, wrong canonical, **checksum-regenerated**.
- **Allowlists + plans:** `P03_IMPLEMENTATION_ALLOWLIST.json`, `P03_EVALUATOR_ALLOWLIST.json`, `P03_ISOLATION_RECORD.md`, `P03_EXECUTION_PLAN.FINAL.md`, `P03_METRIC_DICTIONARY.FINAL.yaml`.

## Gates
`P03_PREFLIGHT_GATE_MATRIX.csv` — PF-G01…G12 addressed (PF-G01 PASS_WITH_LIMITATION: Go module pins declared, not `go mod download`-verified).

## Historical preservation
R3/R4/R4a identifiers preserved (`fe5bb956`, `71287e74`, cd `d1e46eb5`); R4 same-commit limitation retained; archives unmodified. `tex/v18.tex` @40376da untouched.

## Standing
**Stage 1 NOT started; P03 implementations not created; P04 not executed.** K-v2 NOT declared authoritative. Await Experiment Lead approval.