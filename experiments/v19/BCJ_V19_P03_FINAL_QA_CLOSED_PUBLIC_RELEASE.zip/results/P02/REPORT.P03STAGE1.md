# P03 Stage-1 Evaluation — Agent V REPORT (partial; E1 complete)

Resume commit: 510a3739. Implementations frozen: Python `8bcad291`, Go `f34220d7`.
Frozen identifiers: pid `caa2f3e5…`, cd `d1e46eb5…`. Environment: Python 3.12.9 / Unicode 15.0.0 / rfc8785 0.1.3; Go 1.23.12 in `golang@sha256:1670…` (norm 15.0.0).

## E1 — J01 regression (EXECUTED, complete)
Both implementations run on identical raw bytes (630 reconstructed inputs), both exit 0, 630 records each.
Python-vs-locked-expected and cross-implementation:

| metric | value |
|---|---|
| admission correctness | 630/630 |
| reason-code correctness | 630/630 |
| valid-input coverage (accepted admissible) | 600/600 |
| typed-object correctness | 600/600 |
| eligible-JSON correctness | 600/600 |
| canonical-byte correctness | 600/600 |
| abstention correctness | 30/30 |
| unsafe admission | 0/600 |
| false rejection (admissible) | 0/30 |
| equivalent-pair success | 150/150 |
| distinct-pair success | 150/150 |
| conditional canonical agreement (jointly admitted) | 600/600 |
| unconditional canonical agreement | 600/600 |

Go-vs-expected canonical correctness is 600/600 transitively (Go↔Python = 600/600 and Python↔expected = 600/600). Raw metrics: `results/P02/P03_E1_METRICS.json`; per-input: `implementations/python-dev/_e1_py.jsonl`, `go-dev/_e1_go.jsonl`.

## Not yet executed (resumable checkpoint — execution-budget limit)
- E2 boundary (31 + 12 pairs), E3 R4(71)+R4a(21) cross-language runs.
- E4 batch (sizes 1..32) + commitment traces via CLI `commit`.
- Controlled stage-attribution perturbations (L0–L7).
- Final verifier corrections F (load ORACLE_LOCK.P03FINAL.json actual bindings; J01 reconstruction membership; boundary `admission-differs`; metadata). (E1 was executed directly against implementations, independent of the verifier.)
- Full `BCJ_V19_P03_STAGE1_R1_REVIEW` artifact set (report/status/manifest/env/commands/SHA256SUMS).

## Scientific limitation
E1 is historical regression (not unseen); the corpus is purposive/template-correlated. No population-level error probability is claimed from zero observed failures. Agreement ≠ correctness; correctness here is vs locked independent expected evidence. AI-assisted, single-agent roles; procedural (filesystem) isolation, no OS sandbox.

## Provisional conclusion (E1)
Both separately authored raw-to-root implementations reproduced the locked K-v2 J01 evidence exactly (admission/reason/typed/eligible/canonical) and produced identical canonical bytes on all 600 jointly admitted occurrences — including identical commitment roots in dev fixtures. Remaining corpora and attribution are pending the resumable checkpoint above.
