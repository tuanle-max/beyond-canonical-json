# P02-R4 — Oracle Correctness Repair (REPORT, DRAFT)

**Contract NOT frozen; candidate identifiers NOT authoritative; P03/P04 not started.**

## Executed evidence
- R4-03 oracle repair (`r4_oracle.py`, raw-bytes strict): locked adversarial suite **71/71** across schema/alias/monetary/safeint/timestamp/unicode/null/parser/multi families (`R4_ADVERSARIAL_RESULTS.jsonl`).
- R4-04 boundary KAT R4: 31 cases, 31 unique inputs, 0 mismatches, 12 pairs verified (`P02_BOUNDARY_KAT.R4.jsonl`, `P02_BOUNDARY_PAIR_REGISTER.R4.csv`).
- R4-05 J01 per-leg: 330 units / 630 occurrences, 150/150/30 (`J01_K_V2_ADJUDICATION.R4.jsonl`).
- R4-06 manifest verifier V01–V10 all PASS (`MANIFEST_BINDING_VERIFICATION.R4.json`); candidate pid `71287e74…`.
- R4-07 commitment KAT with preimages; recursive vs stack agree (`COMMITMENT_V3_KAT.R4.jsonl`); cd `d1e46eb5…`.
- R4-10 fresh-extraction verification: `verify_normative_bindings.py` run in temp extraction (exit code in commands.log).

## Gates
`P02_GATE_MATRIX.R4.csv` — 14 PASS, 3 PARTIAL (R4-G02 disclosed process; R4-G09/G10 J01 labels observed-not-independent).

## Note on defects 1–29
All 29 independent-review defects have executable evidence of repair except the disclosed independence limits on J01 expected labels.

## Standing
Awaiting Experiment Lead review. Do not declare K-v2 frozen; do not publish candidate identifiers as authoritative.