# P02-R4a (REPORT, DRAFT; K-v2 NOT authoritative)

## Results (executable)
- R4 regression replay: **71/71** (`R4_REGRESSION_REPLAY_RESULTS.jsonl`), no regression.
- R4a corrective suite (prospective lock @6457fc12): **21/21** (`R4A_CORRECTIVE_RESULTS.jsonl`), **0 exceptions**.
- Old oracle reproduces **12/21** corrective defects incl. surrogate crash (`R4A_COUNTEREXAMPLE_REPRO.json`).
- Independent J01 expected (oracle-free) @45cb5498: 630 legs (600 ACCEPT / 30 ABSTAIN), 300 pairs.
- Expected vs observed: admission/reason/business/eligible/canonical **630/630**; eq 150/150, distinct 150/150, abstain 30/30; **compatibility unchanged** (`J01_EXPECTED_VS_OBSERVED.R4A.json`).
- Complete verifier: `verify_review_package.py` (SHA256SUMS, bindings, pid/cd, corpus, input/canonical digests, counts, oracle-vs-expected, R4/R4a results, boundary, commitment, lock, docs).

## Candidate identifiers (unchanged normative payloads; NOT authoritative)
- `pid_sem_v2 = 71287e74…` ; `construction_digest = d1e46eb5…`

## Disclosures
Q/O/V sequential same agent (reduced independence); AI-assisted; no external human adjudication; correlated-specification risk; R4 chronology limitation preserved.

## Standing
P03/P04 NOT started. Awaiting Experiment Lead approval. Do not declare K-v2 frozen.