"""Standalone read-only verifier for R4 package (no repo imports; run from extracted dir). Exit 0 ok, 1 fail."""
import json, hashlib, sys, pathlib
import rfc8785

HERE = pathlib.Path(__file__).resolve().parent
MAN = json.loads((HERE / "semantic_manifest_v2.R4.CANDIDATE.json").read_text(encoding="utf-8"))


def lf(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def main():
    reasons = []
    for a in MAN["normative_artifacts"].values():
        p = HERE / a["path"]
        if not p.exists():
            reasons.append("MISSING:" + a["path"])
        elif lf(p) != a["sha256"]:
            reasons.append("DIGEST:" + a["path"])
    s = json.dumps(MAN)
    if "pid_sem_v2" in s or "semantic_identifier" in s:
        reasons.append("SELFREF")
    try:
        pid = hashlib.sha256(rfc8785.dumps(MAN)).hexdigest()
    except Exception as e:
        reasons.append("JCS:%s" % e); pid = None
    print(json.dumps({"ok": not reasons, "reasons": reasons, "candidate_pid_sem_v2": pid}, indent=2))
    sys.exit(0 if not reasons else 1)


if __name__ == "__main__":
    main()