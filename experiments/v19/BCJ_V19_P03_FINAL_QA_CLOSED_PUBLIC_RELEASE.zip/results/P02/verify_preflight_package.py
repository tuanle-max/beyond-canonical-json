"""Final P03 entry verifier (Track B). Exit 0 all pass. Read-only; actually executes replay+pairs+commitment."""
import json, hashlib, base64, sys, pathlib, csv, io
import rfc8785
BASE = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
F = {}


def chk(n, c):
    F[n] = bool(c)


def lf(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def bsha(b):
    return hashlib.sha256(b).hexdigest()


def rawsha(p):
    return bsha(p.read_bytes())


# ---- B1 package integrity ----
lp = BASE / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"
chk("lock_exists", lp.exists())
LK = json.loads(lp.read_text(encoding="utf-8")) if lp.exists() else {}
_fin = BASE / "ORACLE_LOCK.P03FINAL.json"
chk("p03final_lock_exists", _fin.exists())
if _fin.exists():
    chk("p03final_frozen", json.loads(_fin.read_text(encoding="utf-8")).get("frozen") is True)
chk("freeze_attestation_present", (BASE / "K_V2_FREEZE_ATTESTATION.json").exists())
chk("stage1_auth_record_present", (BASE / "P03_STAGE1_AUTHORIZATION_RECORD.json").exists())
art = LK.get("artifacts", {})
REQ = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml", "SUPPORTED_CURRENCY_SCALE_REGISTRY.json",
       "semantic_manifest_v2.R4.CANDIDATE.json", "COMMITMENT_V3_SPEC.R4.md", "construction_manifest_v3.R4.CANDIDATE.json",
       "J01_SOURCE_CORPUS.json", "J01_RECONSTRUCTED_INPUTS.jsonl", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
       "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv", "R4A_CORRECTIVE_EXPECTED.jsonl", "R4_ADVERSARIAL_EXPECTED.jsonl",
       "P02_BOUNDARY_KAT.R4.jsonl", "P02_BOUNDARY_PAIR_REGISTER.R4.csv", "COMMITMENT_V3_KAT.P03FINAL.jsonl",
       "ORACLE_PROVENANCE.R4.json", "verify_preflight_package.py"]
chk("lock_artifact_map_nonempty", len(art) > 0)
chk("lock_required_inventory", all(n in art for n in REQ))
chk("lock_artifacts_match", all((BASE / n).exists() and lf(BASE / n) == h for n, h in art.items()))
chk("lock_no_selfref", "ORACLE_LOCK.P03FINAL.CANDIDATE.json" not in art and "ORACLE_LOCK.P03FINAL.json" not in art)
scr = LK.get("scripts", {})
chk("lock_scripts_nonempty", len(scr) > 0)
chk("lock_scripts_match", all((ROOT / "scripts" / n).exists() and lf(ROOT / "scripts" / n) == h for n, h in scr.items()))
chk("sha256sums_exists", (BASE / "SHA256SUMS").exists())
_sok = True
for line in (BASE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    h, n = line.split("  ", 1)
    if not (BASE / n).exists() or rawsha(BASE / n) != h:
        _sok = False
chk("sha256sums_all_match", _sok)

MAN = json.loads((BASE / "semantic_manifest_v2.R4.CANDIDATE.json").read_text(encoding="utf-8"))
chk("manifest_artifacts_match", all((BASE / a["path"]).exists() and lf(BASE / a["path"]) == a["sha256"]
                                    for a in MAN["normative_artifacts"].values()))
pid = hashlib.sha256(rfc8785.dumps(MAN)).hexdigest()
CONS = json.loads((BASE / "construction_manifest_v3.R4.CANDIDATE.json").read_text(encoding="utf-8"))
cd = hashlib.sha256(rfc8785.dumps(CONS)).hexdigest()
chk("pid_matches_lock", pid == LK["candidate_pid_sem_v2"])
chk("cd_matches_lock", cd == LK["candidate_construction_digest"])
chk("j01_corpus_digest", rawsha(BASE / "J01_SOURCE_CORPUS.json") == "ab33c07a43bebcc4e9ed8ec9d9d05d7885ec78f71bcf1fc35aac3f2bfbecac94")
import r4a_oracle

# ---- B2 J01 actual replay (630) ----
exp = [json.loads(l) for l in (BASE / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
adm = rea = obj = elig = can = admitted = nonadm = nonadm_ok = 0
obs_typed = {}
for e in exp:
    raw = base64.b64decode(e["reconstructed_input_b64"])
    if bsha(raw) != e["input_sha256"]:
        chk("j01_one_input_digest", False)
    o = r4a_oracle.adjudicate(raw)
    obs_typed[(e["case_id"], e["leg_id"])] = o["eligible_json"]
    adm += (o["decision"] == e["expected_admission"])
    rea += (o["reason_code"] == e["expected_reason_code"])
    obj += (o["eligible_json"] == e["expected_business_object"])
    elig += (o["eligible_json"] == e["expected_eligible_json"])
    cc = base64.b64decode(e["expected_canonical_bytes_b64"]).hex() if e["expected_canonical_bytes_b64"] else None
    can += (o["canonical_hex"] == cc)
    if e["expected_admission"] == "ACCEPT":
        admitted += 1
    else:
        nonadm += 1
        nonadm_ok += (o["eligible_json"] is None and o["canonical_hex"] is None
                      and e["expected_business_object"] is None and e["expected_canonical_bytes_b64"] is None)
N = len(exp)
chk("j01_legs_630", N == 630)
chk("j01_admission_630", adm == N)
chk("j01_reason_630", rea == N)
chk("j01_object_630", obj == N)
chk("j01_eligible_630", elig == N)
chk("j01_canonical_630", can == N)
chk("j01_admitted_600", admitted == 600)
chk("j01_nonadmitted_30", nonadm == 30)
chk("j01_nonadmitted_na_consistency", nonadm_ok == 30)
F["_denominators"] = {"admission": [adm, N], "reason": [rea, N], "admitted_canonical": [admitted, 600], "nonadmitted": [nonadm_ok, 30]}

# ---- B3 J01 pairs (CSV, 300) ----
pr = list(csv.DictReader(io.StringIO((BASE / "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv").read_text(encoding="utf-8"))))
pids = [r["pair_id"] for r in pr]
chk("j01_pairs_300", len(pr) == 300)
chk("j01_pairs_unique", len(set(pids)) == len(pids))
pcor = 0
for r in pr:
    cid = r["pair_id"]; a = obs_typed.get((cid, "A")); b = obs_typed.get((cid, "B")); rel = r["expected_business_relationship"]
    if rel == "business-equal":
        pcor += (a is not None and b is not None and a == b)
    elif rel == "business-distinct":
        pcor += (a is not None and b is not None and a != b)
    elif rel == "not-applicable":
        pcor += (a is None or b is None)
    else:
        pcor += False
chk("j01_pairs_relationships_verified", pcor == 300)

# ---- B4 boundary replay + pairs ----
kat = [json.loads(l) for l in (BASE / "P02_BOUNDARY_KAT.R4.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
bmap = {}
bdec = brea = bcan = 0
for k in kat:
    raw = base64.b64decode(k["input_bytes_base64"])
    o = r4a_oracle.adjudicate(raw)
    bmap[k["case_id"]] = o["eligible_json"]
    bdec += (o["decision"] == k["expected_decision"])
    brea += (o["reason_code"] == k["expected_reason_code"])
    if k.get("expected_canonical_sha256"):
        bcan += (bsha(bytes.fromhex(o["canonical_hex"] or "")) == k["expected_canonical_sha256"])
    else:
        bcan += (o["canonical_hex"] is None)
chk("boundary_31", len(kat) == 31)
chk("boundary_decision_31", bdec == 31)
chk("boundary_reason_31", brea == 31)
chk("boundary_canonical_31", bcan == 31)
bp = list(csv.DictReader(io.StringIO((BASE / "P02_BOUNDARY_PAIR_REGISTER.R4.csv").read_text(encoding="utf-8"))))
bpc = 0
for r in bp:
    a = bmap.get(r["leg_a"]); b = bmap.get(r["leg_b"]); rel = r["expected_equivalence"]
    if rel == "business-equal":
        bpc += (a is not None and b is not None and a == b)
    elif rel == "business-distinct":
        bpc += (a is not None and b is not None and a != b)
    else:
        bpc += (True)
chk("boundary_pairs_12", len(bp) == 12)
chk("boundary_pair_relationships", bpc == 12)

# ---- B5 commitment full topology ----
def sha(b):
    return hashlib.sha256(b).digest()


def node(l, r):
    return sha(b"\x01" + l + r)


def rec2(xs):
    n = len(xs)
    if n == 0:
        return sha(b"\x02\x00")
    if n == 1:
        return xs[0]
    k = 1
    while k * 2 < n:
        k *= 2
    return node(rec2(xs[:k]), rec2(xs[k:]))


def build_nodes(xs, nodes):
    n = len(xs)
    if n == 0:
        return sha(b"\x02\x00")
    if n == 1:
        return xs[0]
    k = 1
    while k * 2 < n:
        k *= 2
    L = build_nodes(xs[:k], nodes); Rr = build_nodes(xs[k:], nodes)
    pre = b"\x01" + L + Rr
    nodes.append(pre.hex())
    return sha(pre)


PIDb = bytes.fromhex(pid); CDb = bytes.fromhex(cd)
ck = [json.loads(l) for l in (BASE / "COMMITMENT_V3_KAT.P03FINAL.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
byname = {c["case_id"]: c for c in ck}
EXPECT = {"empty": 0, "single": 1, "two": 2, "three": 3, "five": 5, "duplicate": 3, "ordered_distinct": 5,
          "permutation_same_multiset": 5, "changed_pid": 2, "changed_construction": 2}
chk("commitment_all_10_cases", set(EXPECT) <= set(byname))
chk("commitment_no_dup_ids", len(ck) == len(byname))
chk("commitment_cardinalities", all(byname[n]["actual_leaf_count"] == v == len(byname[n]["leaf_digests"]) for n, v in EXPECT.items() if n in byname))
cok_leaf = cok_root = cok_topo = True
for c in ck:
    PB = bytes.fromhex(c["semantic_profile_digest"]); CB = bytes.fromhex(c["construction_digest"])
    for i, rhex in enumerate(c["canonical_bytes_hex"]):
        pre = b"\x00\x03" + PB + CB + bytes.fromhex(rhex)
        cok_leaf = cok_leaf and pre.hex() == c["leaf_preimages"][i] and sha(pre).hex() == c["leaf_digests"][i]
    cok_root = cok_root and rec2([bytes.fromhex(h) for h in c["leaf_digests"]]).hex() == c["recursive_root"] == c["stack_root"]
    nodes = []; build_nodes([bytes.fromhex(h) for h in c["leaf_digests"]], nodes)
    stored = [n["preimage"] for n in c["internal_nodes"]]
    cok_topo = cok_topo and sorted(nodes) == sorted(stored)
chk("commitment_leaf_preimage_reconstructed", cok_leaf)
chk("commitment_root_reconstructed", cok_root)
chk("commitment_topology_matches", cok_topo)
_o = byname["ordered_distinct"]; _p = byname["permutation_same_multiset"]
chk("commitment_multiset_canonical", sorted(_o["canonical_bytes_hex"]) == sorted(_p["canonical_bytes_hex"])
    and _o["canonical_bytes_hex"] != _p["canonical_bytes_hex"])
chk("commitment_array_lengths", all(len(c["canonical_bytes_hex"]) == len(c["leaf_preimages"]) == len(c["leaf_digests"]) == c["actual_leaf_count"] for c in ck))
chk("commitment_node_digests", all(hashlib.sha256(bytes.fromhex(n["preimage"])).hexdigest() == n["digest"] for c in ck for n in c["internal_nodes"]))
_two = byname["two"]
cp = byname["changed_pid"]; ccp = byname["changed_construction"]
chk("commitment_oneprogram", cp["semantic_profile_digest"] != pid and cp["construction_digest"] == cd
    and cp["canonical_bytes_hex"] == _two["canonical_bytes_hex"])
chk("commitment_oneconstruction", ccp["semantic_profile_digest"] == pid and ccp["construction_digest"] != cd
    and ccp["canonical_bytes_hex"] == _two["canonical_bytes_hex"])

# ---- B6 regression replay ----
def replay(fn):
    rows = [json.loads(l) for l in (BASE / fn).read_text(encoding="utf-8").splitlines() if l.strip()]
    ok = 0
    for e in rows:
        o = r4a_oracle.adjudicate(base64.b64decode(e["input_b64"]))
        good = o["decision"] == e["expected_decision"] and o["reason_code"] == e["expected_reason"]
        if e["expected_decision"] == "ACCEPT":
            good = good and o["eligible_json"] == e["expected_object"] and o["canonical_hex"] == e["expected_canonical_hex"]
        ok += good
    return ok, len(rows)
r4n, r4t = replay("R4_ADVERSARIAL_EXPECTED.jsonl")
r4an, r4at = replay("R4A_CORRECTIVE_EXPECTED.jsonl")
chk("regression_r4_71", r4n == 71 and r4t == 71)
chk("regression_r4a_21", r4an == 21 and r4at == 21)

F["_pid"] = pid; F["_cd"] = cd
F["_fail"] = [k for k, v in F.items() if v is False]
print(json.dumps(F, indent=2))
sys.exit(0 if not F["_fail"] else 1)