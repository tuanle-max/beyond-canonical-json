"""Complete read-only verifier for R4A package. Exit 0 = all checks pass, 1 = failure. Does not regenerate evidence."""
import json, hashlib, base64, sys, pathlib
import rfc8785

BASE = pathlib.Path(__file__).resolve().parent          # results/P02
ROOT = BASE.parents[1]                                   # extraction root
SCR = ROOT / "scripts"
sys.path.insert(0, str(SCR))
R = {}


def lf(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def bsha(b):
    return hashlib.sha256(b).hexdigest()


# 1. package-wide SHA256SUMS
ok = True
for line in (BASE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    h, n = line.split("  ", 1)
    p = BASE / n
    if not p.exists() or bsha(p.read_bytes()) != h:
        ok = False
R["sha256sums_ok"] = ok

# 2-4. semantic manifest bindings + pid
MAN = json.loads((BASE / "semantic_manifest_v2.R4.CANDIDATE.json").read_text(encoding="utf-8"))
R["manifest_artifacts_ok"] = all((BASE / a["path"]).exists() and lf(BASE / a["path"]) == a["sha256"]
                                 for a in MAN["normative_artifacts"].values())
pid = hashlib.sha256(rfc8785.dumps(MAN)).hexdigest()
R["pid_sem_v2"] = pid
# 5. construction digest
CONS = json.loads((BASE / "construction_manifest_v3.R4.CANDIDATE.json").read_text(encoding="utf-8"))
R["construction_digest"] = hashlib.sha256(rfc8785.dumps(CONS)).hexdigest()

# 6. J01 corpus digest
corp = (BASE / "J01_SOURCE_CORPUS.json").read_bytes()
R["j01_corpus_sha256"] = bsha(corp)

# 7-9. independent expected: input digests, canonical digests, counts
exp = [json.loads(l) for l in (BASE / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
in_ok = can_ok = True
adm = {}
for e in exp:
    raw = base64.b64decode(e["reconstructed_input_b64"])
    in_ok = in_ok and bsha(raw) == e["input_sha256"]
    if e["expected_canonical_bytes_b64"]:
        c = base64.b64decode(e["expected_canonical_bytes_b64"])
        can_ok = can_ok and bsha(c) == e["expected_canonical_sha256"]
    adm[e["expected_admission"]] = adm.get(e["expected_admission"], 0) + 1
R["reconstructed_input_digests_ok"] = in_ok
R["expected_canonical_digests_ok"] = can_ok
R["j01_legs"] = len(exp); R["j01_admission"] = adm
R["j01_counts_ok"] = (len(exp) == 630 and adm.get("ACCEPT") == 600 and adm.get("ABSTAIN_UNDERSPECIFIED") == 30)

# 10. reference-oracle agreement with locked expected (uses locked expected, not regenerating)
import r4a_oracle
agree = 0
for e in exp:
    o = r4a_oracle.adjudicate(base64.b64decode(e["reconstructed_input_b64"]))
    agree += (o["decision"] == e["expected_admission"] and o["reason_code"] == e["expected_reason_code"]
              and o["eligible_json"] == e["expected_business_object"])
R["oracle_agreement"] = [agree, len(exp)]
R["oracle_agreement_ok"] = agree == len(exp)

# 11-12. R4 regression + R4a corrective results
def allpass(f):
    rows = [json.loads(l) for l in (BASE / f).read_text(encoding="utf-8").splitlines() if l.strip()]
    return len(rows) > 0 and all(r["pass"] for r in rows), len(rows)
R["r4_regression_ok"], R["r4_regression_n"] = allpass("R4_REGRESSION_REPLAY_RESULTS.jsonl")
R["r4a_corrective_ok"], R["r4a_corrective_n"] = allpass("R4A_CORRECTIVE_RESULTS.jsonl")

# 13. boundary KAT counts + commitment roots internal agreement
kat = [json.loads(l) for l in (BASE / "P02_BOUNDARY_KAT.R4.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
R["boundary_cases"] = len(kat); R["boundary_ok"] = len(kat) == 31 and len({k["input_sha256"] for k in kat}) == 31
ckat = [json.loads(l) for l in (BASE / "COMMITMENT_V3_KAT.R4.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
R["commitment_roots_ok"] = all(c.get("agree", True) for c in ckat)

# 14. detached lock digests (if present)
lockp = BASE / "ORACLE_LOCK.R4A.CANDIDATE.json"
if lockp.exists():
    lk = json.loads(lockp.read_text(encoding="utf-8"))
    R["lock_ok"] = all((BASE / n).exists() and lf(BASE / n) == h for n, h in lk.get("artifacts", {}).items())
    R["lock_source_commit"] = lk.get("source_commit")
else:
    R["lock_ok"] = "absent"

# 15. required docs present
req = ["P03_EXECUTION_PLAN.md", "P03_METRIC_DICTIONARY.yaml", "P04_ISOLATION_PROTOCOL.md"]
R["required_docs_present"] = all((BASE / n).exists() for n in req)

fail = [k for k, v in R.items() if v is False]
R["_fail"] = fail
print(json.dumps(R, indent=2))
sys.exit(0 if not fail else 1)