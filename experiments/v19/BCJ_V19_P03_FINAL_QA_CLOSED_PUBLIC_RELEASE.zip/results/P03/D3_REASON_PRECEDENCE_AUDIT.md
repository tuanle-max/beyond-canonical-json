# D3 Reason-Precedence Audit (S05)

## Evidence
Locked expected (`R4A_CORRECTIVE_EXPECTED.jsonl` S05): `REJECT_MALFORMED / EVENT_ID_MALFORMED`.
Input: `event_id` contains an escaped unpaired surrogate `"\ud800"`.
Initial Go (`f34220d7`): `REJECT_MALFORMED / UNICODE_MALFORMED`. Python: `EVENT_ID_MALFORMED`.

## Clause audit
- `NORMATIVE_CONTRACT.R4.md` field model: `event_id` grammar `^[A-Za-z0-9_-]{1,256}$`; malformed event_id →
  `EVENT_ID_MALFORMED` (REJECT_MALFORMED).
- Contract Unicode rule: unpaired surrogate / invalid UTF-8 → `UNICODE_MALFORMED`.
- Contract precedence is **category-first** (MALFORMED > PROHIBITED > ABSTAIN) then reason-rank; it does **not**
  specify which reason applies when a single scalar violates both a parser-global Unicode rule and a field grammar.
- Both reasons are in the MALFORMED category (rank UNICODE_MALFORMED=2, EVENT_ID_MALFORMED=5).

## Determination
Not a semantic contradiction in policy, but the **Go parser loses field context**: it rejects the unpaired
surrogate at parse time (global), so the field-specific grammar stage (which would yield `EVENT_ID_MALFORMED`)
is never reached. The reason-rank tie-break therefore resolves to `UNICODE_MALFORMED`. The frozen contract does
not state that a parser-global Unicode rejection outranks a field-grammar reason, so the expected
`EVENT_ID_MALFORMED` is not derivable from parser-first behaviour; it is derivable only from field-aware
diagnosis (as Python's `json` does, yielding a lone surrogate that fails the event_id grammar).

## Safe fix design (field-aware diagnostic rejection) — NOT YET APPLIED
1. Do **not** error on unpaired surrogate inside a JSON string; instead set a per-string `Bad` flag and store a
   non-admittable placeholder rune (U+FFFD used only as an internal marker; it never enters an admitted object).
2. Carry `Bad` on the parsed value; in evaluation classify by field: `event_id.Bad → EVENT_ID_MALFORMED`;
   `beneficiary.Bad → UNICODE_MALFORMED`; `currency/amount/obligation_ref.Bad → UNICODE_MALFORMED`; a `Bad`
   timestamp fails the grammar → `TIMESTAMP_MALFORMED`.
3. Safety invariants preserved: any `Bad` field forces a REJECT (no admission, no typed object, no canonical
   bytes, no leaf/root contribution); no replacement-character coercion of admitted values; duplicate-key and
   malformed-JSON handling unchanged; existing category/rank precedence unchanged.

This is a multi-edit change to `main.go` (parser string handling + `V.Bad` + per-field classification + rebuild +
S05/Unicode/multi-fault regression). It was **not applied** in this session due to execution-budget exhaustion;
S05 therefore **remains an unresolved reason-only discrepancy** and complete reason-code correctness is NOT claimed.

## Consequence
R3-B, R3-C, R3-D are not blocked by a reason-only discrepancy (per directive), but were not executed this session.
