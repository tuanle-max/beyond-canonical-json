# E2/E3 Execution Report (Agent V) — actual results, first pass

Resume commit: 0893c35b. Implementations frozen: Python `8bcad291`, Go `f34220d7`.
Identifiers `caa2f3e5…` / `d1e46eb5…`. Both subprocesses exited 0 for all three suites; no timeouts; no INTERNAL_ERROR.
Evaluator-owned artifacts under `results/P03/`; no new artifacts written into implementation dev workspaces.

## Results vs locked expected evidence

| Suite | N | Python admission | Go admission | Python canonical | Go canonical |
|---|---|---|---|---|---|
| E2 boundary | 31 | **31/31** | 30/31 | 20/20 | 20/20 |
| E3 R4 adversarial | 71 | **71/71** | 69/71 | per metrics | per metrics |
| E3 R4a corrective | 21 | **21/21** | 20/21 | per metrics | per metrics |
| E2 boundary pairs | 12 | **12/12** | (see note) | — | — |

Python reproduces every locked expectation across E2/E3. Go diverges on **5 cases** (2 root causes). E2 pair relationships verified against Python outputs (12/12); Go's R4-29 admission error would make the pair involving R4-29 fail for Go.

## Failure register (all Go; preserved, not corrected)
1. **ALIAS_CONFLICT not detected** — E2 `R4-29`, E3 `B04`, E3 `B06`: both canonical and alias present with different values → expected `REJECT_PROHIBITED/ALIAS_CONFLICT`, Go `ACCEPT`. Root cause: Go `ev()` `find()` returns canonical-or-alias without comparing both when both present.
2. **Negative scale not rejected** — E3 `M05`: `scale=-1`, expected `REJECT_PROHIBITED/SCALE_MISMATCH`, Go `ACCEPT` (Go guards `if scal>=0`, so a negative scale bypasses the mismatch branch and the record is admitted with minor 0). Root cause: negative-scale domain check missing.
3. **Surrogate reason-code precedence** — E3 `S05`: `event_id` = escaped unpaired surrogate; expected `REJECT_MALFORMED/EVENT_ID_MALFORMED`, Go `REJECT_MALFORMED/UNICODE_MALFORMED`. Root cause: Go rejects the surrogate at parse time (Unicode) rather than at the event_id field-grammar stage; same category, different reason code.

These are genuine implementation defects (Go), not expected-evidence errors. Per failure policy they are recorded, not fixed in this session, and the locked expectations are untouched.

## Integrity
- Locked expected evidence unchanged. First-pass outputs preserved (`E2_py/go.jsonl`, `E3_R4_*`, `E3_R4A_*`).
- Execution logs: `E2_E3_EXEC_LOGS.json`. Per-input comparisons: `*_COMPARE.jsonl`.
- E2 pair results: `P03_E2_PAIR_RESULTS.jsonl` (12/12 pass vs Python outputs).
- No E4, no stage attribution, no P04 executed. Manuscript untouched.

## Scientific interpretation
Python satisfies contract-relative correctness on E2/E3. Go achieves identical canonical bytes on all *admitted* cases it shares with Python but has 5 admission/reason defects concentrated in alias-conflict detection, negative-scale rejection, and surrogate precedence — a legitimate cross-implementation divergence that cross-language canonical agreement (E1) does not by itself reveal (agreement ≠ correctness).
