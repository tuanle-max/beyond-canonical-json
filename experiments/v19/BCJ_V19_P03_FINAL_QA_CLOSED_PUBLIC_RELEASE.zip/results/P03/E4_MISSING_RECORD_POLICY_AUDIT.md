# E4 Missing-Record Policy Audit (R3-B)

## Normative clause (cited)
`NORMATIVE_CONTRACT.R4.md`, "Batch policy (construction identity, R4-07)": **"missing record → batch fails"**.
Also: admitted-only root; rejected/abstained excluded and counted separately; index = tree placement.

## Audit of the original E4 "missing" descriptor
Original descriptor `P03_E4_BATCH_DESCRIPTORS.jsonl` id `missing`, order `[EV-1, EV-2, MISSING-1]`, where
`MISSING-1` **was supplied** with an empty `raw_b64` (decodes to `b""`), i.e. a **supplied-but-invalid** record
(→ JSON_MALFORMED → rejected), **not** a genuinely absent required record. Therefore:
- The original descriptor tests **rejected-record accounting / admitted-only root**, NOT genuine absence.
- It is **not** evidence of an implementation defect against the "missing record → batch fails" clause.
- Preserved unchanged; must not be reinterpreted post hoc.

## Distinction (as required)
1. Supplied-but-rejected (e.g. invalid JSON) → excluded, counted in `rejected` (tested by original `missing`/`mixed`).
2. Supplied-but-abstained → excluded, counted in `abstained` (tested by `mixed` ABSTAIN-1).
3. **Required-but-not-supplied** (genuine absence, e.g. expected {A,B,C}, supplied {A,B}) → contract says **batch fails**.

## Genuine-missing descriptor (frozen expected before execution)
Expected membership A,B,C; supplied A,B; C has no raw. Expected outcome: **batch failure / missing-record
identified / no successful root**. The current `commit` CLI interface takes only a `records` list and has **no
"expected membership" parameter**, so genuine absence cannot be expressed without an interface adaptation
(e.g. adding an `expected_ids` field and a pre-commit membership check that fails the batch). That adaptation is
**not yet implemented or executed** this session (execution-budget limit).

## Status
- Audit complete; original descriptor correctly characterised as supplied-but-invalid (not genuine absence).
- Corrected E4 denominators (batch-level vs individual leaf/node; N/A where no leaves expected) and the
  genuine-missing descriptor + both-CLI execution + any minimal membership-precheck correction are **pending**.
- No normative reason code invented; no locked expectation modified.
