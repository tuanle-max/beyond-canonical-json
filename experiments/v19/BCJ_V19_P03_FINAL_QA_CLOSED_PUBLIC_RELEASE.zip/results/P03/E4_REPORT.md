# E4 Batch-Root Evaluation (Agent V) — actual results

Independent expected roots computed only from the frozen construction spec (rfc8785 + sha256); no implementation was used to generate expectations. Both frozen impls (`8bcad291`, `f34220d7`) run via their `commit` CLI on identical batch JSON, evaluator-owned dirs under `results/P03`.

## Descriptors (18, frozen before execution)
Sizes 1,2,3,4,5,7,8,16,31,32 (distinct); empty; duplicate `[EV-1,EV-1,EV-2,EV-3]`; reorder_a vs reorder_b (same multiset, reversed); missing (`EV-1,EV-2,MISSING-1` where MISSING-1 is a non-supplied/invalid record); mixed (`EV-1,INVALID-1,ABSTAIN-1,EV-2`); changed_pid (alt profile); changed_cd (alt construction). Pid/cd substituted per descriptor where applicable.

## Results (exact denominators = 18 batches)
| metric | Python | Go |
|---|---|---|
| batch-status (admitted/rejected/abstained accounting) | **18/18** | **18/18** |
| leaf correctness | **18/18** | **18/18** |
| internal-node correctness (count + digest multiset + preimage rehash) | **18/18** | **18/18** |
| root correctness (vs independent expected) | **18/18** | **18/18** |

Cross-implementation: **matched-context leaf agreement 18/18**, **matched-context root agreement 18/18**. Failures: **0**. `python_exit_all0 = true`, `go_exit = 0`. No timeouts.

## Notes / limitations
- Both implementations realise the frozen **admitted-only root with separate accounting**: rejected and abstained records are excluded from the root and reported in `rejected`/`abstained`. Therefore "missing required record" is represented as a non-supplied/invalid record that is rejected and excluded (not a dedicated batch-failure mode); this matches the frozen construction's admitted-only root semantics. Documented here rather than treated as a separate fail state.
- Ordering is verified via `reorder_a`/`reorder_b` (same canonical-byte multiset, different order → different root for both).
- Profile and construction perturbations verified (changed_pid, changed_cd) with one factor varied.
- Root correctness is claimed from **independent expected roots**, not merely Python-Go agreement (agreement 18/18 is reported separately).

## Integrity
Descriptors and expected roots frozen in `P03_E4_BATCH_DESCRIPTORS.jsonl` / `P03_E4_EXPECTED_ROOTS.jsonl` before execution; first-pass raw outputs preserved (`P03_E4_PYTHON_RESULTS.jsonl`, `P03_E4_GO_RESULTS.jsonl`); logs `E4_EXEC_LOGS.json`; no E4 failures. No stage attribution, no review archive, no P04; manuscript untouched.
