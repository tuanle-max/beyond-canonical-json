# QA-B Verification Report

- Evidence manifest: provenance, candidate/extraction identity, runner bugs = two WindowsPath+str fixes, source digests.
- J01 reconstruction: rebuilt 630 legs from J01_SOURCE_CORPUS.json via JCS; membership + bytes + digests equal locked expected.
- Aggregation: E1 630/630 + 600/600 both, E2 31/31, R4 71/71, R4a 21/21, E4 131/131 leaves & 114/114 nodes & 18/18 roots both, attribution original 9/11 + corrective 2/2.
- Comparison: deterministic-equal; no unexpected scientific discrepancy.
- Mutation: baseline 0, 8/8 detected (checksum-regenerated rejected structurally).

Overall: PASS
