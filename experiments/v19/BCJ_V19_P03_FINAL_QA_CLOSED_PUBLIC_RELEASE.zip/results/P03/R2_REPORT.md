# BCJ-V19 P03 Stage-1 R2 — Consolidated Scientific Report

Implementations (frozen initial): Python `8bcad291`, Go `f34220d7`. Identifiers `caa2f3e5…` / `d1e46eb5…`.
Environment: Python 3.12.9 / unicodedata 15.0.0 / rfc8785 0.1.3 / decimal C; Go 1.23.12 linux/amd64 in
`golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db` (x/text v0.19.0 norm 15.0.0, gowebpki/jcs v1.0.1).

## Scientific aggregation (separate suites; no pooling)
- **E1 (J01, 630 occ)** — corrected, independent per-impl vs locked expected: Py and Go both admission 630/630,
  reason 630/630, typed/eligible/canonical 600/600, abstention 30/30, **unsafe 0/30, false-rejection 0/600,
  false-non-admission 0/600**, equivalent 150/150, distinct 150/150; **Py↔Go exact canonical bytes 600/600**.
- **E2 (boundary, 31; 12 pairs)** — Py 31/31 admission, canonical 20/20, pairs 12/12. Go 30/31 (1 defect).
- **E3 R4 (71)** — Py 71/71; Go 69/71 (2 defects). **E3 R4a (21)** — Py 21/21; Go 20/21 (1 defect).
  Go's 5 divergences are genuine implementation defects: alias-conflict not detected (3), negative-scale not
  rejected (1), surrogate reason-code precedence (1). Recorded, not corrected, expectations untouched.
- **E4 (18 batches: sizes 1–32 + empty/duplicate/reorder/missing/mixed/changed-pid/changed-cd)** — both Py and Go
  **18/18** batch-status, leaf, internal-node, and root vs **independent expected roots**; Py↔Go leaf and root
  agreement 18/18; 0 failures.
- **Stage attribution (11 perturbations)** — 10/11 diverged, 9/11 expected stage matched; 2 honest mismatches
  (canonicalization no-op for the chosen input → NONE; ordering first manifests at L5 not L6). Baseline unmodified.

## Normative correctness vs agreement (kept distinct)
E1/E2/E3 correctness is against locked expected evidence; E4 root correctness is against **independently computed**
expected roots (rfc8785+sha256 only). Cross-implementation agreement (E1 600/600, E4 18/18) is reported separately
and is NOT used as a correctness proof. Go's E2/E3 defects demonstrate agreement ≠ correctness.

## C6 — P03_MUTATION_RESULTS.FINAL.json checksum mismatch (documented, not concealed)
The `results/P02/SHA256SUMS` entry for `P03_MUTATION_RESULTS.FINAL.json` was generated before `p03_mutations3.py`
rewrote that file later in the same session (baseline-first rerun). Content verified (baseline_exit 0, 8/8 detected;
checksum-regenerated mutation rejected by root recomputation). The stale entry was corrected by regenerating
SHA256SUMS from the current verified artifacts (p03_lock), not by hand-editing.

## Verification executed this session
- `p03_lock.py` → rebuilds P02 lock + SHA256SUMS over current artifacts and runs `verify_preflight_package.py`
  in a fresh temp extraction (**exit 0**), earlier reported.
- R2 archive integrity (CRC + detached sha256) verified after build.
Only **archived-evidence verification** was executed in a fresh extraction; full clean-room reproduction of E1–E4
from the extracted R2 archive was **not** executed this session (portable scripts are included). No claim of full
clean-room reproduction is made.

## Claim–Evidence–Limitation matrix
`SCIENTIFIC_CLAIM_MATRIX.csv`.

## Status
`next_phase_authorized: false` (pending Experiment Lead review). P04 NOT executed. Manuscript `tex/v18.tex` @40376da untouched. P02 not reopened.
