# R3-A Report — Go defect corrections

Initial Go snapshot: `f34220d7` (preserved). Corrected Go source: this commit (post-evaluation; NOT evaluator-blind).
Python unchanged: `8bcad291`. Identifiers unchanged (`caa2f3e5…`, `d1e46eb5…`).

## Failure-metric reconciliation (from E2_E3_FAILURE_REGISTER.json, raw evidence)
The five recorded failing observations = **4 unsafe-admission observations** (Go `ACCEPT` where expected reject)
+ **1 reason-only discrepancy**. They are **3 defect classes**, not 5 independent bugs:
- **D1 alias-conflict** — 3 observations: `R4-29`, `B04`, `B06` (unsafe admission).
- **D2 negative-scale** — 1 observation: `M05` (unsafe admission).
- **D3 surrogate reason precedence** — 1 observation: `S05` (admission category correct: REJECT_MALFORMED; reason differs).

## Corrections applied (`implementations/go-dev/main.go`)
- **D1:** detect conflicting canonical/alias pairs (`currency` vs `cur`; `beneficiary_code` vs `beneficiary` after NFC) → `ALIAS_CONFLICT`.
- **D2:** explicit `hasScale` flag (missing ≠ supplied); supplied negative/out-of-registry scale → `SCALE_MISMATCH` (no sentinel bypass).

## Targeted regression (executed in pinned Docker, exit 0)
| case | defect | expected | corrected observed | pass |
|---|---|---|---|---|
| R4-29 | D1 | REJECT_PROHIBITED/ALIAS_CONFLICT | REJECT_PROHIBITED/ALIAS_CONFLICT | ✓ |
| B04 | D1 | REJECT_PROHIBITED/ALIAS_CONFLICT | REJECT_PROHIBITED/ALIAS_CONFLICT | ✓ |
| B06 | D1 | REJECT_PROHIBITED/ALIAS_CONFLICT | REJECT_PROHIBITED/ALIAS_CONFLICT | ✓ |
| M05 | D2 | REJECT_PROHIBITED/SCALE_MISMATCH | REJECT_PROHIBITED/SCALE_MISMATCH | ✓ |
| S05 | D3 | REJECT_MALFORMED/EVENT_ID_MALFORMED | REJECT_MALFORMED/UNICODE_MALFORMED | ✗ (reason-only) |

Result: D1 3/3 fixed, D2 1/1 fixed. D3 admission category correct; reason-code precedence at parse vs field stage differs.

## D3 disposition — escalated (not silently changed)
The frozen contract does not specify precedence between a parser-level Unicode rejection and a field-specific
grammar reason (`event_id`), for an escaped unpaired surrogate inside `event_id`. Changing the Go parser to defer
that to the field stage would weaken strict parsing, which D3 forbids. Evidence preserved; **escalated as a
frozen-contract precedence ambiguity**. No normative policy modified.

## Expected effect on targets (not yet fully rerun)
Corrected Go should now yield E2 admission 31/31, R4 71/71, R4a admission 21/21, with **one reason-only**
discrepancy (S05) remaining. Full E1/E2/E3/E4 corrected regression across all suites is **not** executed in this
session (execution-budget limit); only the five reported cases were re-executed and recorded. First-pass metrics
remain the scientific baseline of record.

## Integrity
Initial Go source, all first-pass outputs, failure register, R2 archive preserved. Expected evidence unmodified.
Post-evaluation correction clearly labelled. Manuscript untouched; P04 not started.
