# R3A WP1 Report — multiplicity + Go sentinel safety (targeted post-evaluation)

Not held-out evidence. Pre/post evidence: `R3A_WP1_pre.json`, `R3A_WP1_post.json`.

## Task 1 — required duplicate multiplicity
Pre-correction defect confirmed in **both** implementations: `M01` (expected [A,A,B], supplied [A,B]) and `M03`
(expected [A,A,A,B], supplied [A,B]) wrongly returned `OK` with 2 leaves (set-membership ignored multiplicity).
`M02` and the original `duplicate_mult` were already correct.

**Correction (independent per language):** count-based needed-vs-supplied comparison; `missing += [id]*deficit`.
- Python `boo.py`: `Counter(exp) - Counter(supplied)` deficit expansion.
- Go `main.go`: `suppliedCount`/`need` maps, deficit loop.

Post-correction (both impls): **M01 BATCH_FAILED (0 leaves), M03 BATCH_FAILED (0 leaves), M02 OK 3 leaves,
duplicate_mult OK 3 leaves**. Leaf encoding/tree construction unchanged; no reordering of supplied records.

Interface semantics: `expected_ids` enforces **required-membership completeness (count-based)**, not exact
inventory equality; unexpected extra supplied records are not rejected (no supported policy). Documented.

## Task 2 — Go malformed-Unicode sentinel safety
Six controls executed pre-correction; **all already safe**:
U01 REJECT/ALIAS_CONFLICT · U02 REJECT/UNICODE_MALFORMED · U03 REJECT/UNKNOWN_FIELD · U04
REJECT/FIELD_TYPE_MALFORMED · U05 ACCEPT (valid surrogate pair) · U06 ACCEPT (literal U+FFFD).
Malformed → non-admission with no canonical bytes and no leaf; valid literal U+FFFD and valid surrogate pairs
remain admissible. **No patch required by evidence.** Residual (documented, not concealed): the object-key `Bad`
flag is not explicitly propagated and alias `Bad` is not separately flagged; a narrow unexplored edge
(canonical and alias both equal-but-malformed) remains theoretically unpatched but was not observed.

## Build/test
Pinned Docker `golang@sha256:1670…`; `go build` + `commit`/`adjudicate` exit 0; Python exit 0. Commands/logs in the
phase results files. Identifiers `caa2f3e5…`/`d1e46eb5…` unchanged.

## Scope
Targeted only; no full regression, no final packaging, no P04. Manuscript @40376da untouched.
