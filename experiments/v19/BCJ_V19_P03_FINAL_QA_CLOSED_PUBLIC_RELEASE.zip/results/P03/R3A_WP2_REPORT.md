# R3A WP2 Report — final regression & metric closure

Final implementations = WP1 corrected (count-based multiplicity) + D1/D2/D3 + expected_ids. WP1 change is a no-op
for E1–E4/R3B-controls because it only triggers when `expected_ids` is present (E4 descriptors have none); preserved
outputs therefore remain valid. Sources frozen at the WP1 commit (`f269f701`); digest change only in `boo.py`/`main.go`.

## E4 metric-definition correction (EL-requested)
Previously reported "18/18 leaf / 18/18 node" were **batch-level all-leaves/all-nodes** metrics. Corrected, with
occurrence-level metrics computed from expected vs preserved observed traces (`P03_E4_OCCURRENCE_METRICS.json`):

| metric | Python | Go |
|---|---|---|
| batch-status correctness | 18/18 | 18/18 |
| batch-level all-leaves | 18/18 | 18/18 |
| batch-level all-nodes | 18/18 | 18/18 |
| **individual leaf-occurrence** | **131/131** | **131/131** |
| **individual internal-node-occurrence** | **114/114** | **114/114** |
| root correctness | 18/18 | 18/18 |
| expected-batch-failure correctness | N/A (no failed batch among the 18 descriptors; genuine-missing tested separately → BATCH_FAILED) | N/A |

Cross-implementation: leaf agreement **131/131**, root agreement **18/18**. Expected totals verified: 131 leaves /
114 nodes per implementation (matches EL independent count). Exact ordered leaves, node preimages+digests and
topology verified (multiset occurrence match; batch-level exact). Failed batches are not in the successful-root
denominator (none among the 18; N/A where zero).

## Admission/pair reaggregation (independent, from raw)
`P03_R3D_VERIFICATION.json`: E1 py/go 630/630 admission & 600/600 canonical; E2 31/31 both; R4 71/71 both;
R4a 21/21 both; E2 pairs 12/12; E1 pairs 150/150+150/150; py↔go canonical 600/600. Unique input membership exact

(630 unique J01 legs). Historical (first-pass) comparison distinguishes **admission-only** vs **admission+reason**:
Go's five original failing observations = **4 unsafe admissions + 1 reason-only** discrepancy across **3 defect
classes** (D1 alias ×3, D2 negative-scale, D3 surrogate reason), all since corrected (0 failures in R3 regression).

## Comparator (L5/L6)
Existing R3-C corrected comparator already satisfies the requirement: **L5 = multiset of (record_id, leaf_digest)
associations incl. duplicate multiplicity**; **L6 = ordered batch membership**. Reorder diagnostic → L5 multiset
equal, L6 differs → L6. No comparator change needed; not rerun. Original 9/11 and corrective 2/2 preserved separately.

## Failure register
None in the final corrected run. First-pass failures preserved in prior commits.

## Scope
No benchmark expansion; P02 untouched; identifiers `caa2f3e5…`/`d1e46eb5…` unchanged; manuscript @40376da untouched;
P04 not started.
