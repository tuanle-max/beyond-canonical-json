# R3-B Execution Report — batch completeness (genuine missing record)

Scope: expected_ids membership precheck added to both commit CLIs; no normative change; no new reason code.
Original E4 `missing` descriptor preserved (it was supplied-invalid accounting, not genuine absence).

## Genuine-missing descriptor (frozen before execution)
`expected_ids = [EV-1, EV-2, EV-3]`; supplied = `[EV-1, EV-2]`; `EV-3` has no raw input.

## Actual results (pinned Docker Go exit 0; Python exits 0)
| batch | expected | Python | Go | ok |
|---|---|---|---|---|
| genuine_missing | BATCH_FAILED, missing=[EV-3], root null | **BATCH_FAILED**, root null | **BATCH_FAILED**, root null | ✓/✓ |
| complete | OK, root | OK, root `9679558f…` | OK, root `9679558f…` | ✓/✓ |
| duplicate_mult | OK, admitted [EV-1,EV-1,EV-2], n=3 | OK, n=3 | OK, n=3 | ✓/✓ |
| supplied_invalid | OK, admitted [EV-1], rejected [INVALID-1] | OK | OK | ✓/✓ |
| supplied_abstained | OK, admitted [EV-1], abstained [ABSTAIN-1] | OK | OK | ✓/✓ |

`genuine_missing_correct = true`, `all_controls_ok = true`. Successful-batch roots identical across implementations (interop preserved); the `complete` root equals the independent E4 odd3 root (`9679558f…`), and duplicate/invalid/abstain roots equal the E4 single/odd roots, confirming the frozen leaf/tree construction is unchanged.

## Verification of required properties
- Missing-record detection: both fail the batch and list the missing required id; **no successful root**.
- Expected vs supplied membership checked before commitment; expected never derived from supplied.
- Ordering and duplicate multiplicity preserved (duplicate_mult n=3, ordered admitted list exact).
- Supplied-invalid and supplied-abstained remain accounting outcomes, not batch failure (distinct from genuine absence).
- Leaf and tree construction unchanged (roots match E4 independent expected values).

## Limitations
Completeness verified only for the supplied expected-membership descriptors above (not a general completeness proof).
No full E1–E4 regression, no R3-C/R3-D, no P04 executed. Locked expected evidence and identifiers unchanged.

## Immutable corrected sources
Python `boo.py` and Go `main.go` with expected_ids precheck — corrected commit: this commit (post-evaluation, not evaluator-blind).
