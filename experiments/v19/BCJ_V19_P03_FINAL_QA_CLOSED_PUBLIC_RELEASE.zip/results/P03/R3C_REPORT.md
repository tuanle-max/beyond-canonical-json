# R3-C Report — targeted attribution corrections

Python-only diagnostic scope. Original attribution results **preserved unchanged** (do NOT read as 11/11):
11 perturbations · 10 observable divergences · 9 expected-stage matches · 1 canonicalization no-effect · 1 L5/L6 mismatch.

## L3 positive control (new, executed)
Fixture: valid `BASE` record. Baseline canonicalizer = RFC 8785 (sorted, `boo`); perturbed = `json.dumps(order=insertion)`.
- L0 admission: identical; L1 typed: identical; L2 eligible: identical.
- L3 bytes: **differ**
  - baseline `7b22626322…` (sorted: bc,cur,eid,minor,ref,t)
  - perturbed `7b22656964…` (insertion: eid,t,minor,cur,bc,ref)
- expected L3 → observed **L3** → **PASS**.
The original no-effect canonicalization result (previous session) remains preserved as a separate historical finding.

## L5/L6 comparator correction (new, executed)
Corrected stage semantics: **L5 = per-record leaf digest multiset (with multiplicity)**; **L6 = ordered batch membership**.
- Pure reorder of 5 records: leaf **multiset identical** (`sorted(leaves)` equal), **ordered membership differs**
  (`[EV-1..5]` vs `[EV-5..1]`).
- expected L6 → observed **L6** → **PASS**.
The original run's L5 attribution (ordered leaf-list captured at L5) is preserved; the corrected comparator now
attributes pure reorder to L6 (membership/sequence), not leaf encoding — without changing frozen semantic or
construction policy.

## Metrics (corrective)
`P03_STAGE_ATTRIBUTION_METRICS.R3C.json`: corrective total 2, pass 2 (L3 ✔, L5/L6 ✔); original preserved block
(11/10/9/1/1) recorded separately.

## Scope / integrity
Python-only; benchmark not expanded; frozen baseline unmodified (perturbation applied to serialization only);
original `P03_STAGE_ATTRIBUTION_RESULTS.jsonl` untouched. No P04. Manuscript @40376da untouched.
