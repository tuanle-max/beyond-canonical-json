# R3 Regression Report — corrected implementations, full E1–E4

Corrected sources: Python + Go (post-evaluation; D1/D2/D3 + R3-B expected_ids). First-pass results preserved in
prior commits (E1 `0893c35b`, E2/E3 `c2c840e7`, E4 `015fae25`); corrected results in this commit. Locked expected
evidence unchanged. Pinned env: Py 3.12.9 / unidata 15.0.0 / rfc8785 0.1.3; Go 1.23.12 in
`golang@sha256:1670…` (norm 15.0.0). All subprocess exits 0; no INTERNAL_ERROR/timeouts.

## E1 (J01, 630 occ; 300 pairs) — corrected
| metric | Python | Go |
|---|---|---|
| admission | 630/630 | 630/630 |
| reason | 630/630 | 630/630 |
| valid coverage | 600/600 | 600/600 |
| typed / eligible / canonical (exact bytes) | 600/600 each | 600/600 each |
| unsafe admission | 0/30 | 0/30 |
| false rejection | 0/600 | 0/600 |
| false non-admission | 0/600 | 0/600 |
| abstention | 30/30 | 30/30 |
| equivalent / distinct pairs | 150/150 · 150/150 | 150/150 · 150/150 |

Py↔Go exact canonical bytes: **600/600**.

## E2 (31 cases; 12 pairs) — corrected
Python admission 31/31, canonical 20/20; **Go admission 31/31** (was 30/31), canonical 20/20; pairs 12/12.

## E3 R4 (71) / E3 R4a (21) — corrected
Python 71/71, 21/21; **Go 71/71, 21/21** (was 69/71, 20/21). Failure count **0** (was 5).

## E4 (18 descriptors) — corrected
Both implementations: batch-status **18/18**, individual leaf **18/18**, internal-node **18/18**, root **18/18**
(vs independent expected). Py↔Go matched-context leaf **18/18**, root **18/18**. Failures 0.

## Genuine-missing + controls (R3-B) — corrected (this session, prior commit)
genuine_missing → both `BATCH_FAILED`, missing `[EV-3]`, root null; complete/duplicate/invalid/abstain controls all
correct; successful roots identical Py↔Go. Expected-failed batch is **not** counted as a successful-root observation.

## First-pass vs corrected
| suite | first-pass (Go) | corrected (Go) |
|---|---|---|
| E1 | 630/630, 600/600 | 630/630, 600/600 |
| E2 | 30/31 | **31/31** |
| E3 R4 | 69/71 | **71/71** |
| E3 R4a | 20/21 | **21/21** |
| E4 | 18/18 | 18/18 |

Python unchanged across all suites. Go's 5 first-pass defects (D1 alias ×3, D2 negative-scale, D3 surrogate
reason) are all resolved; the corrected run reaches 0 failures.

## Regression failure register
Empty — **0 failures** across E1–E4 + R3-B controls.

## Reproducibility / integrity
Raw per-suite outputs committed (`E2_py/go.jsonl`, `E3_R4_*`, `E3_R4A_*`, `P03_E4_*`, `_e1_py/go.jsonl`).
First-pass results retrievable from prior commits (not overwritten in history). Corrected = post-evaluation, not
evaluator-blind. Identifiers `caa2f3e5…`/`d1e46eb5…` unchanged; expected evidence untouched.
Not executed this session: stage attribution, final R3 packaging, P04. Manuscript @`40376da` untouched.

## Scope caveat
E1/E2/E3 are historical/regression (not unseen); corpus purposive/template-correlated; no population error
probability claimed from zero failures; correctness is vs locked expected, agreement reported separately.
