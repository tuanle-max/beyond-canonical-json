# P03 Stage-1 R3 — REPORT (final closure)

Corrected implementations: Python `8bcad291`+expected_ids; Go `f34220d7`+D1/D2/D3+expected_ids (post-evaluation).
Identifiers unchanged `caa2f3e5…`/`d1e46eb5…`. Env: Py 3.12.9/unidata 15.0.0/rfc8785 0.1.3; Go 1.23.12 in `golang@sha256:1670…` (norm 15.0.0).

## Corrected regression (0 failures)
E1 630/630 admission, 600/600 canonical (both impls), pairs 150/150+150/150, py↔go 600/600; E2 31/31 both, pairs 12/12; R4 71/71, R4a 21/21 both; E4 18/18 batch/leaf/node/root both vs independent, py↔go 18/18; R3-B genuine-missing both `BATCH_FAILED` (root null), controls pass. First-pass preserved in prior commits.

## R3-C attribution corrections (2/2)
L3 positive control: L0–L2 identical, L3 differs. Corrected L5/L6: reorder → multiset same, order differs → L6. Original 11-perturbation result preserved (10 diverged / 9 matched); not rewritten.

## R3-D verification (`P03_R3D_VERIFICATION.json`)
- lock frozen ✔; **script bindings all match ✔**; freeze attestation identifiers + source commit ✔.
- **`lock_artifacts_all_match = FALSE`** — DISCREPANCY: several bound artifacts (e.g. `verify_preflight_package.py`, `UNICODE_CONFORMANCE_RESULTS.json`) were legitimately modified after the `ORACLE_LOCK.P03FINAL.json` snapshot. The lock therefore reflects an earlier snapshot and must be refreshed before being treated as authoritative over the current artifact set. Not concealed; not silently re-signed.
- J01: 630 unique legs, case membership exact, reconstructed input digests ✔.
- Mutations: baseline_exit 0, 8/8 detected, checksum-regenerated rejected by root recomputation ✔.
- Unicode: `full_nfc_conformance=false`; listed-record 95,370/95,370 both ✔.
- Independent reaggregation from raw outputs: E1 py/go 630/630 & 600/600; E2 31/31 both; R4 71/71 both; R4a 21/21 both ✔.

## Reproducibility (honest)
A portable reproduction entry point / fresh-extraction re-execution of both implementations over E1–E4 was **NOT executed** this session (execution-budget limit). **No clean-room reproduction is claimed.** Only archived-evidence verification + reaggregation from preserved raw outputs was executed.

## Claim–evidence–limitation
`SCIENTIFIC_CLAIM_MATRIX.R3.csv`. Not claimed: exhaustive Unicode, full clean-room reproduction, held-out generalization (P04 not run), population error probabilities, human-organization independence, OS-enforced isolation.

## Status
`next_phase_authorized: false`. P04 not started. Manuscript `tex/v18.tex` @40376da untouched. P02 not reopened.
