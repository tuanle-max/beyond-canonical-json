# Final Sentinel Collision — Correction Report

## Exact counterexample (frozen)
`beneficiary_code = "\uFFFD"`, `beneficiary = "\ud800"` (escaped unpaired surrogate preserved into the raw parser).

## Observed at runtime (pre-correction)
- **Go: `ACCEPT`** — UNSAFE: canonical bytes and leaf were produced for a malformed input (the predicted mechanism: both
  strings became U+FFFD, alias comparison saw equal strings, `find()` selected the valid canonical, alias `Bad` ignored).
- Python: `REJECT_PROHIBITED / ALIAS_CONFLICT` (its lone-surrogate value is retained and differs from the literal FFFD).

## Minimal correction (Go)
After the alias-conflict check, validate the malformed diagnostic on **both** supplied beneficiary aliases before canonical
selection: if `beneficiary_code.Bad` or `beneficiary.Bad` → `UNICODE_MALFORMED`. Sentinel-string equality is not used as
proof of original validity.

## Post-correction (runtime, both impls)
- COLLISION_U01 → Go `REJECT_MALFORMED/UNICODE_MALFORMED` (safe; no canonical/leaf). Python `ALIAS_CONFLICT`.
- REVERSE → both reject. VALID_LITERAL (`"\uFFFD"` only) → both **ACCEPT** (valid literal preserved).
- S05 → both `EVENT_ID_MALFORMED` (D3 field-specific reason unchanged).
Safety invariants held: valid literal U+FFFD and valid surrogate pairs preserved; duplicate-key strictness and
category/reason precedence unchanged; no canonical bytes or leaf for malformed; identifiers unchanged.

## Scope / note
This exact fixture closes the gap the prior WP1 U01 (`X\uFFFDB` vs `\ud800`, unequal strings → ALIAS_CONFLICT) did not
exercise. Broad new experiments not run; full WP1 U/M and D3 suites were not re-executed this session — S05 re-verified
directly, and the patch only adds a reject condition on malformed alias diagnostics (cannot admit a valid literal).
P02/locked expectations/manuscript untouched; P04 not started.
