# Stage Attribution Report (Agent V) — actual results

Diagnostic harness `scripts/p03_stage_attr.py` monkey-patches the **frozen** Python baseline (`8bcad291`) per perturbation with save/restore; baseline source unmodified. Traces: L0 admission, L1 typed, L2 eligible, L3 canonical, L4 profile/construction, L5 leaf, L6 batch order/accounting, L7 root.

## Results (11 perturbations)
| perturbation | expected | observed | attribution | diverged |
|---|---|---|---|---|
| admission_missing_tz | L0 | **L0** | PARSER/ADMISSION | ✓ |
| nfc_disabled | L1 | **L1** | SEMANTIC_TRANSFORM | ✓ |
| monetary_rounding_down | L1 | **L1** | SEMANTIC_TRANSFORM | ✓ |
| timestamp_truncation | L1 | **L1** | SEMANTIC_TRANSFORM | ✓ |
| eligible_mapping | L2 | **L2** | ELIGIBLE_JSON | ✓ |
| canonical_serialization | L3 | **NONE** | UNRESOLVED (no observable effect) | ✗ |
| semantic_profile_digest | L4 | **L4** | PROFILE IDENTITY | ✓ |
| construction_digest | L4 | **L4** | CONSTRUCTION IDENTITY | ✓ |
| leaf_encoding | L5 | **L5** | LEAF_ENCODING | ✓ |
| batch_ordering | L6 | **L5** | LEAF_ENCODING (ordered leaf list) | ✓ |
| tree_shape | L7 | **L7** | TREE_CONSTRUCTION | ✓ |

## Counts (actual)
- total perturbations: **11**
- diverged: **10 / 11**
- observed stage == expected stage: **9 / 11**
- observed stage != expected: **2 / 11**
- unresolved / no-effect: **1 / 11**

## Honest dispositions (not forced to match)
- **canonical_serialization → NONE**: for the chosen input the substitute canonicalizer (`json.dumps(sorted, compact)`) yields byte-identical output to RFC 8785 (no floats/exotic escapes), so the perturbation had **no observable effect** on L3. Reported as an explicit no-effect case; not forced to L3.
- **batch_ordering → observed L5 (expected L6)**: in this stage model the *ordered leaf digest list* is captured at L5, so a pure reorder first manifests at L5 before the L6 admitted-order/accounting field. Recorded as observed; the root (L7) also changes. This is a model-boundary observation, not a harness error.

## Integrity
- Baseline implementation source unmodified; each perturbation applied then reverted (save/restore).
- Baseline and perturbed traces preserved; no output JSON was edited to simulate attribution.
- No P04 evidence; manuscript untouched.

## Interpretation
Attribution discriminates the intended pipeline stage for 9/11 perturbations directly, with the two exceptions explained by (a) a canonical perturbation that is semantically transparent for the chosen input and (b) a documented L5-vs-L6 boundary for ordering. The harness therefore supports correct first-divergence localisation across most stages and reports the ambiguous cases candidly.
