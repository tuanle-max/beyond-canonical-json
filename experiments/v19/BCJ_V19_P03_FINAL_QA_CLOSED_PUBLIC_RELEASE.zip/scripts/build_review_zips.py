"""Build the two P01-R2 / P02-R1 review archives and their detached SHA-256 checksums."""
import hashlib, pathlib, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"

PKG_A = ["results/P00", "results/P01",
         "SSOT_LOCK.yaml", "EXPERIMENT_PROTOCOL.md", "METRIC_DICTIONARY.yaml",
         "STATISTICAL_ANALYSIS_PLAN.md", "BASELINE_FAIRNESS.md", "REQUIREMENTS_TRACEABILITY.csv",
         "THREAT_MODEL.md", "TEST_MATRIX.csv", "OPEN_ISSUES.md", "EXECUTION_STATUS.yaml"]
PKG_A_FILES = ["scripts/p01_admission.py", "scripts/verify_p01_metrics.py",
               "scripts/p01_mutation_tests.py", "scripts/p01r2_manuscript.py"]
PKG_A_EXTRA = [ROOT / "derived" / "results" / "j01_cases.json",
               ROOT / "derived" / "results" / "j01_summary.json"]

PKG_B = ["results/P02", "OPEN_ISSUES.md", "EXECUTION_STATUS.yaml"]


def build(name, entries, extra=()):
    out = V19 / name
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for e in entries:
            p = V19 / e
            if p.is_dir():
                for f in sorted(p.rglob("*")):
                    if f.is_file() and "__pycache__" not in f.parts:
                        zf.write(f, f.relative_to(V19).as_posix())
            elif p.is_file():
                zf.write(p, e)
        for f in extra:
            if f.exists():
                zf.write(f, f.relative_to(ROOT).as_posix())
    sha = hashlib.sha256(out.read_bytes()).hexdigest()
    (pathlib.Path(str(out) + ".sha256")).write_text(sha + "  " + name + "\n", encoding="utf-8")
    return out, sha


a, sa = build("BCJ_V19_P01_R2_REVIEW.zip", PKG_A, PKG_A_EXTRA)
b, sb = build("BCJ_V19_P02_R1_DRAFT_REVIEW.zip", PKG_B)
print("A", a.name, sa)
print("B", b.name, sb)