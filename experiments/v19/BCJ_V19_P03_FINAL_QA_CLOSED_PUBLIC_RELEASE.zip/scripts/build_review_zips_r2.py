"""Build the two P02-R2 review archives + detached SHA-256 files."""
import hashlib, pathlib, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"


def add_dir(zf, d):
    for f in sorted(d.rglob("*")):
        if f.is_file() and "__pycache__" not in f.parts:
            zf.write(f, f.relative_to(V19).as_posix())


def add_file(zf, name, out_name=None):
    p = V19 / name
    if p.exists():
        zf.write(p, (out_name or name))


def build(name, fn):
    out = V19 / name
    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        fn(zf)
    sha = hashlib.sha256(out.read_bytes()).hexdigest()
    (pathlib.Path(str(out) + ".sha256")).write_text(sha + "  " + name + "\n", encoding="utf-8")
    return name, sha


def pkg_closure(zf):
    add_dir(zf, V19 / "results" / "P01")
    add_file(zf, "results/P02/P01_CLOSURE_REPORT.md")
    add_file(zf, "results/P02/P01_CLOSURE_MUTATION_RESULT.json")
    for s in ("scripts/p01_admission.py", "scripts/verify_p01_metrics.py",
              "scripts/p01_mutation_tests.py", "scripts/p01_closure_mutation.py", "scripts/p01r2_manuscript.py"):
        add_file(zf, s)
    for ext, rel in ((ROOT / "scripts" / "jcommon.py", "scripts/jcommon.py"),
                     (ROOT / "derived" / "results" / "j01_cases.json", "derived/j01_cases.json"),
                     (ROOT / "derived" / "results" / "j01_summary.json", "derived/j01_summary.json")):
        if ext.exists():
            zf.write(ext, rel)


def pkg_r2(zf):
    add_dir(zf, V19 / "results" / "P02")
    add_file(zf, "EXECUTION_STATUS.yaml")
    add_file(zf, "OPEN_ISSUES.md")
    for s in ("scripts/p02r2_data.py", "scripts/p02r2_boundary.py"):
        add_file(zf, s)


print("A", build("BCJ_V19_P01_CLOSURE_REVIEW.zip", pkg_closure))
print("B", build("BCJ_V19_P02_R2_REVIEW.zip", pkg_r2))