"""P00 forensic audit: inventory + freeze of historical artifacts (read-only)."""
from __future__ import annotations
import datetime as _dt
import hashlib
import json
import pathlib
import subprocess
import sys
import csv

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / "experiments" / "v19" / "results" / "P00"
OUT.mkdir(parents=True, exist_ok=True)

# rows: artifact_id | relative_path | artifact_type | related_experiment (all historical)
ITEMS = """\
tex-v18|tex/v18.tex|manuscript|SSOT
j01-cases|derived/results/j01_cases.json|data|J01
j01-summary|derived/results/j01_summary.json|result|J01
j02-ablation|derived/results/j02_ablation.json|result|J02
j03-controls|derived/results/j03_controls.json|result|J03
j04-replay|derived/results/j04_replay.json|result|J04
g2-replay|derived/results/g2_actual_replay_results.json|result|G2
g2-manifest|derived/results/r2b_sample_manifest.json|data|G2
r2b-replay|derived/results/r2b_replay_results.json|result|R2B
stats|derived/stats_results.json|result|E0-E5
corpus|derived/corpus_v1.1.json|data|E0-E5
mining|derived/mining_raw.csv|data|Mining
golden|vectors/golden_v1.json|data|JCS
e0|derived/results/e0_salt_selftest.json|result|E0
e1|derived/results/e1_conformance.json|result|E1
e2|derived/results/e2_drift_ucr.json|result|E2
e3|derived/results/e3_classifier.json|result|E3
e3b|derived/results/e3b_omission_far.json|result|E3b
e4|derived/results/e4_baselines.json|result|E4
tco-json|derived/results/tco_model.json|result|TCO
tco-tex|derived/results/tco_model.tex|result|TCO
legacy-real|derived/legacy_validation_real.csv|data|CR-0006
legacy-eq6|derived/legacy_validation_real_eq6.csv|data|CR-0006
jcommon|scripts/jcommon.py|code|J01-J04/G2
g2-pipe|scripts/g2_actual_pipeline.py|code|G2
harness-j|scripts/harness_j_block.py|code|J01-J04
run-j02|scripts/run_j02_ablation.py|code|J02
run-j03j04|scripts/run_j03_j04_controls.py|code|J03/J04
bundle-builder|scripts/build_g1_r2_bundle.py|code|G2
cr0006-repro|scripts/drtea_eq6_repro.py|code|CR-0006
stats-pack|scripts/stats_pack.py|code|E0-E5
run-exp|scripts/run_experiments.py|code|E0-E5
gen-report|scripts/gen_report_all.py|code|report
verify-report|scripts/verify_report_all.py|code|qa
canon-hash|py/canon/hashing.py|code|canon
canon-transform|py/canon/transform.py|code|canon
canon-pipe|py/canon/pipeline.py|code|canon
canon-mut|py/canon/mutators.py|code|canon
canon-val|py/canon/schema_validator.py|code|canon
boo-lib|crates/boo/src/lib.rs|code|BOO
boo-equiv|crates/boo/src/equiv.rs|code|BOO
boo-types|crates/boo/src/types.rs|code|BOO
go-smoke|go/smoke/main.go|code|JCS
decimal-tests|tests/test_decimal_boundaries.py|test|P0-01
req-pins|pins/requirements.in|pin|deps
digests|pins/DIGESTS.json|pin|deps
js-canon|pins/js/canonicalize.js|code|JCS
g2-traces|EVIDENCE_BUNDLE_G1_R2/proofs/merkle_proof_traces.json|data|G2
g2-kat|EVIDENCE_BUNDLE_G1_R2/proofs/known_answer_vectors.json|data|G2
g2-verify|EVIDENCE_BUNDLE_G1_R2/proofs/verification_results.json|result|G2
g2-verifier|EVIDENCE_BUNDLE_G1_R2/src/independent_verifier.py|code|G2
protocol|docs/EXPERIMENT_PROTOCOL.md|doc|SSOT
freeze|docs/FREEZE.md|doc|SSOT
cr0006|docs/CR-0006-OPEN.md|doc|CR-0006
biz-rules|docs/business_rules.md|doc|SSOT
discrepancy|docs/DISCREPANCY_REPORT.md|doc|audit
""".strip().splitlines()


def main() -> int:
    rows, cl = [], []
    for line in ITEMS:
        aid, rel, typ, exp = line.split("|")
        p = ROOT / rel
        if p.exists():
            h = hashlib.sha256(p.read_bytes()).hexdigest()
            avail = "PRESENT"
        else:
            h = "MISSING"
            avail = "MISSING"
        rows.append([aid, rel, h, typ, exp, "historical", avail, "NOT_VERIFIED", ""])
        cl.append("%s  %s" % (h, rel))

    with (OUT / "ARTIFACT_INVENTORY.csv").open("w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["artifact_id", "relative_path", "sha256", "artifact_type",
                    "related_experiment", "historical_or_new", "availability",
                    "verification_status", "notes"])
        w.writerows(rows)

    cl.sort()
    (OUT / "SHA256SUMS").write_text("\n".join(cl) + "\n", encoding="utf-8", newline="\n")

    env = {
        "python": sys.version.split()[0], "platform": sys.platform, "executable": sys.executable,
        "git_commit": subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(),
        "git_branch": subprocess.run(["git", "rev-parse", "--abbrev-ref", "HEAD"], capture_output=True, text=True).stdout.strip(),
    }
    (OUT / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8")

    m = {"phase": "P00", "run_id": "P00-R1", "git_commit": env["git_commit"], "seed": None,
         "start_utc": _dt.datetime.now(_dt.timezone.utc).isoformat(), "exit_status": 0,
         "generated_by": "experiments/v19/scripts/p00_forensic.py",
         "input_artifact_count": sum(1 for r in rows if r[6] == "PRESENT"),
         "missing_artifact_count": sum(1 for r in rows if r[6] != "PRESENT")}
    (OUT / "RUN_MANIFEST.json").write_text(json.dumps(m, indent=2) + "\n", encoding="utf-8")
    (OUT / "commands.log").write_text(
        "P00-FORENSIC: python experiments/v19/scripts/p00_forensic.py\n", encoding="utf-8", newline="\n")

    n = len(rows)
    pres = sum(1 for r in rows if r[6] == "PRESENT")
    print("inventory %d rows, %d present, %d missing" % (n, pres, n - pres))
    print("wrote", OUT)
    for r in rows:
        if r[6] != "PRESENT":
            print("  MISSING:", r[0], r[1])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())