"""P01 closure: incorrect_pair_relationship mutation test + revision checksum manifest."""
import copy, hashlib, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
P01 = ROOT / "experiments" / "v19" / "results" / "P01"
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
CORPUS = ROOT / "derived" / "results" / "j01_cases.json"

cases = json.loads(CORPUS.read_text(encoding="utf-8"))["cases"]
KIND0 = {c["case_id"]: c["kind"] for c in cases}
LEGS = [json.loads(l) for l in (P01 / "raw" / "J01_PER_LEG_RESULTS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
MET = json.loads((P01 / "derived" / "J01_METRICS.json").read_text(encoding="utf-8"))


def pair_success(legs, kind):
    by = {}
    for p in legs:
        by.setdefault(p["case_id"], {})[p["leg_id"]] = p
    se = sd = 0
    for cid, k in kind.items():
        if k == "ambiguous":
            continue
        a, b = by.get(cid, {}).get("a"), by.get(cid, {}).get("b")
        if a and b and a["actual_admission"] == "ACCEPT" and b["actual_admission"] == "ACCEPT":
            if a["canonical_sha256"] == b["canonical_sha256"]:
                se += (k == "equivalent")
            else:
                sd += (k == "non_equivalent")
    return se, sd


def detects(kind):
    se, sd = pair_success(LEGS, kind)
    flagged = (MET.get("M2_equivalent_pair_success") != [se, 150]) or (MET.get("M3_distinct_pair_success") != [sd, 150])
    return flagged, se, sd


base = detects(copy.deepcopy(KIND0))
# mutation: relabel one equivalent pair as non_equivalent (incorrect pair relationship)
KIND = copy.deepcopy(KIND0)
eq_ids = [cid for cid, k in KIND.items() if k == "equivalent"]
KIND[eq_ids[0]] = "non_equivalent"
mut = detects(KIND)

res = {
    "test": "incorrect_pair_relationship",
    "description": "relabel one equivalent pair as non_equivalent; success metrics must not match",
    "baseline_detected": base[0],  # should be False (consistent)
    "baseline_SE_SD": [base[1], base[2]],
    "mutated_detected": mut[0],    # should be True (taint caught)
    "mutated_SE_SD": [mut[1], mut[2]],
    "outcome": "DETECTED" if (mut[0] and not base[0]) else "NOT_DETECTED",
}
(P02 / "P01_CLOSURE_MUTATION_RESULT.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")

# revision-specific checksum manifest (no self-reference; no SHA256SUMS self-reference)
CLOSE = [P01 / "raw" / "J01_PER_LEG_RESULTS.jsonl", P01 / "derived" / "J01_METRICS.json",
         P01 / "REPORT.md", P01 / "status.json", P01 / "PROCESS_DEVIATION_REPORT.md",
         P01 / "P01_ORACLE_INDEPENDENCE_AUDIT.md", P01 / "P01_ORACLE_DEPENDENCIES.json",
         P01 / "P01_LABEL_PROVENANCE.csv", P01 / "P01_EVIDENCE_CLASSIFICATION.md",
         P01 / "P01_METRIC_VERIFICATION.json", P01 / "P01_METRIC_RECONCILIATION.csv",
         P01 / "P01_TAMPER_TEST_RESULTS.json", P01 / "P01_TAMPER_TEST_REPORT.md",
         P01 / "MANUSCRIPT_FREEZE_ATTESTATION.json" if (P01 / "MANUSCRIPT_FREEZE_ATTESTATION.json").exists() else P02 / "MANUSCRIPT_FREEZE_ATTESTATION.json",
         ROOT / "scripts" / "jcommon.py", CORPUS, ROOT / "derived" / "results" / "j01_summary.json",
         ROOT / "experiments" / "v19" / "scripts" / "p01_admission.py",
         ROOT / "experiments" / "v19" / "scripts" / "verify_p01_metrics.py",
         ROOT / "experiments" / "v19" / "scripts" / "p01_mutation_tests.py"]
lines = []
for p in CLOSE:
    if p.exists():
        lines.append(hashlib.sha256(p.read_bytes()).hexdigest() + "  " + p.relative_to(ROOT).as_posix())
(P01 / "P01_REVISION_SHA256SUMS").write_text("\n".join(sorted(lines)) + "\n", encoding="utf-8")
print(json.dumps(res, indent=2))
print("revision entries", len(lines))