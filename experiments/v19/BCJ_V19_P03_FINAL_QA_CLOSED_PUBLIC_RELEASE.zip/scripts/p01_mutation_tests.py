"""P01-R2 / Task E - mutation & negative verification tests (in-memory copies)."""
import copy, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
P01 = ROOT / "experiments" / "v19" / "results" / "P01"
CORPUS = ROOT / "derived" / "results" / "j01_cases.json"

CASES = json.loads(CORPUS.read_text(encoding="utf-8"))["cases"]
KIND = {c["case_id"]: c["kind"] for c in CASES}
LEGS0 = [json.loads(l) for l in (P01 / "raw" / "J01_PER_LEG_RESULTS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
MET0 = json.loads((P01 / "derived" / "J01_METRICS.json").read_text(encoding="utf-8"))


def recompute(legs):
    adm = [p for p in legs if p["expected_partition"] == "D_K+"]
    amb = [p for p in legs if p["expected_partition"] == "D_K?"]
    by = {}
    for p in legs:
        by.setdefault(p["case_id"], {})[p["leg_id"]] = p
    se = sd = 0
    for cid, k in KIND.items():
        if k == "ambiguous":
            continue
        a, b = by.get(cid, {}).get("a"), by.get(cid, {}).get("b")
        if a and b and a["actual_admission"] == "ACCEPT" and b["actual_admission"] == "ACCEPT":
            if a["canonical_sha256"] == b["canonical_sha256"]:
                se += (k == "equivalent")
            else:
                sd += (k == "non_equivalent")
    return {
        "n_occ": len(legs),
        "n_case_ids": len({p["case_id"] for p in legs}),
        "n_adm": len(adm),
        "n_adm_acc": sum(1 for p in adm if p["actual_admission"] == "ACCEPT"),
        "n_amb": len(amb),
        "n_amb_acc": sum(1 for p in amb if p["actual_admission"] == "ACCEPT"),
        "SE": se, "SD": sd,
    }


def check(legs, met):
    r = recompute(legs)
    f = []
    if r["n_occ"] != 630:
        f.append("occurrence_count")
    if r["n_case_ids"] != 330:
        f.append("duplicate_or_missing_occurrence")
    if r["n_adm"] != 600:
        f.append("incorrect_partition")
    if r["n_adm_acc"] != 600:
        f.append("modified_admission")
    if r["SE"] != 150:
        f.append("equiv_pair_success")
    if r["SD"] != 150:
        f.append("distinct_pair_success")
    if met.get("M1_occurrence_weighted_coverage") != [600, 600]:
        f.append("incorrect_coverage_denominator")
    if met.get("M2_equivalent_pair_success") != [r["SE"], 150]:
        f.append("modified_summary_numerator")
    if met.get("M4_invalid_rejection") != "N/A (no D_K- cases)":
        f.append("M4_reported_100pct")
    if met.get("M6_unsafe_admission") != [r["n_amb_acc"], r["n_amb"]]:
        f.append("unsafe_admission_denominator")
    if met.get("_deg") is not None:
        f.append("incorrect_degenerate_baseline")
    return f


def mut(i, key, val):
    N = copy.deepcopy(LEGS0)
    N[i][key] = val
    return N


def mut_reject():
    N = copy.deepcopy(LEGS0)
    for p in N:
        if p["case_id"].startswith("EQ-") and p["leg_id"] == "b":
            p["actual_admission"] = "ABSTAIN_UNDERSPECIFIED"
            p["canonical_sha256"] = None
            break
    return N


res = {}


def add(name, legs, met=None):
    m = met if met is not None else copy.deepcopy(MET0)
    f = check(legs, m)
    res[name] = {"detected": len(f) > 0, "flags": f}


add("missing_occurrence", LEGS0[:-1])
add("duplicate_occurrence", LEGS0 + [LEGS0[0]])
add("incorrect_partition", mut(0, "expected_partition", "D_K?"))
add("modified_admission", mut(0, "actual_admission", "ABSTAIN_UNDERSPECIFIED"))
add("modified_canonical_digest", mut(0, "canonical_sha256", "0" * 64))
add("pair_success_despite_rejection", mut_reject())

def emit(results):
    (P01 / "P01_TAMPER_TEST_RESULTS.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    lines = ["# P01 mutation / negative-verification report", ""]
    for k, v in results.items():
        lines.append("- %s: %s -> %s" % (k, "DETECTED" if v["detected"] else "NOT DETECTED", ",".join(v["flags"])))
    lines.append("")
    lines.append("checksum-regenerated case is detected semantically (recompute), not via digest comparison.")
    (P01 / "P01_TAMPER_TEST_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


# summary-file mutations
# summary-file mutations
m = copy.deepcopy(MET0); m["M1_occurrence_weighted_coverage"] = [600, 500]; res["incorrect_coverage_denominator"] = {"detected": len(check(LEGS0, m)) > 0, "flags": check(LEGS0, m)}
m = copy.deepcopy(MET0); m["M4_invalid_rejection"] = "100%"; res["M4_reported_100pct"] = {"detected": len(check(LEGS0, m)) > 0, "flags": check(LEGS0, m)}
m = copy.deepcopy(MET0); m["M6_unsafe_admission"] = [0, 150]; res["incorrect_unsafe_denominator"] = {"detected": len(check(LEGS0, m)) > 0, "flags": check(LEGS0, m)}
m = copy.deepcopy(MET0); m["M2_equivalent_pair_success"] = [149, 150]; res["modified_summary_numerator"] = {"detected": len(check(LEGS0, m)) > 0, "flags": check(LEGS0, m)}
m = copy.deepcopy(MET0); m["_deg"] = [["B-REJECT-ALL", 600, 0, 0, 0, 30]]; res["incorrect_degenerate_baseline"] = {"detected": len(check(LEGS0, m)) > 0, "flags": check(LEGS0, m)}

# checksum-regenerated case
res["checksum_regenerated_modified_numerator"] = {"detected": res["modified_summary_numerator"]["detected"],
                                                   "note": "semantic detection, not digest-based",
                                                   "flags": res["modified_summary_numerator"]["flags"]}

emit(res)
print(json.dumps({k: v["detected"] for k, v in res.items()}, indent=2))
print("ALL_DETECTED:", all(v["detected"] for v in res.values()))