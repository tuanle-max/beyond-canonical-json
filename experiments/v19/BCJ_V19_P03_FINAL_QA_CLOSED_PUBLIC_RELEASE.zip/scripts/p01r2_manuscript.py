"""P01-R2 / Task B — manuscript SSOT hash + drift capture (read-only; never overwrites candidates)."""
from __future__ import annotations
import difflib, hashlib, json, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = ROOT / "experiments" / "v19" / "results" / "P01"
V18 = ROOT / "tex" / "v18.tex"
MSS = ROOT / "tex" / "MANUSCRIPT_SSOT.tex"
LEGACY = ROOT / "tex" / "manuscript.tex"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_head(path):
    r = subprocess.run(["git", "show", "HEAD:" + path], capture_output=True, text=True)
    return r.stdout if r.returncode == 0 else None


hashes = {
    "tex/v18.tex (working, untracked)": sha(V18),
    "tex/MANUSCRIPT_SSOT.tex (working, modified)": sha(MSS),
    "tex/MANUSCRIPT_SSOT.tex (HEAD committed)": hashlib.sha256(git_head("tex/MANUSCRIPT_SSOT.tex").encode()).hexdigest() if git_head("tex/MANUSCRIPT_SSOT.tex") is not None else "UNTRACKED/ABSENT",
    "tex/manuscript.tex (working)": sha(LEGACY),
    "v18 vs MANUSCRIPT_SSOT identical": (sha(V18) == sha(MSS)),
}
(OUT / "MANUSCRIPT_HASHES.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")

# drift diffs
head_mss = git_head("tex/MANUSCRIPT_SSOT.tex")
if head_mss is not None:
    wc_diff = list(difflib.unified_diff(head_mss.splitlines(), MSS.read_text(encoding="utf-8").splitlines(),
                                        "MANUSCRIPT_SSOT.tex@HEAD", "MANUSCRIPT_SSOT.tex@working", lineterm=""))
else:
    wc_diff = ["# MANUSCRIPT_SSOT.tex not present at HEAD"]

v18_mss = list(difflib.unified_diff(MSS.read_text(encoding="utf-8").splitlines(),
                                    V18.read_text(encoding="utf-8").splitlines(),
                                    "MANUSCRIPT_SSOT.tex@working", "v18.tex", lineterm=""))
(OUT / "MANUSCRIPT_DRIFT.diff").write_text("\n".join(wc_diff + ["", "# ===== v18 vs MANUSCRIPT_SSOT =====", ""] + v18_mss) + "\n", encoding="utf-8")

cand = {
    "reviewed_manuscript_digest_available": False,
    "candidate_hash": sha(V18),
    "parser_requires_author_confirm": True,
    "snapshots": {
        "v18.tex": hashes["tex/v18.tex (working, untracked)"],
        "MANUSCRIPT_SSOT.tex@working": hashes["tex/MANUSCRIPT_SSOT.tex (working, modified)"],
        "MANUSCRIPT_SSOT.tex@HEAD": hashes["tex/MANUSCRIPT_SSOT.tex (HEAD committed)"],
    },
}
(OUT / "MANUSCRIPT_SSOT_CANDIDATE.json").write_text(json.dumps(cand, indent=2) + "\n", encoding="utf-8")

n_wc = len(wc_diff) - 3 if len(wc_diff) >= 3 else 0
n_v18 = sum(1 for l in v18_mss if l.startswith(("+", "-")) and not l.startswith(("+++", "---")))
print("hashes:", json.dumps(hashes, indent=2))
print("working-tree diff hunks (lines):", n_wc, "; v18-vs-MSS changed lines:", n_v18)