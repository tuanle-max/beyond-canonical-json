"""P02-R1 / Task J - draft boundary/conformance suite (40 units). NOT executed."""
import json, pathlib, csv
from collections import Counter

OUT = pathlib.Path(__file__).resolve().parents[3] / "experiments" / "v19" / "results" / "P02"
OUT.mkdir(parents=True, exist_ok=True)

# (group, family, doc, expected_partition, expected_decision, rationale)
T = [
("Timestamp","timestamp",{"timestamp":"2026-02-30T00:00:00Z"},"D_K-","REJECT_MALFORMED","impossible date"),
("Timestamp","timestamp",{"timestamp":"2026-01-01T00:00:00+99:00"},"D_K-","REJECT_MALFORMED","offset range"),
("Timestamp","timestamp",{"timestamp":"2026-01-01"},"D_K?","ABSTAIN_UNDERSPECIFIED","missing tz"),
("Timestamp","timestamp",{"timestamp":"2026-01-01T00:00:00.1234567Z"},"D_K-","REJECT_MALFORMED","excess precision"),
("Timestamp","timestamp",{"timestamp":"2026-01-01T23:59:60Z"},"D_K-","REJECT_MALFORMED","leap second D-02"),
("Timestamp","timestamp",{"timestamp":"2026-01-01T07:00:00+07:00"},"D_K+","ACCEPT","valid offset"),
("Timestamp","timestamp",{"timestamp":"2026-01-01T00:00:00Z"},"D_K+","ACCEPT","valid Z"),
("Monetary","amount",{"amount":"NaN","scale":2,"currency":"USD"},"D_K-","REJECT_MALFORMED","non-finite"),
("Monetary","amount",{"amount":"1e9","scale":2,"currency":"USD"},"D_K-","REJECT_MALFORMED","scientific"),
("Monetary","amount",{"amount":"12.34.56","scale":2,"currency":"USD"},"D_K-","REJECT_MALFORMED","bad decimal"),
("Monetary","amount",{"amount":"9"*32,"scale":6,"currency":"USD"},"D_K-","REJECT_MALFORMED","overflow"),
("Monetary","amount",{"amount":"2.675","scale":2,"currency":"USD"},"D_K+","ACCEPT","half-up 268"),
("Monetary","amount",{"amount":"2.68","scale":2,"currency":"USD"},"D_K+","ACCEPT","exact"),
("Monetary","amount",{"amount":"-2.675","scale":2,"currency":"USD"},"D_K-","REJECT_PROHIBITED","negative D-03"),
("Unicode","unicode",{"beneficiary_code":"\ud800"},"D_K-","REJECT_MALFORMED","unpaired surrogate"),
("Unicode","unicode",{"beneficiary_code":"Jos\u00e9"},"D_K+","ACCEPT","NFC"),
("Unicode","unicode",{"beneficiary_code":"Jose\u0301"},"D_K+","ACCEPT","NFD->NFC"),
("Null/default","null",{"event_id":None},"D_K?","ABSTAIN_UNDERSPECIFIED","required null"),
("Null/default","null",{"obligation_ref":None},"D_K+","ACCEPT","null==absent D-06"),
("Null/default","null",{"obligation_ref":"OBL-1"},"D_K+","ACCEPT","present"),
("Alias/parser","alias",{"currency":"USD","cur":"USD"},"D_K+","ACCEPT","equal aliases"),
("Alias/parser","alias",{"currency":"USD","cur":"EUR"},"D_K-","REJECT_MALFORMED","conflict D-07"),
("Alias/parser","parser",'{"a":1,"a":2}',"D_K-","REJECT_MALFORMED","duplicate keys"),
("Alias/parser","parser","{bad json}","D_K-","REJECT_MALFORMED","malformed"),
("Timestamp","timestamp",{"timestamp":"not-a-date"},"D_K-","REJECT_MALFORMED","grammar"),
("Monetary","amount",{"amount":"","scale":2,"currency":"USD"},"D_K-","REJECT_MALFORMED","empty"),
("Monetary","amount",{"amount":1.5,"scale":2,"currency":"USD"},"D_K-","REJECT_MALFORMED","float"),
("Monetary","amount",{"amount":"0.005","scale":2,"currency":"USD"},"D_K+","ACCEPT","half-up 1"),
("Unicode","unicode",{"beneficiary_code":"abc\u0001"},"D_K-","REJECT_MALFORMED","control"),
("Unicode","unicode",{"beneficiary_code":"cafe"},"D_K+","ACCEPT","ascii"),
("Null/default","null",{"amount":None},"D_K?","ABSTAIN_UNDERSPECIFIED","amount null"),
("Null/default","null",{"event_id":"e","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"BC"},"D_K+","ACCEPT","obligation_ref absent"),
("Alias/parser","alias",{"cur":"USD"},"D_K+","ACCEPT","alias-only"),
("Alias/parser","parser",{"currency":"USD","unknown_field":"x"},"D_K+","ACCEPT","unknown ignored"),
("Alias/parser","parser",{"timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"BC","event_id":"e"},"D_K+","ACCEPT","fully valid"),
("Alias/parser","parser",{"timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"BC","event_id":"e","extra":1},"D_K+","ACCEPT","valid + extra"),
("Alias/parser","parser",{"timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"BC","event_id":"e","cur":"USD"},"D_K+","ACCEPT","currency+cur"),
("Monetary","amount",{"amount":"0.00","scale":2,"currency":"USD"},"D_K+","ACCEPT","zero"),
("Unicode","unicode",{"beneficiary_code":"Jos\u00e9"},"D_K+","ACCEPT","NFC pre"),
("Alias/parser","parser",{"amount":"1.00"},"D_K?","ABSTAIN_UNDERSPECIFIED","missing currency"),
]

V = [{"case_id":"BV-%02d"%(i+1),"group":g,"fault_family":f,"input":doc,"expected_partition":p,
      "expected_decision":d,"rationale":w,"status":"DRAFT"} for i,(g,f,doc,p,d,w) in enumerate(T)]

with (OUT/"P02_BOUNDARY_VECTORS.DRAFT.jsonl").open("w",encoding="utf-8") as fh:
    for v in V: fh.write(json.dumps(v,sort_keys=True)+"\n")
with (OUT/"P02_BOUNDARY_ORACLE_RATIONALES.DRAFT.jsonl").open("w",encoding="utf-8") as fh:
    for v in V: fh.write(json.dumps({"case_id":v["case_id"],"rationale":v["rationale"],"status":"DRAFT"},sort_keys=True)+"\n")
with (OUT/"MALFORMED_INPUT_COVERAGE_MATRIX.csv").open("w",encoding="utf-8",newline="") as fh:
    w=csv.writer(fh); w.writerow(["group","invalid_or_prohibited","valid_controls","total","status"])
    for g in ["Timestamp","Monetary","Unicode","Null/default","Alias/parser"]:
        inv=sum(1 for v in V if v["group"]==g and v["expected_partition"]=="D_K-")
        val=sum(1 for v in V if v["group"]==g and v["expected_partition"]=="D_K+")
        w.writerow([g,inv,val,inv+val,"DRAFT"])
    w.writerow(["TOTAL",sum(1 for v in V if v["expected_partition"]=="D_K-"),sum(1 for v in V if v["expected_partition"]=="D_K+"),len(V),"DRAFT"])
print("boundary vectors:",len(V),"partition",dict(Counter(v["expected_partition"] for v in V)))