"""P02-R2 boundary suite: start from a COMPLETE valid base record, apply one mutation per unit."""
import base64, json, pathlib, csv, copy
OUT = pathlib.Path(__file__).resolve().parents[3] / "experiments" / "v19" / "results" / "P02"
BASE = {"event_id": "EV-1", "timestamp": "2026-01-01T00:00:00Z", "amount": "100.00",
        "currency": "USD", "scale": 2, "beneficiary_code": "BC-1"}

def mk(i, g, fam, doc=None, raw=None, part="D_K+", dec="ACCEPT", why=""):
    d = {"case_id": "R2-%02d" % i, "group": g, "fault_family": fam,
         "expected_partition": part, "expected_decision": dec, "rationale": why, "status": "DRAFT"}
    if raw is not None:
        d["raw_bytes_hex"] = raw.hex(); d["input_bytes_base64"] = base64.b64encode(raw).decode()
    else:
        d["input"] = doc
    return d

def m(**kw):
    d = copy.deepcopy(BASE); d.update(kw); return d

V = [
 mk(1, "Timestamp", "timestamp", doc=m(timestamp="2026-02-30T00:00:00Z"), part="D_K-", dec="REJECT_MALFORMED", why="impossible date"),
 mk(2, "Timestamp", "timestamp", doc=m(timestamp="2026-01-01T23:59:60Z"), part="D_K-", dec="REJECT_MALFORMED", why="leap second D-02"),
 mk(3, "Timestamp", "timestamp", doc=m(timestamp="2026-01-01T00:00:00"), part="D_K?", dec="ABSTAIN_UNDERSPECIFIED", why="missing tz"),
 mk(4, "Timestamp", "timestamp", doc=m(timestamp="2026-01-01T00:00:00.123Z"), part="D_K+", dec="ACCEPT", why="sub-ms same class"),
 mk(5, "Timestamp", "timestamp", doc=m(timestamp="2026-01-01T00:00:00.999Z"), part="D_K+", dec="ACCEPT", why="sub-ms same ms class D-10"),
 mk(6, "Monetary", "amount", doc=m(amount="2.674999", scale=2), part="D_K+", dec="ACCEPT", why="rounds 267 R2-01"),
 mk(7, "Monetary", "amount", doc=m(amount="2.675", scale=2), part="D_K+", dec="ACCEPT", why="rounds 268"),
 mk(8, "Monetary", "amount", doc=m(amount="2.6750", scale=2), part="D_K+", dec="ACCEPT", why="rounds 268"),
 mk(9, "Monetary", "amount", doc=m(amount="0.005", scale=2), part="D_K+", dec="ACCEPT", why="rounds 1"),
 mk(10, "Monetary", "amount", doc=m(amount="0.004999", scale=2), part="D_K+", dec="ACCEPT", why="rounds 0"),
 mk(11, "Monetary", "amount", doc=m(amount=250.0), part="D_K+", dec="ACCEPT", why="decimal token exact D-09"),
 mk(12, "Monetary", "amount", doc=m(amount="-2.675", scale=2), part="D_K-", dec="REJECT_PROHIBITED", why="negative D-03"),
 mk(13, "Monetary", "amount", doc=m(amount="NaN"), part="D_K-", dec="REJECT_MALFORMED", why="non-finite"),
 mk(14, "Monetary", "amount", doc=m(amount="9"*32, scale=6), part="D_K-", dec="REJECT_MALFORMED", why="overflow"),
 mk(15, "Monetary", "scale", doc=m(scale=1), part="D_K-", dec="REJECT_PROHIBITED", why="USD scale must be 2 D-11"),
 mk(16, "Monetary", "currency", doc=m(currency="XXX"), part="D_K-", dec="REJECT_PROHIBITED", why="unsupported currency"),
 mk(17, "Unicode", "unicode", doc=m(beneficiary_code="Jos\u00e9"), part="D_K+", dec="ACCEPT", why="NFC"),
 mk(18, "Unicode", "unicode", doc=m(beneficiary_code="Jose\u0301"), part="D_K+", dec="ACCEPT", why="NFD->NFC equal"),
 mk(19, "Unicode", "unicode", doc=m(beneficiary_code="\uff21"), part="D_K+", dec="ACCEPT", why="fullwidth A distinct compat"),
 mk(20, "Unicode", "unicode", doc=m(beneficiary_code="\ud800"), part="D_K-", dec="REJECT_MALFORMED", why="unpaired surrogate"),
 mk(21, "Null/default", "null", doc=m(obligation_ref=None), part="D_K+", dec="ACCEPT", why="null==absent D-06"),
 mk(22, "Null/default", "null", doc=m(obligation_ref="OBL-9"), part="D_K+", dec="ACCEPT", why="present ref"),
 mk(23, "Null/default", "required", doc={k: v for k, v in BASE.items() if k != "currency"}, part="D_K?", dec="ABSTAIN_UNDERSPECIFIED", why="missing currency"),
 mk(24, "Alias", "alias", doc=m(cur="USD"), part="D_K+", dec="ACCEPT", why="equal alias"),
 mk(25, "Alias", "alias", doc=m(cur="EUR"), part="D_K-", dec="REJECT_PROHIBITED", why="conflict D-07"),
 mk(26, "Parser", "dup_key", raw=b'{"event_id":"EV-1","event_id":"EV-2","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2}', part="D_K-", dec="REJECT_MALFORMED", why="duplicate keys D-08"),
 mk(27, "Parser", "invalid_utf8", raw=b'{"beneficiary_code":"\xff\xfe"}', part="D_K-", dec="REJECT_MALFORMED", why="invalid UTF-8"),
 mk(28, "Parser", "malformed_json", raw=b'{"event_id":"EV-1",', part="D_K-", dec="REJECT_MALFORMED", why="truncated JSON"),
 mk(29, "Parser", "unknown_field", doc=m(secret_extra="x"), part="D_K-", dec="REJECT_PROHIBITED", why="closed schema D-12"),
]

with (OUT / "P02_BOUNDARY_VECTORS.R2.jsonl").open("w", encoding="utf-8") as fh:
    for v in V: fh.write(json.dumps(v, sort_keys=True) + "\n")
with (OUT / "P02_BOUNDARY_ORACLE_RATIONALES.R2.jsonl").open("w", encoding="utf-8") as fh:
    for v in V: fh.write(json.dumps({"case_id": v["case_id"], "rationale": v["rationale"], "status": "DRAFT"}, sort_keys=True) + "\n")

from collections import Counter
cnt = Counter(v["expected_partition"] for v in V)
with (OUT / "MALFORMED_INPUT_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["group", "D_K+", "D_K-", "D_K?", "total", "status"])
    for g in sorted({v["group"] for v in V}):
        gv = [v for v in V if v["group"] == g]
        w.writerow([g, sum(1 for v in gv if v["expected_partition"]=="D_K+"), sum(1 for v in gv if v["expected_partition"]=="D_K-"), sum(1 for v in gv if v["expected_partition"]=="D_K?"), len(gv), "DRAFT"])
    w.writerow(["TOTAL", cnt["D_K+"], cnt["D_K-"], cnt["D_K?"], len(V), "DRAFT"])
print("boundary R2:", len(V), dict(cnt))