"""P02-R2 generator part 1: decision register (uniform CSV via csv.writer)."""
import csv, pathlib
OUT = pathlib.Path(__file__).resolve().parents[3] / "experiments" / "v19" / "results" / "P02"

COLS = ["decision_id","fault_family","fields","historical_rule","observed_impl_behavior","proposed_k_v2_rule",
        "alternatives","recommended","scientific_rationale","business_rationale","compatibility","example",
        "counterexample","requires_human_approval","group","approval_status"]
ROWS = [
 ["D-01","Timestamp","timestamp","ISO-8601","accepts Z/offset; missing tz -> abstain","explicit timezone required; missing -> ABSTAIN","assume_utc","abstain","no silent instant assumption","time correctness","compatible","2026-01-01T00:00:00Z","2026-01-01T07:00:00 (no tz)","true","PRESERVE_K_V1","APPROVED"],
 ["D-02","Timestamp","timestamp","leap seconds unspecified","rejects :60","reject ':60' stable code","accept 23:59:59","reject","no silent leap-second policy","audit completeness","compatible","2026-01-01T23:59:59Z","2026-01-01T23:59:60Z","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-03","Monetary","amount","negatives unspecified","parse_minor computes negative minor","REJECT_PROHIBITED for negative; define -0","accept negatives","reject_prohibited","profile models non-negative payable","refunds out of scope","INTENTIONAL_CHANGE","refund out of scope","-100 rejected","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-04","Monetary","amount/currency","2-decimal half-up","round to minor then compare","equivalence = quantized payable amount + currency","exact pre-rounding","quantized","matches documented half-up","payable is post-quantization","compatible","2.675==2.680 after round","2.675 vs 2.674999 share class","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-05","Unicode","beneficiary_code","NFKC","NFKC normalizes","field-scoped NFC; opaque preserved","global normalization","nfc_field_scoped","intentional NFKC->NFC change","correct identifier semantics","INTENTIONAL_CHANGE","Jose NFC==NFD","fullwidth A != ASCII A","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-06","Null","obligation_ref","null==absent (M3)","beta null==absent","null==absent for obligation_ref only","global null removal","field_specific","preserves historical semantics","no distinct-state collapse","compatible","ref:null==omitted","null vs omitted distinct elsewhere","false","PRESERVE_K_V1","APPROVED"],
 ["D-07","Alias","currency/cur","unspecified","first-wins","conflicting aliases -> REJECT","last-write-wins","reject","no silent resolution","auditability","INTENTIONAL_CHANGE","cur==currency accepted","cur!=currency reject","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-08","Parser","all","unspecified","json.loads discards duplicates","reject duplicate keys before parse","last-write-wins","reject","prevents data loss","integrity","INTENTIONAL_CHANGE","unique keys","{a:1,a:2} reject","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-09","Monetary","amount","float accepted in K-v1","float(value)","accept raw decimal token exactly; no float64","reject numeric tokens","exact_decimal","token 250.0 is exact decimal","corpus has 250.0 tokens","INTENTIONAL_CHANGE",'"250.00" and token 250.0 both 25000',"float64 intermediate prohibited","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-10","Timestamp","timestamp","epoch-ms","int ms accepted","business resolution = integer epoch-ms","iso only","epoch_ms","ms equivalence class","matches historical t","compatible","same ms class equal","sub-ms boundary distinct","true","CLARIFY_WITHOUT_INTENDED_BEHAVIOR_CHANGE","APPROVED"],
 ["D-11","Monetary","currency/scale","unspecified","scale not validated per currency","fixed scale per currency registry","variable scale","fixed_registry","prevents 100 vs 100 collision","currency semantics","INTENTIONAL_CHANGE","USD scale 2","USD scale 1 reject","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
 ["D-12","Parser","all","unknown ignored","unknown fields ignored","closed schema; reject unknown except allowlisted metadata","ignore all","closed_schema","no silent field loss","integrity","INTENTIONAL_CHANGE","known fields only","unknown business field reject","true","INTENTIONAL_K_V2_BEHAVIOR_CHANGE","APPROVED"],
]
with (OUT / "CONTRACT_DECISION_REGISTER.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL)
    w.writerow(COLS)
    w.writerows(ROWS)
print("decision rows", len(ROWS), "cols", len(COLS))

FIELDS = ["field","aliases","required","accepted_raw_types","lexical_grammar","business_meaning","null_policy","missing_policy","default_policy","normalization","output_field","output_type","valid_range","equivalence_rule","reject_reason","abstain_reason"]
FROWS = [
 ["event_id","","required","string","[A-Za-z0-9_-]{1,256}","payment event identity","REJECT","ABSTAIN","none","exact","eid","string","non-empty","exact identity","EVENT_ID_MALFORMED","MISSING_EVENT_ID"],
 ["timestamp","","required","int epoch-ms | ISO string","ISO YYYY-MM-DD[T ]HH:MM[:SS][.f]{1..6}(Z|+hh:mm)","business instant","ABSTAIN","ABSTAIN","none","UTC->ms","t","int","int64 ms","same ms class","TIMESTAMP_MALFORMED","TIMESTAMP_MISSING_TZ"],
 ["amount","","required","decimal string | int | decimal token","grouped or plain decimal","payable amount","ABSTAIN","ABSTAIN","none","exact decimal","minor","int","non-negative","quantized class","AMOUNT_MALFORMED","AMOUNT_MISSING"],
 ["currency","cur","required","string","3-letter","currency code","ABSTAIN","ABSTAIN","none","upper; alias compare","cur","string","registry","equal code+scale","CURRENCY_CONFLICT","MISSING_CURRENCY"],
 ["scale","","required","int","0..6","minor-unit exponent","ABSTAIN","ABSTAIN","none","must match registry","(implicit)","int","registry","fixed per currency","SCALE_MISMATCH","MISSING_SCALE"],
 ["beneficiary_code","beneficiary","optional","string","unicode text","human-readable beneficiary","ABSTAIN","ABSTAIN","none","NFC","bc","string","text","NFC equal","FIELD_MALFORMED","MISSING_FIELD"],
 ["obligation_ref","","optional","string|null","unicode text","obligation reference (opaque)","null==absent","null==absent","none","exact","ref","string|null","text","exact/null==absent","FIELD_MALFORMED","MISSING_FIELD"],
]
with (OUT / "FIELD_SEMANTICS.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL); w.writerow(FIELDS); w.writerows(FROWS)

import json as _json
(OUT / "SUPPORTED_CURRENCY_SCALE_REGISTRY.json").write_text(_json.dumps({
  "schema": "drtea-currency-scale", "version": "1.0-DRAFT",
  "currencies": {"USD": 2, "EUR": 2, "VND": 0},
  "source": "currencies in historical J01 (USD, EUR) + KAT (VND)",
  "rule": "input scale MUST equal registry; mismatch -> SCALE_MISMATCH; unknown currency -> UNSUPPORTED_CURRENCY",
  "case": "uppercase ISO-4217 3-letter; compared after uppercasing"}, indent=2) + "\n", encoding="utf-8")

(OUT / "ERROR_TAXONOMY.yaml").write_text(
"error_taxonomy:\n"
"  precedence: [REJECT_MALFORMED, REJECT_PROHIBITED, ABSTAIN_UNDERSPECIFIED, INTERNAL_ERROR, TIMEOUT]\n"
"  REJECT_MALFORMED: [TIMESTAMP_MALFORMED, AMOUNT_MALFORMED, UNICODE_MALFORMED, DUPLICATE_KEY, MALFORMED_JSON, UNSUPPORTED_NUMERIC]\n"
"  REJECT_PROHIBITED: [NEGATIVE_AMOUNT, UNSUPPORTED_CURRENCY, SCALE_MISMATCH, CURRENCY_CONFLICT, UNKNOWN_FIELD]\n"
"  ABSTAIN_UNDERSPECIFIED: [MISSING_EVENT_ID, MISSING_CURRENCY, MISSING_SCALE, MISSING_FIELD, TIMESTAMP_MISSING_TZ]\n"
"  INTERNAL_ERROR: [ARITHMETIC_OVERFLOW, UNHANDLED_EXCEPTION]\n"
"  TIMEOUT: [EXCEEDED_BUDGET]\n",
encoding="utf-8", newline="\n")
print("fields", len(FROWS), "registry+taxonomy written")