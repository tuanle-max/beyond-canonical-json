"""CLOSURE-C: final-source attestation + archive-wide SHA256SUMS + CLOSED archive + gate matrix."""
import json, hashlib, pathlib, zipfile
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"; IMPL = V19 / "implementations"; SCR = V19 / "scripts"
def raw(p): return hashlib.sha256(p.read_bytes()).hexdigest()
GO = raw(IMPL / "go-dev/main.go"); PY = raw(IMPL / "python-dev/boo.py")
att = {
  "final_source_attestation": True,
  "python_final_sha256": PY, "go_final_sha256": GO,
  "initial_commits": {"python": "8bcad291", "go": "f34220d7"},
  "r3a_commit": "f269f701", "final_source_commit": "this-commit",
  "identifiers": {"pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
                  "construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"},
  "historical_locks_preserved": True,
  "note": "Historical oracle lock / evidence attestations preserved; this binds exact current source digests.",
}
(P03 / "P03_FINAL_SOURCE_ATTESTATION.json").write_text(json.dumps(att, indent=2) + "\n", encoding="utf-8")

lines = []
for base, pref in ((P02, "results/P02/"), (P03, "results/P03/"), (IMPL, "implementations/"), (SCR, "scripts/")):
    for p in sorted(base.rglob("*")):
        if p.is_file() and p.name != "SHA256SUMS" and not p.name.startswith("SHA256SUMS"):
            lines.append("%s  %s%s" % (raw(p), pref, str(p.relative_to(base)).replace("\\", "/")))
(P03 / "ARCHIVE_WIDE_SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

zp = V19 / "BCJ_V19_P03_CLOSED_REPRODUCTION_REVIEW.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for base, pref in ((P02, "results/P02/"), (P03, "results/P03/"), (IMPL, "implementations/"), (SCR, "scripts/")):
        for p in sorted(base.rglob("*")):
            if p.is_file():
                z.write(p, pref + str(p.relative_to(base)).replace("\\", "/"))
zsha = raw(zp)
(V19 / "BCJ_V19_P03_CLOSED_REPRODUCTION_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P03_CLOSED_REPRODUCTION_REVIEW.zip\n" % zsha, encoding="utf-8")
with zipfile.ZipFile(zp) as z:
    crc = z.testzip(); names = z.namelist(); cnt = len(names)

gates = {
  "aggregation_all_suites": "MET (P03_R3D_VERIFICATION + E1_CORRECTED + E4_OCCURRENCE + E2/E3/R4/R4A metrics)",
  "j01_reconstruction": "MET (j01_membership_exact=true, 630 unique legs)",
  "mutation_tests": "PARTIAL (8/8 detected + baseline 0 recorded; per-mutation stdout not re-captured this session)",
  "package_level_reproduction_fresh_extraction": "NOT_EXECUTED (Priority 1 ran in-repo via harness; not from a re-extracted candidate)",
  "packaging": "COMPLETE (archive built, archive-wide SHA256SUMS, detached sha, CRC/inventory verified)",
  "overall": "PARTIAL",
  "unseen_generalization": False, "offline_reproduction": False, "third_party_replication": False,
  "next_phase_authorized": False, "p04": "NOT_STARTED",
}
(P03 / "FINAL_GATE_MATRIX.json").write_text(json.dumps(gates, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"zip": str(zp), "sha256": zsha, "entries": cnt, "crc_ok": crc is None, "opens": True,
                  "py_sha": PY, "go_sha": GO, "overall": gates["overall"],
                  "failed_gate": gates["package_level_reproduction_fresh_extraction"]}, indent=2))