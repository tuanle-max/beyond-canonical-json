"""Exact sentinel-collision counters: collision / reverse / valid-literal / S05. phase=pre|post; both impls."""
import json, base64, subprocess, pathlib, sys
V19 = pathlib.Path(__file__).resolve().parents[1]; P03 = V19 / "results/P03"
PYD = V19 / "implementations/python-dev"; GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"; CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
phase = sys.argv[1] if len(sys.argv) > 1 else "pre"
BASE = '{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,'
CTRL = {
 "COLLISION_U01": (BASE + '"beneficiary_code":"\\uFFFD","beneficiary":"\\ud800"}').encode(),
 "REVERSE": (BASE + '"beneficiary_code":"\\ud800","beneficiary":"\\uFFFD"}').encode(),
 "VALID_LITERAL": (BASE + '"beneficiary_code":"\\uFFFD"}').encode(),
}
# S05 raw from locked expected
for r in [json.loads(l) for l in (V19 / "results/P02/R4A_CORRECTIVE_EXPECTED.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]:
    if r["case_id"] == "S05":
        CTRL["S05"] = base64.b64decode(r["input_b64"])
lines = [json.dumps({"record_id": k, "raw_b64": base64.b64encode(v).decode(), "pid_sem": PID, "construction_digest": CD}) for k, v in CTRL.items()]
rec = P03 / ("coll_%s_records.jsonl" % phase); rec.write_text("\n".join(lines) + "\n", encoding="utf-8")
py = P03 / ("coll_%s_py.jsonl" % phase)
subprocess.run([sys.executable, str(PYD / "boo.py"), "adjudicate", "--in", str(rec), "--out", str(py)], capture_output=True, text=True)
g = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "cd /work && /usr/local/go/bin/go build -o /tmp/boo . && /tmp/boo adjudicate /data/coll_%s_records.jsonl /data/coll_%s_go.jsonl" % (phase, phase)],
                   capture_output=True, text=True)
def L(p): return {j["record_id"]: j for j in [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]}
P = L(py); G = L(P03 / ("coll_%s_go.jsonl" % phase))
rows = []
for k in CTRL:
    def safe(o):
        if k in ("COLLISION_U01", "REVERSE", "S05"):
            return o.get("admission") != "ACCEPT" and o.get("canonical_bytes_hex") is None and o.get("leaf_digest") is None
        return o.get("admission") == "ACCEPT"
    rows.append({"control": k, "py": [P.get(k, {}).get("admission"), P.get(k, {}).get("reason_code"), safe(P.get(k, {}))],
                 "go": [G.get(k, {}).get("admission"), G.get(k, {}).get("reason_code"), safe(G.get(k, {}))]})
out = {"phase": phase, "go_exit": g.returncode, "rows": rows}
(P03 / ("FINAL_SENTINEL_COLLISION_RESULTS_%s.json" % phase)).write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))