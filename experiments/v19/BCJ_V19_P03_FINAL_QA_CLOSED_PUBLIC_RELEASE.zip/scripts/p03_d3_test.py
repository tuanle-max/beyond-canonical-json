"""D3 targeted: build corrected Go, run S05 + Unicode/parser/multi-fault, verify no malformed admission."""
import json, subprocess, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"
GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"


def jl(p):
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


raw = {}
for k in jl(P02 / "P02_BOUNDARY_KAT.R4.jsonl"):
    raw[k["case_id"]] = (k["input_bytes_base64"], k["expected_decision"], k["expected_reason_code"])
for r in jl(P02 / "R4_ADVERSARIAL_EXPECTED.jsonl"):
    raw[r["case_id"]] = (r["input_b64"], r["expected_decision"], r["expected_reason"])
for r in jl(P02 / "R4A_CORRECTIVE_EXPECTED.jsonl"):
    raw[r["case_id"]] = (r["input_b64"], r["expected_decision"], r["expected_reason"])
raw["MULTI"] = (__import__("base64").b64encode(b'{"event_id":"\\ud800","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B","zzz":1}').decode(),
                "REJECT_MALFORMED", "EVENT_ID_MALFORMED")

IDS = ["S05", "S01", "S02", "F02", "H01", "H05", "MULTI"]
lines = [json.dumps({"record_id": i, "raw_b64": raw[i][0], "pid_sem": PID, "construction_digest": CD}) for i in IDS]
rec = P03 / "d3_records.jsonl"; rec.write_text("\n".join(lines) + "\n", encoding="utf-8")
g = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "/usr/local/go/bin/go build -o /tmp/boo . && /tmp/boo adjudicate /data/d3_records.jsonl /data/d3_go.jsonl"],
                   capture_output=True, text=True)
go = {j["record_id"]: j for j in jl(P03 / "d3_go.jsonl")} if (P03 / "d3_go.jsonl").exists() else {}
rows = []
for i in IDS:
    ed, er = raw[i][1], raw[i][2]
    o = go.get(i, {})
    admitted = o.get("admission") == "ACCEPT"
    safe = True
    if er is None:  # expected accept
        safe = admitted and o.get("canonical_bytes_hex") and o.get("leaf_digest")
    else:
        safe = (not admitted) and o.get("canonical_bytes_hex") is None and o.get("leaf_digest") is None
    rows.append({"case": i, "expected": [ed, er], "observed": [o.get("admission"), o.get("reason_code")],
                 "admission_ok": o.get("admission") == ed, "reason_ok": o.get("reason_code") == er,
                 "no_malformed_admission_or_output": safe})
res = {"go_exit": g.returncode, "go_err": g.stderr[-400:], "cases": rows,
       "summary": {"all_admission_ok": all(r["admission_ok"] for r in rows),
                   "all_reason_ok": all(r["reason_ok"] for r in rows),
                   "s05_reason_ok": [r for r in rows if r["case"] == "S05"][0]["reason_ok"],
                   "safety_all": all(r["no_malformed_admission_or_output"] for r in rows)}}
(P03 / "D3_RESOLUTION_RESULTS.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
print(json.dumps(rows, indent=2)); print("go_exit", g.returncode, "summary", res["summary"])