"""Corrected E1 reaggregation from PRESERVED first-pass outputs (no impl rerun). Correct denominators; independent per-impl."""
import json, pathlib, hashlib
V19 = pathlib.Path(__file__).resolve().parents[1]
PYD = V19 / "implementations/python-dev"
GOD = V19 / "implementations/go-dev"
P02 = V19 / "results/P02"


def load(p):
    d = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            j = json.loads(line)
            d[j["record_id"]] = j
    return d


exp = [json.loads(l) for l in (P02 / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
kind = {c["case_id"]: c["kind"] for c in json.loads((P02 / "J01_SOURCE_CORPUS.json").read_text(encoding="utf-8"))["cases"]}
PY = load(PYD / "_e1_py.jsonl")
GO = load(GOD / "_e1_go.jsonl")

# duplicate/membership guard
assert len(PY) == 630 and len(GO) == 630, (len(PY), len(GO))
exp_ids = {e["case_id"] + ":" + e["leg_id"] for e in exp}
assert set(PY) == exp_ids and set(GO) == exp_ids, "membership mismatch"

N = len(exp)


def evalm(out):
    adm = rea = typ = elg = can = cov = 0
    unsafe = fr = fnadm = abst = 0
    nonadm_total = 0
    per = {}
    for e in exp:
        rid = e["case_id"] + ":" + e["leg_id"]; o = out[rid]
        adm += o["admission"] == e["expected_admission"]
        rea += o.get("reason_code") == e["expected_reason_code"]
        if e["expected_admission"] == "ACCEPT":
            cov += o["admission"] == "ACCEPT"
            typ += o.get("typed_business_object") == e["expected_business_object"]
            elg += o.get("eligible_json") == e["expected_eligible_json"]
            expb = e["expected_canonical_bytes_b64"]
            can += (o.get("canonical_bytes_hex") == __import__("base64").b64decode(expb).hex()) if expb else (o.get("canonical_bytes_hex") is None)
            if o["admission"] == "ACCEPT":
                pass
            else:
                fnadm += 1
                if o["admission"] in ("REJECT_PROHIBITED", "REJECT_MALFORMED"):
                    fr += 1
        else:
            nonadm_total += 1
            abst += o["admission"] == "ABSTAIN_UNDERSPECIFIED"
            if o["admission"] == "ACCEPT":
                unsafe += 1
        per.setdefault(e["case_id"], {})[e["leg_id"]] = o
    eq = eqt = ne = net = 0
    for cid, legs in per.items():
        a = legs.get("A"); b = legs.get("B")
        if not a or not b:
            continue
        same = a.get("typed_business_object") is not None and b.get("typed_business_object") is not None and a["typed_business_object"] == b["typed_business_object"]
        if kind.get(cid) == "equivalent":
            eqt += 1; eq += same
        elif kind.get(cid) == "non_equivalent":
            net += 1; ne += (a.get("typed_business_object") is not None and b.get("typed_business_object") is not None and not same)
    return {
        "occurrences": N,
        "admission_correct": [adm, N], "reason_correct": [rea, N],
        "valid_coverage": [cov, 600], "typed_object_correct": [typ, 600],
        "eligible_json_correct": [elg, 600], "canonical_bytes_correct": [can, 600],
        "unsafe_admission": [unsafe, nonadm_total], "false_rejection": [fr, 600], "false_non_admission": [fnadm, 600],
        "abstention_correct": [abst, nonadm_total],
        "equivalent_pair_success": [eq, eqt], "distinct_pair_success": [ne, net],
    }


py = evalm(PY); go = evalm(GO)

# exact canonical bytes python vs go on jointly admitted
joint = agree = 0
for e in exp:
    if e["expected_admission"] != "ACCEPT":
        continue
    rid = e["case_id"] + ":" + e["leg_id"]
    pb = PY[rid].get("canonical_bytes_hex"); gb = GO[rid].get("canonical_bytes_hex")
    if pb and gb:
        joint += 1; agree += (pb == gb)

out = {
    "note": "Reaggregated from preserved first-pass outputs; corrected denominators; independent per-impl vs locked expected.",
    "python_vs_expected": py, "go_vs_expected": go,
    "python_vs_go_canonical_bytes": [agree, joint],
    "preserved_outputs": {
        "python": {"path": "implementations/python-dev/_e1_py.jsonl", "sha256": hashlib.sha256((PYD / "_e1_py.jsonl").read_bytes()).hexdigest()},
        "go": {"path": "implementations/go-dev/_e1_go.jsonl", "sha256": hashlib.sha256((GOD / "_e1_go.jsonl").read_bytes()).hexdigest()},
    },
}
(P02 / "P03_E1_METRICS.CORRECTED.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))