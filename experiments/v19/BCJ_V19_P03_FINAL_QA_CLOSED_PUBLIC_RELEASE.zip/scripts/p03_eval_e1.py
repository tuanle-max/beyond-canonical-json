"""Agent V evaluator: E1 J01 (630) cross-language run of frozen Python + Go implementations vs locked expected."""
import json, subprocess, sys, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
PYD = V19 / "implementations/python-dev"
GOD = V19 / "implementations/go-dev"
P02 = V19 / "results/P02"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"

exp = [json.loads(l) for l in (P02 / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
kind = {c["case_id"]: c["kind"] for c in json.loads((P02 / "J01_SOURCE_CORPUS.json").read_text(encoding="utf-8"))["cases"]}

lines = []
for e in exp:
    lines.append(json.dumps({"record_id": e["case_id"] + ":" + e["leg_id"], "raw_b64": e["reconstructed_input_b64"],
                             "pid_sem": PID, "construction_digest": CD}))
recs = "\n".join(lines) + "\n"
for d in (PYD, GOD):
    (d / "_e1_records.jsonl").write_text(recs, encoding="utf-8")

py = subprocess.run([sys.executable, str(PYD / "boo.py"), "adjudicate", "--in", str(PYD / "_e1_records.jsonl"),
                     "--out", str(PYD / "_e1_py.jsonl")], capture_output=True, text=True)
go = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-w", "/work", IMG, "bash", "-c",
                     "/usr/local/go/bin/go run . adjudicate _e1_records.jsonl _e1_go.jsonl"], capture_output=True, text=True)

def load(p):
    d = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            j = json.loads(line)
            d[j["record_id"]] = j
    return d

PY = load(PYD / "_e1_py.jsonl")
GO = load(GOD / "_e1_go.jsonl")
N = len(exp)
adm = rea = obj = elig = can = cov = unsafe = false_rej = abst_ok = 0
joint = uncond = 0
eq_ok = eq_tot = ne_ok = ne_tot = 0
per_case_py = {}
for e in exp:
    rid = e["case_id"] + ":" + e["leg_id"]
    p = PY.get(rid); g = GO.get(rid)
    if not p:
        continue
    adm += p["admission"] == e["expected_admission"]
    rea += (p.get("reason_code") == e["expected_reason_code"])
    if e["expected_admission"] == "ACCEPT":
        cov += (p["admission"] == "ACCEPT")
        obj += (p.get("typed_business_object") == e["expected_business_object"])
        elig += (p.get("eligible_json") == e["expected_eligible_json"])
        can += (p.get("canonical_sha256") == e["expected_canonical_sha256"])
        if p.get("canonical_sha256") and g and g.get("canonical_sha256"):
            joint += 1
            uncond += (p["canonical_sha256"] == g["canonical_sha256"])
        unsafe += (p["admission"] != "ACCEPT")
    else:
        abst_ok += (p["admission"] == e["expected_admission"])
        false_rej += (p["admission"] == "REJECT_PROHIBITED" or p["admission"] == "REJECT_MALFORMED")
    per_case_py.setdefault(e["case_id"], {})[e["leg_id"]] = p

for cid, legs in per_case_py.items():
    k = kind.get(cid)
    a = legs.get("A"); b = legs.get("B")
    if a is None or b is None:
        continue
    eq = a.get("typed_business_object") is not None and b.get("typed_business_object") is not None and a["typed_business_object"] == b["typed_business_object"]
    if k == "equivalent":
        eq_tot += 1; eq_ok += eq
    elif k == "non_equivalent":
        ne_tot += 1; ne_ok += (not eq and a.get("typed_business_object") is not None and b.get("typed_business_object") is not None)

out = {
    "E1_occurrences": N, "python_exit": py.returncode, "go_exit": go.returncode,
    "python_records": len(PY), "go_records": len(GO),
    "admission_correct": [adm, N], "reason_correct": [rea, N],
    "valid_coverage_accepted": [cov, 600], "typed_object_correct": [obj, 600],
    "eligible_json_correct": [elig, 600], "canonical_correct": [can, 600],
    "abstention_correct": [abst_ok, 30], "unsafe_admission": [unsafe, 600], "false_rejection": [false_rej, 30],
    "equivalent_pair_success": [eq_ok, eq_tot], "distinct_pair_success": [ne_ok, ne_tot],
    "conditional_canonical_agreement": [uncond, joint] if joint else "N/A",
    "unconditional_canonical_agreement": [uncond, 600],
}
(P02 / "P03_E1_METRICS.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))