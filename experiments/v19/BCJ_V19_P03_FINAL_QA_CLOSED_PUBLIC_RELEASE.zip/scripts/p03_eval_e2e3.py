"""Agent V: execute E2 (31 boundary) and E3 (R4 71, R4a 21) on both frozen impls vs locked expected."""
import json, csv, io, subprocess, sys, pathlib, hashlib
import rfc8785
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"
P03 = V19 / "results/P03"; P03.mkdir(parents=True, exist_ok=True)
PYD = V19 / "implementations/python-dev"
GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"


def bsha(b):
    return hashlib.sha256(b).hexdigest()


def load(p):
    d = {}
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            j = json.loads(line)
            d[j["record_id"]] = j
    return d


def run_both(tag, exp_items):
    lines = [json.dumps({"record_id": e["id"], "raw_b64": e["raw_b64"], "pid_sem": PID,
                         "construction_digest": CD}) for e in exp_items]
    rec = P03 / (tag + "_records.jsonl"); rec.write_text("\n".join(lines) + "\n", encoding="utf-8")
    py_out = P03 / (tag + "_py.jsonl"); go_out = P03 / (tag + "_go.jsonl")
    py = subprocess.run([sys.executable, str(PYD / "boo.py"), "adjudicate", "--in", str(rec), "--out", str(py_out)],
                        capture_output=True, text=True)
    go = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG,
                         "bash", "-c", "/usr/local/go/bin/go run . adjudicate /data/" + tag + "_records.jsonl /data/" + tag + "_go.jsonl"],
                        capture_output=True, text=True)
    return {"py_rc": py.returncode, "go_rc": go.returncode, "py_err": py.stderr[-400:], "go_err": go.stderr[-400:],
            "PY": load(py_out) if py_out.exists() else {}, "GO": load(go_out) if go_out.exists() else {}}


def metrics(out, exp_items):
    N = len(exp_items)
    acc = [e for e in exp_items if e["decision"] == "ACCEPT"]
    non = [e for e in exp_items if e["decision"] != "ACCEPT"]
    nA, nN = len(acc), len(non)
    adm = rea = cov = typ = elg = can = dig = leaf = 0
    mal_c = mal_t = proh_c = proh_t = abst_c = unsafe = fr = fna = ie = 0
    for e in exp_items:
        o = out.get(e["id"])
        if o is None:
            continue
        ie += o.get("admission") == "INTERNAL_ERROR"
        adm += o["admission"] == e["decision"]
        rea += o.get("reason_code") == e["reason"]
        if e["decision"] == "ACCEPT":
            cov += o["admission"] == "ACCEPT"
            typ += o.get("typed_business_object") == e["obj"]
            elg += o.get("eligible_json") == e["obj"]
            cb = o.get("canonical_bytes_hex")
            can += cb == e["canon_hex"]
            if cb:
                dig += o.get("canonical_sha256") == bsha(bytes.fromhex(cb))
                pre = b"\x00\x03" + bytes.fromhex(PID) + bytes.fromhex(CD) + bytes.fromhex(cb)
                leaf += o.get("leaf_digest") == bsha(pre)
            if o["admission"] != "ACCEPT":
                fna += 1
                if o["admission"] in ("REJECT_PROHIBITED", "REJECT_MALFORMED"):
                    fr += 1
        else:
            if o["admission"] == "ACCEPT":
                unsafe += 1
            if e["decision"] == "REJECT_MALFORMED":
                mal_t += 1; mal_c += o["admission"] == "REJECT_MALFORMED"
            elif e["decision"] == "REJECT_PROHIBITED":
                proh_t += 1; proh_c += o["admission"] == "REJECT_PROHIBITED"
            elif e["decision"] == "ABSTAIN_UNDERSPECIFIED":
                abst_c += o["admission"] == "ABSTAIN_UNDERSPECIFIED"
    return {
        "N": N,
        "admission_correct": [adm, N], "reason_correct": [rea, N],
        "valid_coverage": [cov, nA], "typed_correct": [typ, nA], "eligible_correct": [elg, nA],
        "canonical_bytes_correct": [can, nA], "canonical_digest_recomputed": [dig, nA], "leaf_correct": [leaf, nA],
        "correct_malformed_rejection": [mal_c, mal_t] if mal_t else "N/A",
        "correct_prohibited_rejection": [proh_c, proh_t] if proh_t else "N/A",
        "correct_abstention": [abst_c, nN] if nN else "N/A",
        "unsafe_admission": [unsafe, nN] if nN else "N/A",
        "false_rejection": [fr, nA] if nA else "N/A",
        "false_non_admission": [fna, nA] if nA else "N/A",
        "internal_errors": ie,
    }


def agreement(R):
    joint = agr = 0
    for e in R["exp_items"]:
        if e["decision"] != "ACCEPT":
            continue
        p = R["PY"].get(e["id"]); g = R["GO"].get(e["id"])
        if p and g and p.get("canonical_bytes_hex") and g.get("canonical_bytes_hex"):
            joint += 1
            agr += p["canonical_bytes_hex"] == g["canonical_bytes_hex"]
    return {"jointly_admitted": joint, "canonical_agree": agr}


def e2_items():
    kat = [json.loads(l) for l in (P02 / "P02_BOUNDARY_KAT.R4.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    out = []
    for k in kat:
        obj = k.get("expected_eligible_json")
        out.append({"id": k["case_id"], "raw_b64": k["input_bytes_base64"], "decision": k["expected_decision"],
                    "reason": k["expected_reason_code"], "obj": obj,
                    "canon_hex": rfc8785.dumps(obj).hex() if obj is not None else None})
    return out


def e3_items(fn):
    rows = [json.loads(l) for l in (P02 / fn).read_text(encoding="utf-8").splitlines() if l.strip()]
    return [{"id": r["case_id"], "raw_b64": r["input_b64"], "decision": r["expected_decision"],
             "reason": r["expected_reason"], "obj": r["expected_object"], "canon_hex": r["expected_canonical_hex"]} for r in rows]


def run_suite(tag, exp_items):
    R = run_both(tag, exp_items); R["exp_items"] = exp_items
    res = {"tag": tag, "python_exit": R["py_rc"], "go_exit": R["go_rc"],
           "python_records": len(R["PY"]), "go_records": len(R["GO"]),
           "python_vs_expected": metrics(R["PY"], exp_items), "go_vs_expected": metrics(R["GO"], exp_items),
           "python_vs_go_canonical": agreement(R)}
    for e in exp_items:
        p = R["PY"].get(e["id"], {}); g = R["GO"].get(e["id"], {})
        if p.get("admission") != e["decision"] or p.get("reason_code") != e["reason"] or g.get("admission") != e["decision"] or g.get("reason_code") != e["reason"]:
            pass
    rows = [{"case_id": e["id"], "expected": [e["decision"], e["reason"]],
             "py": [R["PY"].get(e["id"], {}).get("admission"), R["PY"].get(e["id"], {}).get("reason_code")],
             "go": [R["GO"].get(e["id"], {}).get("admission"), R["GO"].get(e["id"], {}).get("reason_code")]} for e in exp_items]
    (P03 / (tag + "_COMPARE.jsonl")).write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8")
    return res, R


logs = []
e2 = run_suite("E2", e2_items())
r2m, R2 = e2
pairs = list(csv.DictReader(io.StringIO((P02 / "P02_BOUNDARY_PAIR_REGISTER.R4.csv").read_text(encoding="utf-8"))))
prow = []; pbad = 0
for pr in pairs:
    a = R2["PY"].get(pr["leg_a"]); b = R2["PY"].get(pr["leg_b"]); rel = pr["expected_equivalence"]
    ao = a.get("typed_business_object") if a else None; bo = b.get("typed_business_object") if b else None
    if rel == "business-equal":
        ok = ao is not None and bo is not None and ao == bo
    elif rel == "business-distinct":
        ok = ao is not None and bo is not None and ao != bo
    elif rel == "admission-differs":
        ok = bool(a and b and a.get("admission") != b.get("admission"))
    else:
        ok = False
    pbad += (not ok)
    prow.append({"pair_id": pr["pair_id"], "leg_a": pr["leg_a"], "leg_b": pr["leg_b"], "expected": rel, "pass": ok})
(P03 / "P03_E2_PAIR_RESULTS.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in prow), encoding="utf-8")
r2m["pairs"] = {"n": len(pairs), "pass": len(pairs) - pbad, "fail": pbad}
(P03 / "P03_E2_METRICS.json").write_text(json.dumps(r2m, indent=2) + "\n", encoding="utf-8")
logs.append({"suite": "E2", "python_exit": r2m["python_exit"], "go_exit": r2m["go_exit"]})

r3m, R4 = run_suite("E3_R4", e3_items("R4_ADVERSARIAL_EXPECTED.jsonl"))
(P03 / "P03_E3_R4_METRICS.json").write_text(json.dumps(r3m, indent=2) + "\n", encoding="utf-8")
logs.append({"suite": "E3_R4", "python_exit": r3m["python_exit"], "go_exit": r3m["go_exit"]})

r3am, R4A = run_suite("E3_R4A", e3_items("R4A_CORRECTIVE_EXPECTED.jsonl"))
(P03 / "P03_E3_R4A_METRICS.json").write_text(json.dumps(r3am, indent=2) + "\n", encoding="utf-8")
logs.append({"suite": "E3_R4A", "python_exit": r3am["python_exit"], "go_exit": r3am["go_exit"]})

fails = []
for tag, R in [("E2", R2), ("E3_R4", R4), ("E3_R4A", R4A)]:
    for e in R["exp_items"]:
        for impl in ("PY", "GO"):
            o = R[impl].get(e["id"], {})
            if o.get("admission") != e["decision"] or o.get("reason_code") != e["reason"]:
                fails.append({"suite": tag, "case": e["id"], "impl": impl.lower(),
                              "expected": [e["decision"], e["reason"]], "observed": [o.get("admission"), o.get("reason_code")]})
(P03 / "E2_E3_FAILURE_REGISTER.json").write_text(json.dumps({"count": len(fails), "failures": fails}, indent=2) + "\n", encoding="utf-8")
(P03 / "E2_E3_EXEC_LOGS.json").write_text(json.dumps(logs, indent=2) + "\n", encoding="utf-8")

summary = {
    "E2": {"pairs": r2m["pairs"], "py_canonical": r2m["python_vs_expected"]["canonical_bytes_correct"],
           "go_canonical": r2m["go_vs_expected"]["canonical_bytes_correct"],
           "py_admission": r2m["python_vs_expected"]["admission_correct"], "go_admission": r2m["go_vs_expected"]["admission_correct"]},
    "E3_R4": {"py": r3m["python_vs_expected"]["admission_correct"], "go": r3m["go_vs_expected"]["admission_correct"]},
    "E3_R4A": {"py": r3am["python_vs_expected"]["admission_correct"], "go": r3am["go_vs_expected"]["admission_correct"]},
    "failures": len(fails), "exits": logs,
}
print(json.dumps(summary, indent=2))