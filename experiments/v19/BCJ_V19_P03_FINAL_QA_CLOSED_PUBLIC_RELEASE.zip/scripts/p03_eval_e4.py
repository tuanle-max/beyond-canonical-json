"""Agent V E4: batch-root evaluation, independent expected roots, both frozen impls."""
import json, subprocess, sys, pathlib, hashlib
import rfc8785
V19 = pathlib.Path(__file__).resolve().parents[1]
P03 = V19 / "results/P03"; P03.mkdir(parents=True, exist_ok=True)
PYD = V19 / "implementations/python-dev"
GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
ALT_PID = "00" * 32
ALT_CD = "11" * 32
T = 1767225600000


def bsha(b):
    return hashlib.sha256(b).hexdigest()


def canon(i):
    typed = {"eid": "EV-%d" % i, "t": T, "minor": 100, "cur": "USD", "bc": "B-%d" % i, "ref": None}
    return rfc8785.dumps(typed)


RECN = 40
RAW = {}
for i in range(1, RECN + 1):
    RAW["EV-%d" % i] = ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B-%d"}' % (i, i)).encode()
RAW["INVALID-1"] = b'{"event_id":"EV-X","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B","junk":1}'
RAW["ABSTAIN-1"] = b'{"event_id":"EV-A","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","scale":2,"beneficiary_code":"B"}'
RAW["MISSING-1"] = b''  # empty raw -> malformed (represents a non-supplied/invalid record)


def is_valid(rid):
    return rid in RAW and rid.startswith("EV-")


def leaf(pid, cd, cb):
    return bsha(b"\x00\x03" + bytes.fromhex(pid) + bytes.fromhex(cd) + cb)


def node(l, r):
    return bsha(b"\x01" + bytes.fromhex(l) + bytes.fromhex(r))


def root(leaves):
    n = len(leaves)
    if n == 0:
        return bsha(b"\x02\x00"), []
    if n == 1:
        return leaves[0], []
    k = 1
    while k * 2 < n:
        k *= 2
    L, ln = root(leaves[:k]); R, rn = root(leaves[k:])
    pre = b"\x01" + bytes.fromhex(L) + bytes.fromhex(R)
    nd = {"preimage_hex": pre.hex(), "digest": node(L, R)}
    return node(L, R), [nd] + ln + rn


DESC = []
def add(bid, kind, order, pid=PID, cd=CD):
    DESC.append({"batch_id": bid, "kind": kind, "order": order, "pid": pid, "cd": cd})

for n in [1, 2, 3, 4, 5, 7, 8, 16, 31, 32]:
    add("size_%d" % n, "distinct", ["EV-%d" % i for i in range(1, n + 1)])
add("empty", "empty", [])
add("duplicate", "duplicate", ["EV-1", "EV-1", "EV-2", "EV-3"])
add("reorder_a", "reorder", ["EV-%d" % i for i in range(1, 6)])
add("reorder_b", "reorder", ["EV-5", "EV-4", "EV-3", "EV-2", "EV-1"])
add("missing", "missing", ["EV-1", "EV-2", "MISSING-1"])
add("mixed", "mixed", ["EV-1", "INVALID-1", "ABSTAIN-1", "EV-2"])
add("changed_pid", "changed_pid", ["EV-1", "EV-2"], pid=ALT_PID)
add("changed_cd", "changed_cd", ["EV-1", "EV-2"], cd=ALT_CD)

with (P03 / "P03_E4_BATCH_DESCRIPTORS.jsonl").open("w", encoding="utf-8") as fh:
    for d in DESC:
        fh.write(json.dumps(d, sort_keys=True) + "\n")


def expected(d):
    admitted = [r for r in d["order"] if is_valid(r)]
    rejected = [r for r in d["order"] if r not in admitted and r != "ABSTAIN-1" and r in RAW and r != "MISSING-1"]
    abstained = [r for r in d["order"] if r == "ABSTAIN-1"]
    leaves = [leaf(d["pid"], d["cd"], canon(int(r.split("-")[1]))) for r in admitted]
    rt, nodes = root(leaves)
    return {"admitted": admitted, "rejected": sorted(rejected + [r for r in d["order"] if r == "MISSING-1"]),
            "abstained": abstained, "leaf_digests": leaves, "internal_nodes": nodes, "root": rt}


with (P03 / "P03_E4_EXPECTED_ROOTS.jsonl").open("w", encoding="utf-8") as fh:
    for d in DESC:
        e = expected(d)
        fh.write(json.dumps({"batch_id": d["batch_id"], "root": e["root"], "leaf_count": len(e["leaf_digests"]),
                             "admitted": e["admitted"], "rejected": e["rejected"], "abstained": e["abstained"]}, sort_keys=True) + "\n")
print("descriptors", len(DESC))

import base64
for d in DESC:
    batch = {"batch_id": d["batch_id"], "pid_sem": d["pid"], "construction_digest": d["cd"],
             "records": [{"record_id": r, "raw_b64": base64.b64encode(RAW[r]).decode()} for r in d["order"]]}
    (P03 / ("e4_batch_" + d["batch_id"] + ".json")).write_text(json.dumps(batch), encoding="utf-8")

pylogs = []
for d in DESC:
    b = P03 / ("e4_batch_" + d["batch_id"] + ".json")
    o = P03 / ("e4_" + d["batch_id"] + "_py.json")
    pr = subprocess.run([sys.executable, str(PYD / "boo.py"), "commit", "--in", str(b), "--out", str(o)], capture_output=True, text=True)
    pylogs.append({"batch": d["batch_id"], "rc": pr.returncode, "err": pr.stderr[-300:]})

golog = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                        "/usr/local/go/bin/go build -o /tmp/boo . && for f in /data/e4_batch_*.json; do /tmp/boo commit \"$f\" \"${f%.json}_go.json\"; done"],
                       capture_output=True, text=True)


def loadjson(p):
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


pyres = {}; gores = {}
for d in DESC:
    pyres[d["batch_id"]] = loadjson(P03 / ("e4_" + d["batch_id"] + "_py.json"))
    gores[d["batch_id"]] = loadjson(P03 / ("e4_batch_" + d["batch_id"] + "_go.json"))

metrics = {"N_batches": len(DESC), "python": {"batch_status": 0, "leaf": 0, "node": 0, "root": 0},
           "go": {"batch_status": 0, "leaf": 0, "node": 0, "root": 0},
           "py_go_leaf_agree": 0, "py_go_root_agree": 0, "joint": 0}
fails = []
stat_rows = []; 
for d in DESC:
    e = expected(d); bid = d["batch_id"]
    for impl, res in (("python", pyres[bid]), ("go", gores[bid])):
        if res is None:
            fails.append({"batch": bid, "impl": impl, "reason": "no_output"}); continue
        adm_ok = sorted(res.get("admitted") or []) == sorted(e["admitted"])
        rej_ok = sorted(res.get("rejected") or []) == sorted(e["rejected"])
        abst_ok = sorted(res.get("abstained") or []) == sorted(e["abstained"])
        metrics[impl]["batch_status"] += (adm_ok and rej_ok and abst_ok)
        leaf_ok = res.get("leaf_digests") == e["leaf_digests"]
        metrics[impl]["leaf"] += leaf_ok
        node_ok = len(res.get("internal_nodes", [])) == len(e["internal_nodes"]) and \
            sorted(n["digest"] for n in res.get("internal_nodes", [])) == sorted(n["digest"] for n in e["internal_nodes"]) and \
            all(hashlib.sha256(bytes.fromhex(n["preimage_hex"])).hexdigest() == n["digest"] for n in res.get("internal_nodes", []))
        metrics[impl]["node"] += node_ok
        root_ok = res.get("root") == e["root"]
        metrics[impl]["root"] += root_ok
        if not (adm_ok and rej_ok and abst_ok and leaf_ok and node_ok and root_ok):
            fails.append({"batch": bid, "impl": impl, "admitted_ok": adm_ok, "rejected_ok": rej_ok,
                          "abstained_ok": abst_ok, "leaf_ok": leaf_ok, "node_ok": node_ok, "root_ok": root_ok,
                          "exp_root": e["root"], "obs_root": res.get("root")})
    py = pyres[bid]; go = gores[bid]
    if py and go and py.get("leaf_count") == go.get("leaf_count") and py.get("root"):
        metrics["joint"] += 1
        metrics["py_go_leaf_agree"] += py.get("leaf_digests") == go.get("leaf_digests")
        metrics["py_go_root_agree"] += py.get("root") == go.get("root")
    stat_rows.append({"batch_id": bid, "kind": d["kind"], "exp_root": e["root"], "leaf_count": len(e["leaf_digests"])})

(P03 / "P03_E4_PYTHON_RESULTS.jsonl").write_text("".join(json.dumps({"batch_id": k, **(v or {})}, sort_keys=True) + "\n" for k, v in pyres.items()), encoding="utf-8")
(P03 / "P03_E4_GO_RESULTS.jsonl").write_text("".join(json.dumps({"batch_id": k, **(v or {})}, sort_keys=True) + "\n" for k, v in gores.items()), encoding="utf-8")
mN = metrics["N_batches"]
metrics["python"] = {k: [v, mN] for k, v in metrics["python"].items()}
metrics["go"] = {k: [v, mN] for k, v in metrics["go"].items()}
metrics["py_go_leaf_agree"] = [metrics["py_go_leaf_agree"], metrics["joint"]]
metrics["py_go_root_agree"] = [metrics["py_go_root_agree"], metrics["joint"]]
metrics["python_exit_all0"] = all(l["rc"] == 0 for l in pylogs)
metrics["go_exit"] = golog.returncode
(P03 / "P03_E4_METRICS.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
(P03 / "E4_FAILURE_REGISTER.json").write_text(json.dumps({"count": len(fails), "failures": fails}, indent=2) + "\n", encoding="utf-8")
(P03 / "E4_EXEC_LOGS.json").write_text(json.dumps({"python": pylogs, "go_rc": golog.returncode, "go_err": golog.stderr[-400:]}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"metrics": metrics, "failures": len(fails)}, indent=2))