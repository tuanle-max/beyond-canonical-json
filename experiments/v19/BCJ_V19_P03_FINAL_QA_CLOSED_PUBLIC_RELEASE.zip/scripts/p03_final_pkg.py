"""WP3/WP4: final evidence lock + path-safe packaging + verification (no reproduction execution here)."""
import json, hashlib, pathlib, zipfile, time
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"
IMPL = V19 / "implementations"; SCR = V19 / "scripts"
def raw(p): return hashlib.sha256(p.read_bytes()).hexdigest()
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
FROZEN_VER = "570eb4d9faa487a78a4c5020c37c84f342047cb83b21cc65d8dfd892125408b5"
OBS_VER = raw(P02 / "verify_preflight_package.py") if (P02 / "verify_preflight_package.py").exists() else None
lock = json.loads((P02 / "ORACLE_LOCK.P03FINAL.json").read_text(encoding="utf-8"))
att = json.loads((P02 / "K_V2_FREEZE_ATTESTATION.json").read_text(encoding="utf-8"))
ev = {
  "historical_oracle_lock": {"path": "results/P02/ORACLE_LOCK.P03FINAL.json", "sha256": raw(P02 / "ORACLE_LOCK.P03FINAL.json"),
     "candidate_pid_sem_v2": lock.get("candidate_pid_sem_v2"), "candidate_construction_digest": lock.get("candidate_construction_digest"), "frozen": lock.get("frozen")},
  "freeze_attestation": {"path": "results/P02/K_V2_FREEZE_ATTESTATION.json", "sha256": raw(P02 / "K_V2_FREEZE_ATTESTATION.json"),
     "pid_matches": att.get("pid_sem_v2") == PID, "cd_matches": att.get("construction_digest") == CD},
  "verifier": {"path": "results/P02/verify_preflight_package.py", "frozen_digest": FROZEN_VER, "observed_digest": OBS_VER, "mismatch": OBS_VER != FROZEN_VER,
     "rationale": "verify_preflight_package.py strengthened (F01/F02/F06) AFTER the P03FINAL lock snapshot; lock binds pre-strengthening verifier. History preserved, not overwritten."},
  "identifiers_unchanged": {"pid_sem_v2": PID, "construction_digest": CD},
  "implementation_sources": {
     "python": {"initial_commit": "8bcad291", "final_path": "implementations/python-dev/boo.py", "final_sha256": raw(IMPL / "python-dev/boo.py")},
     "go": {"initial_commit": "f34220d7", "final_path": "implementations/go-dev/main.go", "final_sha256": raw(IMPL / "go-dev/main.go")}},
  "runtime": {"python": "3.12.9", "unicodedata": "15.0.0", "rfc8785": "0.1.3", "go_current": "go1.23.12 linux/amd64",
     "go_historical": "go1.27.3 windows/amd64 (historical; compile blocked by host policy)",
     "docker_image": "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db", "norm": "15.0.0"},
  "post_freeze_notice": "Artifacts generated after the freeze are evidence updates, not retroactively frozen-before-evaluation.",
  "reproduction": "fresh-extraction re-execution NOT executed this session (budget); no clean-room claim",
}
(P02 / "P03_FINAL_EVIDENCE_LOCK.R3A.json").write_text(json.dumps(ev, indent=2) + "\n", encoding="utf-8")
(P03 / "REPORT.R3A.md").write_text(
  "# P03 R3A FINAL — package report\n\n"
  "- Historical oracle lock preserved; evidence lock records verifier mismatch (frozen %s vs observed %s) with rationale.\n" % (FROZEN_VER[:12], (OBS_VER or "")[:12]) +
  "- Corrected impls: E1 630/600 both; E2 31/31; R4 71/71; R4a 21/21; E4 occurrence 131/131 & 114/114 both, batch 18/18, cross leaf 131/131 root 18/18; WP1 M01/M03 fixed, U01-U06 safe; R3C 2/2.\n"
  "- REPRODUCTION: NOT EXECUTED (budget) — no clean-room claim.\n- next_phase_authorized=false; P04 not started; manuscript untouched.\n", encoding="utf-8")
(P03 / "status.R3A.json").write_text(json.dumps({"phase": "P03", "revision": "STAGE1-R3A-FINAL", "next_phase_authorized": False,
  "p04": "NOT_AUTHORIZED", "process": "COMPLETE (evidence+package)", "scientific_targets": "MET on locked suites", "reproduction": "NOT_EXECUTED",
  "manuscript": "40376da untouched"}, indent=2) + "\n", encoding="utf-8")
(P03 / "RUN_MANIFEST.R3A.json").write_text(json.dumps({"scripts": ["p03_eval_e1.py", "p03_e1_corrected.py", "p03_eval_e2e3.py",
  "p03_eval_e4.py", "p03_r3a_regress.py", "p03_d3_test.py", "p03_r3b.py", "p03_r3c.py", "p03_r3d.py", "p03_wp1.py", "p03_wp2_e4occ.py"],
  "reproduction_entry": "NOT_EXECUTED"}, indent=2) + "\n", encoding="utf-8")
(P03 / "environment.R3A.json").write_text(json.dumps(ev["runtime"], indent=2) + "\n", encoding="utf-8")
(P03 / "commands.R3A.log").write_text("p03_r3d.py; p03_wp1.py pre/post; p03_wp2_e4occ.py; final package; REPRODUCTION NOT EXECUTED\n", encoding="utf-8")
print("evidence lock + metadata written; verifier_mismatch=", OBS_VER != FROZEN_VER, "obs=", OBS_VER)

lines = []
for base, pref in ((P02, "results/P02/"), (P03, "results/P03/")):
    for p in sorted(base.iterdir()):
        if p.is_file() and not p.name.startswith("SHA256SUMS"):
            lines.append("%s  %s%s" % (raw(p), pref, p.name))
(P03 / "SHA256SUMS.R3A").write_text("\n".join(lines) + "\n", encoding="utf-8")

zp = V19 / "BCJ_V19_P03_STAGE1_R3A_FINAL_REVIEW.zip"
t0 = time.time()
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(P02.rglob("*")):
        if p.is_file():
            z.write(p, "results/P02/" + str(p.relative_to(P02)).replace("\\", "/"))
    for p in sorted(P03.rglob("*")):
        if p.is_file():
            z.write(p, "results/P03/" + str(p.relative_to(P03)).replace("\\", "/"))
    for p in sorted(IMPL.rglob("*")):
        if p.is_file():
            z.write(p, "implementations/" + str(p.relative_to(IMPL)).replace("\\", "/"))
    for p in sorted(SCR.glob("*.py")):
        if p.is_file():
            z.write(p, "scripts/" + p.name)
zsha = raw(zp)
(V19 / "BCJ_V19_P03_STAGE1_R3A_FINAL_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P03_STAGE1_R3A_FINAL_REVIEW.zip\n" % zsha, encoding="utf-8")
with zipfile.ZipFile(zp) as z:
    crc = z.testzip(); cnt = len(z.namelist())
print(json.dumps({"zip": str(zp), "sha256": zsha, "entries": cnt, "crc_ok": crc is None, "opens": True,
                  "elapsed_s": round(time.time() - t0, 2), "verifier_frozen": FROZEN_VER, "verifier_observed": OBS_VER,
                  "verifier_mismatch": OBS_VER != FROZEN_VER, "p02_files": len([p for p in P02.iterdir() if p.is_file()]),
                  "p03_files": len([p for p in P03.iterdir() if p.is_file()])}, indent=2))