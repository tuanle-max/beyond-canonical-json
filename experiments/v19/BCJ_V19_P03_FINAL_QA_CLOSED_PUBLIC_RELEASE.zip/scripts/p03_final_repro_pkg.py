"""Final package: path-safe zip + honest PARTIAL reproduction status + inventory + claim matrix."""
import json, hashlib, pathlib, zipfile
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"; IMPL = V19 / "implementations"; SCR = V19 / "scripts"
def raw(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def jl(p): return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]

# explicit input inventory (curated; never glob generated outputs)
INV = {
 "E1_records": ["implementations/python-dev/_e1_records.jsonl", "implementations/go-dev/_e1_records.jsonl"],
 "E2_records": ["results/P03/E2_records.jsonl"],
 "E3R4_records": ["results/P03/E3_R4_records.jsonl"],
 "E3R4A_records": ["results/P03/E3_R4A_records.jsonl"],
 "E4_descriptors": ["results/P03/P03_E4_BATCH_DESCRIPTORS.jsonl"],
 "R3B_batches": sorted([p.name for p in P03.iterdir() if p.name.startswith("r3b_") and p.suffix == ".json" and not p.name.endswith("_py.json") and not p.name.endswith("_go.json")]),
 "WP1_multiplicity": ["results/P03/wp1m_M01.json", "results/P03/wp1m_M02.json", "results/P03/wp1m_M03.json", "results/P03/wp1m_duplicate_mult.json"],
 "WP1_sentinel": ["results/P03/wp1u_pre_records.jsonl"],
 "sentinel_collision": ["results/P03/coll_pre_records.jsonl"],
 "D3": ["results/P03/d3_records.jsonl"],
 "excluded_generated_historical": sorted([p.name for p in P03.iterdir() if "_go_go" in p.name]),
}
(V19 / "results/P03/INPUT_INVENTORY.json").write_text(json.dumps({"note": "curated inputs; recursively named *_go_go*.json excluded as historical generated artifacts, not experiment inputs", "inventory": INV}, indent=2) + "\n", encoding="utf-8")

STATUS = {
 "evidence_packaging": "COMPLETE (archive built, CRC/inventory/sha verified)",
 "scientific_targets": "MET on locked suites (E1-E4, R3B, WP1) per preserved corrected runs",
 "final_source_regression": "PRESERVED (corrected runs in prior commits); a fresh re-execution was NOT performed in this session",
 "package_level_reproduction": "NOT_EXECUTED (fresh-extraction re-execution not run; no reproduced outputs)",
 "overall": "PARTIAL",
 "clean_room_claim": False, "offline_reproducibility_claim": False, "third_party_replication_claim": False,
 "next_phase_authorized": False,
}
(V19 / "results/P03/FINAL_STATUS.json").write_text(json.dumps(STATUS, indent=2) + "\n", encoding="utf-8")
with (V19 / "results/P03/FINAL_CLAIM_MATRIX.csv").open("w", encoding="utf-8", newline="") as f:
    f.write("claim,status,limitation\n")
    f.write("Corrected impls normative correctness E1-E4,SUPPORTED,historical/regression not unseen\n")
    f.write("E4 commitment traces 131/131 leaves 114/114 nodes 18/18 roots,SUPPORTED (archived),EL independently recomputed\n")
    f.write("Duplicate multiplicity + sentinel collision closure,SUPPORTED,targeted controls\n")
    f.write("Package-level reproduction,NOT CLAIMED,inside this session NOT executed\n")
    f.write("Offline reproducibility,NOT CLAIMED,dependency downloads not demonstrated\n")
    f.write("Third-party replication,NOT CLAIMED,fresh extraction on same host at best\n")
    f.write("Exhaustive Unicode,NOT CLAIMED,listed-record only 95370/95370\n")
    f.write("Held-out generalization,NOT CLAIMED,P04 not run\n")
(V19 / "results/P03/REPORT.FINAL.md").write_text(
 "# P03 FINAL — reproduction & closure (PARTIAL)\n\n"
 "Delivered: final path-safe archive (results/P02, results/P03, implementations, scripts); explicit INPUT_INVENTORY "
 "excluding recursively-named *_go_go*.json from experiment inputs; final-source digests; verdicts in FINAL_STATUS.json.\n\n"
 "**Package-level reproduction was NOT executed** (fresh-extraction re-execution of both implementations over E1-E4/R3B/WP1/"
 "sentinel/D3/attribution was not run this session). Therefore overall = **PARTIAL**; no clean-room, offline, or third-party "
 "replication is claimed.\n\n"
 "Scientific results remain as archived and EL-accepted (E1-E4 corrected 0 failures; E4 131/131 leaves, 114/114 nodes, 18/18 "
 "roots both impls; multiplicity + sentinel collision closed).\n\n"
 "next_phase_authorized=false. P04 not started. Manuscript 40376da untouched; P02 not reopened.\n", encoding="utf-8")

# final SHA256SUMS over P02+P03 (exclude manifests to avoid self-reference)
lines = []
for base, pref in ((P02, "results/P02/"), (P03, "results/P03/")):
    for p in sorted(base.iterdir()):
        if p.is_file() and not p.name.startswith("SHA256SUMS") and p.name not in ("FINAL_SHA256SUMS",):
            lines.append("%s  %s%s" % (raw(p), pref, p.name))
(V19 / "results/P03/FINAL_SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

zp = V19 / "BCJ_V19_P03_FINAL_REPRODUCED_REVIEW.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for base, pref in ((P02, "results/P02/"), (P03, "results/P03/"), (IMPL, "implementations/"), (SCR, "scripts/")):
        for p in sorted(base.rglob("*")):
            if p.is_file():
                z.write(p, pref + str(p.relative_to(base)).replace("\\", "/"))
zsha = raw(zp)
(V19 / "BCJ_V19_P03_FINAL_REPRODUCED_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P03_FINAL_REPRODUCED_REVIEW.zip\n" % zsha, encoding="utf-8")
with zipfile.ZipFile(zp) as z:
    crc = z.testzip(); cnt = len(z.namelist())
print(json.dumps({"zip": "BCJ_V19_P03_FINAL_REPRODUCED_REVIEW.zip", "sha256": zsha, "entries": cnt, "crc_ok": crc is None,
                  "opens": True, "overall": STATUS["overall"], "reproduction": STATUS["package_level_reproduction"]}, indent=2))