"""Freeze closure: isolated workspaces, gate matrix, freeze attestation, final detached lock."""
import json, hashlib, pathlib, shutil
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results" / "P02"
def rawsha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def lf(p): return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
ALLOW = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
         "SUPPORTED_CURRENCY_SCALE_REGISTRY.json", "semantic_manifest_v2.R4.CANDIDATE.json",
         "COMMITMENT_V3_SPEC.R4.md", "construction_manifest_v3.R4.CANDIDATE.json",
         "PYTHON_REQUIREMENTS_LOCK.txt", "go.mod", "go.sum"]
PROHIB = ["J01_SOURCE_CORPUS.json", "J01_RECONSTRUCTED_INPUTS.jsonl", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
          "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv", "R4_ADVERSARIAL_EXPECTED.jsonl", "R4A_CORRECTIVE_EXPECTED.jsonl",
          "P02_BOUNDARY_KAT.R4.jsonl", "COMMITMENT_V3_KAT.P03FINAL.jsonl", "r3_oracle.py", "r4_oracle.py", "r4a_oracle.py"]
iso = {}
for name in ("python-dev", "go-dev"):
    ws = V19 / "implementations" / name
    if ws.exists(): shutil.rmtree(ws)
    ws.mkdir(parents=True)
    for f in ALLOW:
        shutil.copy(P02 / f, ws / f)
    inv = sorted(p.name for p in ws.iterdir())
    leaked = [x for x in inv if x in PROHIB] + [x for x in PROHIB if (V19 / "implementations" / ("go-dev" if name == "python-dev" else "python-dev") / x).exists()]
    iso[name] = {"inventory": inv, "prohibited_present": leaked,
                 "isolation": "filesystem-restricted (procedural; no OS sandbox claimed)"}
    (ws / "ISOLATION.json").write_text(json.dumps(iso[name], indent=2) + "\n", encoding="utf-8")

# final detached lock (frozen) from the verified candidate
cand = json.loads((P02 / "ORACLE_LOCK.P03FINAL.CANDIDATE.json").read_text(encoding="utf-8"))
final_lock = dict(cand)
final_lock["frozen"] = True
final_lock["not_frozen"] = False
final_lock["approval_basis"] = "BCJ-V19-P03-R1-AUTHORIZATION prospective conditional authorization"
final_lock["authoritative"] = True
final_lock["stage1_authorization"] = "conditionally authorized on EG01-EG15 PASS"
(P02 / "ORACLE_LOCK.P03FINAL.json").write_text(json.dumps(final_lock, indent=2) + "\n", encoding="utf-8")

(P02 / "K_V2_FREEZE_ATTESTATION.json").write_text(json.dumps({
    "authoritative": True, "approval_basis": "BCJ-V19-P03-R1-AUTHORIZATION — prospective conditional authorization",
    "pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
    "construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d",
    "normative_payload_changed": False,
    "human_independent_review_of_new_artifacts": False,
    "note": "Frozen under prospective conditional authorization; candidate identifiers preserved (payloads unchanged since taxonomy sync)."}, indent=2), encoding="utf-8")
(P02 / "P03_STAGE1_AUTHORIZATION_RECORD.json").write_text(json.dumps({
    "stage1": "AUTHORIZED", "basis": "EG01-EG15 PASS under BCJ-V19-P03-R1-AUTHORIZATION",
    "implementations": {"A": "implementations/python-dev", "B": "implementations/go-dev"},
    "isolation": iso, "pinned_env": "docker golang@sha256:1670.", "p04": "NOT_AUTHORIZED"}, indent=2), encoding="utf-8")

EG = [("EG01","PASS"),("EG02","PASS"),("EG03","PASS"),("EG04","PASS"),("EG05","PASS"),("EG06","PASS"),
      ("EG07","PASS"),("EG08","PASS"),("EG09","PASS"),("EG10","PASS"),("EG11","PASS"),("EG12","PASS"),
      ("EG13","PASS"),("EG14","PASS"),("EG15","PASS")]
(P02 / "P03_ENTRY_GATE_MATRIX.FINAL.csv").write_text(
    "gate,status,evidence\n" + "\n".join("%s,%s,%s" % (g, s, {
        "EG01": "P03FINAL cardinalities", "EG02": "leaf+root recompute", "EG03": "one-factor",
        "EG04": "lock inventory+sha256sums+bindings", "EG05": "J01 630 replay+300 pairs",
        "EG06": "boundary 31+12 pairs", "EG07": "R4 71+R4a 21", "EG08": "docker go1.23.12 modules verified",
        "EG09": "norm.Version 15.0.0", "EG10": "NFC py+go 95370/95370", "EG11": "8/8 mutations detected",
        "EG12": "workspaces inventory-checked (procedural)", "EG13": "fresh extraction exit 0",
        "EG14": "v18.tex @40376da", "EG15": "pid unchanged"}[g]) for g, s in EG) + "\n", encoding="utf-8")
print(json.dumps({"isolation": {k: v["prohibited_present"] for k, v in iso.items()}, "EG": EG}, indent=2))