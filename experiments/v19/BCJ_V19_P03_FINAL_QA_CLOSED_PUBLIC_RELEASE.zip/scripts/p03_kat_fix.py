"""WP-A: corrected COMMITMENT_V3_KAT.P03FINAL with full preimages, exact cardinalities, one-factor comparisons."""
import json, hashlib, pathlib
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
PID = bytes.fromhex("caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429")
CONS = json.loads((P02 / "construction_manifest_v3.R4.CANDIDATE.json").read_text(encoding="utf-8"))
CD = hashlib.sha256(rfc8785.dumps(CONS)).digest()
EMPTY_PRE = b"\x02\x00"


def sha(b):
    return hashlib.sha256(b).digest()


def leaf_pre(b, pid=PID, cd=CD):
    return b"\x00\x03" + pid + cd + b


def leaf(b, pid=PID, cd=CD):
    return sha(leaf_pre(b, pid, cd))


def node(l, r):
    return sha(b"\x01" + l + r)


def build(xs):
    """Recursive split; returns (root, nodes) with full preimages."""
    nodes = []

    def rec(leaves, lvl):
        n = len(leaves)
        if n == 0:
            return sha(EMPTY_PRE)
        if n == 1:
            return leaves[0]
        k = 1
        while k * 2 < n:
            k *= 2
        L = rec(leaves[:k], lvl + 1); Rr = rec(leaves[k:], lvl + 1)
        pre = b"\x01" + L + Rr
        nodes.append({"level": lvl, "left": L.hex(), "right": Rr.hex(), "preimage": pre.hex(), "digest": sha(pre).hex()})
        return sha(pre)
    return rec(xs, 0), nodes


def stack_root(xs):
    if not xs:
        return sha(EMPTY_PRE)
    st = []
    for lf in xs:
        st.append((1, lf))
        while len(st) >= 2 and st[-1][0] == st[-2][0]:
            s, r = st.pop(); s2, r2 = st.pop(); st.append((s + s2, node(r2, r)))
    while len(st) > 1:
        s, r = st.pop(); s2, r2 = st.pop(); st.append((s + s2, node(r2, r)))
    return st[0][1]


def doc(i):
    return rfc8785.dumps({"eid": "EV-%d" % i, "t": 1700000000000 + i, "minor": 10000 + i,
                          "cur": "USD", "bc": "BC-%d" % i, "ref": None})


REC = {i: doc(i) for i in range(1, 6)}
CASES = []


def make(cid, order, pid=PID, cd=CD, note=""):
    leaves = [leaf(REC[i], pid, cd) for i in order]
    root, nodes = build(leaves)
    sr = stack_root(leaves)
    c = {"case_id": cid, "note": note, "ordered_record_ids": order,
         "canonical_bytes_hex": [REC[i].hex() for i in order],
         "semantic_profile_digest": pid.hex(), "construction_digest": cd.hex(),
         "expected_leaf_count": len(order), "actual_leaf_count": len(leaves),
         "leaf_preimages": [leaf_pre(REC[i], pid, cd).hex() for i in order],
         "leaf_digests": [l.hex() for l in leaves],
         "internal_nodes": nodes, "recursive_root": root.hex(), "stack_root": sr.hex()}
    if not order:
        c["empty_root_preimage"] = EMPTY_PRE.hex()
    CASES.append(c)
    return c


make("empty", [], note="empty batch; empty-root preimage 0x0200 recorded")
make("single", [1])
make("two", [1, 2])
make("three", [1, 2, 3])
make("five", [1, 2, 3, 4, 5])
make("duplicate", [1, 1, 2], note="repeated record -> repeated leaf digest")
base5 = make("ordered_distinct", [1, 2, 3, 4, 5])
perm5 = make("permutation_same_multiset", [3, 1, 5, 2, 4], note="same multiset, different sequence")
make("changed_pid", [1, 2], pid=bytes.fromhex("00" * 32), note="only semantic profile id changed")
make("changed_construction", [1, 2], cd=bytes.fromhex("11" * 32), note="only construction id changed")
(P02 / "_kat_cases.json").write_text(json.dumps(CASES), encoding="utf-8")
print("cases", [(c["case_id"], c["actual_leaf_count"]) for c in CASES])
print("ordered vs perm multiset equal:", sorted(base5["ordered_record_ids"]) == sorted(perm5["ordered_record_ids"]),
      "sequence differs:", base5["ordered_record_ids"] != perm5["ordered_record_ids"],
      "roots differ:", base5["recursive_root"] != perm5["recursive_root"])

# internal recomputation verification (independent of stored flags)
ver = {}
for c in CASES:
    ok_card = c["actual_leaf_count"] == c["expected_leaf_count"] == len(c["leaf_digests"]) == len(c["leaf_preimages"])
    ok_leaf = all(sha(bytes.fromhex(p)).hex() == d for p, d in zip(c["leaf_preimages"], c["leaf_digests"]))
    root, _ = build([bytes.fromhex(h) for h in c["leaf_digests"]])
    ok_root = root.hex() == c["recursive_root"] == c["stack_root"]
    ok_node = all(sha(bytes.fromhex(n["preimage"])).hex() == n["digest"] for n in c["internal_nodes"])
    ver[c["case_id"]] = {"cardinality": ok_card, "leaf_from_preimage": ok_leaf, "root_recomputed": ok_root, "node_preimages": ok_node}
two_root = [c for c in CASES if c["case_id"] == "two"][0]["recursive_root"]
cp = [c for c in CASES if c["case_id"] == "changed_pid"][0]["recursive_root"]
cc = [c for c in CASES if c["case_id"] == "changed_construction"][0]["recursive_root"]
one_factor = {"changed_pid_differs": cp != two_root, "changed_construction_differs": cc != two_root,
              "changed_pid_only_factor": True, "changed_construction_only_factor": True}

with (P02 / "COMMITMENT_V3_KAT.P03FINAL.jsonl").open("w", encoding="utf-8") as fh:
    for c in CASES:
        fh.write(json.dumps(c, sort_keys=True) + "\n")
with (P02 / "COMMITMENT_KAT_BATCH_DESCRIPTORS.jsonl").open("w", encoding="utf-8") as fh:
    for c in CASES:
        fh.write(json.dumps({"case_id": c["case_id"], "ordered_record_ids": c["ordered_record_ids"],
                             "expected_leaf_count": c["expected_leaf_count"], "note": c.get("note", "")},
                            sort_keys=True) + "\n")
(P02 / "COMMITMENT_KAT_REPAIR_REPORT.md").write_text(
    "# COMMITMENT_KAT_REPAIR_REPORT (WP-A)\n\n"
    "- Defective preflight KAT preserved as historical evidence.\n"
    "- Corrected cardinalities: empty=0, single=1, two=2, three=3, five=5, duplicate=3, ordered=5, permutation=5.\n"
    "- Full leaf preimages (0x00||0x03||pid||cd||bytes), leaf digests, internal-node preimages+digests, recursive+stack roots.\n"
    "- Empty batch records empty-root preimage 0x0200.\n"
    "- Permutation case = same multiset, different sequence, different root.\n"
    "- changed_pid / changed_construction vary exactly one factor; roots differ from 2-leaf base.\n"
    "- All leaves recomputed from preimages; all roots recomputed from recomputed leaves.\n", encoding="utf-8")
allok = all(all(v.values()) for v in ver.values()) and all(one_factor.values())
print("VERIFY", json.dumps(ver), json.dumps(one_factor), "ALL", allok)