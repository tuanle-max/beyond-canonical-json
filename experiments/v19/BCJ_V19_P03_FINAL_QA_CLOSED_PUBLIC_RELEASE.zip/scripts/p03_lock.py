"""P03 preflight lock + package: detached lock, SHA256SUMS, zip, fresh-extraction verifier."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile, shutil
P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
SCR = pathlib.Path(__file__).resolve().parent
OUT = P02.parents[1]
A = "b4769d521c63f75991692e277736633cb38f6935"
def lf(p): return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
ART = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
       "SUPPORTED_CURRENCY_SCALE_REGISTRY.json", "semantic_manifest_v2.R4.CANDIDATE.json",
       "COMMITMENT_V3_SPEC.R4.md", "construction_manifest_v3.R4.CANDIDATE.json", "J01_SOURCE_CORPUS.json",
       "J01_RECONSTRUCTED_INPUTS.jsonl", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
       "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv", "R4A_CORRECTIVE_EXPECTED.jsonl", "R4_ADVERSARIAL_EXPECTED.jsonl",
       "P02_BOUNDARY_KAT.R4.jsonl", "P02_BOUNDARY_PAIR_REGISTER.R4.csv", "COMMITMENT_V3_KAT.P03FINAL.jsonl",
       "ORACLE_PROVENANCE.R4.json", "PYTHON_REQUIREMENTS_LOCK.txt", "GO_DEPENDENCY_LOCK.md",
       "UNICODE_RUNTIME_VERIFICATION.json", "UNICODE_CONFORMANCE_RESULTS.json",
       "verify_preflight_package.py"]
SCRIPTS = ["r4_oracle.py", "r4a_oracle.py", "r4a_j01_independent.py", "r4_commitment_kat.py", "p03_preflight.py"]
lock = {
    "candidate": True, "not_frozen": True, "source_commit": A,
    "chronology": {"corrective_expected_lock": "6457fc12", "j01_independent_lock": "45cb5498",
                   "r4a_evidence_commit_A": "b05da57", "r4a_attestation": "68d7e5d",
                   "p03preflight_commit_A": A,
                   "note": "R4 same-commit expected/repair limitation preserved; P03 locks are prospective."},
    "candidate_pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
    "candidate_construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d",
    "artifacts": {n: lf(P02 / n) for n in ART},
    "scripts": {n: lf(SCR / n) for n in SCRIPTS},
    "dependencies": {"python": "3.12.9", "rfc8785": "0.1.3", "unicodedata": "15.0.0", "go": "go1.27.3"}}
(P02 / "ORACLE_LOCK.P03FINAL.CANDIDATE.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")
lines = sorted("%s  %s" % (hashlib.sha256(p.read_bytes()).hexdigest(), p.name)
               for p in P02.iterdir() if p.is_file() and p.name != "SHA256SUMS")
(P02 / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
zp = OUT / "BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(P02.iterdir()):
        if p.is_file():
            z.write(p, "results/P02/" + p.name)
    for n in SCRIPTS:
        z.write(SCR / n, "scripts/" + n)
zsha = hashlib.sha256(zp.read_bytes()).hexdigest()
(OUT / "BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip\n" % zsha, encoding="utf-8")
td = pathlib.Path(tempfile.mkdtemp())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    z.extractall(td)
r = subprocess.run([sys.executable, str(td / "results/P02/verify_preflight_package.py")], capture_output=True, text=True, cwd=str(td))
print("zip_sha256", zsha, "entries", len(zipfile.ZipFile(zp).namelist()))
print("verify_exit", r.returncode)
print(r.stdout[-1400:])
if r.returncode: print("ERR", r.stderr[-800:])
shutil.rmtree(td, ignore_errors=True)