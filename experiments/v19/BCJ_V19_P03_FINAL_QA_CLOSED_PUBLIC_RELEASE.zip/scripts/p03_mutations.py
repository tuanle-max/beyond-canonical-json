"""P03 preflight mutation tests: each mutation must make verify_preflight_package.py exit non-zero."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile, shutil, base64
OUT = pathlib.Path(__file__).resolve().parents[1]  # experiments/v19
ZIP = OUT / "BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip"


def fresh():
    td = pathlib.Path(tempfile.mkdtemp())
    with zipfile.ZipFile(ZIP) as z:
        z.extractall(td)
    return td


def run(td):
    return subprocess.run([sys.executable, str(td / "results/P02/verify_preflight_package.py"),
                           str(td / "results/P02")], capture_output=True, text=True).returncode


def mut(name, fn):
    td = fresh(); P = td / "results/P02"; fn(P)
    rc = run(td); shutil.rmtree(td, ignore_errors=True)
    return name, rc != 0


def m_missing_lock(P):
    (P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json").unlink()


def m_empty_map(P):
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text()); d["artifacts"] = {}; f.write_text(json.dumps(d))


def m_wrong_pid(P):
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text()); d["candidate_pid_sem_v2"] = "0" * 64; f.write_text(json.dumps(d))


def m_kat_preimage(P):
    f = P / "COMMITMENT_V3_KAT.R4.jsonl"; rows = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    for r in rows:
        if r.get("internal_nodes"):
            r["internal_nodes"][0]["digest"] = "0" * 64; break
    f.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n")


def m_raw_lexeme(P):
    f = P / "J01_INDEPENDENT_EXPECTED.R4A.jsonl"; rows = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    raw = base64.b64decode(rows[0]["reconstructed_input_b64"]) + b" "
    rows[0]["reconstructed_input_b64"] = base64.b64encode(raw).decode()
    f.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n")


def m_expected_canonical(P):
    f = P / "J01_INDEPENDENT_EXPECTED.R4A.jsonl"; rows = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    for r in rows:
        if r["expected_canonical_sha256"]:
            r["expected_canonical_sha256"] = "f" * 64; break
    f.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n")


def m_checksum_regen(P):
    # change a KAT root AND recompute its SHA256SUMS entry -> checksum matches, structure must still fail
    f = P / "COMMITMENT_V3_KAT.R4.jsonl"; rows = [json.loads(l) for l in f.read_text().splitlines() if l.strip()]
    for r in rows:
        if "root" in r:
            r["root"] = "0" * 64; break
    f.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n")
    s = P / "SHA256SUMS"; lines = []
    for line in s.read_text().splitlines():
        h, n = line.split("  ", 1)
        if n == "COMMITMENT_V3_KAT.R4.jsonl":
            h = hashlib.sha256(f.read_bytes()).hexdigest()
        lines.append("%s  %s" % (h, n))
    s.write_text("\n".join(lines) + "\n")


res = [mut("missing_lock", m_missing_lock), mut("empty_artifact_map", m_empty_map),
       mut("wrong_locked_pid", m_wrong_pid), mut("commitment_preimage", m_kat_preimage),
       mut("raw_numeric_lexeme", m_raw_lexeme), mut("incorrect_expected_canonical", m_expected_canonical),
       mut("checksum_regenerated", m_checksum_regen)]
out = {"mutations": {n: ("DETECTED" if d else "MISSED") for n, d in res},
       "detected": sum(1 for _, d in res if d), "total": len(res)}
(OUT / "results" / "P02" / "P03_MUTATION_RESULTS.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))