"""Track C: 7 targeted mutations against the FINAL verifier (fresh extraction each)."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile, shutil
OUT = pathlib.Path(__file__).resolve().parents[1]
ZIP = OUT / "BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip"


def fresh():
    td = pathlib.Path(tempfile.mkdtemp())
    with zipfile.ZipFile(ZIP) as z:
        z.extractall(td)
    return td


def vrun(td):
    return subprocess.run([sys.executable, str(td / "results/P02/verify_preflight_package.py"),
                           str(td / "results/P02")], capture_output=True, text=True).returncode


def mut(name, fn):
    td = fresh(); P = td / "results/P02"; fn(P)
    rc = vrun(td); shutil.rmtree(td, ignore_errors=True)
    return name, rc != 0


def jw(f, fn):
    rows = [json.loads(l) for l in f.read_text(encoding="utf-8").splitlines() if l.strip()]
    fn(rows); f.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n", encoding="utf-8")


def m1(P):  # wrong J01 pair relationship
    f = P / "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv"; L = f.read_text(encoding="utf-8").splitlines()
    L[1] = L[1].replace("business-equal", "business-distinct").replace("business-distinct", "business-equal", 1) if "business-equal" not in L[1] else L[1].replace("business-equal", "business-distinct")
    f.write_text("\n".join(L) + "\n", encoding="utf-8")


def m2(P):  # incorrect commitment cardinality
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"
    def g(rows):
        for r in rows:
            if r["case_id"] == "five":
                r["actual_leaf_count"] = 4
    jw(f, g)


def m3(P):  # missing leaf preimage
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"
    def g(rows):
        for r in rows:
            if r["case_id"] == "three":
                r["leaf_preimages"] = r["leaf_preimages"][:-1]
    jw(f, g)


def m4(P):  # reordering comparison with a different multiset
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"
    def g(rows):
        for r in rows:
            if r["case_id"] == "permutation_same_multiset":
                r["canonical_bytes_hex"] = r["canonical_bytes_hex"][:-1] + ["00"]
    jw(f, g)


def m5(P):  # modified oracle-source digest in lock
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text(encoding="utf-8"))
    d["scripts"]["r4a_oracle.py"] = "0" * 64; f.write_text(json.dumps(d), encoding="utf-8")


def m6(P):  # missing required artifact from non-empty lock
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text(encoding="utf-8"))
    d["artifacts"].pop("NORMATIVE_CONTRACT.R4.md", None); f.write_text(json.dumps(d), encoding="utf-8")


def m7(P):  # missing changed-profile root trace
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"
    def g(rows):
        rows[:] = [r for r in rows if r["case_id"] != "changed_pid"]
    jw(f, g)


res = [mut("wrong_pair_relationship", m1), mut("incorrect_cardinality", m2), mut("missing_leaf_preimage", m3),
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"
    def g(rows):
        for r in rows:
            if r["case_id"] == "two":
                r["recursive_root"] = "0" * 64
    jw(f, g)
    newh = hashlib.sha256(f.read_bytes()).hexdigest()
    s = P / "SHA256SUMS"; L = []
    for line in s.read_text(encoding="utf-8").splitlines():
        h, n = line.split("  ", 1)
        if n == "COMMITMENT_V3_KAT.P03FINAL.jsonl":
            h = newh
        L.append("%s  %s" % (h, n))
    s.write_text("\n".join(L) + "\n", encoding="utf-8")
    lk = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(lk.read_text(encoding="utf-8"))
    d["artifacts"]["COMMITMENT_V3_KAT.P03FINAL.jsonl"] = newh
    lk.write_text(json.dumps(d), encoding="utf-8")


res = [mut("wrong_pair_relationship", m1), mut("incorrect_cardinality", m2), mut("missing_leaf_preimage", m3),
       mut("reorder_different_multiset", m4), mut("modified_oracle_digest", m5), mut("missing_required_artifact", m6),
       mut("missing_changed_profile_trace", m7), mut("checksum_regenerated_structural", m8)]
out = {"baseline_exit": None, "mutations": {n: ("DETECTED" if d else "MISSED") for n, d in res},
       "detected": sum(1 for _, d in res if d), "total": len(res)}
(OUT / "results" / "P02" / "P03_MUTATION_RESULTS.FINAL.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))