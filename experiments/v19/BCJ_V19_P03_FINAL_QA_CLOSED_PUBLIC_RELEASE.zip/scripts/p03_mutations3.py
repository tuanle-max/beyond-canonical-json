"""Clean Track C: baseline + 8 mutations against final verifier."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile, shutil
OUT = pathlib.Path(__file__).resolve().parents[1]
ZIP = OUT / "BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip"


def fresh():
    td = pathlib.Path(tempfile.mkdtemp())
    zipfile.ZipFile(ZIP).extractall(td)
    return td


def vrun(td):
    return subprocess.run([sys.executable, str(td / "results/P02/verify_preflight_package.py"),
                           str(td / "results/P02")], capture_output=True, text=True).returncode


def mut(name, fn):
    td = fresh(); P = td / "results/P02"
    try:
        fn(P)
    except Exception:
        pass
    rc = vrun(td); shutil.rmtree(td, ignore_errors=True)
    return name, rc != 0


def jl(p):
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def jw(p, rows):
    p.write_text("\n".join(json.dumps(r, sort_keys=True) for r in rows) + "\n", encoding="utf-8")


def m_pair(P):
    f = P / "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv"; L = f.read_text(encoding="utf-8").splitlines()
    c = L[1].split(","); c[3] = "bad-label"; L[1] = ",".join(c); f.write_text("\n".join(L) + "\n", encoding="utf-8")


def m_card(P):
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"; r = jl(f)
    for x in r:
        if x["case_id"] == "five":
            x["actual_leaf_count"] = 4
    jw(f, r)


def m_leaf(P):
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"; r = jl(f)
    for x in r:
        if x["case_id"] == "three":
            x["leaf_preimages"] = x["leaf_preimages"][:-1]
    jw(f, r)


def m_reorder(P):
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"; r = jl(f)
    for x in r:
        if x["case_id"] == "permutation_same_multiset":
            x["canonical_bytes_hex"] = x["canonical_bytes_hex"][:-1] + ["00"]
    jw(f, r)


def m_oracle(P):
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text(encoding="utf-8"))
    d["scripts"]["r4a_oracle.py"] = "0" * 64; f.write_text(json.dumps(d), encoding="utf-8")


def m_missart(P):
    f = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(f.read_text(encoding="utf-8"))
    d["artifacts"].pop("NORMATIVE_CONTRACT.R4.md", None); f.write_text(json.dumps(d), encoding="utf-8")


def m_misstrace(P):
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"; jw(f, [x for x in jl(f) if x["case_id"] != "changed_pid"])


def m_ckregen(P):
    f = P / "COMMITMENT_V3_KAT.P03FINAL.jsonl"; r = jl(f)
    for x in r:
        if x["case_id"] == "two":
            x["recursive_root"] = "0" * 64
    jw(f, r)
    newh = hashlib.sha256(f.read_bytes()).hexdigest()
    s = P / "SHA256SUMS"; L = []
    for line in s.read_text(encoding="utf-8").splitlines():
        h, n = line.split("  ", 1)
        if n == "COMMITMENT_V3_KAT.P03FINAL.jsonl":
            h = newh
        L.append("%s  %s" % (h, n))
    s.write_text("\n".join(L) + "\n", encoding="utf-8")
    lk = P / "ORACLE_LOCK.P03FINAL.CANDIDATE.json"; d = json.loads(lk.read_text(encoding="utf-8"))
    d["artifacts"]["COMMITMENT_V3_KAT.P03FINAL.jsonl"] = newh
    lk.write_text(json.dumps(d), encoding="utf-8")


bt = fresh(); base_rc = vrun(bt); shutil.rmtree(bt, ignore_errors=True)
res = [mut("wrong_pair_relationship", m_pair), mut("incorrect_cardinality", m_card), mut("missing_leaf_preimage", m_leaf),
       mut("reorder_different_multiset", m_reorder), mut("modified_oracle_digest", m_oracle),
       mut("missing_required_artifact", m_missart), mut("missing_changed_profile_trace", m_misstrace),
       mut("checksum_regenerated_structural", m_ckregen)]
out = {"baseline_exit": base_rc, "mutations": {n: ("DETECTED" if d else "MISSED") for n, d in res},
       "detected": sum(1 for _, d in res if d), "total": len(res)}
(OUT / "results" / "P02" / "P03_MUTATION_RESULTS.FINAL.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))