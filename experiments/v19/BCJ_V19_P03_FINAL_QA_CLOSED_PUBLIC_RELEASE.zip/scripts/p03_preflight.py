"""P03 Stage-0 preflight: pin env, verify Unicode, sync taxonomy, rebuild manifest+commitment, final lock, plans."""
import json, hashlib, pathlib, unicodedata, sys, platform
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
SCR = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(SCR))


def lf(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


# ---- P03-00A environment pinning (actual runtime) ----
import importlib.metadata as md
pyv = platform.python_version(); uni = unicodedata.unidata_version; rv = md.version("rfc8785")
(P02 / "PYTHON_REQUIREMENTS_LOCK.txt").write_text(
    "# Pinned Python deps (P03 preflight)\n# python==%s  decimal=_decimal(C)  unicodedata==%s\nrfc8785==%s\n" % (pyv, uni, rv),
    encoding="utf-8")
(P02 / "GO_DEPENDENCY_LOCK.md").write_text(
    "# Go dependency lock (declared; go.sum pending Stage 1)\n"
    "- toolchain: go1.27.3 windows/amd64 (verified via `go version`)\n"
    "- golang.org/x/text v0.19.0 (NFC/UAX#15)\n- github.com/gowebpki/jcs v1.0.1 (JCS RFC 8785)\n"
    "Status: DECLARED, not `go mod download`-verified in Stage 0 (no build executed).\n", encoding="utf-8")
(P02 / "UNICODE_RUNTIME_VERIFICATION.json").write_text(json.dumps({
    "normative_target": "Unicode 15.0.0 (UAX#15 NFC)",
    "python": pyv, "unicodedata.unidata_version": uni, "rfc8785": rv,
    "decimal_impl": "decimal._decimal (C)", "matches_normative": uni == "15.0.0",
    "note": "R4a environment note claiming 14.0.0 was incorrect; actual runtime inspected."}, indent=2), encoding="utf-8")

# ---- Unicode conformance (PARTIAL, digest-verified mini corpus; NOT full UCD conformance) ----
ucases = [["e\u0301", "\u00e9"], ["A\u030a", "\u00c5"], ["\u212b", "\u00c5"],
          ["Jose\u0301", "Jos\u00e9"], ["\u0041\u0301", "\u00c1"]]
uok = all(unicodedata.normalize("NFC", a) == b for a, b in ucases)
uc_sha = hashlib.sha256(json.dumps(ucases, sort_keys=True).encode()).hexdigest()
(P02 / "UNICODE_CONFORMANCE_RESULTS.json").write_text(json.dumps({
    "partial": True, "full_ucd_conformance": False, "n_cases": len(ucases), "all_pass": uok,
    "corpus_sha256": uc_sha, "unicode_version": uni,
    "note": "Partial NFC spot-check on digest-verified mini corpus; NOT full NormalizationTest.txt conformance."}, indent=2), encoding="utf-8")

(P02 / "environment.json").write_text(json.dumps({
    "python": pyv, "platform": platform.platform(), "unicodedata.unidata_version": uni,
    "rfc8785": rv, "decimal": "C", "go_toolchain": "go1.27.3 windows/amd64"}, indent=2), encoding="utf-8")

# ---- P03-00B sync ERROR_TAXONOMY.yaml to actual normative reason codes ----
TAX = """error_taxonomy:
  precedence: [REJECT_MALFORMED, REJECT_PROHIBITED, ABSTAIN_UNDERSPECIFIED]
  execution_failures: [INTERNAL_ERROR, TIMEOUT]
  REJECT_MALFORMED: [JSON_MALFORMED, DUPLICATE_KEY, UNICODE_MALFORMED, TIMESTAMP_MALFORMED, SCALE_MALFORMED, EVENT_ID_MALFORMED, FIELD_TYPE_MALFORMED, AMOUNT_MALFORMED]
  REJECT_PROHIBITED: [NEGATIVE_AMOUNT, MONETARY_OVERFLOW, UNSUPPORTED_CURRENCY, SCALE_MISMATCH, UNKNOWN_FIELD, ALIAS_CONFLICT, TIMESTAMP_OUT_OF_RANGE]
  ABSTAIN_UNDERSPECIFIED: [MISSING_BENEFICIARY, MISSING_EVENT_ID, MISSING_CURRENCY, MISSING_SCALE, MISSING_AMOUNT, MISSING_TIMESTAMP, TIMESTAMP_MISSING_TZ]
"""
old_tax = (P02 / "ERROR_TAXONOMY.yaml").read_text(encoding="utf-8")
(P02 / "ERROR_TAXONOMY.yaml").write_text(TAX, encoding="utf-8")

# ---- rebuild semantic manifest with new taxonomy digest ----
ART = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml", "SUPPORTED_CURRENCY_SCALE_REGISTRY.json"]
dig = {a: lf(P02 / a) for a in ART}
MAN = {"schema": "drtea-payment", "semantic_version": "2.0",
       "normative_artifacts": {k: {"path": v, "sha256": dig[v]} for k, v in
           [("contract", ART[0]), ("field_semantics", ART[1]), ("error_taxonomy", ART[2]), ("currency_scale_registry", ART[3])]},
       "unicode": {"normalization": "NFC", "version": "UAX#15 Unicode 15.0.0", "fields": ["beneficiary_code"]},
       "safe_integer": {"max": 9007199254740991, "min": -9007199254740991},
       "admission_precedence": ["REJECT_MALFORMED", "REJECT_PROHIBITED", "ABSTAIN_UNDERSPECIFIED", "INTERNAL_ERROR", "TIMEOUT"]}
(P02 / "semantic_manifest_v2.R4.CANDIDATE.json").write_text(json.dumps(MAN, indent=2) + "\n", encoding="utf-8")
PID = hashlib.sha256(rfc8785.dumps(MAN)).hexdigest()
(P02 / "NORMATIVE_ARTIFACT_DIFF.md").write_text(
    "# NORMATIVE_ARTIFACT_DIFF (P03-00B)\n\n## ERROR_TAXONOMY.yaml (rewritten)\n"
    "- MALFORMED_JSON -> JSON_MALFORMED\n- CURRENCY_CONFLICT -> ALIAS_CONFLICT\n"
    "- MISSING_FIELD -> MISSING_BENEFICIARY/MISSING_AMOUNT/MISSING_TIMESTAMP\n"
    "- added MONETARY_OVERFLOW, TIMESTAMP_OUT_OF_RANGE, SCALE_MALFORMED, EVENT_ID_MALFORMED, FIELD_TYPE_MALFORMED\n"
    "- execution failures (INTERNAL_ERROR/TIMEOUT) separated from admission categories\n", encoding="utf-8")
print("new_pid", PID, "unidata", uni, "uconf", uok)

# ---- regenerate commitment KAT with final pid (import executes the calculator) ----
import r4_commitment_kat  # noqa: E402  (regenerates COMMITMENT_V3_KAT.R4.jsonl + construction manifest)
CONS = json.loads((P02 / "construction_manifest_v3.R4.CANDIDATE.json").read_text(encoding="utf-8"))
CD = hashlib.sha256(rfc8785.dumps(CONS)).hexdigest()
(P02 / "FINAL_CANDIDATE_IDENTIFIER_REPORT.json").write_text(json.dumps({
    "candidate_pid_sem_v2": PID, "candidate_construction_digest": CD,
    "note": "CANDIDATE only; not authoritative. pid changed because ERROR_TAXONOMY.yaml normative payload changed.",
    "historical_preserved": {"R3": "fe5bb956", "R4": "71287e74", "construction": "d1e46eb5"}}, indent=2), encoding="utf-8")
(P02 / "FINAL_NORMATIVE_CONSISTENCY_REPORT.md").write_text(
    "# FINAL_NORMATIVE_CONSISTENCY_REPORT (P03-00B)\n\n"
    "- ERROR_TAXONOMY.yaml synchronized to canonical reason codes (JSON_MALFORMED, ALIAS_CONFLICT, "
    "MISSING_BENEFICIARY, MONETARY_OVERFLOW, TIMESTAMP_OUT_OF_RANGE, SCALE_MALFORMED, EVENT_ID_MALFORMED, FIELD_TYPE_MALFORMED).\n"
    "- Admission categories separated from execution failures (INTERNAL_ERROR/TIMEOUT).\n"
    "- Cross-checked: contract, field semantics, taxonomy, registry, semantic manifest, construction spec+manifest.\n"
    "- Semantic manifest rebuilt; candidate pid recomputed (see FINAL_CANDIDATE_IDENTIFIER_REPORT.json).\n"
    "- Commitment KAT regenerated under final candidate identifiers.\n", encoding="utf-8")

# ---- P03-00D allowlists + plans + isolation ----
(P02 / "P03_IMPLEMENTATION_ALLOWLIST.json").write_text(json.dumps({
    "allowed": ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
                "SUPPORTED_CURRENCY_SCALE_REGISTRY.json", "semantic_manifest_v2.R4.CANDIDATE.json",
                "COMMITMENT_V3_SPEC.R4.md", "construction_manifest_v3.R4.CANDIDATE.json",
                "P02_BOUNDARY_KAT.R4.jsonl", "R4A_ADVERSARIAL_EXPECTED.jsonl", "R4A_CORRECTIVE_EXPECTED.jsonl",
                "J01_SOURCE_CORPUS.json", "J01_RECONSTRUCTED_INPUTS.jsonl"],
    "prohibited": ["scripts/r3_oracle.py", "scripts/r4_oracle.py", "scripts/r4a_oracle.py",
                   "scripts/r4a_j01_independent.py", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
                   "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv", "other implementation source", "P04 held-out"]},
    indent=2), encoding="utf-8")
(P02 / "P03_EVALUATOR_ALLOWLIST.json").write_text(json.dumps({
    "allowed": ["P03_PYTHON_PER_INPUT.jsonl", "P03_GO_PER_INPUT.jsonl", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
                "R4_REGRESSION_REPLAY_RESULTS.jsonl", "R4A_CORRECTIVE_RESULTS.jsonl", "P02_BOUNDARY_KAT.R4.jsonl",
                "COMMITMENT_V3_KAT.R4.jsonl", "P03_BATCH_DESCRIPTORS.jsonl"],
    "prohibited": ["P04 held-out evidence"]}, indent=2), encoding="utf-8")
(P02 / "P03_ISOLATION_RECORD.md").write_text(
    "# P03_ISOLATION_RECORD (Stage 0 planning)\n\n- Agent A (Python) and Agent B (Go) receive only P03_IMPLEMENTATION_ALLOWLIST.json items.\n"
    "- Neither receives oracle source, independent J01 expected, the other's source, or P04.\n"
    "- Agent V receives both frozen sources + locked expected, after initial source commits are frozen.\n"
    "- STAGE 0: no implementations created; isolation not yet technically enforced (disclosed).\n", encoding="utf-8")
(P02 / "P03_EXECUTION_PLAN.FINAL.md").write_text(
    "# P03_EXECUTION_PLAN.FINAL\n\n- Contract: NORMATIVE_CONTRACT.R4.md (final candidate). Identifiers: see FINAL_CANDIDATE_IDENTIFIER_REPORT.json.\n"
    "- Impls: Python (A) and Go (B), raw-bytes->root, no shared semantic code.\n"
    "- Corpora: E1 J01 (frozen, 630 occ), E2 boundary KAT (final), E3 R4(71)+R4a(21) as regression, E4 batches {1,2,3,4,5,7,8,16,31,32}.\n"
    "- Stages L0..L7 with attribution categories per directive.\n"
    "- GATED: Stage 1 requires Experiment Lead approval.\n", encoding="utf-8")
(P02 / "P03_METRIC_DICTIONARY.FINAL.yaml").write_text(
    "# P03_METRIC_DICTIONARY.FINAL\nadmission: [unique_valid_coverage, occurrence_valid_coverage, invalid_rejection, underspecified_abstention, unsafe_admission, false_rejection, internal_errors, timeouts]\n"
    "semantic: [equivalent_pair_success, distinct_pair_success, admission_agreement, reason_agreement, typed_object_agreement, eligible_json_agreement, canonical_byte_agreement]\n"
    "cross_impl: [conditional_agreement_jointly_admitted, unconditional_agreement_all_expected_admissible, leaf_agreement_matched, root_agreement_matched]\n"
    "batch: [expected_batches, successful_batches, accounting_correct, reorder_distinction, profile_change_distinction, construction_change_distinction]\n"
    "reporting: 'exact counts/denominators; N/A when denominator 0; no population error-rate claims from zero failures; agreement != correctness'\n",
    encoding="utf-8")
print("preflight evidence written; CD", CD)

