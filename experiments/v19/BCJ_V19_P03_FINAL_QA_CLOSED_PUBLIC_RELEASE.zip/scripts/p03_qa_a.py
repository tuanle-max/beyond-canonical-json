"""Fresh-extraction preparation: build flat candidate, extract to short path, record provenance, smoke verify-inputs."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile
V19 = pathlib.Path(__file__).resolve().parents[1]
def raw(p): return hashlib.sha256(p.read_bytes()).hexdigest()
PY = raw(V19 / "implementations/python-dev/boo.py"); GO = raw(V19 / "implementations/go-dev/main.go")
assert PY == "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f", "PY mismatch"
assert GO == "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa", "GO mismatch"

cand = V19 / "_candidate_repro.zip"
with zipfile.ZipFile(cand, "w", zipfile.ZIP_DEFLATED) as z:
    for base, pref in ((V19 / "results/P02", "results/P02/"), (V19 / "results/P03", "results/P03/"),
                       (V19 / "implementations", "implementations/"), (V19 / "scripts", "scripts/")):
        for p in sorted(base.rglob("*")):
            if p.is_file():
                z.write(p, pref + str(p.relative_to(base)).replace("\\", "/"))
candsha = raw(cand)

td = pathlib.Path(tempfile.mkdtemp(prefix="p03repro_"))
with zipfile.ZipFile(cand) as z:
    z.extractall(td)
ext = td
# smoke: verify-inputs from the extracted layout
mp = {"candidate": str(cand), "candidate_sha256": candsha, "extract_dir": str(ext),
      "entries": len([p for p in zipfile.ZipFile(cand).namelist()]),
      "py_sha": PY, "go_sha": GO}
(P03 := V19 / "results/P03")
(P03 / "EXTRACTION_PREP.json").write_text(json.dumps(mp, indent=2) + "\n", encoding="utf-8")
# run the extracted runner's verify-inputs
rc = subprocess.run([sys.executable, str(ext / "scripts/run_reproduction.py"), "verify-inputs"], capture_output=True, text=True)
print(json.dumps({"candidate_sha256": candsha, "extract_dir": str(ext), "entries": mp["entries"],
                  "verify_exit": rc.returncode, "verify_out": rc.stdout[-200:]}, indent=2))