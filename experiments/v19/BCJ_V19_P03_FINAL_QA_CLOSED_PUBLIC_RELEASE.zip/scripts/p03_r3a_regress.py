"""R3-A: run corrected Go on the 5 reported cases; verify D1/D2 fixes; document D3 discrepancy."""
import json, base64, subprocess, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"
GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"


def load_jsonl(p):
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


exp = {}
for k in load_jsonl(P02 / "P02_BOUNDARY_KAT.R4.jsonl"):
    exp[k["case_id"]] = (k["input_bytes_base64"], k["expected_decision"], k["expected_reason_code"])
for r in load_jsonl(P02 / "R4_ADVERSARIAL_EXPECTED.jsonl"):
    exp[r["case_id"]] = (r["input_b64"], r["expected_decision"], r["expected_reason"])
for r in load_jsonl(P02 / "R4A_CORRECTIVE_EXPECTED.jsonl"):
    exp[r["case_id"]] = (r["input_b64"], r["expected_decision"], r["expected_reason"])

CASES = [("R4-29", "D1"), ("B04", "D1"), ("B06", "D1"), ("M05", "D2"), ("S05", "D3")]
lines = [json.dumps({"record_id": cid, "raw_b64": exp[cid][0], "pid_sem": PID, "construction_digest": CD}) for cid, _ in CASES]
rec = P03 / "r3a_targeted_records.jsonl"; rec.write_text("\n".join(lines) + "\n", encoding="utf-8")
g = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "/usr/local/go/bin/go build -o /tmp/boo . && /tmp/boo adjudicate /data/r3a_targeted_records.jsonl /data/r3a_targeted_go.jsonl"],
                   capture_output=True, text=True)
go = {j["record_id"]: j for j in load_jsonl(P03 / "r3a_targeted_go.jsonl")} if (P03 / "r3a_targeted_go.jsonl").exists() else {}
rows = []
for cid, d in CASES:
    ed, er = exp[cid][1], exp[cid][2]
    o = go.get(cid, {})
    adm_ok = o.get("admission") == ed
    rea_ok = o.get("reason_code") == er
    rows.append({"case": cid, "defect": d, "expected": [ed, er], "observed": [o.get("admission"), o.get("reason_code")],
                 "admission_ok": adm_ok, "reason_ok": rea_ok, "pass": adm_ok and rea_ok})
(P03 / "GO_DEFECT_CORRECTION_REGISTER.json").write_text(json.dumps({
    "go_exit": g.returncode, "go_err": g.stderr[-300:],
    "cases": rows,
    "summary": {"D1_fixed": all(r["pass"] for r in rows if r["defect"] == "D1"),
                "D2_fixed": all(r["pass"] for r in rows if r["defect"] == "D2"),
                "D3_status": "ESCALATED (frozen parser-vs-field reason precedence ambiguity; not corrected)"},
    "note": "Initial Go snapshot f34220d7 preserved; this is a post-evaluation corrected source (not evaluator-blind).",
}, indent=2) + "\n", encoding="utf-8")
print(json.dumps(rows, indent=2))
print("go_exit", g.returncode)