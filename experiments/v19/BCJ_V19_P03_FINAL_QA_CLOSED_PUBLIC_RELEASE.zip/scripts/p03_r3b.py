"""R3-B: expected_ids membership precheck — genuine missing + controls, both CLIs."""
import json, base64, subprocess, pathlib, sys
V19 = pathlib.Path(__file__).resolve().parents[1]
P03 = V19 / "results/P03"
PYD = V19 / "implementations/python-dev"; GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"; CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
T = 1767225600000
def evraw(i): return ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B"}' % i).encode()
RAW = {"EV-1": evraw(1), "EV-2": evraw(2), "EV-3": evraw(3),
       "INVALID-1": b'{"event_id":"EV-X","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B","junk":1}',
       "ABSTAIN-1": b'{"event_id":"EV-A","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","scale":2,"beneficiary_code":"B"}'}

DESCS = {
 "genuine_missing": {"expected_ids": ["EV-1", "EV-2", "EV-3"], "supplied": ["EV-1", "EV-2"]},
 "complete": {"expected_ids": ["EV-1", "EV-2", "EV-3"], "supplied": ["EV-1", "EV-2", "EV-3"]},
 "duplicate_mult": {"expected_ids": ["EV-1", "EV-2"], "supplied": ["EV-1", "EV-1", "EV-2"]},
 "supplied_invalid": {"expected_ids": ["EV-1", "INVALID-1"], "supplied": ["EV-1", "INVALID-1"]},
 "supplied_abstained": {"expected_ids": ["EV-1", "ABSTAIN-1"], "supplied": ["EV-1", "ABSTAIN-1"]},
}
for bid, d in DESCS.items():
    batch = {"batch_id": bid, "pid_sem": PID, "construction_digest": CD, "expected_ids": d["expected_ids"],
             "records": [{"record_id": r, "raw_b64": base64.b64encode(RAW[r]).decode()} for r in d["supplied"]]}
    (P03 / ("r3b_" + bid + ".json")).write_text(json.dumps(batch), encoding="utf-8")

plog = []
for bid in DESCS:
    b = P03 / ("r3b_" + bid + ".json"); o = P03 / ("r3b_" + bid + "_py.json")
    pr = subprocess.run([sys.executable, str(PYD / "boo.py"), "commit", "--in", str(b), "--out", str(o)], capture_output=True, text=True)
    plog.append({"batch": bid, "rc": pr.returncode})
g = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "/usr/local/go/bin/go build -o /tmp/boo . && for f in /data/r3b_*.json; do case \"$f\" in *_py.json|*_go.json) continue;; esac; /tmp/boo commit \"$f\" \"${f%.json}_go.json\"; done"],
                   capture_output=True, text=True)

def L(p): return json.loads(p.read_text(encoding="utf-8"))
rows = []
for bid, d in DESCS.items():
    py = L(P03 / ("r3b_" + bid + "_py.json")); go = L(P03 / ("r3b_" + bid + "_go.json"))
    def check(out):
        st = out.get("status"); root = out.get("root")
        if bid == "genuine_missing":
            return st == "BATCH_FAILED" and out.get("missing_required") == ["EV-3"] and root is None and out.get("leaf_count") == 0
        if bid == "complete":
            return st == "OK" and root is not None and out.get("admitted") == ["EV-1", "EV-2", "EV-3"]
        if bid == "duplicate_mult":
            return st == "OK" and out.get("admitted") == ["EV-1", "EV-1", "EV-2"] and out.get("leaf_count") == 3
        if bid == "supplied_invalid":
            return st == "OK" and out.get("admitted") == ["EV-1"] and out.get("rejected") == ["INVALID-1"] and root is not None
        if bid == "supplied_abstained":
            return st == "OK" and out.get("admitted") == ["EV-1"] and out.get("abstained") == ["ABSTAIN-1"] and root is not None
    rows.append({"batch": bid, "python": {"status": py.get("status"), "root": py.get("root"), "ok": check(py)},
                 "go": {"status": go.get("status"), "root": go.get("root"), "ok": check(go)}})
res = {"python_exit_all0": all(x["rc"] == 0 for x in plog), "go_exit": g.returncode, "go_err": g.stderr[-300:], "rows": rows,
       "genuine_missing_correct": all(r["python"]["ok"] and r["go"]["ok"] for r in rows if r["batch"] == "genuine_missing"),
       "all_controls_ok": all(r["python"]["ok"] and r["go"]["ok"] for r in rows)}
(P03 / "R3B_EXECUTION_RESULTS.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
print(json.dumps(res, indent=2))