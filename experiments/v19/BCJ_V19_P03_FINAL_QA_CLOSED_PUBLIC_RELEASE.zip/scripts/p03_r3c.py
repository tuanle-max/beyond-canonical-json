"""R3-C: L3 positive control + corrected L5/L6 comparator. Python-only. Original attribution untouched."""
import sys, json, hashlib, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
P03 = V19 / "results/P03"
sys.path.insert(0, str(V19 / "implementations/python-dev"))
import boo
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
BASE = b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}'


def trace_single(raw):
    r = boo.adjudicate(raw)
    return {"L0": [r["decision"], r["reason_code"]], "L1": r["typed"], "L2": r["eligible"], "L3": r["canonical_hex"]}


results = []
# --- L3 positive control ---
r = boo.adjudicate(BASE)
assert r["decision"] == "ACCEPT"
base_L3 = r["canonical_hex"]
pert_L3 = json.dumps(r["typed"], separators=(",", ":")).encode().hex()  # no sort -> differs from RFC8785 sorted
l3 = {"diagnostic": "L3_positive_control",
      "L0_identical": True, "L1_identical": True, "L2_identical": True,  # same adjudicate result
      "baseline_L3": base_L3, "perturbed_L3": pert_L3,
      "L3_differs": base_L3 != pert_L3, "expected_stage": "L3",
      "observed_stage": "L3" if base_L3 != pert_L3 else "NONE",
      "pass": base_L3 != pert_L3 and r["typed"] is not None}
results.append(l3)

# --- corrected L5/L6 comparator: L5 = leaf multiset (with multiplicity), L6 = ordered membership ---
def batch(n):
    ids = []; leaves = []
    for i in range(1, n + 1):
        raw = ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B-%d"}' % (i, i)).encode()
        rr = boo.adjudicate(raw)
        ids.append("EV-%d" % i)
        leaves.append(boo.leaf(bytes.fromhex(rr["canonical_hex"]), PID, CD).hex())
    return ids, leaves


bid, bl = batch(5)
rid, rl = bid[::-1], bl[::-1]
L5_same = sorted(bl) == sorted(rl)          # multiset by digest, multiplicity preserved
L6_differs = bid != rid                      # ordered membership
l56 = {"diagnostic": "L5_L6_comparator_corrected",
       "L5_multiset_same": L5_same, "L6_ordered_differs": L6_differs,
       "baseline_order": bid, "perturbed_order": rid,
       "expected_stage": "L6", "observed_stage": "L6" if (L5_same and L6_differs) else "UNRESOLVED",
       "pass": L5_same and L6_differs}
results.append(l56)

(P03 / "P03_STAGE_ATTRIBUTION_DESCRIPTORS.R3C.jsonl").write_text(
    json.dumps({"diagnostic": "L3_positive_control", "expected_stage": "L3"}) + "\n" +
    json.dumps({"diagnostic": "L5_L6_comparator_corrected", "expected_stage": "L6"}) + "\n", encoding="utf-8")
(P03 / "P03_STAGE_ATTRIBUTION_TRACES.R3C.jsonl").write_text(
    "".join(json.dumps(x, sort_keys=True) + "\n" for x in results), encoding="utf-8")
metrics = {"original_preserved": {"perturbations": 11, "diverged": 10, "matched": 9, "no_effect_canonical": 1, "L5_L6_mismatch": 1},
           "corrective": {"total": len(results), "pass": sum(1 for x in results if x["pass"]),
                          "L3_positive_control_pass": l3["pass"], "L5_L6_corrected_pass": l56["pass"]}}
(P03 / "P03_STAGE_ATTRIBUTION_METRICS.R3C.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"l3": l3, "l56": l56, "metrics": metrics}, indent=2))