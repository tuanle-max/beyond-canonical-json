"""R3-D verification + independent reaggregation + R3 package metadata."""
import json, hashlib, csv, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
P02 = V19 / "results/P02"; P03 = V19 / "results/P03"
def lf(p): return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()
def bsha(b): return hashlib.sha256(b).hexdigest()
def jl(p): return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
import base64
R = {}

lock = json.loads((P02 / "ORACLE_LOCK.P03FINAL.json").read_text(encoding="utf-8"))
R["lock_frozen"] = lock.get("frozen") is True
R["lock_artifacts_all_match"] = all((P02 / n).exists() and lf(P02 / n) == h for n, h in lock.get("artifacts", {}).items())
R["lock_scripts_all_match"] = all((V19 / "scripts" / n).exists() and lf(V19 / "scripts" / n) == h for n, h in lock.get("scripts", {}).items())
att = json.loads((P02 / "K_V2_FREEZE_ATTESTATION.json").read_text(encoding="utf-8"))
R["attestation_identifiers_match"] = att.get("pid_sem_v2") == lock.get("candidate_pid_sem_v2") and att.get("construction_digest") == lock.get("candidate_construction_digest")
R["source_commit_present"] = bool(lock.get("source_commit"))

exp = jl(P02 / "J01_INDEPENDENT_EXPECTED.R4A.jsonl")
corp = json.loads((P02 / "J01_SOURCE_CORPUS.json").read_text(encoding="utf-8"))["cases"]
legs = [(e["case_id"], e["leg_id"]) for e in exp]
R["j01_legs"] = len(legs); R["j01_unique_legs"] = len(set(legs))
R["j01_reconstructed_digest_ok"] = all(bsha(base64.b64decode(e["reconstructed_input_b64"])) == e["input_sha256"] for e in exp)
R["j01_case_membership_ok"] = {e["case_id"] for e in exp} == {c["case_id"] for c in corp}
R["j01_membership_exact"] = (len(exp) == 630 and len(set(legs)) == 630 and R["j01_case_membership_ok"])

mut_p = (P03 / "P03_MUTATION_RESULTS.FINAL.json") if (P03 / "P03_MUTATION_RESULTS.FINAL.json").exists() else (P02 / "P03_MUTATION_RESULTS.FINAL.json")
mut = json.loads(mut_p.read_text(encoding="utf-8"))
R["mutation_baseline_0"] = mut.get("baseline_exit") == 0
R["mutation_8_8"] = mut.get("detected") == 8 and mut.get("total") == 8
R["mutation_checksum_regen_detected"] = mut.get("mutations", {}).get("checksum_regenerated_structural") == "DETECTED"

uni = json.loads((P02 / "UNICODE_CONFORMANCE_RESULTS.FINAL.json").read_text(encoding="utf-8"))
R["unicode_full_false"] = uni.get("full_nfc_conformance") is False
R["unicode_listed_py_go"] = uni.get("listed_record_conformance", {}).get("python", {}).get("passed") == 95370 and uni.get("listed_record_conformance", {}).get("go", {}).get("passed") == 95370
print(json.dumps({k: v for k, v in R.items()}, indent=2))

# reaggregation from raw outputs
e1 = {(e["case_id"] + ":" + e["leg_id"]): e for e in exp}
py1 = {j["record_id"]: j for j in jl(V19 / "implementations/python-dev/_e1_py.jsonl")}
go1 = {j["record_id"]: j for j in jl(V19 / "implementations/go-dev/_e1_go.jsonl")}
def e1_stats(o):
    adm = sum(1 for k, e in e1.items() if o.get(k, {}).get("admission") == e["expected_admission"])
    can = sum(1 for k, e in e1.items() if e["expected_admission"] == "ACCEPT" and o.get(k, {}).get("canonical_bytes_hex") == (base64.b64decode(e["expected_canonical_bytes_b64"]).hex() if e["expected_canonical_bytes_b64"] else None))
    return [adm, 630], [can, 600]
R["E1_py"], R["E1_go"] = e1_stats(py1), e1_stats(go1)
def agg(out_path, items):
    o = {j["record_id"]: j for j in jl(out_path)}
    return sum(1 for e in items if o.get(e["id"], {}).get("admission") == e["decision"]), len(items)
kat = jl(P02 / "P02_BOUNDARY_KAT.R4.jsonl")
e2 = [{"id": k["case_id"], "decision": k["expected_decision"]} for k in kat]
r4 = [{"id": r["case_id"], "decision": r["expected_decision"]} for r in jl(P02 / "R4_ADVERSARIAL_EXPECTED.jsonl")]
r4a = [{"id": r["case_id"], "decision": r["expected_decision"]} for r in jl(P02 / "R4A_CORRECTIVE_EXPECTED.jsonl")]
def pick(*cands):
    for c in cands:
        if (P03 / c).exists():
            return P03 / c
    return P03 / cands[-1]
R["E2_py"] = agg(pick("E2_py.jsonl"), e2); R["E2_go"] = agg(pick("E2_batch_go.jsonl", "E2_go.jsonl"), e2)
R["E3R4_py"] = agg(pick("E3_R4_py.jsonl"), r4); R["E3R4_go"] = agg(pick("E3_R4_go.jsonl"), r4)
R["E3R4A_py"] = agg(pick("E3_R4A_py.jsonl"), r4a); R["E3R4A_go"] = agg(pick("E3_R4A_go.jsonl"), r4a)
(P03 / "P03_R3D_VERIFICATION.json").write_text(json.dumps(R, indent=2) + "\n", encoding="utf-8")

(P03 / "status.R3.json").write_text(json.dumps({"phase": "P03", "revision": "STAGE1-R3", "next_phase_authorized": False,
    "p04": "NOT_AUTHORIZED", "corrected_impls": "D1/D2/D3 + expected_ids", "regression": "0 failures E1-E4+R3B",
    "r3c": "2/2 corrective pass", "reproduction": "fresh-extraction re-execution NOT executed this session"}, indent=2) + "\n", encoding="utf-8")
(P03 / "environment.R3.json").write_text(json.dumps({"python": "3.12.9", "unicodedata": "15.0.0", "rfc8785": "0.1.3",
    "go": "go1.23.12 linux/amd64", "docker": "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db", "norm": "15.0.0"}, indent=2) + "\n", encoding="utf-8")
with (P03 / "SCIENTIFIC_CLAIM_MATRIX.R3.csv").open("w", encoding="utf-8", newline="") as f:
    w = csv.writer(f); w.writerow(["claim", "evidence", "status", "limitation"])
    w.writerow(["Corrected E1 correctness", json.dumps({"py": R["E1_py"], "go": R["E1_go"]}), "SUPPORTED", "historical regression"])
    w.writerow(["Corrected E2/E3 admission", json.dumps({"E2": [R["E2_py"], R["E2_go"]], "R4": [R["E3R4_py"], R["E3R4_go"]], "R4a": [R["E3R4A_py"], R["E3R4A_go"]]}), "SUPPORTED", "regression not unseen"])
    w.writerow(["E4 batch-root interop", "18/18 both vs independent", "SUPPORTED", "18 purposive batches"])
    w.writerow(["Attribution L3/L6 corrective", "2/2", "SUPPORTED", "python-only"])
    w.writerow(["Exhaustive Unicode", "listed-record 95370/95370 both", "NOT CLAIMED", "scope amendment"])
    w.writerow(["Full clean-room reproduction", "NOT EXECUTED", "NOT CLAIMED", "budget"])
    w.writerow(["Held-out generalization", "P04 not run", "NOT CLAIMED", "-"])
print(json.dumps({k: R[k] for k in ["E1_py", "E1_go", "E2_py", "E2_go", "E3R4_py", "E3R4_go", "E3R4A_py", "E3R4A_go"]}, indent=2))