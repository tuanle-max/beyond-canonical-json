"""Stage attribution: one-factor perturbations vs frozen Python baseline (diagnostic harness; no source edits)."""
import sys, json, hashlib, pathlib, types
V19 = pathlib.Path(__file__).resolve().parents[1]
P03 = V19 / "results/P03"
sys.path.insert(0, str(V19 / "implementations/python-dev"))
import boo, decimal
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
ALT_PID = "00" * 32; ALT_CD = "11" * 32
ORDER = ["L0", "L1", "L2", "L3", "L4", "L5", "L6", "L7"]
LABEL = {"L0": "PARSER/ADMISSION", "L1": "SEMANTIC_TRANSFORM", "L2": "ELIGIBLE_JSON", "L3": "CANONICALIZATION",
         "L4": "PROFILE_CONSTRUCTION_IDENTITY", "L5": "LEAF_ENCODING", "L6": "BATCH_ORDERING", "L7": "TREE_CONSTRUCTION"}
BASE_RAW = b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}'
NFD_RAW = '{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"Jose\\u0301"}'.encode()
AMT_RAW = b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"2.675","currency":"USD","scale":2,"beneficiary_code":"BC-1"}'
PRE_RAW = b'{"event_id":"EV-1","timestamp":"1969-12-31T23:59:59.999999Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}'
NOTZ_RAW = b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}'
_orig_ts = boo.ts


def trace_single(raw, pid=PID, cd=CD):
    r = boo.adjudicate(raw)
    L3 = r["canonical_hex"]
    L5 = boo.leaf(bytes.fromhex(L3), pid, cd).hex() if L3 else None
    return {"L0": [r["decision"], r["reason_code"]], "L1": r["typed"], "L2": r["eligible"], "L3": L3,
            "L4": [pid, cd], "L5": L5}


def trace_batch(n, pid=PID, cd=CD):
    leaves = []
    adm = []
    for i in range(1, n + 1):
        raw = ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B-%d"}' % (i, i)).encode()
        r = boo.adjudicate(raw)
        leaves.append(boo.leaf(bytes.fromhex(r["canonical_hex"]), pid, cd)); adm.append("EV-%d" % i)
    rt, _ = boo.root(leaves)
    return {"L5": [l.hex() for l in leaves], "L6": adm, "L7": rt.hex()}


def first_diff(b, t):
    for k in ORDER:
        if k in b and k in t and b[k] != t[k]:
            return k
    return "NONE"


def ts_trunc(v):
    if isinstance(v, str):
        m = boo.TS.fullmatch(v)
        if m:
            y, mo, d, H, M, S, fr, off = m.groups()
            if int(S) > 59:
                return None, "TIMESTAMP_MALFORMED"
            if off == "Z":
                tr = boo.dt.timedelta(0)
            else:
                oh, om = int(off[1:3]), int(off[4:6])
                tr = (1 if off[0] == "+" else -1) * boo.dt.timedelta(hours=oh, minutes=om)
            loc = boo.dt.datetime(int(y), int(mo), int(d), int(H), int(M), int(S), int((fr or "0").ljust(6, "0")), tzinfo=boo.dt.timezone(tr))
            dl = loc.astimezone(boo.dt.timezone.utc) - boo.EP
            tus = dl.days * 86400 * 10**6 + dl.seconds * 10**6 + dl.microseconds
            return int(tus / 1000), None
    return _orig_ts(v)


def mid_tree(leaves):
    n = len(leaves)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest(), []
    if n == 1:
        return leaves[0], []
    k = n // 2
    L, ln = mid_tree(leaves[:k]); R, rn = mid_tree(leaves[k:])
    return hashlib.sha256(b"\x01" + L + R).digest(), [None] + ln + rn


def save_restore_apply(patch):
    saved = []
    def setattr_(obj, name, val):
        saved.append((obj, name, getattr(obj, name)))
        setattr(obj, name, val)
    patch(setattr_)
    def restore():
        for obj, name, val in reversed(saved):
            setattr(obj, name, val)
    return restore


results = []


def singles(pid_, inp, expected, patch=None):
    b = trace_single(inp)
    if patch is None:
        t = b
    else:
        restore = save_restore_apply(patch)
        t = trace_single(inp)
        restore()
    obs = first_diff(b, t)
    results.append({"perturbation": pid_, "expected_stage": expected, "observed_stage": obs,
                    "attribution": LABEL.get(obs, "UNRESOLVED"), "diverged": obs != "NONE"})


singles("admission_missing_tz", NOTZ_RAW, "L0", lambda s: s(boo, "ts", lambda v: (0, None)))
singles("nfc_disabled", NFD_RAW, "L1", lambda s: s(boo, "unicodedata", types.SimpleNamespace(normalize=lambda f, x: x)))
singles("monetary_rounding_down", AMT_RAW, "L1", lambda s: s(boo, "ROUND_HALF_UP", decimal.ROUND_DOWN))
singles("timestamp_truncation", PRE_RAW, "L1", lambda s: s(boo, "ts", ts_trunc))
singles("canonical_serialization", BASE_RAW, "L3", lambda s: s(boo, "rfc8785", types.SimpleNamespace(
    dumps=lambda o: __import__("json").dumps(o, sort_keys=True, separators=(",", ":")).encode())))


def elig_patch(s):
    orig = boo.adjudicate

    def w(raw):
        r = orig(raw)
        if r["decision"] == "ACCEPT":
            r = dict(r); e = dict(r["typed"]); e["x"] = 1; r["eligible"] = e
        return r
    s(boo, "adjudicate", w)


singles("eligible_mapping", BASE_RAW, "L2", elig_patch)
singles("leaf_encoding", BASE_RAW, "L5", lambda s: s(boo, "leaf", lambda canon, pid, cd: hashlib.sha256(canon).digest()))

b = trace_single(BASE_RAW); t = trace_single(BASE_RAW, pid=ALT_PID)
results.append({"perturbation": "semantic_profile_digest", "expected_stage": "L4", "observed_stage": first_diff(b, t),
                "attribution": LABEL.get(first_diff(b, t), "UNRESOLVED"), "diverged": first_diff(b, t) != "NONE"})
b = trace_single(BASE_RAW); t = trace_single(BASE_RAW, cd=ALT_CD)
results.append({"perturbation": "construction_digest", "expected_stage": "L4", "observed_stage": first_diff(b, t),
                "attribution": LABEL.get(first_diff(b, t), "UNRESOLVED"), "diverged": first_diff(b, t) != "NONE"})


def leaves_n(n):
    L = []
    for i in range(1, n + 1):
        raw = ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B-%d"}' % (i, i)).encode()
        r = boo.adjudicate(raw)
        L.append(("EV-%d" % i, boo.leaf(bytes.fromhex(r["canonical_hex"]), PID, CD)))
    return L


lp = leaves_n(5)
base = {"L5": [d.hex() for _, d in lp], "L6": [i for i, _ in lp], "L7": boo.root([d for _, d in lp])[0].hex()}
rev = lp[::-1]
pert = {"L5": [d.hex() for _, d in rev], "L6": [i for i, _ in rev], "L7": boo.root([d for _, d in rev])[0].hex()}
od = first_diff(base, pert)
results.append({"perturbation": "batch_ordering", "expected_stage": "L6", "observed_stage": od,
                "attribution": LABEL.get(od, "UNRESOLVED"), "diverged": od != "NONE"})
rt = mid_tree([d for _, d in lp])[0]
pert2 = {"L5": base["L5"], "L6": base["L6"], "L7": rt.hex()}
od = first_diff(base, pert2)
results.append({"perturbation": "tree_shape", "expected_stage": "L7", "observed_stage": od,
                "attribution": LABEL.get(od, "UNRESOLVED"), "diverged": od != "NONE"})

(P03 / "P03_STAGE_ATTRIBUTION_RESULTS.jsonl").write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in results), encoding="utf-8")
(P03 / "P03_STAGE_ATTRIBUTION_DESCRIPTORS.jsonl").write_text("".join(
    json.dumps({"perturbation": r["perturbation"], "expected_stage": r["expected_stage"]}, sort_keys=True) + "\n" for r in results), encoding="utf-8")
total = len(results)
div = sum(1 for r in results if r["diverged"])
match = sum(1 for r in results if r["observed_stage"] == r["expected_stage"])
metrics = {"total_perturbations": total, "diverged": div, "expected_stage_matched": match,
           "expected_stage_mismatched": total - match, "unresolved": sum(1 for r in results if r["observed_stage"] in ("NONE", "UNRESOLVED")),
           "per_perturbation": {r["perturbation"]: [r["expected_stage"], r["observed_stage"]] for r in results}}
(P03 / "P03_STAGE_ATTRIBUTION_METRICS.json").write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")
(P03 / "STAGE_ATTRIBUTION_FAILURE_REGISTER.json").write_text(json.dumps(
    {"mismatches": [r for r in results if r["observed_stage"] != r["expected_stage"]]}, indent=2) + "\n", encoding="utf-8")
print(json.dumps(metrics, indent=2))