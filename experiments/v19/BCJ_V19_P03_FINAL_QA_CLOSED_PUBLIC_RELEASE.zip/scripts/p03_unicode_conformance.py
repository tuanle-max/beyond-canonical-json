"""Unicode 15.0.0 NFC conformance over official NormalizationTest.txt (UAX#15 clauses)."""
import sys, hashlib, unicodedata, json, pathlib
f = pathlib.Path(sys.argv[1]); data = f.read_bytes(); sha = hashlib.sha256(data).hexdigest()
lines = [l for l in data.decode("utf-8").splitlines() if l and not l.startswith(("#", "@"))]
rec = ass = passed = failed = skipped = 0
sample_fail = None
for l in lines:
    p = l.split(";")
    if len(p) < 5:
        skipped += 1; continue
    try:
        c = ["".join(chr(int(t, 16)) for t in x.split()) for x in p[:5]]
    except Exception:
        skipped += 1; continue
    rec += 1
    c1, c2, c3, c4, c5 = c
    checks = [(unicodedata.normalize("NFC", c1), c2), (unicodedata.normalize("NFC", c2), c2),
              (unicodedata.normalize("NFC", c3), c2), (unicodedata.normalize("NFC", c4), c4),
              (unicodedata.normalize("NFC", c5), c4)]
    for got, exp in checks:
        ass += 1
        if got == exp:
            passed += 1
        else:
            failed += 1
            if sample_fail is None:
                sample_fail = {"c": [c1, c2, c3, c4, c5], "got": got, "exp": exp}
res = {"source": "https://www.unicode.org/Public/15.0.0/ucd/NormalizationTest.txt",
       "corpus_sha256": sha, "corpus_version": "Unicode 15.0.0", "runtime_unidata": unicodedata.unidata_version,
       "records": rec, "assertions": ass, "passed": passed, "failed": failed, "skipped": skipped,
       "full_conformance": failed == 0 and rec > 0, "sample_fail": sample_fail}
out = pathlib.Path(sys.argv[2]); out.write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
print(json.dumps(res))