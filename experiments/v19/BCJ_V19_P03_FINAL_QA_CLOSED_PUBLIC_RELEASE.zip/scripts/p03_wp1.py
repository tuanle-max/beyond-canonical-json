"""WP1 targeted: multiplicity M01-M03 (both impls) + sentinel U01-U06 (Go). phase=pre|post."""
import json, base64, subprocess, pathlib, sys
V19 = pathlib.Path(__file__).resolve().parents[1]; P03 = V19 / "results/P03"
PYD = V19 / "implementations/python-dev"; GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"; CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
phase = sys.argv[1] if len(sys.argv) > 1 else "pre"
def ev(i): return ('{"event_id":"EV-%d","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B"}' % i).encode()
RAW = {"EV-1": ev(1), "EV-2": ev(2)}
M = {"M01": {"expected": ["EV-1", "EV-1", "EV-2"], "supplied": ["EV-1", "EV-2"]},
     "M02": {"expected": ["EV-1", "EV-1", "EV-2"], "supplied": ["EV-1", "EV-1", "EV-2"]},
     "M03": {"expected": ["EV-1", "EV-1", "EV-1", "EV-2"], "supplied": ["EV-1", "EV-2"]},
     "duplicate_mult": {"expected": ["EV-1", "EV-2"], "supplied": ["EV-1", "EV-1", "EV-2"]}}
for bid, d in M.items():
    b = {"batch_id": bid, "pid_sem": PID, "construction_digest": CD, "expected_ids": d["expected"],
         "records": [{"record_id": r, "raw_b64": base64.b64encode(RAW[r]).decode()} for r in d["supplied"]]}
    (P03 / ("wp1m_" + bid + ".json")).write_text(json.dumps(b), encoding="utf-8")
plog = []
for bid in M:
    o = P03 / ("wp1m_%s_%s_py.json" % (phase, bid))
    pr = subprocess.run([sys.executable, str(PYD / "boo.py"), "commit", "--in", str(P03 / ("wp1m_" + bid + ".json")), "--out", str(o)], capture_output=True, text=True)
    plog.append({"batch": bid, "rc": pr.returncode})
g = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "cd /work && /usr/local/go/bin/go build -o /tmp/boo . && for f in /data/wp1m_*.json; do case \"$f\" in *_py.json|*_go.json) continue;; esac; /tmp/boo commit \"$f\" \"${f%.json}_" + phase + "_go.json\"; done"],
                   capture_output=True, text=True)
mrow = []
for bid, d in M.items():
    py = json.loads((P03 / ("wp1m_%s_%s_py.json" % (phase, bid))).read_text(encoding="utf-8"))
    go = json.loads((P03 / ("wp1m_" + bid + "_" + phase + "_go.json")).read_text(encoding="utf-8"))
    exp_fail = bid in ("M01", "M03")
    def ok(o):
        if exp_fail:
            return o.get("status") == "BATCH_FAILED" and o.get("root") is None
        return o.get("status") == "OK" and o.get("root") is not None and o.get("leaf_count") == (3 if bid == "M02" else 3)
    mrow.append({"control": bid, "expected": "BATCH_FAILED" if exp_fail else "OK",
                 "py": {"status": py.get("status"), "leaf_count": py.get("leaf_count"), "ok": ok(py)},
                 "go": {"status": go.get("status"), "leaf_count": go.get("leaf_count"), "ok": ok(go)}})

# U controls (Go only)
U = {
 "U01": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"X\\uFFFDB","beneficiary":"\\ud800"}',
 "U02": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"\\ud800","beneficiary":"X\\uFFFDB"}',
 "U03": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B","\\ud800":1}',
 "U04": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"B","obligation_ref":{"x":"\\ud800"}}',
 "U05": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"\\ud83d\\ude00"}',
 "U06": b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"1.00","currency":"USD","scale":2,"beneficiary_code":"X\\uFFFDB"}',
}
lines = [json.dumps({"record_id": k, "raw_b64": base64.b64encode(v).decode(), "pid_sem": PID, "construction_digest": CD}) for k, v in U.items()]
(P03 / ("wp1u_%s_records.jsonl" % phase)).write_text("\n".join(lines) + "\n", encoding="utf-8")
ug = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(P03) + ":/data", "-w", "/work", IMG, "bash", "-c",
                    "cd /work && /usr/local/go/bin/go build -o /tmp/boo . && /tmp/boo adjudicate /data/wp1u_%s_records.jsonl /data/wp1u_%s_go.jsonl" % (phase, phase)],
                   capture_output=True, text=True)
ugo = {j["record_id"]: j for j in [json.loads(l) for l in (P03 / ("wp1u_%s_go.jsonl" % phase)).read_text(encoding="utf-8").splitlines() if l.strip()]}
urow = []
for k in U:
    o = ugo.get(k, {})
    reject_expected = k in ("U01", "U02", "U03", "U04")
    safe = (o.get("admission") != "ACCEPT" and o.get("canonical_bytes_hex") is None and o.get("leaf_digest") is None) if reject_expected else (o.get("admission") == "ACCEPT")
    urow.append({"control": k, "expected": "REJECT" if reject_expected else "ACCEPT", "observed": [o.get("admission"), o.get("reason_code")], "safe_ok": safe})
out = {"phase": phase, "membership": mrow, "sentinel_go": urow, "go_exit": g.returncode, "ugo_exit": ug.returncode}
(P03 / ("R3A_WP1_%s.json" % phase)).write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))