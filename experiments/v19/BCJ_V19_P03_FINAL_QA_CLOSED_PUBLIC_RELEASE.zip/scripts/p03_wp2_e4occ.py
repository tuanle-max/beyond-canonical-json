"""WP2: E4 occurrence-level metrics (131 leaves / 114 nodes) from preserved traces; reaggregate summary."""
import json, pathlib, hashlib
import rfc8785
V19 = pathlib.Path(__file__).resolve().parents[1]; P03 = V19 / "results/P03"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"; CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
ALT_PID = "00" * 32; ALT_CD = "11" * 32; T = 1767225600000
def bsha(b): return hashlib.sha256(b).hexdigest()
def jl(p): return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
def canon(i): return rfc8785.dumps({"eid": "EV-%d" % i, "t": T, "minor": 100, "cur": "USD", "bc": "B-%d" % i, "ref": None})
def leaf(pid, cd, cb): return bsha(b"\x00\x03" + bytes.fromhex(pid) + bytes.fromhex(cd) + cb)
def node(l, r): return bsha(b"\x01" + bytes.fromhex(l) + bytes.fromhex(r))
def root(leaves):
    n = len(leaves)
    if n == 0: return bsha(b"\x02\x00"), []
    if n == 1: return leaves[0], []
    k = 1
    while k * 2 < n: k *= 2
    L, ln = root(leaves[:k]); R, rn = root(leaves[k:])
    return node(L, R), [node(L, R)] + ln + rn
def is_valid(r): return r.startswith("EV-")
def expected(d):
    admitted = [r for r in d["order"] if is_valid(r)]
    leaves = [leaf(d["pid"], d["cd"], canon(int(r.split("-")[1]))) for r in admitted]
    rt, nodes = root(leaves)
    return admitted, leaves, nodes, rt
DESC = jl(P03 / "P03_E4_BATCH_DESCRIPTORS.jsonl")
out = {"batches": len(DESC), "python": {}, "go": {}, "cross": {}}
def loadp(*c): 
    for x in c:
        if (P03 / x).exists(): return json.loads((P03 / x).read_text(encoding="utf-8"))
    return None
agg = {"py": {"leaf_occ": 0, "leaf_tot": 0, "node_occ": 0, "node_tot": 0, "batch_all_leaves": 0, "batch_all_nodes": 0, "root_ok": 0, "status_ok": 0},
       "go": {"leaf_occ": 0, "leaf_tot": 0, "node_occ": 0, "node_tot": 0, "batch_all_leaves": 0, "batch_all_nodes": 0, "root_ok": 0, "status_ok": 0},
       "xleaf_occ": 0, "xleaf_tot": 0, "xroot": 0, "xroot_tot": 0}
for d in DESC:
    bid = d["batch_id"]; adm, leaves, nodes, rt = expected(d)
    py = loadp("e4_%s_py.json" % bid); go = loadp("e4_batch_%s_go.json" % bid)
    for impl, o in (("py", py), ("go", go)):
        if o is None: continue
        ol = o.get("leaf_digests") or []; on = [n["digest"] for n in (o.get("internal_nodes") or [])]
        agg[impl]["leaf_tot"] += len(leaves); agg[impl]["leaf_occ"] += sum(1 for a, b in zip(leaves, ol) if a == b)
        # node occurrence = multiset intersection count
        rem = list(nodes); m = 0
        for x in on:
            if x in rem: rem.remove(x); m += 1
        agg[impl]["node_tot"] += len(nodes); agg[impl]["node_occ"] += m
        agg[impl]["batch_all_leaves"] += (ol == leaves)
        agg[impl]["batch_all_nodes"] += (m == len(nodes))
        agg[impl]["root_ok"] += (o.get("root") == rt)
        agg[impl]["status_ok"] += (o.get("status") == "OK")
    if py and go:
        pl = py.get("leaf_digests") or []; gl = go.get("leaf_digests") or []
        agg["xleaf_tot"] += len(pl); agg["xleaf_occ"] += sum(1 for a, b in zip(pl, gl) if a == b)
        if py.get("root"):
            agg["xroot_tot"] += 1; agg["xroot"] += (py.get("root") == go.get("root"))
out["python"] = agg["py"]; out["go"] = agg["go"]
out["cross"] = {"leaf_agree": [agg["xleaf_occ"], agg["xleaf_tot"]], "root_agree": [agg["xroot"], agg["xroot_tot"]]}
out["verify_totals"] = {"expected_leaves": agg["py"]["leaf_tot"], "expected_nodes": agg["py"]["node_tot"]}
(P03 / "P03_E4_OCCURRENCE_METRICS.json").write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2))