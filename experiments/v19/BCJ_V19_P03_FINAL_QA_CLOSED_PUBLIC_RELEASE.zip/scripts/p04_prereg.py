"""P04-P00 preregistration package (preparation only; no measured execution)."""
import json, hashlib, pathlib
V19 = pathlib.Path(__file__).resolve().parents[1]
OUT = V19 / "p04_prereg"
OUT.mkdir(parents=True, exist_ok=True)
F = {}

F["P04_EXPERIMENT_PROTOCOL.md"] = """# P04 Experimental Protocol (preregistration)

Objective: quantify the incremental scientific benefit of the assurance architecture beyond a typed
semantic-normalization + RFC 8785 canonicalization baseline — NOT another canonicalization-correctness demo.

Arms:
- A0 raw JCS diagnostic baseline (no semantic normalization).
- A1 typed semantic normalization + JCS (matched baseline used by P03).
- A1+PID profile-binding guard.
- A1+CI finite regression guard.
- A2 complete proposed assurance mechanism.
- reject-all methodological control; constant-output methodological control.

Hold constant across A1..A2: parser, semantic contract, transformation, canonicalization, construction,
inputs, runtime. Only the evaluated assurance mechanism(s) differ.

Corpus: 100 units = 60 fault-injected + 40 benign; 4 balanced groups (Wrong semantic profile,
Construction mismatch, Semantic transformation regression, Encoding/batch regression); each group =
15 fault + 10 benign.

Isolation: development, historical-regression, and held-out fixtures kept separate; held-out expected
outcomes never exposed to implementation agents. Fault descriptors + expected outcomes frozen before any
measured execution.  STATUS: MEASURED EXECUTION NOT AUTHORIZED.
"""

F["P04_BASELINE_FAIRNESS.md"] = """# P04 Baseline Fairness

A1 is the fairness anchor: typed semantic normalization + JCS (identical to the accepted P03 pipeline).
A2 differs from A1 ONLY in the evaluated assurance mechanisms. Parser/semantics/transform/canonicalization/
construction/inputs/runtime are pinned to the same versions for A1 and A2.

Methodological controls (reject-all, constant-output) bound degenerate detectors and are explicitly NOT
rewarded (reject-all trivially maximizes some detection metrics but fails benign admission/usefulness).

Passive divergence (a stage output that differs) is NOT equated with an emitted detector alarm.
Detector-specific applicability is reported per fault family; common end-to-end assurance outcomes are
reported separately.
"""

F["P04_HYPOTHESES.md"] = """# P04 Hypotheses (preregistered)

H1 (increment): A2 strictly improves fault detection over A1 (McNemar paired) without degrading benign admission.
H2 (profile): A2 detects wrong-semantic-profile faults that A1 cannot (A1 has no profile binding).
H3 (construction): A2 detects construction-mismatch faults.
H4 (transformation): A2 detects semantic-transformation-regression faults.
H5 (encoding/batch): A2 detects encoding/batch-regression faults.
H6 (alarm validity): A2 emitted alarms correspond to actual injected divergence (not passive output difference).
H7 (usefulness): A2 is strictly better than reject-all on precision/recall/F1 and benign admission.
Each hypothesis is two-sided where applicable and tied to P04_METRIC_DICTIONARY.yaml / P04_TEST_MATRIX.csv.
"""

F["P04_METRIC_DICTIONARY.yaml"] = """admission:
  admission_rate: admitted / presented (per arm)
  valid_coverage: correctly admitted admissible / admissible
unsafe:
  unsafe_admission: non-admissible admitted / non-admissible
  false_non_admission: admissible not admitted / admissible
semantics:
  equivalence_preserved: equivalent pairs both admitted AND equal-parity / equivalent pairs
  distinction_preserved: distinct pairs both admitted AND distinct-parity / distinct pairs
detection:
  TP FP TN FN: per fault family and aggregate
  precision: TP/(TP+FP); recall: TP/(TP+FN); F1; false_positive_rate: FP/(FP+TN)
  detector_applicability: family-specific detector hits / family faults
  earliest_divergence: first differing stage L0-L7 (or UNRESOLVED)
assurance:
  common_end_to_end: admitted / admitted-with-alarm / blocked-with-alarm / blocked-no-alarm / silent-failure
  paired_improvement_A1_A2: per-unit A2-detected minus A1-detected (paired)
perf:
  median_ms IQR_ms memory_bytes: 3 warmup + 10 measured per applicable arm, batch 100/1000/5000
notes: |
  N/A when denominator zero. Purposive fault proportions are NOT production prevalence.
  reject-all is not rewarded. Passive divergence != emitted alarm.
"""

F["P04_TEST_MATRIX.csv"] = """group,fault_units,benign_units,arm_coverage,primary_metric
Wrong semantic profile,15,10,A1 A1+PID A2,detection+detector_applicability
Construction mismatch,15,10,A1 A1+CI A2,detection+earliest_divergence
Semantic transformation regression,15,10,A1 A2,detection+semantics
Encoding/batch regression,15,10,A1 A2,detection+admission
Benign controls,0,40,all,valid_coverage+false_non_admission
"""

F["P04_FAULT_INJECTION_PLAN.md"] = """# P04 Fault Injection Plan

Fault injection mutates actual system behavior/configuration, never expected-result files:
- Group 1 (Wrong semantic profile): substitute pid_sem with a same-length digest at leaf-binding scope.
- Group 2 (Construction mismatch): substitute construction_digest / change tree-shape expectation.
- Group 3 (Semantic transformation regression): disable NFC, change rounding, floor->trunc, drop alias.
- Group 4 (Encoding/batch regression): reorder batch, duplicate-multiplicity error, leaf-prefix, empty-root.

Each fault descriptor is frozen (input ids, injected mutation, expected non-admission/alarm, earliest stage)
and placed in the held-out set, opaque to implementation agents. Injections are one-factor; measured
execution requires authorization not yet granted.
"""

F["P04_STATISTICAL_ANALYSIS_PLAN.md"] = """# P04 Statistical Analysis Plan

- Paired A1-vs-A2 via McNemar on per-unit detected/not-detected (two-sided alpha 0.05).
- Per-family TP/FP/TN/FN, precision/recall/F1/FPR with exact counts (report cells, not only ratios).
- Performance: 3 warm-up + 10 measured runs per applicable arm; batches 100/1000/5000; median & IQR.
- Runtime guard overhead reported separately from configuration-time / CI-time overhead.
- Explicitly disclaim production-prevalence interpretation (documented purposive 60/100 proportion).
- Earliest-divergence (L0-L7) per injected unit; UNRESOLVED allowed, never forced.
"""

F["P04_REQUIREMENTS_TRACEABILITY.csv"] = """requirement,metric,hypothesis,test
Detect wrong profile,detection+detector_applicability,H2,group1
Detect construction mismatch,detection+earliest_divergence,H3,group2
Detect transformation regression,detection+semantics,H4,group3
Detect encoding/batch regression,detection+admission,H5,group4
Incremental over A1,paired_improvement_A1_A2,H1,all groups
Alarm validity,TP/FP/common_end_to_end,H6,all groups
Usefulness vs reject-all,precision/recall/F1,H7,all groups
Benchmark fairness,perf,,batch 100/1000/5000
"""

F["P04_OPEN_ISSUES.md"] = """# P04 Open Issues

- Measured P04 execution NOT authorized (this package is preregistration only).
- Held-out expected outcomes must remain opaque to implementation agents throughout.
- Passive-divergence vs emitted-alarm boundary needs a concrete emission contract before runs.
- Performance harness must separate runtime guard overhead from CI/config overhead (TBD instrumentation).
- Whether A1+PID / A1+CI are runtime-evaluable vs verified-at-audit-time must be stated per arm before runs.
- No prevalence / offline / third-party replication claims.
"""

for name, content in F.items():
    (OUT / name).write_text(content, encoding="utf-8")

lock = {"candidate": True, "not_frozen": True, "measured_execution_authorized": False,
        "identifiers": {"pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
                        "construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"},
        "documents": {}}
for name in sorted(F):
    lock["documents"][name] = hashlib.sha256((OUT / name).read_bytes()).hexdigest()
(OUT / "P04_SSOT_LOCK.CANDIDATE.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")

(OUT / "P04_PREPARATION_REPORT.md").write_text(
    "# P04 Preparation Report\n\nPreregistration package prepared (no measured execution). Arms A0/A1/A1+PID/"
    "A1+CI/A2 + reject-all/constant controls; 100-unit balanced fault design (60 fault / 40 benign across 4 groups "
    "15/10); metric dictionary; hypotheses; fault-injection and statistical plans; requirements traceability; "
    "candidate SSOT lock (binds prereg doc digests; identifiers caa2f3e5/d1e46eb5).\n\n"
    "STATUS: preparation only - measured P04 execution NOT authorized; no results invented. Held-out expected "
    "outcomes not accessed. P03 implementations unchanged; manuscript untouched.\n", encoding="utf-8")
print("wrote", len([p for p in OUT.iterdir()]), "files to", OUT)
print(json.dumps(lock, indent=2))