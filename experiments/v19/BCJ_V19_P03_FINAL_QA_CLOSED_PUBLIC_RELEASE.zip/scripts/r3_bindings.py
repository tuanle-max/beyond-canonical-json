"""P02-R3 / R3-01: cryptographic semantic binding + V01-V08 manifest-binding tests."""
import hashlib, json, pathlib, csv
import rfc8785

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"

FCOLS = ["field","aliases","required","accepted_raw_types","lexical_grammar","business_meaning","null_policy","missing_policy","default_policy","normalization","output_field","output_type","valid_range","equivalence_rule","reject_reason","abstain_reason"]
FROWS = [
 ["event_id","","required","string","^[A-Za-z0-9_-]{1,256}$","payment event identity","ABSTAIN","ABSTAIN","none","exact, no NFC","eid","string","non-empty","exact identity","EVENT_ID_MALFORMED","MISSING_EVENT_ID"],
 ["timestamp","","required","int epoch-ms | ISO string","YYYY-MM-DD[T ]HH:MM[:SS][.f{1,6}](Z|+hh:mm)","business instant (ms)","ABSTAIN","ABSTAIN","none","UTC->int ms; sub-ms floor","t","int","MIN_SAFE..MAX_SAFE","same ms class","TIMESTAMP_MALFORMED","TIMESTAMP_MISSING_TZ"],
 ["amount","","required","decimal string | decimal token | integer token","DECIMAL: integer[.frac{1,6}]; no grouping","quantized payable amount","ABSTAIN","ABSTAIN","none","exact Decimal, ROUND_HALF_UP","minor","int","0..MAX_SAFE","quantized class","AMOUNT_MALFORMED","AMOUNT_MISSING"],
 ["currency","cur","required","string","^[A-Z]{3}$","currency code","ABSTAIN","ABSTAIN","none","uppercase; alias compare","cur","string","registry","equal code+scale","CURRENCY_CONFLICT","MISSING_CURRENCY"],
 ["scale","","required","int","0..6","minor-unit exponent","ABSTAIN","ABSTAIN","none","must match registry","(implicit)","int","registry","fixed per currency","SCALE_MISMATCH","MISSING_SCALE"],
 ["beneficiary_code","beneficiary","required","string","unicode text (NFC)","human-readable beneficiary","ABSTAIN","ABSTAIN","none","NFC (Unicode 15.0.0)","bc","string","text","NFC equal","FIELD_MALFORMED","MISSING_BENEFICIARY"],
 ["obligation_ref","","optional","string|null","printable ASCII 1..256","obligation reference (opaque)","ref:null==absent","ref:null==absent","none","exact, no NFC","ref","string|null","text","exact / null==absent","FIELD_MALFORMED","(none; optional)"],
]
with (P02 / "FIELD_SEMANTICS.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL); w.writerow(FCOLS); w.writerows(FROWS)

ARTIFACTS = ["NORMATIVE_CONTRACT.R3.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
             "SUPPORTED_CURRENCY_SCALE_REGISTRY.json"]


def lf_sha(path):
    return hashlib.sha256(path.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


def build_manifest(d):
    return {
        "schema": "drtea-payment", "contract_version": "2.0-R3-CANDIDATE",
        "normative_artifacts": {k: {"path": v, "sha256": d[v]} for k, v in
            [("contract","NORMATIVE_CONTRACT.R3.md"),("field_semantics","FIELD_SEMANTICS.csv"),
             ("error_taxonomy","ERROR_TAXONOMY.yaml"),("currency_scale_registry","SUPPORTED_CURRENCY_SCALE_REGISTRY.json")]},
        "unicode": {"normalization": "NFC", "version": "UAX#15 Unicode 15.0.0", "fields": ["beneficiary_code"]},
        "safe_integer": {"max": 9007199254740991, "min": -9007199254740991},
        "admission_precedence": ["REJECT_MALFORMED","REJECT_PROHIBITED","ABSTAIN_UNDERSPECIFIED","INTERNAL_ERROR","TIMEOUT"],
    }


digests = {a: lf_sha(P02 / a) for a in ARTIFACTS}
manifest = build_manifest(digests)

res = {}
res["V01_artifacts_exist"] = all((P02 / a).exists() for a in ARTIFACTS)
res["V02_digests_match"] = all(lf_sha(P02 / a) == digests[a] for a in ARTIFACTS)
try:
    m1 = rfc8785.dumps(manifest); m2 = rfc8785.dumps(manifest)
    res["V03_rfc8785_eligible"] = True
    res["V04_deterministic"] = (m1 == m2)
except Exception as e:
    res["V03_rfc8785_eligible"] = "FAIL: %s" % e; res["V04_deterministic"] = False
res["V05_no_self_reference"] = ("pid_sem_v2" not in json.dumps(manifest))
orig_field = lf_sha(P02 / "FIELD_SEMANTICS.csv")
txt = (P02 / "FIELD_SEMANTICS.csv").read_text(encoding="utf-8")
(P02 / "_mut_field.csv").write_text(txt.replace("DECIMAL: integer[.frac{1,6}]; no grouping", "DECIMAL: changed-rule"), encoding="utf-8", newline="\n")
res["V06_mutation_detected"] = (lf_sha(P02 / "_mut_field.csv") != orig_field)
mut_d = dict(digests); mut_d["FIELD_SEMANTICS.csv"] = lf_sha(P02 / "_mut_field.csv")
pid_old = hashlib.sha256(rfc8785.dumps(manifest)).hexdigest()
pid_new = hashlib.sha256(rfc8785.dumps(build_manifest(mut_d))).hexdigest()
res["V07_pid_changes"] = (pid_old != pid_new)
res["V08_workflow_excluded"] = ("status" not in json.dumps(manifest)) and (pid_old == hashlib.sha256(rfc8785.dumps(manifest)).hexdigest())
(P02 / "_mut_field.csv").unlink()
res["_candidate_pid_sem_v2"] = pid_old
res["_note"] = "CANDIDATE only; not published as authoritative"
(P02 / "MANIFEST_BINDING_VERIFICATION.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
print(json.dumps(res, indent=2))
(P02 / "NORMATIVE_ARTIFACT_BINDINGS.json").write_text(json.dumps({"line_ending":"LF","encoding":"UTF-8","digests":digests}, indent=2) + "\n", encoding="utf-8")
manifest = build_manifest(digests)
(P02 / "semantic_manifest_v2.R3.CANDIDATE.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print("wrote field semantics + bindings + manifest")