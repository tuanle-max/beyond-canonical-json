"""P02-R3 / R3-05: boundary KAT (complete expected outputs) + pair register, using the independent K-v2 transform."""
import hashlib, json, pathlib, sys, csv
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r3_oracle as O  # reuse independent transform only (not jcommon)
import rfc8785

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
BASE = {"event_id": "EV-1", "timestamp": "2026-01-01T00:00:00Z", "amount": "100.00", "currency": "USD", "scale": 2, "beneficiary_code": "BC-1"}


def kat(case_id, fam, doc=None, raw=None, rule="R3", why=""):
    if raw is not None:
        inb = raw
        adm, elig = "REJECT_MALFORMED", None
    else:
        inb = rfc8785.dumps(doc)
        adm, elig = O.transform(doc)
    if adm == "ACCEPT":
        part, dec, rc = "D_K+", "ACCEPT", ""
    elif adm == "ABSTAIN_UNDERSPECIFIED":
        part, dec, rc = "D_K?", "ABSTAIN_UNDERSPECIFIED", "ABSTAIN_UNDERSPECIFIED"
    else:
        part, dec, rc = "D_K-", adm, adm
    return {"case_id": case_id, "fault_family": fam,
            "input_bytes_base64": __import__("base64").b64encode(inb).decode(),
            "input_sha256": hashlib.sha256(inb).hexdigest(),
            "expected_partition": part, "expected_decision": dec, "expected_reason_code": rc,
            "expected_business_object": (json.loads(elig).__repr__() if elig else None),
            "expected_eligible_json": (elig.decode() if elig else None),
            "expected_canonical_bytes_base64": (__import__("base64").b64encode(elig).decode() if elig else None),
            "expected_canonical_sha256": (hashlib.sha256(elig).hexdigest() if elig else None),
            "normative_rule_reference": rule, "oracle_rationale": why}


R = lambda **kw: {**BASE, **kw}
cases = [
 kat("K08", "Monetary", R(amount="2.674999"), why="267"),
 kat("K09", "Monetary", R(amount="2.675"), why="268"),
 kat("K10", "Monetary", R(amount="2.6750"), why="268"),
 kat("K11", "Monetary", R(amount="0.005"), why="1"),
 kat("K12", "Monetary", R(amount="0.004999"), why="0"),
 kat("K13", "Monetary", R(amount=250.0), why="exact token 250.0 -> 25000"),
 kat("K14", "Monetary", R(amount="250.00"), why="string 250.00 -> 25000"),
 kat("K15", "Monetary", R(amount="-2.675"), why="negative prohibited"),
 kat("K16", "Monetary", R(amount="9"*20, scale=2), why="monetary overflow (valid USD scale 2)"),
 kat("K17", "Monetary", R(scale=1), why="USD scale must be 2 (scale mismatch)"),
 kat("K18", "Timestamp", R(timestamp="2026-01-01T07:00:00+07:00"), why="same instant as Z"),
 kat("K19", "Timestamp", R(timestamp="2026-01-01T00:00:00.123Z"), why="sub-ms same class"),
 kat("K20", "Timestamp", R(timestamp="2026-01-01T00:00:00"), why="missing tz abstain"),
 kat("K21", "Timestamp", R(timestamp="2026-01-01T23:59:60Z"), why="leap second reject"),
 kat("K22", "Timestamp", R(timestamp="9007199254740992"), why="MAX_SAFE+1 timestamp out of range"),
 kat("K23", "Unicode", R(beneficiary_code="Jos\u00e9"), why="NFC"),
 kat("K24", "Unicode", R(beneficiary_code="Jose\u0301"), why="NFD->NFC equal"),
 kat("K25", "Unicode", R(beneficiary_code="\uff21"), why="fullwidth A distinct"),
 kat("K26", "Null/default", R(obligation_ref=None), why="null==absent -> ref null"),
 kat("K27", "Null/default", R(obligation_ref="OBL-9"), why="present ref"),
 kat("K28", "Alias", R(cur="USD"), why="equal alias"),
 kat("K29", "Alias", R(cur="EUR"), why="conflict reject"),
 kat("K30", "Parser", raw=b'{"event_id":"EV-1","event_id":"EV-2","timestamp":"2026-01-01T00:00:00Z"}', why="duplicate key"),
 kat("K31", "Parser", raw=b'{"beneficiary_code":"\xff\xfe"}', why="invalid UTF-8"),
 kat("K32", "Monetary", R(amount="2.675", scale=2), why="MAX boundary rounding ok"),
]
with (P02 / "P02_BOUNDARY_KAT.R3.jsonl").open("w", encoding="utf-8") as fh:
    for c in cases:
        fh.write(json.dumps(c, sort_keys=True) + "\n")
with (P02 / "P02_BOUNDARY_ORACLE_RATIONALES.R3.jsonl").open("w", encoding="utf-8") as fh:
    for c in cases:
        fh.write(json.dumps({"case_id": c["case_id"], "rationale": c["oracle_rationale"], "rule": c["normative_rule_reference"]}, sort_keys=True) + "\n")

PAIRS = [
 ("P01", "K13", "K14", "business-equal", "canonical-equal", "token 250.0 == string 250.00"),
 ("P02", "K09", "K10", "business-equal", "canonical-equal", "2.675 == 2.6750 same payable 268"),
 ("P03", "K09", "K11", "business-distinct", "canonical-distinct", "268 vs 1"),
 ("P04", "K12", "K11", "business-distinct", "canonical-distinct", "0 vs 1"),
 ("P05", "K18", "K19", "same-ms-class(may differ sub-ms)", "canonical-equal-if-same-ms", "offset vs Z same instant"),
 ("P06", "K23", "K24", "business-equal", "canonical-equal", "NFC==NFD"),
 ("P07", "K23", "K25", "business-distinct", "canonical-distinct", "é vs fullwidth A"),
 ("P08", "K26", "K27", "business-distinct", "canonical-distinct", "null vs present ref"),
 ("P09", "K28", "K29", "n/a", "n/a", "alias equal vs conflict (one rejected)"),
 ("P10", "K19", "K20", "n/a", "n/a", "sub-ms admit vs missing-tz abstain"),
 ("P11", "K08", "K09", "business-distinct", "canonical-distinct", "267 vs 268"),
 ("P12", "K09", "K32", "business-equal", "canonical-equal", "2.675 == 2.675"),
]
with (P02 / "P02_BOUNDARY_PAIR_REGISTER.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["pair_id","leg_a","leg_b","expected_equivalence","expected_canonical","rationale"]); w.writerows(PAIRS)

from collections import Counter
c = Counter(x["expected_partition"] for x in cases)
with (P02 / "MALFORMED_INPUT_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["metric","value"]); w.writerow(["unique_case_records", len(cases)]); w.writerow(["D_K+", c["D_K+"]]); w.writerow(["D_K-", c["D_K-"]]); w.writerow(["D_K?", c["D_K?"]]); w.writerow(["pairs", len(PAIRS)])
print("KAT cases", len(cases), dict(c), "pairs", len(PAIRS))