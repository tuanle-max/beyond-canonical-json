"""P02-R3 / R3-07: commitment-v3 spec calculator + known-answer roots (two independent root paths)."""
import hashlib, json, pathlib
import rfc8785

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"

PID = bytes.fromhex("fe5bb956dfefa947f69b1bc7062d6abda7bb711c7ba5cc07a44bc35c47413a46")  # CANDIDATE
CONSTR = {"schema": "drtea-commitment-v3", "version": "3.0-R3-CANDIDATE", "sha256": "leaf=SHA256(0x00||0x03||pid[32]||cd[32]||bytes)", "internal": "SHA256(0x01||L[32]||R[32])", "tree": "rfc9162_recursive", "empty_root": "SHA256(0x02||0x00)"}
CD = hashlib.sha256(rfc8785.dumps(CONSTR)).digest()


def leaf(b):
    return hashlib.sha256(b"\x00\x03" + PID + CD + b).digest()


def node(l, r):
    return hashlib.sha256(b"\x01" + l + r).digest()


def root_rec(xs):
    n = len(xs)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest()
    if n == 1:
        return xs[0]
    k = 1
    while k * 2 < n:
        k *= 2
    return node(root_rec(xs[:k]), root_rec(xs[k:]))


def root_iter(xs):
    """Independent path: fold left-complete power-of-two subtrees."""
    def rng(lo, hi):
        n = hi - lo
        if n == 1:
            return xs[lo]
        k = 1
        while k * 2 < n:
            k *= 2
        return node(rng(lo, lo + k), rng(lo + k, hi))
    if not xs:
        return hashlib.sha256(b"\x02\x00").digest()
    return rng(0, len(xs))


def doc(s):
    return rfc8785.dumps({"eid": s, "t": 1730000000000, "minor": 25000, "cur": "USD", "bc": "BC-1", "ref": None})


cases = {"leaves_simple_5": [doc(x) for x in ("a", "b", "c", "d", "e")],
         "leaves_dup": [doc("a"), doc("a"), doc("b")],
         "leaves_reorder": [doc("b"), doc("a"), doc("c")]}
out = []
for name, docs in cases.items():
    leaves = [leaf(d) for d in docs]
    rr, ri = root_rec(leaves), root_iter(leaves)
    out.append({"case": name, "n": len(leaves), "leaf_hex": [l.hex() for l in leaves],
                "root_hex": rr.hex(), "root_iter_hex": ri.hex(), "paths_agree": rr == ri})
# empty / single
out.append({"case": "empty", "n": 0, "root_hex": root_rec([]).hex(), "root_iter_hex": root_iter([]).hex(), "paths_agree": root_rec([]) == root_iter([])})
out.append({"case": "single", "n": 1, "leaf_hex": [leaf(doc("z")).hex()], "root_hex": root_rec([leaf(doc("z"))]).hex(), "paths_agree": True})

# changed semantic identifier -> different leaves/roots
PID_ALT = bytes.fromhex("00" * 32)
leaves_alt = [hashlib.sha256(b"\x00\x03" + PID_ALT + CD + d).digest() for d in [doc("a"), doc("b")]]
base2 = [leaf(doc("a")), leaf(doc("b"))]
out.append({"case": "changed_pid", "n": 2, "root_base_hex": root_rec(base2).hex(),
            "root_changed_pid_hex": root_rec(leaves_alt).hex(),
            "differs": root_rec(base2) != root_rec(leaves_alt)})
CD_ALT = bytes.fromhex("11" * 32)
leaves_cd = [hashlib.sha256(b"\x00\x03" + PID + CD_ALT + d).digest() for d in [doc("a"), doc("b")]]
out.append({"case": "changed_construction", "n": 2, "root_base_hex": root_rec(base2).hex(),
            "root_changed_cd_hex": root_rec(leaves_cd).hex(), "differs": root_rec(base2) != root_rec(leaves_cd)})

put = P02 / "COMMITMENT_V3_KAT.jsonl"
with put.open("w", encoding="utf-8") as fh:
    for c in out:
        fh.write(json.dumps(c, sort_keys=True) + "\n")
(P02 / "construction_manifest_v3.R3.CANDIDATE.json").write_text(json.dumps(CONSTR, indent=2) + "\n", encoding="utf-8")
print("construction_digest", CD.hex())
print(json.dumps([{c["case"]: c.get("paths_agree", c.get("differs"))} for c in out], indent=2))
print("all_two_path_agree_or_differ:", all(c.get("paths_agree", True) for c in out if "paths_agree" in c),
      "changed_differ:", all(c["differs"] for c in out if "differs" in c))