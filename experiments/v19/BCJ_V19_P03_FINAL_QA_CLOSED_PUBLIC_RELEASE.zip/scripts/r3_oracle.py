"""P02-R3 / R3-05,R3-06: independent K-v2 adjudicator (boundary KAT + J01 adjudication). No jcommon import."""
import datetime as _dt, json, pathlib, re, unicodedata
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
J01 = json.loads((ROOT / "derived" / "results" / "j01_cases.json").read_text(encoding="utf-8"))["cases"]
MAXS = 9007199254740991
REG = {"USD": 2, "EUR": 2, "VND": 0}
DECRE = re.compile(r"^[0-9]+(\.[0-9]{1,6})?$")


def ts_ms(v):
    if v is None:
        return None, "ABSTAIN"
    if isinstance(v, bool):
        return None, "MALFORMED"
    if isinstance(v, int):
        return (v, None) if -MAXS <= v <= MAXS else (None, "OUT_OF_RANGE")
    s = str(v).strip()
    if s.lstrip("-").isdigit():
        i = int(s); return (i, None) if -MAXS <= i <= MAXS else (None, "OUT_OF_RANGE")
    try:
        d = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return None, "MALFORMED"
    if d.tzinfo is None:
        return None, "ABSTAIN"
    ms = int(d.timestamp() * 1000)
    return (ms, None) if -MAXS <= ms <= MAXS else (None, "OUT_OF_RANGE")


def minor_of(v, scale):
    if v is None:
        return None, "ABSTAIN"
    if isinstance(v, bool):
        return None, "MALFORMED"
    if isinstance(v, str):
        s = v.strip()
        if s.startswith("-"):
            return None, "PROHIBITED"
    elif isinstance(v, float):
        s = repr(v)
    elif isinstance(v, int):
        s = str(v)
    else:
        return None, "MALFORMED"
    if not DECRE.match(s):
        return None, "MALFORMED"
    with localcontext() as c:
        c.prec = 60
        d = Decimal(s) * (Decimal(10) ** int(scale))
        m = int(d.quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return (m, None) if 0 <= m <= MAXS else (None, "PROHIBITED")


def transform(doc):
    if not isinstance(doc, dict):
        return ("REJECT_MALFORMED", None)
    cur = doc.get("currency", doc.get("cur"))
    if isinstance(cur, str):
        cur = cur.upper()
    if doc.get("currency") is not None and doc.get("cur") is not None and str(doc["currency"]).upper() != str(doc["cur"]).upper():
        return ("REJECT_PROHIBITED", None)
    scale = doc.get("scale")
    eid = doc.get("event_id")
    t, tr = ts_ms(doc.get("timestamp"))
    if eid is None or scale is None or cur is None or doc.get("amount") is None:
        return ("ABSTAIN_UNDERSPECIFIED", None)
    if cur not in REG or int(scale) != REG.get(cur, -1):
        return ("REJECT_PROHIBITED", None)
    m, mr = minor_of(doc.get("amount"), int(scale))
    if tr == "MALFORMED" or mr == "MALFORMED":
        return ("REJECT_MALFORMED", None)
    if tr == "OUT_OF_RANGE" or mr == "PROHIBITED":
        return ("REJECT_PROHIBITED", None)
    if t is None or m is None:
        return ("ABSTAIN_UNDERSPECIFIED", None)
    bc = doc.get("beneficiary_code", doc.get("beneficiary"))
    bc = None if bc is None else unicodedata.normalize("NFC", str(bc)).strip()
    typed = {"eid": eid, "t": t, "minor": m, "cur": cur, "bc": bc, "ref": doc.get("obligation_ref")}
    return ("ACCEPT", rfc8785.dumps(typed))


def adjudicate_J01():
    rows = []
    for c in J01:
        kind = c["kind"]
        da = c["input_a"]; db = c.get("input_b")
        ra, ea = transform(da)
        rb, eb = transform(db) if db is not None else (None, None)
        if kind == "equivalent":
            label = "equal" if (ra == "ACCEPT" and rb == "ACCEPT" and ea == eb) else "not_equal"
        elif kind == "non_equivalent":
            label = "distinct" if (ra == "ACCEPT" and rb == "ACCEPT" and ea != eb) else "collapse"
        else:
            label = "abstain" if ra == "ABSTAIN_UNDERSPECIFIED" else ("accept" if ra == "ACCEPT" else "reject")
        rows.append({"case_id": c["case_id"], "kind": kind, "historical_label": kind,
                     "kv2_admission_a": ra, "kv2_admission_b": rb, "kv2_label": label})
    return rows


rows = adjudicate_J01()
with (P02 / "J01_K_V2_ADJUDICATION.jsonl").open("w", encoding="utf-8") as fh:
    for r in rows:
        fh.write(json.dumps(r, sort_keys=True) + "\n")
eq = sum(1 for r in rows if r["kind"] == "equivalent")
neq = sum(1 for r in rows if r["kind"] == "non_equivalent")
amb = sum(1 for r in rows if r["kind"] == "ambiguous")
eq_ok = sum(1 for r in rows if r["kind"] == "equivalent" and r["kv2_label"] == "equal")
neq_ok = sum(1 for r in rows if r["kind"] == "non_equivalent" and r["kv2_label"] == "distinct")
amb_ok = sum(1 for r in rows if r["kind"] == "ambiguous" and r["kv2_label"] == "abstain")
import csv
with (P02 / "J01_K_V2_COMPATIBILITY.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["kind", "n", "kv2_expected", "kv2_ok", "compatible"])
    w.writerow(["equivalent", eq, "equal", eq_ok, eq_ok == eq])
    w.writerow(["non_equivalent", neq, "distinct", neq_ok, neq_ok == neq])
    w.writerow(["ambiguous", amb, "abstain", amb_ok, amb_ok == amb])
print(json.dumps({"equiv": [eq_ok, eq], "distinct": [neq_ok, neq], "ambiguous": [amb_ok, amb]}, indent=2))