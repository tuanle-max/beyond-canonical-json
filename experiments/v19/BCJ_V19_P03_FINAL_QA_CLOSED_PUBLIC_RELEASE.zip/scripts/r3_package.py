"""P02-R3 packaging: regenerate SHA256SUMS, build BCJ_V19_P02_R3_REVIEW.zip, verify."""
import hashlib, pathlib, zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
SCRIPTS = ROOT / "experiments" / "v19" / "scripts"
OUT = ROOT / "experiments" / "v19"

files = sorted(p for p in P02.iterdir() if p.is_file() and p.name != "SHA256SUMS")
lines = ["%s  %s" % (hashlib.sha256(p.read_bytes()).hexdigest(), p.name) for p in files]
(P02 / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

zip_path = OUT / "BCJ_V19_P02_R3_REVIEW.zip"
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(P02.iterdir()):
        if p.is_file():
            z.write(p, "results/P02/" + p.name)
    for n in ["r3_bindings.py", "r3_commitment_kat.py", "r3_oracle.py", "r3_boundary_kat.py"]:
        z.write(SCRIPTS / n, "scripts/" + n)

sha = hashlib.sha256(zip_path.read_bytes()).hexdigest()
(OUT / "BCJ_V19_P02_R3_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P02_R3_REVIEW.zip\n" % sha, encoding="utf-8")

# verify
with zipfile.ZipFile(zip_path) as z:
    crc = z.testzip()  # None if all CRCs ok
    names = z.namelist()
    ok_internal = True
    sums = z.read("results/P02/SHA256SUMS").decode().splitlines()
    for line in sums:
        h, n = line.split("  ", 1)
        if hashlib.sha256(z.read("results/P02/" + n)).hexdigest() != h:
            ok_internal = False
print("zip_sha256", sha)
print("crc_ok", crc is None, "entries", len(names), "internal_manifest_ok", ok_internal)
print("detached_match", (OUT / "BCJ_V19_P02_R3_REVIEW.zip.sha256").read_text().split()[0] == sha)