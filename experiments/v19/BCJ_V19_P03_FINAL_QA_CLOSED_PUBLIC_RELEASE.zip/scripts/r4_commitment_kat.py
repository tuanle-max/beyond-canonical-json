"""R4-07: commitment-v3 KAT with full preimages; recursive-split vs stack/frontier (independent) root paths."""
import json, hashlib, pathlib
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
MAN = json.loads((P02 / "semantic_manifest_v2.R4.CANDIDATE.json").read_text(encoding="utf-8"))
PID = bytes.fromhex(hashlib.sha256(rfc8785.dumps(MAN)).hexdigest())
CONSTR = {"schema": "drtea-commitment-v3", "construction_version": "3.0",
          "leaf": "SHA256(0x00||0x03||pid[32]||cd[32]||canonical_bytes)",
          "internal": "SHA256(0x01||L[32]||R[32])", "tree": "rfc9162_recursive_split",
          "empty_root": "SHA256(0x02||0x00)", "batch": {"admitted_only": True, "order": "record_order",
          "duplicates": "repeated_leaf", "missing_record": "batch_fail", "index": "tree_placement_not_hashed",
          "rejected_excluded": True, "counts": "kept_outside_root"}}
CD = hashlib.sha256(rfc8785.dumps(CONSTR)).digest()
(P02 / "construction_manifest_v3.R4.CANDIDATE.json").write_text(json.dumps(CONSTR, indent=2) + "\n", encoding="utf-8")


def leaf(b):
    return hashlib.sha256(b"\x00\x03" + PID + CD + b).digest()


def node(l, r):
    return hashlib.sha256(b"\x01" + l + r).digest()


def rec(xs, nodes, depth=0):
    """Recursive largest-power-of-two split; logs internal node preimages/digests."""
    n = len(xs)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest()
    if n == 1:
        return xs[0]
    k = 1
    while k * 2 < n:
        k *= 2
    left = rec(xs[:k], nodes, depth + 1); right = rec(xs[k:], nodes, depth + 1)
    nodes.append({"level": depth, "left": left.hex(), "right": right.hex(),
                  "preimage_hex": (b"\x01" + left + right).hex(), "digest": node(left, right).hex()})
    return node(left, right)


def stack_root(leaves):
    """Independent path: streaming frontier (combine equal-size subtrees), then fold top-down."""
    if not leaves:
        return hashlib.sha256(b"\x02\x00").digest()
    st = []
    for lf in leaves:
        st.append((1, lf))
        while len(st) >= 2 and st[-1][0] == st[-2][0]:
            s, r = st.pop(); s2, r2 = st.pop()
            st.append((s + s2, node(r2, r)))
    while len(st) > 1:
        s, r = st.pop(); s2, r2 = st.pop()
        st.append((s + s2, node(r2, r)))
    return st[0][1]


def doc(s):
    return rfc8785.dumps({"eid": s, "t": 1730000000000, "minor": 25000, "cur": "USD", "bc": "BC-1", "ref": None})


docs5 = [doc(x) for x in "abcde"]
LEAVES = [leaf(d) for d in docs5]
cases = [("empty", []), ("single", [1]), ("two", [2]), ("three", [3]), ("five", [5])]
out = []
for name, idx in cases:
    leaves = [LEAVES[i - 1] if idx else None for i in idx] if idx else []
    leaves = [LEAVES[i - 1] for i in idx] if idx else []
    nodes = []
    rr = rec(leaves, nodes)
    rs = stack_root(leaves)
    out.append({"case": name, "n": len(leaves), "pid": PID.hex(), "cd": CD.hex(),
                "leaf_preimages": [b"\x00\x03".hex() + PID.hex() + CD.hex() + (docs5[i - 1].hex() if idx else "") for i in []] if False else [],
                "leaf_digests": [l.hex() for l in leaves], "internal_nodes": nodes,
                "root": rr.hex(), "root_stack": rs.hex(), "agree": rr == rs})
# duplicate + reorder
dups = [LEAVES[0], LEAVES[0], LEAVES[1]]
nodes = []; rd = rec(dups, nodes); sd = stack_root(dups)
out.append({"case": "duplicate", "n": 3, "leaf_digests": [l.hex() for l in dups], "internal_nodes": nodes,
            "root": rd.hex(), "root_stack": sd.hex(), "agree": rd == sd})
reo = [LEAVES[1], LEAVES[0], LEAVES[2]]
nodes = []; rr2 = rec(reo, nodes); sr2 = stack_root(reo)
out.append({"case": "reorder", "n": 3, "leaf_digests": [l.hex() for l in reo], "internal_nodes": nodes,
            "root": rr2.hex(), "root_stack": sr2.hex(), "agree": rr2 == sr2,
            "differs_from_original": rr2.hex() != rec([LEAVES[0], LEAVES[1], LEAVES[2]], []).hex()})
# changed pid / construction
PID2 = bytes.fromhex("00" * 32)
def leaf2(b):
    return hashlib.sha256(b"\x00\x03" + PID2 + CD + b).digest()
L2 = [leaf2(d) for d in docs5[:2]]
base2 = [LEAVES[0], LEAVES[1]]
out.append({"case": "changed_pid", "n": 2, "root_base": rec(base2, []).hex(), "root_changed": rec(L2, []).hex(),
            "differs": rec(base2, []) != rec(L2, [])})
CD2 = bytes.fromhex("11" * 32)
def leaf3(b):
    return hashlib.sha256(b"\x00\x03" + PID + CD2 + b).digest()
L3 = [leaf3(d) for d in docs5[:2]]
out.append({"case": "changed_construction", "n": 2, "root_base": rec(base2, []).hex(), "root_changed": rec(L3, []).hex(),
            "differs": rec(base2, []) != rec(L3, [])})
with (P02 / "COMMITMENT_V3_KAT.R4.jsonl").open("w", encoding="utf-8") as fh:
    for c in out:
        fh.write(json.dumps(c, sort_keys=True) + "\n")
print("cd", CD.hex())
print("agree_all", all(c["agree"] for c in out if "agree" in c),
      "changed_differ", all(c["differs"] for c in out if "differs" in c),
      "reorder_differs", out[6]["differs_from_original"])