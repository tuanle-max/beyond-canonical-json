"""R4 adversarial EXPECTED suite (Agent-Q: hand-derived from NORMATIVE_CONTRACT.R4; does NOT import r4_oracle)."""
import json, datetime as dt, hashlib, base64, csv
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

BASE = [("event_id", '"EV-1"'), ("timestamp", '"2026-01-01T00:00:00Z"'),
        ("amount", '"100.00"'), ("currency", '"USD"'), ("scale", "2"),
        ("beneficiary_code", '"BC-1"')]
_OMIT = object()
_EPOCH = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)


def mk(**kw):
    d = dict(BASE)
    for k, v in kw.items():
        if v is _OMIT:
            d.pop(k, None)
        else:
            d[k] = v
    return list(d.items())


def raw(pairs):
    return ('{' + ','.join(json.dumps(k) + ':' + v for k, v in pairs) + '}').encode()


def tms(iso):
    s = iso
    off = 0
    if s.endswith("Z"):
        s2 = s[:-1]
    else:
        sign = 1 if s[-6] == "+" else -1
        off = sign * (int(s[-5:-3]) * 60 + int(s[-2:]))
        s2 = s[:-6]
    d, _, frac = s2.partition(".")
    y, mo, da, H, M, S = map(int, d.replace("T", " ").replace("-", " ").replace(":", " ").split())
    local = dt.datetime(y, mo, da, H, M, S, int((frac or "0").ljust(6, "0")[:6]),
                        tzinfo=dt.timezone(dt.timedelta(minutes=off)))
    dl = local.astimezone(dt.timezone.utc) - _EPOCH
    return (dl.days * 86400 * 10**6 + dl.seconds * 10**6 + dl.microseconds) // 1000


def minor(amt, scale):
    with localcontext() as c:
        c.prec = 60
        return int((Decimal(amt) * (Decimal(10) ** scale)).quantize(Decimal(1), rounding=ROUND_HALF_UP))


CASES = []


def rej(cid, fam, rule, pairs, decision, reason, rawbytes=None):
    CASES.append({"case_id": cid, "fault_family": fam, "rule": rule,
                  "raw": rawbytes if rawbytes is not None else raw(pairs),
                  "expected_decision": decision, "expected_reason": reason, "expected_object": None})


def acc(cid, fam, rule, pairs, eid, ts, amt, cur, bc, ref):
    t = ts if isinstance(ts, int) else tms(ts)
    m = minor(amt, {"USD": 2, "EUR": 2, "VND": 0}[cur])
    CASES.append({"case_id": cid, "fault_family": fam, "rule": rule, "raw": raw(pairs),
                  "expected_decision": "ACCEPT", "expected_reason": None,
                  "expected_object": {"eid": eid, "t": t, "minor": m, "cur": cur, "bc": bc, "ref": ref}})


# A. schema/types
rej("A01", "schema", "beneficiary required", mk(beneficiary_code=_OMIT), "ABSTAIN_UNDERSPECIFIED", "MISSING_BENEFICIARY")
rej("A02", "schema", "null beneficiary", mk(beneficiary_code="null"), "ABSTAIN_UNDERSPECIFIED", "MISSING_BENEFICIARY")
rej("A03", "schema", "non-string beneficiary", mk(beneficiary_code="123"), "REJECT_MALFORMED", "FIELD_TYPE_MALFORMED")
rej("A04", "schema", "unknown field", mk() + [("foo", "1")], "REJECT_PROHIBITED", "UNKNOWN_FIELD")
rej("A05", "schema", "unsupported payer_id", mk() + [("payer_id", '"P1"')], "REJECT_PROHIBITED", "UNKNOWN_FIELD")
rej("A06", "schema", "event_id grammar", mk(event_id='"EV 1"'), "REJECT_MALFORMED", "EVENT_ID_MALFORMED")
rej("A07", "schema", "obligation_ref grammar", mk() + [("obligation_ref", '"bad\\tref"')], "REJECT_MALFORMED", "FIELD_TYPE_MALFORMED")
rej("A08", "schema", "boolean scale", mk(scale="true"), "REJECT_MALFORMED", "SCALE_MALFORMED")
rej("A09", "schema", "string scale", mk(scale='"2"'), "REJECT_MALFORMED", "SCALE_MALFORMED")
rej("A10", "schema", "decimal scale", mk(scale="2.0"), "REJECT_MALFORMED", "SCALE_MALFORMED")
rej("A11", "schema", "lowercase currency", mk(currency='"usd"'), "REJECT_PROHIBITED", "UNSUPPORTED_CURRENCY")

# B. aliases
acc("B01", "alias", "canonical-only currency", mk(), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
acc("B02", "alias", "alias-only currency", mk(currency=_OMIT) + [("cur", '"USD"')], "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
acc("B03", "alias", "equal currency aliases", mk() + [("cur", '"USD"')], "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
rej("B04", "alias", "conflicting currency aliases", mk() + [("cur", '"EUR"')], "REJECT_PROHIBITED", "ALIAS_CONFLICT")
acc("B05", "alias", "equal beneficiary aliases NFC", mk(beneficiary_code='"Jos\u00e9"') + [("beneficiary", '"Jose\\u0301"')], "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "Jos\u00e9", None)
rej("B06", "alias", "conflicting beneficiary aliases", mk() + [("beneficiary", '"B"')], "REJECT_PROHIBITED", "ALIAS_CONFLICT")

# C. monetary lexical
acc("C01", "monetary", "raw decimal token 250.0", mk(amount="250.0"), "EV-1", "2026-01-01T00:00:00Z", "250.00", "USD", "BC-1", None)
acc("C02", "monetary", "integer token 250", mk(amount="250"), "EV-1", "2026-01-01T00:00:00Z", "250.00", "USD", "BC-1", None)
acc("C03", "monetary", "decimal string 250.00", mk(amount='"250.00"'), "EV-1", "2026-01-01T00:00:00Z", "250.00", "USD", "BC-1", None)
acc("C04", "monetary", "raw decimal 2.675", mk(amount="2.675"), "EV-1", "2026-01-01T00:00:00Z", "2.68", "USD", "BC-1", None)
rej("C05", "monetary", "leading-zero", mk(amount='"0250.00"'), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C06", "monetary", "grouping", mk(amount='"1,000.00"'), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C07", "monetary", "exponent", mk(amount="1e3"), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C08", "monetary", "excess fraction", mk(amount='"1.2345678"'), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C09", "monetary", "excess integer digits", mk(amount='"12345678901234567"'), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C10", "monetary", "negative", mk(amount='"-5.00"'), "REJECT_PROHIBITED", "NEGATIVE_AMOUNT")
rej("C11", "monetary", "negative zero", mk(amount='"-0.00"'), "REJECT_PROHIBITED", "NEGATIVE_AMOUNT")
rej("C12", "monetary", "boolean amount", mk(amount="true"), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("C13", "monetary", "whitespace", mk(amount='" 250.00"'), "REJECT_MALFORMED", "AMOUNT_MALFORMED")

# D. safe-integer boundary (USD scale 2)
acc("D01", "safeint", "max exact", mk(amount='"90071992547409.91"'), "EV-1", "2026-01-01T00:00:00Z", "90071992547409.91", "USD", "BC-1", None)
acc("D02", "safeint", "round to max", mk(amount='"90071992547409.914"'), "EV-1", "2026-01-01T00:00:00Z", "90071992547409.914", "USD", "BC-1", None)
rej("D03", "safeint", "round overflow", mk(amount='"90071992547409.915"'), "REJECT_PROHIBITED", "MONETARY_OVERFLOW")
rej("D04", "safeint", "exact overflow", mk(amount='"90071992547409.92"'), "REJECT_PROHIBITED", "MONETARY_OVERFLOW")

# E. timestamp
acc("E01", "timestamp", "same instant +07:00", mk(timestamp='"2026-01-01T07:00:00+07:00"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
acc("E02", "timestamp", "same ms class microseconds", mk(timestamp='"2026-01-01T00:00:00.123456Z"'), "EV-1", "2026-01-01T00:00:00.123000Z", "100.00", "USD", "BC-1", None)
acc("E03", "timestamp", "adjacent ms", mk(timestamp='"2026-01-01T00:00:00.124000Z"'), "EV-1", "2026-01-01T00:00:00.124000Z", "100.00", "USD", "BC-1", None)
acc("E04", "timestamp", "pre-epoch floor", mk(timestamp='"1969-12-31T23:59:59.999500Z"'), "EV-1", -1, "100.00", "USD", "BC-1", None)
acc("E05", "timestamp", "post-epoch", mk(timestamp='"1970-01-01T00:00:00.000500Z"'), "EV-1", 0, "100.00", "USD", "BC-1", None)
acc("E06", "timestamp", "int MAX_SAFE", mk(timestamp="9007199254740991"), "EV-1", 9007199254740991, "100.00", "USD", "BC-1", None)
rej("E07", "timestamp", "int MAX+1", mk(timestamp="9007199254740992"), "REJECT_PROHIBITED", "TIMESTAMP_OUT_OF_RANGE")
rej("E08", "timestamp", "int MAX+2", mk(timestamp="9007199254740993"), "REJECT_PROHIBITED", "TIMESTAMP_OUT_OF_RANGE")
acc("E09", "timestamp", "int MIN_SAFE", mk(timestamp="-9007199254740991"), "EV-1", -9007199254740991, "100.00", "USD", "BC-1", None)
rej("E10", "timestamp", "int MIN-1", mk(timestamp="-9007199254740992"), "REJECT_PROHIBITED", "TIMESTAMP_OUT_OF_RANGE")
rej("E11", "timestamp", "numeric string", mk(timestamp='"1700000000000"'), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
rej("E12", "timestamp", "invalid calendar", mk(timestamp='"2026-02-30T00:00:00Z"'), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
rej("E13", "timestamp", "missing tz", mk(timestamp='"2026-01-01T00:00:00"'), "ABSTAIN_UNDERSPECIFIED", "TIMESTAMP_MISSING_TZ")
rej("E14", "timestamp", "bad offset minute", mk(timestamp='"2026-01-01T00:00:00+05:07"'), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
rej("E15", "timestamp", "leap second", mk(timestamp='"2026-01-01T00:00:60Z"'), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")

# F. unicode / identifiers
acc("F01", "unicode", "precomposed Jos\u00e9", mk(beneficiary_code='"Jos\\u00e9"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "Jos\u00e9", None)
acc("F02", "unicode", "decomposed Jose+combining", mk(beneficiary_code='"Jose\\u0301"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "Jos\u00e9", None)
acc("F03", "unicode", "fullwidth A", mk(beneficiary_code='"\uff21"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "\uff21", None)
acc("F04", "unicode", "circled digit 1", mk(beneficiary_code='"\u2460"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "\u2460", None)
acc("F05", "unicode", "compat ligature fi", mk(beneficiary_code='"\ufb01"'), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "\ufb01", None)
rej("F06", "unicode", "C0 control", mk(beneficiary_code='"\\u0001"'), "REJECT_MALFORMED", "UNICODE_MALFORMED")
rej("F07", "unicode", "C1 control", mk(beneficiary_code='"\\u0085"'), "REJECT_MALFORMED", "UNICODE_MALFORMED")
rej("F08", "unicode", "unpaired surrogate",
    None, "REJECT_MALFORMED", "UNICODE_MALFORMED",
    rawbytes=b'{"event_id":"EV-1","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"\xed\xa0\x80"}')
acc("F09", "unicode", "distinct opaque ids", mk(event_id='"EV-2"') + [("obligation_ref", '"OBL-XYZ"')], "EV-2", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", "OBL-XYZ")

# G. null / absence
acc("G01", "null", "missing obligation_ref", mk(), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
acc("G02", "null", "null obligation_ref", mk() + [("obligation_ref", "null")], "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", None)
acc("G03", "null", "present obligation_ref", mk() + [("obligation_ref", '"OBL-9"')], "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "BC-1", "OBL-9")
rej("G04", "null", "missing mandatory", mk(event_id=_OMIT), "ABSTAIN_UNDERSPECIFIED", "MISSING_EVENT_ID")

# H. parser
rej("H01", "parser", "duplicate keys", None, "REJECT_MALFORMED", "DUPLICATE_KEY",
    rawbytes=b'{"event_id":"EV-1","event_id":"EV-2","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}')
rej("H02", "parser", "invalid utf-8", None, "REJECT_MALFORMED", "UNICODE_MALFORMED",
    rawbytes=b'{"event_id":"EV-1","beneficiary_code":"\xff\xfe"}')
rej("H03", "parser", "malformed json", None, "REJECT_MALFORMED", "JSON_MALFORMED", rawbytes=b'{"event_id":')
rej("H04", "parser", "non-finite NaN", None, "REJECT_MALFORMED", "JSON_MALFORMED", rawbytes=b'{"amount":NaN}')
rej("H05", "parser", "non-object top-level", None, "REJECT_MALFORMED", "JSON_MALFORMED", rawbytes=b'[1,2]')

# I. multiple violations
rej("I01", "multi", "malformed event_id + unknown field", mk(event_id='"EV 1"') + [("foo", "1")], "REJECT_MALFORMED", "EVENT_ID_MALFORMED")
rej("I02", "multi", "unknown field + missing beneficiary", mk(beneficiary_code=_OMIT) + [("foo", "1")], "REJECT_PROHIBITED", "UNKNOWN_FIELD")
rej("I03", "multi", "two malformed", mk(event_id='"EV 1"', amount='"bad"'), "REJECT_MALFORMED", "EVENT_ID_MALFORMED")
rej("I04", "multi", "negative + unknown", mk(amount='"-1.00"') + [("foo", "1")], "REJECT_PROHIBITED", "NEGATIVE_AMOUNT")

for _c in CASES:
    _c["input_sha256"] = hashlib.sha256(_c["raw"]).hexdigest()
    _c["input_b64"] = base64.b64encode(_c["raw"]).decode()
    if _c["expected_object"]:
        body = rfc8785.dumps(_c["expected_object"])
        _c["expected_canonical_hex"] = body.hex()
        _c["expected_canonical_sha256"] = hashlib.sha256(body).hexdigest()
    else:
        _c["expected_canonical_hex"] = None
        _c["expected_canonical_sha256"] = None

import pathlib
P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
with (P02 / "R4_ADVERSARIAL_EXPECTED.jsonl").open("w", encoding="utf-8") as fh:
    for c in CASES:
        fh.write(json.dumps({k: c[k] for k in ("case_id", "fault_family", "rule", "input_b64",
                 "input_sha256", "expected_decision", "expected_reason", "expected_object",
                 "expected_canonical_hex", "expected_canonical_sha256")}, sort_keys=True) + "\n")
with (P02 / "R4_RULE_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["case_id", "fault_family", "rule", "expected_decision", "expected_reason"])
    for c in CASES:
        w.writerow([c["case_id"], c["fault_family"], c["rule"], c["expected_decision"], c["expected_reason"] or ""])
print("expected lock written:", len(CASES), "cases")