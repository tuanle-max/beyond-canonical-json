"""R4 reference oracle: raw-bytes strict K-v2 adjudicator. r3_oracle.py is preserved unchanged."""
import json, re, unicodedata, datetime as dt
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

MAXS = 9007199254740991
MINS = -9007199254740991
REGISTRY = {"USD": 2, "EUR": 2, "VND": 0}
EID_RE = re.compile(r"^[A-Za-z0-9_-]{1,256}$")
REF_RE = re.compile(r"^[\x20-\x7E]{1,256}$")
AMT_RE = re.compile(r"^(0|[1-9][0-9]*)(\.[0-9]{1,6})?$")
TS_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,6}))?(Z|[+-]\d{2}:\d{2})$")
TS_NOTZ_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?$")
INT_RE = re.compile(r"^-?(0|[1-9][0-9]*)$")
ALLOWED = {"event_id", "timestamp", "amount", "currency", "cur", "scale",
           "beneficiary_code", "beneficiary", "obligation_ref"}
CAT = {"REJECT_MALFORMED": 0, "REJECT_PROHIBITED": 1, "ABSTAIN_UNDERSPECIFIED": 2}
RANK = {r: i for i, r in enumerate([
    "JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED",
    "SCALE_MALFORMED", "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED",
    "NEGATIVE_AMOUNT", "MONETARY_OVERFLOW", "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH",
    "UNKNOWN_FIELD", "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE",
    "MISSING_BENEFICIARY", "MISSING_EVENT_ID", "MISSING_CURRENCY", "MISSING_SCALE",
    "MISSING_AMOUNT", "MISSING_TIMESTAMP", "TIMESTAMP_MISSING_TZ"])}
REASON_CAT = {}
for r in RANK:
    REASON_CAT[r] = ("REJECT_MALFORMED" if r in (
        "JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED",
        "SCALE_MALFORMED", "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED")
        else "REJECT_PROHIBITED" if r in (
        "NEGATIVE_AMOUNT", "MONETARY_OVERFLOW", "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH",
        "UNKNOWN_FIELD", "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE")
        else "ABSTAIN_UNDERSPECIFIED")


class Num:
    __slots__ = ("lex", "kind")

    def __init__(self, lex, kind):
        self.lex = lex; self.kind = kind

    def __repr__(self):
        return "Num(%r,%s)" % (self.lex, self.kind)


class DupKey(Exception):
    pass


def _hook(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise DupKey(k)
        d[k] = v
    return d


def _const(c):
    raise ValueError("non-finite")


def parse_raw(b):
    try:
        s = b.decode("utf-8")
    except UnicodeDecodeError:
        return None, "UNICODE_MALFORMED"
    try:
        obj = json.loads(s, object_pairs_hook=_hook, parse_int=lambda x: Num(x, "int"),
                         parse_float=lambda x: Num(x, "dec"), parse_constant=_const)
    except DupKey:
        return None, "DUPLICATE_KEY"
    except ValueError:
        return None, "JSON_MALFORMED"
    if not isinstance(obj, dict):
        return None, "JSON_MALFORMED"
    return obj, None


_EPOCH = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)


def _ts(v):
    if isinstance(v, bool):
        return None, "TIMESTAMP_MALFORMED"
    if isinstance(v, Num) and v.kind == "int":
        i = int(v.lex)
        return (i, None) if MINS <= i <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")
    if isinstance(v, Num) or not isinstance(v, str):
        return None, "TIMESTAMP_MALFORMED"
    if TS_NOTZ_RE.match(v):
        return None, "TIMESTAMP_MISSING_TZ"
    m = TS_RE.match(v)
    if not m:
        return None, "TIMESTAMP_MALFORMED"
    y, mo, d, H, M, S, frac, off = m.groups()
    if int(S) > 59:
        return None, "TIMESTAMP_MALFORMED"
    if off == "Z":
        offs = dt.timedelta(0)
    else:
        oh, om = int(off[1:3]), int(off[4:6])
        if oh > 23 or om not in (0, 15, 30, 45):
            return None, "TIMESTAMP_MALFORMED"
        offs = (1 if off[0] == "+" else -1) * dt.timedelta(hours=oh, minutes=om)
    try:
        local = dt.datetime(int(y), int(mo), int(d), int(H), int(M), int(S),
                            int((frac or "0").ljust(6, "0")), tzinfo=dt.timezone(offs))
    except ValueError:
        return None, "TIMESTAMP_MALFORMED"
    delta = local.astimezone(dt.timezone.utc) - _EPOCH
    total_us = delta.days * 86400 * 10**6 + delta.seconds * 10**6 + delta.microseconds
    ms = total_us // 1000
    return (ms, None) if MINS <= ms <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")


def _amount_lex(v):
    if isinstance(v, bool):
        return None, "AMOUNT_MALFORMED"
    if isinstance(v, Num):
        return v.lex, None
    if isinstance(v, str):
        return v, None
    return None, "AMOUNT_MALFORMED"


def _minor(lex, scale):
    if lex.startswith("-"):
        return None, "NEGATIVE_AMOUNT"
    if len(lex) > 24 or not AMT_RE.match(lex) or len(lex.split(".")[0]) > 16:
        return None, "AMOUNT_MALFORMED"
    with localcontext() as c:
        c.prec = 60
        m = int((Decimal(lex) * (Decimal(10) ** scale)).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return (m, None) if 0 <= m <= MAXS else (None, "MONETARY_OVERFLOW")


def _alias(doc, canon, alias, normalize):
    a = doc.get(canon, "\x00ABSENT"); b = doc.get(alias, "\x00ABSENT")
    pa = a != "\x00ABSENT" and a is not None
    pb = b != "\x00ABSENT" and b is not None
    if pa and pb:
        if normalize(a) != normalize(b):
            return None, "ALIAS_CONFLICT"
        return a, None
    if pb:
        return b, None
    if pa:
        return a, None
    return "\x00ABSENT", None


def evaluate(obj):
    issues = []
    for k in obj:
        if k not in ALLOWED:
            issues.append("UNKNOWN_FIELD")
    eid = obj.get("event_id", "\x00ABSENT")
    if eid == "\x00ABSENT" or eid is None:
        issues.append("MISSING_EVENT_ID")
    elif not isinstance(eid, str) or not EID_RE.match(eid):
        issues.append("EVENT_ID_MALFORMED")
    ts = obj.get("timestamp", "\x00ABSENT")
    t = None
    if ts == "\x00ABSENT" or ts is None:
        issues.append("MISSING_TIMESTAMP")
    else:
        t, terr = _ts(ts)
        if terr:
            issues.append(terr)
    cur, cerr = _alias(obj, "currency", "cur", lambda x: x)
    if cerr:
        issues.append(cerr)
    if cur == "\x00ABSENT" or cur is None:
        issues.append("MISSING_CURRENCY"); cur = None
    elif not isinstance(cur, str) or cur not in REGISTRY:
        issues.append("UNSUPPORTED_CURRENCY"); cur = None
    sc = obj.get("scale", "\x00ABSENT"); scal = None
    if sc == "\x00ABSENT" or sc is None:
        issues.append("MISSING_SCALE")
    elif not (isinstance(sc, Num) and sc.kind == "int" and INT_RE.match(sc.lex)):
        issues.append("SCALE_MALFORMED")
    else:
        scal = int(sc.lex)
    if scal is not None and cur is not None and scal != REGISTRY[cur]:
        issues.append("SCALE_MISMATCH")
    am = obj.get("amount", "\x00ABSENT"); minor = None
    if am == "\x00ABSENT" or am is None:
        issues.append("MISSING_AMOUNT")
    else:
        lex, aerr = _amount_lex(am)
        if aerr:
            issues.append(aerr)
        elif lex.startswith("-"):
            issues.append("NEGATIVE_AMOUNT")
        elif scal is not None:
            minor, merr = _minor(lex, scal)
            if merr:
                issues.append(merr)
    nfc = lambda x: unicodedata.normalize("NFC", x) if isinstance(x, str) else x
    bc, berr = _alias(obj, "beneficiary_code", "beneficiary", nfc)
    if berr:
        issues.append(berr)
    bcv = None
    if bc == "\x00ABSENT" or bc is None:
        issues.append("MISSING_BENEFICIARY")
    elif not isinstance(bc, str):
        issues.append("FIELD_TYPE_MALFORMED")
    else:
        n = unicodedata.normalize("NFC", bc)
        if n == "":
            issues.append("FIELD_TYPE_MALFORMED")
        elif any(ord(c) < 0x20 or 0x7F <= ord(c) <= 0x9F for c in n):
            issues.append("UNICODE_MALFORMED")
        else:
            bcv = n
    ref = obj.get("obligation_ref", "\x00ABSENT"); refv = None
    if ref not in ("\x00ABSENT", None):
        if not isinstance(ref, str) or not REF_RE.match(ref):
            issues.append("FIELD_TYPE_MALFORMED")
        else:
            refv = ref
    if issues:
        best = min(issues, key=lambda r: (CAT[REASON_CAT[r]], RANK[r]))
        return {"decision": REASON_CAT[best], "reason_code": best, "business_object": None,
                "eligible_json": None, "canonical_hex": None, "execution_status": "OK"}
    typed = {"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bcv, "ref": refv}
    return {"decision": "ACCEPT", "reason_code": None, "business_object": typed,
            "eligible_json": typed, "canonical_hex": rfc8785.dumps(typed).hex(), "execution_status": "OK"}


def adjudicate(raw):
    obj, perr = parse_raw(raw)
    if perr:
        return {"decision": REASON_CAT[perr], "reason_code": perr, "business_object": None,
                "eligible_json": None, "canonical_hex": None, "execution_status": "OK"}
    return evaluate(obj)