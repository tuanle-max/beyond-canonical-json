"""R4 boundary KAT (fixes K13/K09-K32/P05/K22/K16/P07/reason-codes) + J01 per-leg adjudication (R4-04, R4-05)."""
import json, base64, hashlib, csv, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r4_oracle

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
BASE = [("event_id", '"EV-1"'), ("timestamp", '"2026-01-01T00:00:00Z"'),
        ("amount", '"100.00"'), ("currency", '"USD"'), ("scale", "2"),
        ("beneficiary_code", '"BC-1"')]
_OMIT = object()


def raw(pairs):
    return ('{' + ','.join(json.dumps(k) + ':' + v for k, v in pairs) + '}').encode()


def mk(**kw):
    d = dict(BASE)
    for k, v in kw.items():
        if v is _OMIT:
            d.pop(k, None)
        else:
            d[k] = v
    return list(d.items())


# (case_id, family, raw_bytes, expected_decision, expected_reason)
B = [
    ("R4-01", "base", raw(mk()), "ACCEPT", None),
    ("R4-13", "monetary", raw(mk(amount="250.0")), "ACCEPT", None),          # exact raw decimal token
    ("R4-14", "monetary", raw(mk(amount='"250.00"')), "ACCEPT", None),
    ("R4-08", "monetary", raw(mk(amount="2.674999")), "ACCEPT", None),
    ("R4-09", "monetary", raw(mk(amount="2.675")), "ACCEPT", None),
    ("R4-10", "monetary", raw(mk(amount="2.6750")), "ACCEPT", None),
    ("R4-11", "monetary", raw(mk(amount="0.005")), "ACCEPT", None),
    ("R4-12", "monetary", raw(mk(amount="0.004999")), "ACCEPT", None),
    ("R4-15", "monetary", raw(mk(amount='"-2.675"')), "REJECT_PROHIBITED", "NEGATIVE_AMOUNT"),
    ("R4-16", "monetary", raw(mk(amount='"90071992547409.92"')), "REJECT_PROHIBITED", "MONETARY_OVERFLOW"),
    ("R4-17", "monetary", raw(mk(scale="1")), "REJECT_PROHIBITED", "SCALE_MISMATCH"),
    ("R4-18", "timestamp", raw(mk(timestamp='"2026-01-01T07:00:00+07:00"')), "ACCEPT", None),
    ("R4-19", "timestamp", raw(mk(timestamp='"2026-01-01T00:00:00.123456Z"')), "ACCEPT", None),
    ("R4-19b", "timestamp", raw(mk(timestamp='"2026-01-01T00:00:00.123000Z"')), "ACCEPT", None),
    ("R4-19c", "timestamp", raw(mk(timestamp='"2026-01-01T00:00:00.124000Z"')), "ACCEPT", None),
    ("R4-20", "timestamp", raw(mk(timestamp='"2026-01-01T00:00:00"')), "ABSTAIN_UNDERSPECIFIED", "TIMESTAMP_MISSING_TZ"),
    ("R4-21", "timestamp", raw(mk(timestamp='"2026-01-01T00:00:60Z"')), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED"),
    ("R4-22", "timestamp", raw(mk(timestamp="9007199254740992")), "REJECT_PROHIBITED", "TIMESTAMP_OUT_OF_RANGE"),
    ("R4-22b", "timestamp", raw(mk(timestamp='"1700000000000"')), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED"),
    ("R4-23", "unicode", raw(mk(beneficiary_code='"Jos\\u00e9"')), "ACCEPT", None),
    ("R4-24", "unicode", raw(mk(beneficiary_code='"Jose\\u0301"')), "ACCEPT", None),
    ("R4-25", "unicode", raw(mk(beneficiary_code='"\uff21"')), "ACCEPT", None),
    ("R4-25a", "unicode", raw(mk(beneficiary_code='"A"')), "ACCEPT", None),
    ("R4-26", "null", raw(mk() + [("obligation_ref", "null")]), "ACCEPT", None),
    ("R4-27", "null", raw(mk() + [("obligation_ref", '"OBL-9"')]), "ACCEPT", None),
    ("R4-28", "alias", raw(mk() + [("cur", '"USD"')]), "ACCEPT", None),
    ("R4-29", "alias", raw(mk() + [("cur", '"EUR"')]), "REJECT_PROHIBITED", "ALIAS_CONFLICT"),
    ("R4-30", "parser", b'{"event_id":"EV-1","event_id":"EV-2","timestamp":"2026-01-01T00:00:00Z","amount":"100.00","currency":"USD","scale":2,"beneficiary_code":"BC-1"}', "REJECT_MALFORMED", "DUPLICATE_KEY"),
    ("R4-31", "parser", b'{"beneficiary_code":"\xff"}', "REJECT_MALFORMED", "UNICODE_MALFORMED"),
    ("R4-32", "safeint", raw(mk(amount='"90071992547409.91"')), "ACCEPT", None),
    ("R4-32b", "safeint", raw(mk(amount='"90071992547409.915"')), "REJECT_PROHIBITED", "MONETARY_OVERFLOW"),
]
kat = []
uns = 0
for cid, fam, rb, ed, er in B:
    obs = r4_oracle.adjudicate(rb)
    if not (obs["decision"] == ed and obs["reason_code"] == er):
        uns += 1
        print("BOUNDARY MISMATCH", cid, ed, er, "->", obs["decision"], obs["reason_code"])
    kat.append({"case_id": cid, "fault_family": fam, "input_bytes_base64": base64.b64encode(rb).decode(),
                "input_sha256": hashlib.sha256(rb).hexdigest(), "expected_decision": ed,
                "expected_reason_code": er, "observed_decision": obs["decision"],
                "observed_reason_code": obs["reason_code"],
                "expected_eligible_json": obs["eligible_json"], "expected_canonical_sha256": (
                    hashlib.sha256(bytes.fromhex(obs["canonical_hex"])).hexdigest() if obs["canonical_hex"] else None)})
with (P02 / "P02_BOUNDARY_KAT.R4.jsonl").open("w", encoding="utf-8") as fh:
    for k in kat:
        fh.write(json.dumps(k, sort_keys=True) + "\n")
print("boundary cases", len(kat), "mismatches", uns)

# ---- pair register (definite relationships) ----
byid = {k["case_id"]: k for k in kat}


def biz(cid):
    return byid[cid]["expected_eligible_json"]


def rel_ok(a, b, want):
    ea, eb = biz(a), biz(b)
    if want == "business-equal":
        return ea is not None and eb is not None and ea == eb
    if want == "business-distinct":
        return ea is not None and eb is not None and ea != eb
    if want == "admission-differs":
        return byid[a]["observed_decision"] != byid[b]["observed_decision"]
    return False


PAIRS = [
    ("R4-P01", "R4-13", "R4-14", "business-equal", "canonical-equal", "token 250.0 == string 250.00"),
    ("R4-P02", "R4-09", "R4-10", "business-equal", "canonical-equal", "2.675 == 2.6750 -> 268"),
    ("R4-P03", "R4-09", "R4-11", "business-distinct", "canonical-distinct", "268 vs 1"),
    ("R4-P04", "R4-12", "R4-11", "business-distinct", "canonical-distinct", "0 vs 1"),
    ("R4-P05", "R4-18", "R4-01", "business-equal", "canonical-equal", "+07:00 same instant as Z"),
    ("R4-P06", "R4-19", "R4-19b", "business-equal", "canonical-equal", ".123456 vs .123000 same ms"),
    ("R4-P07", "R4-19", "R4-19c", "business-distinct", "canonical-distinct", ".123 vs .124 adjacent ms"),
    ("R4-P08", "R4-23", "R4-24", "business-equal", "canonical-equal", "NFC == NFD Jose"),
    ("R4-P09", "R4-25a", "R4-25", "business-distinct", "canonical-distinct", "ASCII A vs fullwidth A"),
    ("R4-P10", "R4-26", "R4-27", "business-distinct", "canonical-distinct", "null ref vs present ref"),
    ("R4-P11", "R4-28", "R4-29", "admission-differs", "n/a", "equal alias vs conflict"),
    ("R4-P12", "R4-08", "R4-09", "business-distinct", "canonical-distinct", "267 vs 268"),
]
with (P02 / "P02_BOUNDARY_PAIR_REGISTER.R4.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["pair_id", "leg_a", "leg_b", "expected_equivalence", "expected_canonical", "rationale", "verified"])
    nbad = 0
    for pid, a, b, e, c, r in PAIRS:
        ok = rel_ok(a, b, e)
        nbad += (not ok)
        w.writerow([pid, a, b, e, c, r, ok])
from collections import Counter
pc = Counter(k["observed_decision"] for k in kat)
uniq = len({k["input_sha256"] for k in kat})
with (P02 / "MALFORMED_INPUT_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["metric", "value"])
    w.writerow(["case_ids", len(kat)])
    w.writerow(["unique_input_digests", uniq])
    w.writerow(["D_K+", pc.get("ACCEPT", 0)])
    w.writerow(["D_K-", pc.get("REJECT_MALFORMED", 0) + pc.get("REJECT_PROHIBITED", 0)])
    w.writerow(["D_K?", pc.get("ABSTAIN_UNDERSPECIFIED", 0)])
    w.writerow(["pairs", len(PAIRS)])
print("pairs bad", nbad, "unique_inputs", uniq, dict(pc))

# ---- J01 per-leg adjudication (R4-05) ----
import rfc8785
ROOT = pathlib.Path(__file__).resolve().parents[3]
src = ROOT / "derived" / "results" / "j01_cases.json"
srcb = src.read_bytes()
J = json.loads(srcb)["cases"]
(P02 / "J01_SOURCE_CORPUS.json").write_text(srcb.decode("utf-8"), encoding="utf-8")
print("j01 corpus sha256", hashlib.sha256(srcb).hexdigest(), "units", len(J))


def leg_evidence(cid, leg, hist, doc):
    rb = rfc8785.dumps(doc)
    o = r4_oracle.adjudicate(rb)
    return {"case_id": cid, "leg": leg, "historical_label": hist,
            "input_b64": base64.b64encode(rb).decode(), "input_sha256": hashlib.sha256(rb).hexdigest(),
            "admission": o["decision"], "reason_code": o["reason_code"], "business_object": o["eligible_json"],
            "canonical_sha256": hashlib.sha256(bytes.fromhex(o["canonical_hex"])).hexdigest() if o["canonical_hex"] else None,
            "rule": "NORMATIVE_CONTRACT.R4", "rationale": "JCS(parsed fixture) reconstruct; typed-object equivalence"}


adj = []
comp = Counter()
occ = 0
for c in J:
    kind = c["kind"]
    a = leg_evidence(c["case_id"], "A", kind, c["input_a"]); adj.append(a); occ += 1
    b = None
    if c.get("input_b") is not None:
        b = leg_evidence(c["case_id"], "B", kind, c["input_b"]); adj.append(b); occ += 1
    eq = (a["business_object"] is not None and b is not None and b["business_object"] is not None
          and a["business_object"] == b["business_object"])
    if kind == "equivalent":
        got = "equal" if eq else "not_equal"
    elif kind == "non_equivalent":
        got = "distinct" if (a["business_object"] is not None and b is not None and b["business_object"] is not None and not eq) else "collapse"
    else:
        got = "abstain" if a["admission"] == "ABSTAIN_UNDERSPECIFIED" else a["admission"]
    comp[(kind, got)] += 1
with (P02 / "J01_K_V2_ADJUDICATION.R4.jsonl").open("w", encoding="utf-8") as fh:
    for r in adj:
        fh.write(json.dumps(r, sort_keys=True) + "\n")
(P02 / "J01_RECONSTRUCTED_INPUTS.jsonl").write_text(
    "".join(json.dumps({"case_id": r["case_id"], "leg": r["leg"], "input_b64": r["input_b64"],
                        "input_sha256": r["input_sha256"]}, sort_keys=True) + "\n" for r in adj), encoding="utf-8")
ne = sum(v for (k, g), v in comp.items() if k == "equivalent")
nn = sum(v for (k, g), v in comp.items() if k == "non_equivalent")
na = sum(v for (k, g), v in comp.items() if k == "ambiguous")
ok_eq = comp[("equivalent", "equal")]; ok_neq = comp[("non_equivalent", "distinct")]; ok_amb = comp[("ambiguous", "abstain")]
with (P02 / "J01_K_V2_COMPATIBILITY.R4.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["kind", "n", "kv2_expected", "kv2_ok", "compatible"])
    w.writerow(["equivalent", ne, "equal", ok_eq, ok_eq == ne])
    w.writerow(["non_equivalent", nn, "distinct", ok_neq, ok_neq == nn])
    w.writerow(["ambiguous", na, "abstain", ok_amb, ok_amb == na])
print("j01 occurrences", occ, "compat eq/neq/amb", ok_eq, ok_neq, ok_amb)