"""R4 packaging + QA: environment, mutation results, SHA256SUMS, zip, fresh-extraction verify."""
import json, hashlib, pathlib, base64, zipfile, subprocess, sys, shutil, tempfile, platform
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
SCR = pathlib.Path(__file__).resolve().parent
OUT = P02.parents[1]  # experiments/v19
sys.path.insert(0, str(SCR))
import r4_oracle

DELIV = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
         "SUPPORTED_CURRENCY_SCALE_REGISTRY.json", "semantic_manifest_v2.R4.CANDIDATE.json",
         "construction_manifest_v3.R4.CANDIDATE.json", "R4_ADVERSARIAL_EXPECTED.jsonl",
         "R4_ADVERSARIAL_RESULTS.jsonl", "R4_RULE_COVERAGE_MATRIX.csv", "P02_BOUNDARY_KAT.R4.jsonl",
         "P02_BOUNDARY_PAIR_REGISTER.R4.csv", "P02_BOUNDARY_ORACLE_RATIONALES.R4.jsonl",
         "J01_SOURCE_CORPUS.json", "J01_RECONSTRUCTED_INPUTS.jsonl", "J01_K_V2_ADJUDICATION.R4.jsonl",
         "J01_K_V2_COMPATIBILITY.R4.csv", "ORACLE_PROVENANCE.R4.json", "COMMITMENT_V3_SPEC.R4.md",
         "COMMITMENT_V3_KAT.R4.jsonl", "MANIFEST_BINDING_VERIFICATION.R4.json", "ORACLE_MUTATION_RESULTS.json",
         "P02_GATE_MATRIX.R4.csv", "P02_R3_TO_R4_CHANGELOG.md", "INDEPENDENT_QA_REPORT.md", "REPORT.R4.md",
         "status.R4.json", "RUN_MANIFEST.R4.json", "environment.json", "commands.log", "verify_normative_bindings.py"]
SCRIPTS = ["r4_oracle.py", "r4_expected_suite.py", "r4_run_adversarial.py", "r4_oracle_evidence.py",
           "r4_verify.py", "r4_commitment_kat.py", "r4_package.py"]

# environment.json
import unicodedata
try:
    import importlib.metadata as md
    rv = md.version("rfc8785")
except Exception:
    rv = "unknown"
(P02 / "environment.json").write_text(json.dumps({
    "python": platform.python_version(), "platform": platform.platform(),
    "unicodedata.unidata_version": unicodedata.unidata_version, "rfc8785": rv,
    "decimal": "python stdlib", "datetime": "python stdlib"}, indent=2) + "\n", encoding="utf-8")

# rationales R4 from boundary KAT
kat = [json.loads(l) for l in (P02 / "P02_BOUNDARY_KAT.R4.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
(P02 / "P02_BOUNDARY_ORACLE_RATIONALES.R4.jsonl").write_text(
    "".join(json.dumps({"case_id": k["case_id"], "fault_family": k["fault_family"],
                        "rule": "NORMATIVE_CONTRACT.R4", "expected_decision": k["expected_decision"],
                        "expected_reason_code": k["expected_reason_code"]}, sort_keys=True) + "\n" for k in kat),
    encoding="utf-8")

# mutation QA: mutations must be detected by the checker (observed != mutated expectation)
exp = [json.loads(l) for l in (P02 / "R4_ADVERSARIAL_EXPECTED.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
muts = {"decision": [0, 0], "reason": [0, 0], "canonical": [0, 0], "struct_regen_canonical": [0, 0]}
for e in exp:
    raw = base64.b64decode(e["input_b64"])
    obs = r4_oracle.adjudicate(raw)
    fake = "REJECT_MALFORMED" if obs["decision"] != "REJECT_MALFORMED" else "ACCEPT"
    muts["decision"][1] += 1; muts["decision"][0] += (obs["decision"] != fake)
    muts["reason"][1] += 1; muts["reason"][0] += (obs["reason_code"] != "WRONG_REASON")
    if e["expected_decision"] == "ACCEPT":
        muts["canonical"][1] += 1; muts["canonical"][0] += (obs["canonical_hex"] != "0" * len(obs["canonical_hex"] or "00"))
        mutobj = dict(e["expected_object"]); mutobj["minor"] = (mutobj["minor"] + 1)
        try:
            mutcan = rfc8785.dumps(mutobj).hex()
            det = obs["canonical_hex"] != mutcan
        except Exception:
            det = True  # mutation not representable -> detected
        muts["struct_regen_canonical"][1] += 1; muts["struct_regen_canonical"][0] += det
(P02 / "ORACLE_MUTATION_RESULTS.json").write_text(json.dumps(
    {"detected_over_total": muts, "note": "detection = checker reports mismatch; structural regen still detected"}, indent=2) + "\n", encoding="utf-8")

# commands.log
(P02 / "commands.log").write_text("\n".join([
    "python experiments/v19/scripts/r4_expected_suite.py -> expected lock 71 cases",
    "python experiments/v19/scripts/r4_run_adversarial.py -> 71/71 pass",
    "python experiments/v19/scripts/r4_oracle_evidence.py -> boundary 31 cases 0 mismatch; j01 630 occ 150/150/30",
    "python experiments/v19/scripts/r4_verify.py -> V01-V10 all true; pid 71287e74",
    "python experiments/v19/scripts/r4_commitment_kat.py -> rec==stack; cd d1e46eb5",
    "python experiments/v19/scripts/r4_package.py -> package + fresh-extraction verify"]) + "\n", encoding="utf-8")

# SHA256SUMS over deliverables (+ scripts referenced)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
lines = sorted("%s  %s" % (sha(P02 / n), n) for n in DELIV if (P02 / n).exists())
(P02 / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

# zip
zp = OUT / "BCJ_V19_P02_R4_REVIEW.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in DELIV:
        z.write(P02 / n, "results/P02/" + n)
    for n in SCRIPTS:
        z.write(SCR / n, "scripts/" + n)
zsha = hashlib.sha256(zp.read_bytes()).hexdigest()
(OUT / "BCJ_V19_P02_R4_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P02_R4_REVIEW.zip\n" % zsha, encoding="utf-8")

# fresh extraction verify
td = pathlib.Path(tempfile.mkdtemp())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    z.extractall(td)
r = subprocess.run([sys.executable, str(td / "results/P02/verify_normative_bindings.py")],
                   capture_output=True, text=True, cwd=str(td))
print("zip_sha256", zsha)
print("zip_entries", len(zipfile.ZipFile(zp).namelist()))
print("fresh_verify_exit", r.returncode)
print(r.stdout.strip())
shutil.rmtree(td, ignore_errors=True)