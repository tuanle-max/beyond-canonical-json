"""R4 adversarial RESULTS: run repaired r4_oracle against locked R4_ADVERSARIAL_EXPECTED (Agent-O result pass)."""
import json, base64, pathlib, sys, csv
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r4_oracle

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
exp = [json.loads(l) for l in (P02 / "R4_ADVERSARIAL_EXPECTED.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
rows = []
npass = 0
fam = {}
for e in exp:
    raw = base64.b64decode(e["input_b64"])
    obs = r4_oracle.adjudicate(raw)
    ok = obs["decision"] == e["expected_decision"] and obs["reason_code"] == (e["expected_reason"])
    if e["expected_decision"] == "ACCEPT":
        ok = ok and obs["eligible_json"] == e["expected_object"] and obs["canonical_hex"] == e["expected_canonical_hex"]
    rows.append({"case_id": e["case_id"], "fault_family": e["fault_family"], "rule": e["rule"],
                 "input_sha256": e["input_sha256"], "expected_decision": e["expected_decision"],
                 "expected_reason": e["expected_reason"], "observed_decision": obs["decision"],
                 "observed_reason": obs["reason_code"], "observed_canonical_hex": obs["canonical_hex"],
                 "pass": ok})
    npass += ok
    f = e["fault_family"]
    fam.setdefault(f, [0, 0]); fam[f][1] += 1; fam[f][0] += ok
with (P02 / "R4_ADVERSARIAL_RESULTS.jsonl").open("w", encoding="utf-8") as fh:
    for r in rows:
        fh.write(json.dumps(r, sort_keys=True) + "\n")
with (P02 / "R4_RULE_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["case_id", "fault_family", "rule", "expected_decision", "expected_reason", "observed_decision", "observed_reason", "pass"])
    for r in rows:
        w.writerow([r["case_id"], r["fault_family"], r["rule"], r["expected_decision"], r["expected_reason"] or "",
                    r["observed_decision"], r["observed_reason"] or "", r["pass"]])
print("adversarial:", npass, "/", len(rows), "pass")
for f, (p, t) in sorted(fam.items()):
    print("  %-10s %d/%d" % (f, p, t))
fails = [r["case_id"] for r in rows if not r["pass"]]
print("FAILS:", fails)