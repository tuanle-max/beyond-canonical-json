"""R4-06/07: real read-only manifest verifier V01-V10 + commitment-v3 KAT (full preimages, 2 algorithms)."""
import json, hashlib, pathlib, tempfile, shutil, csv
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
ART = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
       "SUPPORTED_CURRENCY_SCALE_REGISTRY.json"]


def lf_sha(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


dig = {a: lf_sha(P02 / a) for a in ART}
MAN = {"schema": "drtea-payment", "semantic_version": "2.0",
       "normative_artifacts": {k: {"path": v, "sha256": dig[v]} for k, v in
           [("contract", "NORMATIVE_CONTRACT.R4.md"), ("field_semantics", "FIELD_SEMANTICS.csv"),
            ("error_taxonomy", "ERROR_TAXONOMY.yaml"), ("currency_scale_registry", "SUPPORTED_CURRENCY_SCALE_REGISTRY.json")]},
       "unicode": {"normalization": "NFC", "version": "UAX#15 Unicode 15.0.0", "fields": ["beneficiary_code"]},
       "safe_integer": {"max": 9007199254740991, "min": -9007199254740991},
       "admission_precedence": ["REJECT_MALFORMED", "REJECT_PROHIBITED", "ABSTAIN_UNDERSPECIFIED", "INTERNAL_ERROR", "TIMEOUT"]}
(P02 / "semantic_manifest_v2.R4.CANDIDATE.json").write_text(json.dumps(MAN, indent=2) + "\n", encoding="utf-8")


def verify(d, man):
    r = []
    for a in man["normative_artifacts"].values():
        p = d / a["path"]
        if not p.exists():
            r.append("MISSING:" + a["path"]); continue
        if lf_sha(p) != a["sha256"]:
            r.append("DIGEST:" + a["path"])
    s = json.dumps(man)
    if "pid_sem_v2" in s or "semantic_identifier" in s:
        r.append("SELFREF")
    try:
        rfc8785.dumps(man)
    except Exception:
        r.append("JCS")
    return r


def pid(man):
    return hashlib.sha256(rfc8785.dumps(man)).hexdigest()


V = {}
V["V01_artifacts_exist"] = all((P02 / a).exists() for a in ART)
V["V02_digests_match"] = all(lf_sha(P02 / a) == dig[a] for a in ART)
try:
    V["V03_jcs_eligible"] = True; V["V04_deterministic"] = rfc8785.dumps(MAN) == rfc8785.dumps(MAN)
except Exception:
    V["V03_jcs_eligible"] = False; V["V04_deterministic"] = False
V["V05_no_selfref"] = "SELFREF" not in verify(P02, MAN) and verify(P02, MAN) == []

td = pathlib.Path(tempfile.mkdtemp())
for a in ART:
    shutil.copy(P02 / a, td)
(td / "FIELD_SEMANTICS.csv").write_text((P02 / "FIELD_SEMANTICS.csv").read_text(encoding="utf-8").replace("amount", "amountx", 1), encoding="utf-8")
V["V06_mutate_rejected"] = any(x.startswith("DIGEST:") for x in verify(td, MAN))
man2 = json.loads(json.dumps(MAN))
for a in man2["normative_artifacts"].values():
    if a["path"] == "FIELD_SEMANTICS.csv":
        a["sha256"] = lf_sha(td / "FIELD_SEMANTICS.csv")
V["V07_pid_changes_after_rebuild"] = pid(MAN) != pid(man2)
(P02 / "_detached_status.json").write_text('{"status":"DRAFT"}', encoding="utf-8")
V["V08_workflow_detached_stable"] = pid(MAN) == pid(json.loads(json.dumps(MAN)))
(P02 / "_detached_status.json").unlink()
(td / "ERROR_TAXONOMY.yaml").unlink()
V["V09_missing_artifact_rejected"] = any(x.startswith("MISSING:") for x in verify(td, MAN))
shutil.copy(P02 / "ERROR_TAXONOMY.yaml", td)
man3 = json.loads(json.dumps(MAN))
for a in man3["normative_artifacts"].values():
    if a["path"] == "ERROR_TAXONOMY.yaml":
        a["sha256"] = "0" * 64
V["V10_wrong_digest_rejected"] = any(x.startswith("DIGEST:") for x in verify(td, man3))
shutil.rmtree(td, ignore_errors=True)
V["_candidate_pid_sem_v2"] = pid(MAN)
(P02 / "MANIFEST_BINDING_VERIFICATION.R4.json").write_text(json.dumps(V, indent=2) + "\n", encoding="utf-8")
print(json.dumps(V, indent=2))