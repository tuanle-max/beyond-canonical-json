"""R4a corrective EXPECTED suite (Agent-Q; hand-derived from NORMATIVE_CONTRACT.R4; imports no oracle)."""
import json, datetime as dt, hashlib, base64, csv, pathlib
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
BASE = [("event_id", '"EV-1"'), ("timestamp", '"2026-01-01T00:00:00Z"'),
        ("amount", '"100.00"'), ("currency", '"USD"'), ("scale", "2"), ("beneficiary_code", '"BC-1"')]
_OMIT = object()
_EPOCH = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)


def mk(**kw):
    d = dict(BASE)
    for k, v in kw.items():
        if v is _OMIT:
            d.pop(k, None)
        else:
            d[k] = v
    return list(d.items())


def raw(pairs):
    return ('{' + ','.join(json.dumps(k) + ':' + v for k, v in pairs) + '}').encode()


def tms(iso):
    s = iso
    off = 0
    if s.endswith("Z"):
        s2 = s[:-1]
    else:
        off = (1 if s[-6] == "+" else -1) * (int(s[-5:-3]) * 60 + int(s[-2:]))
        s2 = s[:-6]
    d, _, frac = s2.partition(".")
    y, mo, da, H, M, S = map(int, d.replace("T", " ").replace("-", " ").replace(":", " ").split())
    local = dt.datetime(y, mo, da, H, M, S, int((frac or "0").ljust(6, "0")[:6]), tzinfo=dt.timezone(dt.timedelta(minutes=off)))
    dl = local.astimezone(dt.timezone.utc) - _EPOCH
    return (dl.days * 86400 * 10**6 + dl.seconds * 10**6 + dl.microseconds) // 1000


def minor(amt, scale):
    with localcontext() as c:
        c.prec = 60
        return int((Decimal(amt) * (Decimal(10) ** scale)).quantize(Decimal(1), rounding=ROUND_HALF_UP))


CASES = []


def rej(cid, fam, rule, rb, decision, reason):
    CASES.append({"case_id": cid, "fault_family": fam, "rule": rule, "raw": rb,
                  "expected_decision": decision, "expected_reason": reason, "expected_object": None})


def acc(cid, fam, rule, rb, eid, ts, amt, cur, bc, ref):
    t = ts if isinstance(ts, int) else tms(ts)
    m = minor(amt, {"USD": 2, "EUR": 2, "VND": 0}[cur])
    CASES.append({"case_id": cid, "fault_family": fam, "rule": rule, "raw": rb,
                  "expected_decision": "ACCEPT", "expected_reason": None,
                  "expected_object": {"eid": eid, "t": t, "minor": m, "cur": cur, "bc": bc, "ref": ref}})


rej("S01", "unicode", "escaped unpaired high surrogate", raw(mk(beneficiary_code='"\\ud800"')), "REJECT_MALFORMED", "UNICODE_MALFORMED")
rej("S02", "unicode", "escaped unpaired low surrogate", raw(mk(beneficiary_code='"\\udc00"')), "REJECT_MALFORMED", "UNICODE_MALFORMED")
acc("S03", "unicode", "valid astral direct UTF-8", raw(mk(beneficiary_code='"\U0001F600"')), "EV-1", "2026-01-01T00:00:00Z", "100.00", "USD", "\U0001F600", None)
rej("S04", "unicode", "previous sentinel string", raw(mk(beneficiary_code='"\\u0000ABSENT"')), "REJECT_MALFORMED", "UNICODE_MALFORMED")
rej("S05", "unicode", "surrogate in event_id", raw(mk(event_id='"\\ud800"')), "REJECT_MALFORMED", "EVENT_ID_MALFORMED")
rej("L01", "lexical", "event_id trailing newline", raw(mk(event_id='"EV-1\\n"')), "REJECT_MALFORMED", "EVENT_ID_MALFORMED")
rej("L02", "lexical", "obligation_ref trailing newline", raw(mk() + [("obligation_ref", '"OBL-9\\n"')]), "REJECT_MALFORMED", "FIELD_TYPE_MALFORMED")
rej("L03", "lexical", "monetary trailing newline", raw(mk(amount='"100.00\\n"')), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("L04", "lexical", "timestamp trailing newline", raw(mk(timestamp='"2026-01-01T00:00:00Z\\n"')), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
rej("L05", "lexical", "non-ASCII digits timestamp", raw(mk(timestamp='"\u0662\u0660\u0662\u0666-01-01T00:00:00Z"')), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
print("part1 cases", len(CASES))
rej("M01", "multi", "malformed amount + missing scale", raw(mk(amount='"bad"', scale=_OMIT)), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("M02", "multi", "malformed amount + invalid scale type", raw(mk(amount='"bad"', scale='"2"')), "REJECT_MALFORMED", "SCALE_MALFORMED")
rej("M03", "multi", "invalid amount + unsupported currency", raw(mk(amount='"bad"', currency='"usd"')), "REJECT_MALFORMED", "AMOUNT_MALFORMED")
rej("M04", "multi", "extremely large scale", raw(mk(scale="999999")), "REJECT_PROHIBITED", "SCALE_MISMATCH")
rej("M05", "multi", "negative scale", raw(mk(scale="-1")), "REJECT_PROHIBITED", "SCALE_MISMATCH")
rej("M06", "multi", "malformed alias + conflicting alias", raw(mk(beneficiary_code="123") + [("beneficiary", '"A"')]), "REJECT_MALFORMED", "FIELD_TYPE_MALFORMED")
acc("T01", "tsbound", "earliest year + offset", raw(mk(timestamp='"0001-06-01T12:00:00+01:00"')), "EV-1", "0001-06-01T11:00:00Z", "100.00", "USD", "BC-1", None)
acc("T02", "tsbound", "latest year + offset", raw(mk(timestamp='"9999-12-31T23:00:00+01:00"')), "EV-1", "9999-12-31T22:00:00Z", "100.00", "USD", "BC-1", None)
rej("T03", "tsbound", "invalid calendar without tz", raw(mk(timestamp='"2026-02-30T00:00:00"')), "REJECT_MALFORMED", "TIMESTAMP_MALFORMED")
acc("T04", "tsbound", "pre-epoch fractional floor", raw(mk(timestamp='"1969-12-31T23:59:59.999999Z"')), "EV-1", -1, "100.00", "USD", "BC-1", None)
rej("T05", "tsbound", "integer outside safe range", raw(mk(timestamp="9007199254740992")), "REJECT_PROHIBITED", "TIMESTAMP_OUT_OF_RANGE")

for c in CASES:
    c["input_sha256"] = hashlib.sha256(c["raw"]).hexdigest()
    c["input_b64"] = base64.b64encode(c["raw"]).decode()
    if c["expected_object"]:
        body = rfc8785.dumps(c["expected_object"])
        c["expected_canonical_hex"] = body.hex(); c["expected_canonical_sha256"] = hashlib.sha256(body).hexdigest()
    else:
        c["expected_canonical_hex"] = None; c["expected_canonical_sha256"] = None
with (P02 / "R4A_CORRECTIVE_EXPECTED.jsonl").open("w", encoding="utf-8") as fh:
    for c in CASES:
        fh.write(json.dumps({k: c[k] for k in ("case_id", "fault_family", "rule", "input_b64", "input_sha256",
                 "expected_decision", "expected_reason", "expected_object", "expected_canonical_hex",
                 "expected_canonical_sha256")}, sort_keys=True) + "\n")
with (P02 / "R4A_CORRECTIVE_RATIONALES.jsonl").open("w", encoding="utf-8") as fh:
    for c in CASES:
        fh.write(json.dumps({"case_id": c["case_id"], "fault_family": c["fault_family"], "rule": c["rule"],
                             "expected_decision": c["expected_decision"], "expected_reason": c["expected_reason"]}, sort_keys=True) + "\n")
(P02 / "R4A_EXPECTED_SHA256SUMS").write_text(
    "\n".join("%s  %s" % (hashlib.sha256((P02 / n).read_bytes()).hexdigest(), n)
              for n in ["R4A_CORRECTIVE_EXPECTED.jsonl", "R4A_CORRECTIVE_RATIONALES.jsonl"]) + "\n", encoding="utf-8")
print("corrective expected total:", len(CASES))