import json, base64, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r4_oracle as O
E = [json.loads(l) for l in open("experiments/v19/results/P02/R4A_CORRECTIVE_EXPECTED.jsonl", encoding="utf-8") if l.strip()]
bad = []
for e in E:
    try:
        o = O.adjudicate(base64.b64decode(e["input_b64"]))
        wrong = (o["decision"] != e["expected_decision"] or o["reason_code"] != e["expected_reason"])
    except Exception:
        wrong = True
    if wrong:
        bad.append(e["case_id"])
res = {"old_oracle_reproduces_or_fails": len(bad), "total": len(E), "case_ids": sorted(bad)}
open("experiments/v19/results/P02/R4A_COUNTEREXAMPLE_REPRO.json", "w", encoding="utf-8").write(json.dumps(res, indent=2))
print(json.dumps(res))