"""R4a compare: independent expected vs repaired r4a_oracle observed (per-leg + pairs + compatibility)."""
import json, base64, pathlib, sys, csv
from collections import Counter
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r4a_oracle
ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
exp = [json.loads(l) for l in (P02 / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
J = {c["case_id"]: c for c in json.loads((ROOT / "derived" / "results" / "j01_cases.json").read_text(encoding="utf-8"))["cases"]}

agree = Counter(); total = 0; exc = 0
obs_by = {}
rows = []
for e in exp:
    raw = base64.b64decode(e["reconstructed_input_b64"])
    try:
        o = r4a_oracle.adjudicate(raw)
    except Exception:
        o = {"decision": "EXCEPTION", "reason_code": "EXC", "eligible_json": None, "canonical_hex": None, "execution_status": "INTERNAL_ERROR"}
    if o.get("execution_status") == "INTERNAL_ERROR":
        exc += 1
    total += 1
    a_ok = o["decision"] == e["expected_admission"]
    r_ok = o["reason_code"] == e["expected_reason_code"]
    b_ok = o["eligible_json"] == e["expected_business_object"]
    e_ok = o["eligible_json"] == e["expected_eligible_json"]
    c_ok = (o["canonical_hex"] == base64.b64decode(e["expected_canonical_bytes_b64"]).hex()) if e["expected_canonical_bytes_b64"] else (o["canonical_hex"] is None)
    agree["admission"] += a_ok; agree["reason"] += r_ok; agree["business"] += b_ok; agree["eligible"] += e_ok; agree["canonical"] += c_ok
    obs_by[(e["case_id"], e["leg_id"])] = o.get("eligible_json")
    rows.append({"case_id": e["case_id"], "leg_id": e["leg_id"], "admission_ok": a_ok, "reason_ok": r_ok,
                 "business_ok": b_ok, "eligible_ok": e_ok, "canonical_ok": c_ok})
with (P02 / "J01_OBSERVED_VS_EXPECTED.R4A.jsonl").open("w", encoding="utf-8") as fh:
    for r in rows:
        fh.write(json.dumps(r, sort_keys=True) + "\n")

# pair + compatibility
pair = Counter(); compat = Counter()
for cid, c in J.items():
    a = obs_by.get((cid, "A")); b = obs_by.get((cid, "B")); kind = c["kind"]
    if kind in ("equivalent", "non_equivalent"):
        eq = (a is not None and b is not None and a == b)
        if kind == "equivalent":
            pair["eq_success"] += (eq); pair["eq_total"] += 1
            compat[(kind, "equal" if eq else "not_equal")] += 1
        else:
            pair["distinct_success"] += ((a is not None and b is not None and not eq)); pair["distinct_total"] += 1
            compat[(kind, "distinct" if (a is not None and b is not None and not eq) else "collapse")] += 1
    else:
        got = "abstain" if a is None else "accept"
        pair["abstain_success"] += (got == "abstain"); pair["abstain_total"] += 1
        compat[(kind, got)] += 1
summary = {
    "legs": total, "exceptions": exc,
    "admission_agreement": [agree["admission"], total], "reason_agreement": [agree["reason"], total],
    "business_object_agreement": [agree["business"], total], "eligible_json_agreement": [agree["eligible"], total],
    "canonical_byte_agreement": [agree["canonical"], total],
    "equivalent_pair_success": [pair["eq_success"], pair["eq_total"]],
    "distinct_pair_success": [pair["distinct_success"], pair["distinct_total"]],
    "abstention_success": [pair["abstain_success"], pair["abstain_total"]],
    "compatibility_expected_vs_kv2": {("%s->%s" % k): v for k, v in compat.items()},
}
(P02 / "J01_EXPECTED_VS_OBSERVED.R4A.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))