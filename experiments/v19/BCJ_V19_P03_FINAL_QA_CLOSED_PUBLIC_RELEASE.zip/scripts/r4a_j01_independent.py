"""R4a independent J01 adjudication (Q-only; imports NO oracle). Expected derived from NORMATIVE_CONTRACT.R4 rules."""
import json, unicodedata, datetime as dt, hashlib, base64, pathlib, re, csv
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785

ROOT = pathlib.Path(__file__).resolve().parents[3]
P02 = ROOT / "experiments" / "v19" / "results" / "P02"
REG = {"USD": 2, "EUR": 2, "VND": 0}
MAXS = 9007199254740991; MINS = -9007199254740991
EID = re.compile(r"[A-Za-z0-9_-]{1,256}"); AMT = re.compile(r"(0|[1-9][0-9]*)(?:\.[0-9]{1,6})?")
REF = re.compile(r"[\x20-\x7E]{1,256}")
TS = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?(Z|[+-][0-9]{2}:[0-9]{2})")
TSN = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?")
CATOF = {"MALFORMED": 0, "PROHIBITED": 1, "ABSTAIN": 2}
ORDER = ["JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED", "SCALE_MALFORMED",
         "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED", "NEGATIVE_AMOUNT", "MONETARY_OVERFLOW",
         "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH", "UNKNOWN_FIELD", "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE",
         "MISSING_BENEFICIARY", "MISSING_EVENT_ID", "MISSING_CURRENCY", "MISSING_SCALE", "MISSING_AMOUNT",
         "MISSING_TIMESTAMP", "TIMESTAMP_MISSING_TZ"]
RK = {r: i for i, r in enumerate(ORDER)}
CAT_OF = {}
for r in ORDER:
    if r in ("JSON_MALFORMED", "DUPLICATE_KEY", "UNICODE_MALFORMED", "TIMESTAMP_MALFORMED", "SCALE_MALFORMED",
             "EVENT_ID_MALFORMED", "FIELD_TYPE_MALFORMED", "AMOUNT_MALFORMED"):
        CAT_OF[r] = ("REJECT_MALFORMED", "MALFORMED")
    elif r in ("NEGATIVE_AMOUNT", "MONETARY_OVERFLOW", "UNSUPPORTED_CURRENCY", "SCALE_MISMATCH", "UNKNOWN_FIELD",
               "ALIAS_CONFLICT", "TIMESTAMP_OUT_OF_RANGE"):
        CAT_OF[r] = ("REJECT_PROHIBITED", "PROHIBITED")
    else:
        CAT_OF[r] = ("ABSTAIN_UNDERSPECIFIED", "ABSTAIN")
_EP = dt.datetime(1970, 1, 1, tzinfo=dt.timezone.utc)


def _ts(s):
    if isinstance(s, bool):
        return None, "TIMESTAMP_MALFORMED"
    if isinstance(s, int):
        return (s, None) if MINS <= s <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")
    if not isinstance(s, str):
        return None, "TIMESTAMP_MALFORMED"
    m = TS.fullmatch(s)
    if not m:
        return (None, "TIMESTAMP_MISSING_TZ") if TSN.fullmatch(s) else (None, "TIMESTAMP_MALFORMED")
    y, mo, d, H, M, S, fr, off = m.groups()
    if int(S) > 59:
        return None, "TIMESTAMP_MALFORMED"
    if off == "Z":
        o = dt.timedelta(0)
    else:
        oh, om = int(off[1:3]), int(off[4:6])
        if oh > 23 or om not in (0, 15, 30, 45):
            return None, "TIMESTAMP_MALFORMED"
        o = (1 if off[0] == "+" else -1) * dt.timedelta(hours=oh, minutes=om)
    try:
        loc = dt.datetime(int(y), int(mo), int(d), int(H), int(M), int(S), int((fr or "0").ljust(6, "0")), tzinfo=dt.timezone(o))
        dl = loc.astimezone(dt.timezone.utc) - _EP
        ms = (dl.days * 86400 * 10**6 + dl.seconds * 10**6 + dl.microseconds) // 1000
    except (ValueError, OverflowError):
        return None, "TIMESTAMP_MALFORMED"
    return (ms, None) if MINS <= ms <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")


def _minor(lex, sc):
    with localcontext() as c:
        c.prec = 60
        m = int((Decimal(lex) * (Decimal(10) ** sc)).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return (m, None) if 0 <= m <= MAXS else (None, "MONETARY_OVERFLOW")


def _alias(doc, c, a, norm, issues):
    v = c in doc and doc[c] is not None
    w = a in doc and doc[a] is not None
    if v and w:
        if isinstance(doc[c], str) and isinstance(doc[a], str):
            if norm(doc[c]) != norm(doc[a]):
                issues.append("ALIAS_CONFLICT"); return None
            return doc[c]
        return doc[c]
    if w:
        return doc[a]
    if v:
        return doc[c]
    return None


def _nfc(x):
    return unicodedata.normalize("NFC", x)


def adjudicate(doc):
    allowed = {"event_id", "timestamp", "amount", "currency", "cur", "scale",
               "beneficiary_code", "beneficiary", "obligation_ref"}
    issues = []
    for k in doc:
        if k not in allowed:
            issues.append("UNKNOWN_FIELD")
    eid = doc.get("event_id")
    if eid is None:
        issues.append("MISSING_EVENT_ID")
    elif not isinstance(eid, str) or any(0xD800 <= ord(ch) <= 0xDFFF for ch in eid) or not EID.fullmatch(eid):
        issues.append("EVENT_ID_MALFORMED")
    cur = _alias(doc, "currency", "cur", lambda x: x, issues)
    if cur is None:
        issues.append("MISSING_CURRENCY")
    elif not isinstance(cur, str) or cur not in REG:
        issues.append("UNSUPPORTED_CURRENCY"); cur = None
    sc = doc.get("scale"); scal = None
    if sc is None:
        issues.append("MISSING_SCALE")
    elif not (isinstance(sc, int) and not isinstance(sc, bool)):
        issues.append("SCALE_MALFORMED")
    else:
        scal = sc
    if scal is not None:
        if cur is not None:
            if scal != REG[cur]:
                issues.append("SCALE_MISMATCH")
        elif scal not in (0, 1, 2, 3, 4, 5, 6):
            issues.append("SCALE_MISMATCH")
    am = doc.get("amount"); minor = None; lex = None; amt_ok = False
    if am is None:
        issues.append("MISSING_AMOUNT")
    elif isinstance(am, bool) or not isinstance(am, (str, int, float)):
        issues.append("AMOUNT_MALFORMED")
    else:
        lex = am if isinstance(am, str) else (repr(am) if isinstance(am, float) else str(am))
        if lex.startswith("-"):
            issues.append("NEGATIVE_AMOUNT")
        elif len(lex) > 24 or not AMT.fullmatch(lex) or len(lex.split(".")[0]) > 16:
            issues.append("AMOUNT_MALFORMED")
        else:
            amt_ok = True
    if amt_ok and scal is not None and cur is not None and scal == REG[cur]:
        minor, merr = _minor(lex, scal)
        if merr:
            issues.append(merr)
    ts = doc.get("timestamp"); t = None
    if ts is None:
        issues.append("MISSING_TIMESTAMP")
    else:
        t, terr = _ts(ts)
        if terr:
            issues.append(terr)
    bc = _alias(doc, "beneficiary_code", "beneficiary", _nfc, issues); bcv = None
    if bc is None:
        issues.append("MISSING_BENEFICIARY")
    elif not isinstance(bc, str):
        issues.append("FIELD_TYPE_MALFORMED")
    else:
        n = _nfc(bc)
        if n == "":
            issues.append("FIELD_TYPE_MALFORMED")
        elif any(0xD800 <= ord(ch) <= 0xDFFF or ord(ch) < 0x20 or 0x7F <= ord(ch) <= 0x9F for ch in n):
            issues.append("UNICODE_MALFORMED")
        else:
            bcv = n
    ref = doc.get("obligation_ref"); refv = None
    if ref is not None:
        if not isinstance(ref, str) or any(0xD800 <= ord(ch) <= 0xDFFF for ch in ref) or not REF.fullmatch(ref):
            issues.append("FIELD_TYPE_MALFORMED")
        else:
            refv = ref
    if issues:
        best = min(issues, key=lambda r: (CATOF[CAT_OF[r][1]], RK[r]))
        return {"decision": CAT_OF[best][0], "reason_code": best, "typed": None}
    typed = {"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bcv, "ref": refv}
    return {"decision": "ACCEPT", "reason_code": None, "typed": typed}


J = json.loads((ROOT / "derived" / "results" / "j01_cases.json").read_text(encoding="utf-8"))["cases"]
FAM = {"TIM": "timestamp canonicalization to ms class", "AMT": "monetary quantization", "UNI": "Unicode NFC scope",
       "NUL": "null/absence equivalence", "CUR": "currency/scale", "ALI": "alias equivalence", "ID": "identifier exactness"}
adj = []; pairrows = []
for c in J:
    cid = c["case_id"]; mid = cid.split("-")[1] if "-" in cid else "GEN"
    famdesc = FAM.get(mid, "normalized business-tuple equivalence"); typed = {}
    for leg in ("A", "B"):
        doc = c.get("input_" + leg.lower())
        if doc is None:
            continue
        rb = rfc8785.dumps(doc); e = adjudicate(doc)
        part = "D_K+" if e["decision"] == "ACCEPT" else ("D_K?" if e["decision"] == "ABSTAIN_UNDERSPECIFIED" else "D_K-")
        typed[leg] = e["typed"]
        cb = rfc8785.dumps(e["typed"]) if e["typed"] else None
        adj.append({"case_id": cid, "leg_id": leg, "reconstructed_input_b64": base64.b64encode(rb).decode(),
                    "input_sha256": hashlib.sha256(rb).hexdigest(), "expected_partition": part,
                    "expected_admission": e["decision"], "expected_reason_code": e["reason_code"],
                    "expected_business_object": e["typed"], "expected_eligible_json": e["typed"],
                    "expected_canonical_bytes_b64": base64.b64encode(cb).decode() if cb else None,
                    "expected_canonical_sha256": hashlib.sha256(cb).hexdigest() if cb else None,
                    "normative_rule_id": "K2.%s" % mid, "adjudication_rationale": famdesc,
                    "adjudication_method": "rule-level independent (no oracle import)"})
    a, b = typed.get("A"), typed.get("B")
    if b is None:
        continue
    if a is not None and b is not None:
        rel = "business-equal" if a == b else "business-distinct"
        pairrows.append({"pair_id": cid, "leg_a": cid + ":A", "leg_b": cid + ":B", "expected_business_relationship": rel,
                         "expected_canonical_relationship": ("canonical-equal" if a == b else "canonical-distinct"),
                         "expected_admission_behavior": "both-admitted", "rationale": famdesc})
    else:
        pairrows.append({"pair_id": cid, "leg_a": cid + ":A", "leg_b": cid + ":B", "expected_business_relationship": "not-applicable",
                         "expected_canonical_relationship": "not-applicable", "expected_admission_behavior": "not-both-admitted",
                         "rationale": famdesc})
with (P02 / "J01_INDEPENDENT_EXPECTED.R4A.jsonl").open("w", encoding="utf-8") as fh:
    for r in adj:
        fh.write(json.dumps(r, sort_keys=True) + "\n")
with (P02 / "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["pair_id", "leg_a", "leg_b", "expected_business_relationship",
        "expected_canonical_relationship", "expected_admission_behavior", "rationale"])
    for r in pairrows:
        w.writerow([r["pair_id"], r["leg_a"], r["leg_b"], r["expected_business_relationship"],
                    r["expected_canonical_relationship"], r["expected_admission_behavior"], r["rationale"]])
(P02 / "J01_ADJUDICATION_PROVENANCE.R4A.json").write_text(json.dumps({
    "session": "Q-only isolated pass (same agent); inputs: NORMATIVE_CONTRACT.R4.md, FIELD_SEMANTICS.csv, ERROR_TAXONOMY.yaml, registry, j01_cases.json (inputs only)",
    "prohibited": ["r3_oracle.py", "r4_oracle.py", "r4a_oracle.py", "P01 observed outputs", "R4 observed business objects", "R4 labels"],
    "libraries": ["rfc8785", "decimal", "datetime", "unicodedata", "re"], "imports_oracle": False,
    "independence_limitation": "AI-assisted; same agent sequential; no external human adjudication; correlated-specification risk remains"}, indent=2), encoding="utf-8")
(P02 / "J01_RULE_LEVEL_ADJUDICATION.R4A.md").write_text(
    "# J01 rule-level adjudication (R4a)\n\nExpected derived from K-v2 rules, not oracle outputs.\n\n"
    "- TIM: offsets normalized to UTC ms class; sub-ms floored.\n- AMT: exact Decimal x10^scale ROUND_HALF_UP.\n"
    "- UNI: NFC on beneficiary only.\n- NUL: null/absent obligation_ref -> ref null.\n- CUR: currency+scale registry match.\n"
    "- Business equivalence = equality of normalized tuple (eid,t,minor,cur,bc,ref); canonical equality is an outcome, not the definition.\n"
    "- Ambiguous (missing currency) -> ABSTAIN_UNDERSPECIFIED (MISSING_CURRENCY).\n", encoding="utf-8")
(P02 / "J01_EXPECTED_SHA256SUMS").write_text("\n".join(
    "%s  %s" % (hashlib.sha256((P02 / n).read_bytes()).hexdigest(), n) for n in
    ["J01_INDEPENDENT_EXPECTED.R4A.jsonl", "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv",
     "J01_RULE_LEVEL_ADJUDICATION.R4A.md", "J01_ADJUDICATION_PROVENANCE.R4A.json"]) + "\n", encoding="utf-8")
from collections import Counter
pc = Counter(r["expected_admission"] for r in adj)
print("legs", len(adj), "pairs", len(pairrows), dict(pc))