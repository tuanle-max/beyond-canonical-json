"""R4a corrective oracle: versioned fix of r4_oracle.py (10 static findings). r4_oracle.py preserved."""
import re, unicodedata, datetime as _dt
from decimal import Decimal, ROUND_HALF_UP, localcontext
import rfc8785
import r4_oracle as base

MAXS, MINS, REGISTRY, RANK, CAT, REASON_CAT, Num = (base.MAXS, base.MINS, base.REGISTRY,
    base.RANK, base.CAT, base.REASON_CAT, base.Num)
ALLOWED = base.ALLOWED
EID_RE = re.compile(r"[A-Za-z0-9_-]{1,256}")
REF_RE = re.compile(r"[\x20-\x7E]{1,256}")
AMT_RE = re.compile(r"(0|[1-9][0-9]*)(?:\.[0-9]{1,6})?")
TS_RE = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?(Z|[+-][0-9]{2}:[0-9]{2})")
TS_NOTZ_RE = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})[T ]([0-9]{2}):([0-9]{2}):([0-9]{2})(?:\.([0-9]{1,6}))?")
INT_RE = re.compile(r"-?(?:0|[1-9][0-9]*)")
_ABS = object()
_EPOCH = _dt.datetime(1970, 1, 1, tzinfo=_dt.timezone.utc)
parse_raw = base.parse_raw


def _has_surrogate(s):
    return any(0xD800 <= ord(c) <= 0xDFFF for c in s)


def _has_ctrl(s):
    return any(ord(c) < 0x20 or 0x7F <= ord(c) <= 0x9F for c in s)


def _mk_local(y, mo, d, H, M, S, frac, offs):
    return _dt.datetime(int(y), int(mo), int(d), int(H), int(M), int(S),
                        int((frac or "0").ljust(6, "0")), tzinfo=_dt.timezone(offs))


def _to_ms(local):
    delta = local.astimezone(_dt.timezone.utc) - _EPOCH
    return (delta.days * 86400 * 10**6 + delta.seconds * 10**6 + delta.microseconds) // 1000


def _ts(v):
    try:
        if isinstance(v, bool):
            return None, "TIMESTAMP_MALFORMED"
        if isinstance(v, Num) and v.kind == "int":
            i = int(v.lex)
            return (i, None) if MINS <= i <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")
        if isinstance(v, Num) or not isinstance(v, str):
            return None, "TIMESTAMP_MALFORMED"
        m = TS_RE.fullmatch(v)
        if not m:
            n = TS_NOTZ_RE.fullmatch(v)
            if not n:
                return None, "TIMESTAMP_MALFORMED"
            try:
                _dt.datetime(int(n.group(1)), int(n.group(2)), int(n.group(3)),
                             int(n.group(4)), int(n.group(5)), int(n.group(6)))
            except ValueError:
                return None, "TIMESTAMP_MALFORMED"
            return None, "TIMESTAMP_MISSING_TZ"
        y, mo, d, H, M, S, frac, off = m.groups()
        if int(S) > 59:
            return None, "TIMESTAMP_MALFORMED"
        if off == "Z":
            offs = _dt.timedelta(0)
        else:
            oh, om = int(off[1:3]), int(off[4:6])
            if oh > 23 or om not in (0, 15, 30, 45):
                return None, "TIMESTAMP_MALFORMED"
            offs = (1 if off[0] == "+" else -1) * _dt.timedelta(hours=oh, minutes=om)
        local = _mk_local(y, mo, d, H, M, S, frac, offs)
        ms = _to_ms(local)
        return (ms, None) if MINS <= ms <= MAXS else (None, "TIMESTAMP_OUT_OF_RANGE")
    except (ValueError, OverflowError, OSError):
        return None, "TIMESTAMP_MALFORMED"
    except Exception:
        return None, "INTERNAL"


def _amount_lex(v):
    if isinstance(v, bool):
        return None, "AMOUNT_MALFORMED"
    if isinstance(v, Num):
        return v.lex, None
    if isinstance(v, str):
        return v, None
    return None, "AMOUNT_MALFORMED"


def _minor(lex, scale):
    """Assumes grammar already validated and scale is a registry-valid 0..6 int."""
    with localcontext() as c:
        c.prec = 60
        m = int((Decimal(lex) * (Decimal(10) ** scale)).quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return (m, None) if 0 <= m <= MAXS else (None, "MONETARY_OVERFLOW")


def _alias(obj, canon, alias, normalize, issues):
    a = obj.get(canon, _ABS); b = obj.get(alias, _ABS)
    pa = a is not _ABS and a is not None
    pb = b is not _ABS and b is not None
    if pa and pb:
        if isinstance(a, str) and isinstance(b, str):
            if normalize(a) != normalize(b):
                issues.append("ALIAS_CONFLICT"); return _ABS
            return a
        return a
    if pb:
        return b
    if pa:
        return a
    return _ABS


def _nfc(x):
    return unicodedata.normalize("NFC", x)


def evaluate(obj):
    try:
        issues = []
        for k in obj:
            if k not in ALLOWED:
                issues.append("UNKNOWN_FIELD")
        eid = obj.get("event_id", _ABS)
        if eid is _ABS or eid is None:
            issues.append("MISSING_EVENT_ID")
        elif not isinstance(eid, str) or _has_surrogate(eid) or not EID_RE.fullmatch(eid):
            issues.append("EVENT_ID_MALFORMED")
        ts = obj.get("timestamp", _ABS); t = None
        if ts is _ABS or ts is None:
            issues.append("MISSING_TIMESTAMP")
        else:
            t, terr = _ts(ts)
            if terr == "INTERNAL":
                return _internal()
            if terr:
                issues.append(terr)
        cur = _alias(obj, "currency", "cur", lambda x: x, issues)
        if cur is _ABS or cur is None:
            issues.append("MISSING_CURRENCY"); cur = None
        elif not isinstance(cur, str) or cur not in REGISTRY:
            issues.append("UNSUPPORTED_CURRENCY"); cur = None
        sc = obj.get("scale", _ABS); scal = None
        if sc is _ABS or sc is None:
            issues.append("MISSING_SCALE")
        elif not (isinstance(sc, Num) and sc.kind == "int" and INT_RE.fullmatch(sc.lex)):
            issues.append("SCALE_MALFORMED")
        else:
            scal = int(sc.lex)
        if scal is not None:
            if cur is not None:
                if scal != REGISTRY[cur]:
                    issues.append("SCALE_MISMATCH")
            elif scal not in (0, 1, 2, 3, 4, 5, 6):
                issues.append("SCALE_MISMATCH")
        am = obj.get("amount", _ABS); minor = None; amt_ok = False; lex = None
        if am is _ABS or am is None:
            issues.append("MISSING_AMOUNT")
        else:
            lex, aerr = _amount_lex(am)
            if aerr:
                issues.append(aerr)
            elif lex.startswith("-"):
                issues.append("NEGATIVE_AMOUNT")
            elif len(lex) > 24 or not AMT_RE.fullmatch(lex) or len(lex.split(".")[0]) > 16:
                issues.append("AMOUNT_MALFORMED")
            else:
                amt_ok = True
        if amt_ok and scal is not None and cur is not None and scal == REGISTRY[cur]:
            minor, merr = _minor(lex, scal)
            if merr:
                issues.append(merr)
        bc = _alias(obj, "beneficiary_code", "beneficiary", _nfc, issues); bcv = None
        if bc is _ABS or bc is None:
            issues.append("MISSING_BENEFICIARY")
        elif not isinstance(bc, str):
            issues.append("FIELD_TYPE_MALFORMED")
        elif _has_surrogate(bc):
            issues.append("UNICODE_MALFORMED")
        else:
            n = _nfc(bc)
            if n == "":
                issues.append("FIELD_TYPE_MALFORMED")
            elif _has_surrogate(n) or _has_ctrl(n):
                issues.append("UNICODE_MALFORMED")
            else:
                bcv = n
        ref = obj.get("obligation_ref", _ABS); refv = None
        if ref is not _ABS and ref is not None:
            if not isinstance(ref, str) or _has_surrogate(ref) or not REF_RE.fullmatch(ref):
                issues.append("FIELD_TYPE_MALFORMED")
            else:
                refv = ref
        if issues:
            best = min(issues, key=lambda r: (CAT[REASON_CAT[r]], RANK[r]))
            return {"decision": REASON_CAT[best], "reason_code": best, "business_object": None,
                    "eligible_json": None, "canonical_hex": None, "execution_status": "OK"}
        typed = {"eid": eid, "t": t, "minor": minor, "cur": cur, "bc": bcv, "ref": refv}
        return {"decision": "ACCEPT", "reason_code": None, "business_object": typed,
                "eligible_json": typed, "canonical_hex": rfc8785.dumps(typed).hex(), "execution_status": "OK"}
    except Exception:
        return _internal()


def _internal():
    return {"decision": "INTERNAL_ERROR", "reason_code": "INTERNAL_ERROR", "business_object": None,
            "eligible_json": None, "canonical_hex": None, "execution_status": "INTERNAL_ERROR"}


def adjudicate(raw):
    obj, perr = parse_raw(raw)
    if perr:
        return {"decision": REASON_CAT[perr], "reason_code": perr, "business_object": None,
                "eligible_json": None, "canonical_hex": None, "execution_status": "OK"}
    return evaluate(obj)