"""R4a package: write detached lock + SHA256SUMS + zip + fresh-extraction verify_review_package.py."""
import json, hashlib, pathlib, zipfile, subprocess, sys, tempfile, shutil

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"
SCR = pathlib.Path(__file__).resolve().parent
OUT = P02.parents[1]
A = "b05da57ac466f0b41d2ea6e5e84bbbd74b52f354"
EXP_LOCK = "6457fc1227099434a88100863a1d18417163f445"
J01_LOCK = "45cb54981e698a3e3dc7b3d6c8c7b6d799840442"
ART = ["NORMATIVE_CONTRACT.R4.md", "FIELD_SEMANTICS.csv", "ERROR_TAXONOMY.yaml",
       "SUPPORTED_CURRENCY_SCALE_REGISTRY.json", "semantic_manifest_v2.R4.CANDIDATE.json",
       "construction_manifest_v3.R4.CANDIDATE.json", "COMMITMENT_V3_SPEC.R4.md", "J01_SOURCE_CORPUS.json",
       "J01_RECONSTRUCTED_INPUTS.jsonl", "J01_INDEPENDENT_EXPECTED.R4A.jsonl",
       "J01_INDEPENDENT_PAIR_REGISTER.R4A.csv", "R4A_CORRECTIVE_EXPECTED.jsonl",
       "P02_BOUNDARY_KAT.R4.jsonl", "COMMITMENT_V3_KAT.R4.jsonl", "ORACLE_PROVENANCE.R4.json"]


def lf(p):
    return hashlib.sha256(p.read_bytes().replace(b"\r\n", b"\n")).hexdigest()


lock = {"candidate": True, "not_frozen": True, "source_commit": A,
        "expected_answer_lock_commit": EXP_LOCK, "j01_adjudication_lock_commit": J01_LOCK,
        "candidate_pid_sem_v2": "71287e74981877e3290daae6ffa9b560d30e3618330594820f92995f98da8da5",
        "candidate_construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d",
        "oracle_source": "scripts/r4a_oracle.py", "artifacts": {n: lf(P02 / n) for n in ART}}
(P02 / "ORACLE_LOCK.R4A.CANDIDATE.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")

# SHA256SUMS over all results/P02 files (raw bytes)
lines = sorted("%s  %s" % (hashlib.sha256(p.read_bytes()).hexdigest(), p.name)
               for p in P02.iterdir() if p.is_file() and p.name != "SHA256SUMS")
(P02 / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")

zp = OUT / "BCJ_V19_P02_R4A_REVIEW.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(P02.iterdir()):
        if p.is_file():
            z.write(p, "results/P02/" + p.name)
    for p in sorted(SCR.glob("r4*.py")):
        z.write(p, "scripts/" + p.name)

zsha = hashlib.sha256(zp.read_bytes()).hexdigest()
(OUT / "BCJ_V19_P02_R4A_REVIEW.zip.sha256").write_text("%s  BCJ_V19_P02_R4A_REVIEW.zip\n" % zsha, encoding="utf-8")

td = pathlib.Path(tempfile.mkdtemp())
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    z.extractall(td)
r = subprocess.run([sys.executable, str(td / "results/P02/verify_review_package.py")],
                   capture_output=True, text=True, cwd=str(td))
print("zip_sha256", zsha)
print("entries", len(zipfile.ZipFile(zp).namelist()))
print("verify_exit", r.returncode)
print(r.stdout[-1500:])
if r.returncode != 0:
    print("STDERR", r.stderr[-1000:])
shutil.rmtree(td, ignore_errors=True)