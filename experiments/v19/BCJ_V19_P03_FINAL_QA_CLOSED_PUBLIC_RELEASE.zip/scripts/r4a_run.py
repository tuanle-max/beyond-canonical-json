"""R4a verification: replay R4 71-case regression + run locked R4a corrective suite against r4a_oracle."""
import json, base64, pathlib, sys, csv
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import r4a_oracle

P02 = pathlib.Path(__file__).resolve().parents[1] / "results" / "P02"


def run(expfile, resfile):
    exp = [json.loads(l) for l in (P02 / expfile).read_text(encoding="utf-8").splitlines() if l.strip()]
    rows = []; npass = 0; exc = 0; fam = {}
    for e in exp:
        raw = base64.b64decode(e["input_b64"])
        try:
            obs = r4a_oracle.adjudicate(raw)
        except Exception as ex:
            obs = {"decision": "EXCEPTION", "reason_code": str(ex), "eligible_json": None, "canonical_hex": None}
        if obs.get("execution_status") == "INTERNAL_ERROR":
            exc += 1
        ok = obs["decision"] == e["expected_decision"] and obs["reason_code"] == e["expected_reason"]
        if e["expected_decision"] == "ACCEPT":
            ok = ok and obs["eligible_json"] == e["expected_object"] and obs["canonical_hex"] == e["expected_canonical_hex"]
        rows.append({"case_id": e["case_id"], "fault_family": e["fault_family"], "input_sha256": e["input_sha256"],
                     "expected_decision": e["expected_decision"], "expected_reason": e["expected_reason"],
                     "observed_decision": obs["decision"], "observed_reason": obs["reason_code"], "pass": ok})
        npass += ok
        f = e["fault_family"]; fam.setdefault(f, [0, 0]); fam[f][1] += 1; fam[f][0] += ok
    with (P02 / resfile).open("w", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, sort_keys=True) + "\n")
    return npass, len(rows), exc, fam, [r["case_id"] for r in rows if not r["pass"]], rows


p1, t1, e1, f1, fails1, _ = run("R4_ADVERSARIAL_EXPECTED.jsonl", "R4_REGRESSION_REPLAY_RESULTS.jsonl")
p2, t2, e2, f2, fails2, rows2 = run("R4A_CORRECTIVE_EXPECTED.jsonl", "R4A_CORRECTIVE_RESULTS.jsonl")
with (P02 / "R4A_RULE_COVERAGE_MATRIX.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["case_id", "fault_family", "expected_decision", "expected_reason", "observed_decision", "observed_reason", "pass"])
    for r in rows2:
        w.writerow([r["case_id"], r["fault_family"], r["expected_decision"], r["expected_reason"] or "", r["observed_decision"], r["observed_reason"] or "", r["pass"]])
print("R4 regression:", p1, "/", t1, "exceptions", e1, "fails", fails1)
print("R4a corrective:", p2, "/", t2, "exceptions", e2, "fails", fails2)
for f, (p, t) in sorted(f2.items()):
    print("  %-8s %d/%d" % (f, p, t))