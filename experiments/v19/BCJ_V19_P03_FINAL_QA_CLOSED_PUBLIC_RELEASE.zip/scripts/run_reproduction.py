"""RUN_REPRODUCTION — executable reproduction entry point (Portable). Session A: prepare; Session B: run-all."""
import argparse, base64, hashlib, json, pathlib, subprocess, sys, shutil, os
V19 = pathlib.Path(__file__).resolve().parents[1]
PYD = V19 / "implementations/python-dev"; GOD = V19 / "implementations/go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
PID = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"; CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
def bsha(b): return hashlib.sha256(b).hexdigest()
def raw(p): return hashlib.sha256(p.read_bytes()).hexdigest()
CANON_E1 = V19 / "implementations/python-dev/_e1_records.jsonl"

INV = {
 "E1": {"path": str(CANON_E1), "sha256_placeholder": True, "expected_records": 630},
 "E4": {"path": "results/P03/P03_E4_BATCH_DESCRIPTORS.jsonl", "expected": 18},
 "R3B": {"path": "results/P03", "marker": "r3b_"},
 "WP1": {"path": "results/P03", "marker": "wp1m_"},
 "D3": {"path": "results/P03/d3_records.jsonl"},
 "SENTINEL": {"path": "results/P03/coll_pre_records.jsonl"},
}


def verify_inputs(args):
    r = {}
    # E1 two-copy identical + cardinality
    p1 = (V19 / "implementations/python-dev/_e1_records.jsonl").read_bytes()
    p2 = (V19 / "implementations/go-dev/_e1_records.jsonl").read_bytes()
    r["E1_copies_identical"] = p1 == p2
    r["E1_records"] = sum(1 for l in p1.splitlines() if l.strip())
    r["E1_sha256"] = bsha(p1)
    r["E4_descriptors"] = sum(1 for l in (V19 / "results/P03/P03_E4_BATCH_DESCRIPTORS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip())
    out = json.dumps(r, indent=2, sort_keys=True)
    (V19 / "results/P03/VERIFY_INPUTS.json").write_text(out + "\n", encoding="utf-8")
    print(out)
    return 0 if (r["E1_copies_identical"] and r["E1_records"] == 630) else 1


def run_e1(args):
    repro = V19 / "results/P03/repro_e1"
    if repro.exists(): shutil.rmtree(repro)
    repro.mkdir(parents=True)
    rec = repro / "e1_records.jsonl"; rec.write_bytes(CANON_E1.read_bytes())
    py_out = repro / "e1_py.jsonl"; go_out = repro / "e1_go.jsonl"
    py = subprocess.run([sys.executable, str(PYD / "boo.py"), "adjudicate", "--in", str(rec), "--out", str(py_out)], capture_output=True, text=True)
    go = subprocess.run(["docker", "run", "--rm", "-v", str(GOD) + ":/work", "-v", str(repro) + ":/data", "-w", "/work", IMG, "bash", "-c",
                         "/usr/local/go/bin/go build -o /tmp/boo . && /tmp/boo adjudicate /data/e1_records.jsonl /data/e1_go.jsonl"], capture_output=True, text=True)
    np_ = sum(1 for l in py_out.read_text(encoding="utf-8").splitlines() if l.strip()) if py_out.exists() else 0
    ng_ = sum(1 for l in go_out.read_text(encoding="utf-8").splitlines() if l.strip()) if go_out.exists() else 0
    res = {"py_exit": py.returncode, "go_exit": go.returncode, "py_records": np_, "go_records": ng_,
           "py_err": py.stderr[-300:], "go_err": go.stderr[-300:]}
    (repro / "RUN_E1.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(res, indent=2))
    return 0 if (py.returncode == 0 and go.returncode == 0 and np_ == 630 and ng_ == 630) else 1


def exe(name, *args):
    def f(_args):
        return subprocess.run([sys.executable, str(V19 / "scripts" / name)] + list(args), timeout=3600).returncode
    return f


def run_controls(_args):
    for n, a in (("p03_r3b.py", []), ("p03_wp1.py", ["post"]), ("p03_collision.py", ["post"]), ("p03_d3_test.py", [])):
        rc = subprocess.run([sys.executable, str(V19 / "scripts" / n)] + a).returncode
        if rc:
            return rc
    return 0


def run_attribution(args):
    r1 = subprocess.run([sys.executable, str(V19 / "scripts/p03_stage_attr.py")]).returncode
    r2 = subprocess.run([sys.executable, str(V19 / "scripts/p03_r3c.py")]).returncode
    return 1 if (r1 or r2) else 0


def run_all(args):
    steps = [("verify-inputs", verify_inputs), ("run-e1", run_e1),
             ("run-e2-e3", exe("p03_eval_e2e3.py")), ("run-e4", exe("p03_eval_e4.py")),
             ("run-controls", run_controls), ("run-attribution", run_attribution)]
    for name, f in steps:
        rc = f(args)
        print("[run-all] %s rc=%s" % (name, rc))
        if rc:
            print("[run-all] STOPPED at %s (rc=%s)" % (name, rc))
            return rc
    return 0


def main():
    p = argparse.ArgumentParser(prog="run_reproduction")
    s = p.add_subparsers(dest="cmd", required=True)
    s.add_parser("verify-inputs").set_defaults(f=verify_inputs)
    s.add_parser("run-e1").set_defaults(f=run_e1)
    s.add_parser("run-e2-e3").set_defaults(f=exe("p03_eval_e2e3.py"))
    s.add_parser("run-e4").set_defaults(f=exe("p03_eval_e4.py"))
    s.add_parser("run-controls").set_defaults(f=run_controls)
    s.add_parser("run-attribution").set_defaults(f=run_attribution)
    s.add_parser("run-all").set_defaults(f=run_all)
    a = p.parse_args()
    sys.exit(a.f(a))


if __name__ == "__main__":
    main()