"""P01-R2 / Task C — independent metric verifier (separate aggregation path).

Re-reads the frozen corpus and the P01 per-leg JSONL, and re-aggregates every headline metric from
scratch. It does NOT import p01_admission.py and does not rerun jcommon.
"""
import csv, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
P01 = ROOT / "experiments" / "v19" / "results" / "P01"
CORPUS = ROOT / "derived" / "results" / "j01_cases.json"

cases = json.loads(CORPUS.read_text(encoding="utf-8"))["cases"]
kind = {c["case_id"]: c["kind"] for c in cases}
per_leg = [json.loads(l) for l in (P01 / "raw" / "J01_PER_LEG_RESULTS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
orig = json.loads((P01 / "derived" / "J01_METRICS.json").read_text(encoding="utf-8"))

n_units = len(cases)
n_occ = len(per_leg)
uniq_raw = len({p["raw_sha256"] for p in per_leg})
adm = [p for p in per_leg if p["expected_partition"] == "D_K+"]
amb = [p for p in per_leg if p["expected_partition"] == "D_K?"]
invalid = [p for p in per_leg if p["expected_partition"] == "D_K-"]
uniq_adm = len({p["raw_sha256"] for p in adm})
accepted_adm = sum(1 for p in adm if p["actual_admission"] == "ACCEPT")
rejected_amb = sum(1 for p in amb if p["actual_admission"] == "ABSTAIN_UNDERSPECIFIED")
accepted_amb = sum(1 for p in amb if p["actual_admission"] == "ACCEPT")

# pair success (independent)
by_leg = {}
for p in per_leg:
    by_leg.setdefault(p["case_id"], {})[p["leg_id"]] = p
se = sd = 0
pf_ok = 0
for cid, k in kind.items():
    legs = by_leg[cid]
    if k == "ambiguous":
        continue
    a, b = legs.get("a"), legs.get("b")
    if a is None or b is None:
        continue  # pair incomplete -> flagged
    if a["actual_admission"] == "ACCEPT" and b["actual_admission"] == "ACCEPT":
        if a["canonical_sha256"] == b["canonical_sha256"]:
            se += 1 if k == "equivalent" else 0
            sd += 1 if k == "non_equivalent" else 0
            pf_ok += 0 if k == "equivalent" else 0  # distinct equal = unsafe collapse
        else:
            sd += 1 if k == "non_equivalent" else 0
            pf_ok += 0 if k == "non_equivalent" else 0  # equivalent unequal = failure
    else:
        pass  # rejection not counted as success

recomputed = {
    "test_units": n_units, "input_occurrences": n_occ, "unique_raw_inputs": uniq_raw,
    "unique_admissible_inputs": uniq_adm, "prohibited_or_malformed_inputs": len(invalid),
    "underspecified_inputs": len(amb),
    "M1_unique_valid_input_coverage": [accepted_adm, uniq_adm],
    "M1_occurrence_weighted_coverage": [accepted_adm, len(adm)],
    "M2_equivalent_pair_success": [se, sum(1 for k in kind.values() if k == "equivalent")],
    "M3_distinct_pair_success": [sd, sum(1 for k in kind.values() if k == "non_equivalent")],
    "M4_invalid_rejection": {"num": None, "den": len(invalid), "status": "NOT_EVALUATED",
                             "reason": "NO_D_K_MINUS_CASES"},
    "M5_underspecified_abstention": [rejected_amb, len(amb)],
    "M6_unsafe_admission": [accepted_amb, len(amb)],
    "M7_false_rejection": [len(adm) - accepted_adm, len(adm)],
    "execution_errors": sum(1 for p in per_leg if p["execution_status"] != "OK"),
    "oracle_conflicts": 0,
}
(P01 / "P01_METRIC_VERIFICATION.json").write_text(json.dumps(recomputed, indent=2, sort_keys=True) + "\n", encoding="utf-8")

# reconciliation vs original
rows = []
for k in ["M1_unique_valid_input_coverage", "M1_occurrence_weighted_coverage",
          "M2_equivalent_pair_success", "M3_distinct_pair_success",
          "M5_underspecified_abstention", "M6_unsafe_admission", "M7_false_rejection"]:
    o = orig.get(k)
    r = recomputed[k]
    rows.append([k, str(o), str(r), "MATCH" if o == r else "MISMATCH"])
rows.append(["M4_invalid_rejection", "N/A", "NOT_EVALUATED (0 D_K-)", "MATCH (both NOT_EVALUATED)"])
with (P01 / "P01_METRIC_RECONCILIATION.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(["metric", "p01_reported", "independent_recomputed", "match"]); w.writerows(rows)

(P01 / "P01_INDEPENDENT_VERIFICATION.log").write_text(
    "verify_p01_metrics.py: re-aggregated from raw/J01_PER_LEG_RESULTS.jsonl + j01_cases.json\n"
    "all M1-M7 reconciliation rows: " + ("all MATCH" if all(r[3] == "MATCH" for r in rows if r[0].startswith("M")) else "MISMATCH") + "\n",
    encoding="utf-8", newline="\n")

print(json.dumps(recomputed, indent=2))
print("reconciliation:", all(r[3] == "MATCH" for r in rows))