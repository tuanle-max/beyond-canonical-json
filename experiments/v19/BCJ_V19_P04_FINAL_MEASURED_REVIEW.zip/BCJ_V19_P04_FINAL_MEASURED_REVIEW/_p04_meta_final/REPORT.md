# BCJ-V19-P04 FINAL MEASURED Report

Base `a00305bb2e8031905472ca4d8a8bfa806c9d5b22`; R4 archive `ebb1d824…` preserved.

## Gates
- F17 Go cross-check (Docker Linux, go1.23.12, golang@sha256:1670…): PASS — 143 occurrences (142 unique) + 16 batch units, 0 mismatches vs Python across admission/reason/canonical/leaf/batch/root.
- F18–F23 corrections done; final entry gates FE01–FE15 = PASS (P04_FINAL_ENTRY_GATE_MATRIX.json).
- Execution lock sha `37180cfafa394feb6138931e9ccb384236573c77224ebd5f331c2d5159fb0a0a`.

## Measured results (100 units × 4 arms = 400 observations; run p04d:40301435501d43d6)
- Per-arm common correctness: A1 = 45/100, A1+PID = 75/100, A1+CI = 55/100, A2 = 85/100.
- Paired A1 vs A2: both_correct=45, A1_only=0, A2_only=40, both_incorrect=15, paired_effect=0.4.
- Identity guard: TP=30, FP=0, FN=0, TN=40 (recall 1.0, FPR 0). CI guard: TP=15, FP=0, FN=0, TN=40.
- Benign service preserved (M11 = 1.0 all arms). No false alarms.
- Shared miss = 15 G4 hidden encoding/batch faults (identity-invisible, outside record-level CI coverage).

## Interpretation
A2 adds assurance only where a guard can observe it: manifest-visible identity mismatch (identity guard; 30 faults) and
CI-exercised behavioral regressions (CI guard; 15 faults). Hidden executable drift unchanged in declared identity, and
construction drift invisible to identity comparison, remain shared misses — a finite CI suite cannot cover them. No
authenticated checkpoint verification, universal semantic correctness, production prevalence, or unseen-mechanism
generalization is claimed. Same-team Python+Go cross-check is not third-party replication.

## Performance (156 reps = 36 warm-up + 120 measured; seed 42)
Median end-to-end and IQR per arm/size in P04_PERFORMANCE_SUMMARY.csv; memory = Python-traced peak ALLOCATED bytes
(not process RSS). Example: A2 @5000 ≈ 1.81 s median. Identity/CI guard cost is per-batch/build, not per-record.

## Scope / stop
No P05; no P07 remediation; no manuscript modification; P03 not reopened. Scientific conclusions pending EL review.
