# CR-0011 Adjudication and Preservation Record

## Experiment Lead decision (2026-11-24)

CR-0011 escalation ACCEPTED. **Option (b)**: restore exactly the two deleted P04 deliverables from
the immutable commit; PRESERVE the dirty working tree as-is (no reset/clean/restore/stash/unrelated
commit); isolate subsequent P04 development in a separate clean worktree. P04-A R2 design ACCEPTED;
protocol freeze CONDITIONAL pending F01-F08. P03 CLOSED/FROZEN; P07 F01-F05 OPEN_MANDATORY.

## Base commit

`1c88fa9e4a466f70e539b0d92fc2de7598a340f9`

## Preservation (unresolved workspace drift — PRESERVED, not owned by this phase)

Recovery location (OUTSIDE the repository; not included in this scientific archive):

`C:\Users\lemin\OneDrive\Desktop\Research\CR0011_PRESERVATION\cr0011_preserve_20261125T041812Z`

Preserved (SHA-256 recorded in `CR0011_WORKTREE_PRESERVATION.json` in that recovery dir):
- modified: docs/CHANGE_REQUEST.md, BCJ_V19_P03_PREFLIGHT_R1_REVIEW.zip(+.sha256), scripts/p03_lock.py,
  scripts/p03_mutations2.py, scripts/p03_unicode_conformance.py, tex/MANUSCRIPT_SSOT.tex
- untracked: EVIDENCE_BUNDLE_G1.zip, EVIDENCE_BUNDLE_G1_R2.zip, experiments/v19/_candidate_repro.zip, tex/v19_P00_P03.tex
- deleted (recorded, then restored): experiments/v19/BCJ_V19_P04_PREREG_R2_REVIEW.zip (git blob 348a1d6c169b8cc7012991224c60b0399f79f49b), .sha256 (blob 762fbc181f4d9ec294c62cbf43aaf765d4d62fc7)

These dirty files were NOT modified, deleted, or committed. Their ownership/purpose remains unresolved.

## Deliverable recovery (RESOLVED)

Restored exactly two files from commit 1c88fa9:
- experiments/v19/BCJ_V19_P04_PREREG_R2_REVIEW.zip -> SHA-256 828a3f44eb52304c6481e9aa9ee39519e93c674cf69a0948ccec0f3a5f7202ea (detached sha256 match; ZIP CRC ok; 16 unique entries; git blob agreement 348a1d6c)
- experiments/v19/BCJ_V19_P04_PREREG_R2_REVIEW.zip.sha256 -> content matches 828a3f44...  BCJ_V19_P04_PREREG_R2_REVIEW.zip

Verification record: `CR0011_RESTORE_VERIFICATION.json` (recovery dir). All 11 preserved files re-hashed unchanged after restore.

## Worktree isolation (RESOLVED pending verification)

Clean worktree created from 1c88fa9 at `C:\Users\lemin\OneDrive\Desktop\Research\BCJ-P04-R3`
(branch `p04-assurance-r3`). Tracked files unmodified; only new P04 deliverables added. Frozen P03
sources verified (python git blob 4bc829761c93be1b57a867440a160e4b3295474f; go git blob
e2a22d1937c60704c4d291bcede714c6939dbc03; frozen SHA-256 2b692401... / 493102b2... reproduce under CRLF).

## Status distinctions

- P04 deliverable recovery: RESOLVED
- Original workspace drift ownership: UNRESOLVED (preserved; pending owner disposition)
- P04 development isolation: RESOLVED