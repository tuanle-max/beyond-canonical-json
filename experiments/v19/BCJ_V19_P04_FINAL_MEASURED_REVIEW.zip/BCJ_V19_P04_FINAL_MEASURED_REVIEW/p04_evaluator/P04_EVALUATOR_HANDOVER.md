# P04-C Evaluator Handover (P04-A/P04-B development readiness)

STATUS: preparation only. Measured corpus NOT generated. Measured execution NOT authorized.
No evaluator answer key is exposed to the guard-development workspace.

## Frozen guard source digests (P04-B)

| file | sha256 |
|------|--------|
| engine_adapter.py | 358036c746e91ab00916879f375f83cdd1f23553ef65dc95122ac482bc3bf212 |
| guards.py | 24057610ba55dcbd1712c581fc027869ae713bc8bdf136eed7cade085d4dabfc |
| arms.py | c1420ac03bce67a1291d897ae1c23157f5d53104dab3ab9abe3c7ded5c97d392 |
| mutations.py | bf38d5bc430de2fd212e980a7a8faf196b12dfcb6e1dbc32d08d51290838bad3 |
| oracle.py | d3ea22d60f9c2d512388d642d8f22799a75d573683084f734ad072f87188f607 |
| aggregate.py | b11b7de6116c2173e59a97c88070e6c08b6a0c1090e7381b868741aab674c9b6 |
| schema.py | 4e72aebfbc895d7e1814902817fb6c81766b0bd5466f98c6a339d380c8ab9de7 |
| perf.py | 1d347597ca248c5e042a97087d6fe7a93fe088ee8a0299d4dfa98e640fc28b8e |
| runner.py | 35fc924f64ac94b736e0281cb056dbad52d5e827212d4253f3f8abde0697d506 |

## Frozen D_CI and D_DEV digests

- D_CI `vectors.json` sha256: ffe1da6d368fab475640988c3e5f86fc054f8c2755755cfd9188015f3bedddeb
- D_DEV `units.json` sha256: 1fae0f3883c2ed2fdf01963cd450f84f0bad6f905c27361acdca87a79d64e580

## Planned measured corpus (P04-C, gated)

- Exactly 100 unique units: 60 fault + 40 benign.
- 4 groups × (15 fault + 10 benign): G1 semantic-profile, G2 construction, G3 semantic regression, G4 encoding/batch.
- Primary arm coverage (F01): A1, A1+PID, A1+CI, A2 each on all 100 units = 400 arm-unit observations.
- A0/N0/N1 are controls, excluded from the 400.

## Evaluator session procedure (P04-C)

1. Confirm guard-source and D_CI freeze (digests above) BEFORE generating D_EVAL.
2. Generate D_EVAL membership + fault labels + expected outcomes in a SEPARATE evaluator workspace.
3. Do NOT expose the D_EVAL answer key, fault labels, or expected digests to the guard workspace.
4. Freeze D_EVAL artifacts with SHA-256 and record exposure chronology.
5. Return the execution-readiness package. Measured execution stays gated until explicit Lead authorization.

## Exact future execution commands (P04-D/E, gated)

```powershell
# Aggregation from raw observations (P04-F) — independent recomputation
python experiments/v19/p04_implementation/dev_smoke.py   # DEV only (already run)
# For measured execution (NOT authorized here), the evaluator session will:
#   python experiments/v19/p04_evaluator/run_measured.py --corpus d_eval/units.json --out results/P04/measured_raw.jsonl
```

No measured command above is executed in this invocation.