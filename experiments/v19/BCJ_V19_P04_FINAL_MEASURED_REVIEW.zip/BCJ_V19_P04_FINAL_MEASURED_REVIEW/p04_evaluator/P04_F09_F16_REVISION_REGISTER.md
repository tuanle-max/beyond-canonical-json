# P04-B Hardening Revision Register (F09–F16) — R3A

Base: accepted development commit `f5f963bcf6a52dfd5cfc9757daffd2e260eec88c` (R3 archive `bd862cbc…`).
Scope: production hardening before evaluator freeze. No measured execution, no P03/P07/manuscript change.

| ID | Correction | Deliverable / evidence | Status |
|----|------------|------------------------|--------|
| F09 | Generalize harness to RECORD + BATCH; 12 mutation operators across G1–G4 with full metadata + impl digests; batch validated against frozen-engine behavior (incl. empty root `99be5efb…`) and duplicate/reorder/missing-required/odd/even | `arms.py`, `mutations.py`, dev smoke batch observations | DONE |
| F10 | Correct A0 raw-JCS (no `.encode()` on bytes); raw JSON domain; distinguish valid/unsupported/malformed/programming error; no exception suppression | `arms._a0`, `results/P04/a0_controls.json` (5/5) | DONE |
| F11 | Structured per-detector guard events (identity + CI preserved for A2; CI NOT_EXECUTED when identity blocks; dedup by guard_execution_id) | `schema.make_guard_event`, `guards.py`, `arms.run_unit`, `aggregate.detector_confusion` | DONE |
| F12 | Production common correctness classifier (error/timeout first; exact admission/reason; RELEASE/PREVENT/REJECT classes; explicit N/A; no None coercion) | `aggregate.classify` | DONE |
| F13 | Integrated QA Q01–Q15 against production verifier/runner/aggregator (original R3 QA retained) | `qa_integrated.py`, `results/P04/qa_integrated_results.json` (15/15); `results/P04/dev_qa_results.json` (R3 retained) | DONE |
| F14 | Correct D_CI detached checksum to file-bytes digest `ffe1da6d…`; vector contents unchanged | `d_ci/vectors.json.sha256` | DONE |
| F15 | Complete performance runner (100/1000/5000 × 4 arms; 3 warm-up + 10 measured = 120 + 36; seed 42; tracemalloc labelled Python-traced alloc, not RSS; cost separation); dev smoke only | `perf.py`, `results/P04/perf_dev_smoke.json` | DONE |
| F16 | Source/resume integrity: verify frozen P03 source + manifests before import; run_id + plan digest + schema binding; reject duplicate/unexpected/incompatible on resume; timeout + explicit failure records; COMPLETE only on exact plan | `envprobe.py`, `P04_SOURCE_ATTESTATION.json`, `runner.py`, QA Q15 | DONE |

Additional: production fairness verifier + M01–M14 (`aggregate.verify_fairness`, `aggregate.summary`),
independent commitment reconstruction + spec-derived oracle (`p04_evaluator/corpus.py`).

Line-ending policy is frozen and explicit (`envprobe.POLICY`): raw / LF / CRLF digests recorded separately;
raw-byte hashes are never silently substituted for normalized ones.

Known blocker (P04-C, not a hardening gate): the accepted Go engine cannot be compiled in this environment
(`Application Control policy blocks Go compile.exe`), so the Go cross-check oracle reference is UNAVAILABLE.
The P04-C oracle therefore relies on the frozen Python engine + independent commitment reconstruction +
spec-derived assertions, and is marked CONDITIONAL pending a Go cross-check in a permissive environment.