# P04 F17–F23 Revision Register (R4A)

Base R4 commit `a00305bb2e8031905472ca4d8a8bfa806c9d5b22`.

| ID | Correction | Evidence | Status |
|----|------------|----------|--------|
| F17 | Go reference cross-check via Docker Linux (golang@sha256:1670…, go1.23.12) | P04_GO_REFERENCE_CROSSCHECK.json (143 occ / 142 unique / 16 batch, 0 mismatches) | DONE |
| F18 | Operator-level prospective applicability (12 operators) from frozen detector contract + D_CI basis | P04_DETECTOR_APPLICABILITY.R4A.json | DONE |
| F19 | Activation-aware required behavior (pristine-vs-mutated outputs; not fault⇒PREVENT) | P04_FAULT_ACTIVATION_R4A.jsonl (60 fault units; 60 activated, 0 inactive, 0 required-changed) | DONE |
| F20 | Final append-only execution lock binding all inputs | P04_FINAL_EXECUTION_LOCK.json (sha 37180cf…) | DONE |
| F21 | Runner/resume integrity with execution-lock binding | runner.py; P04D_RUN_METADATA.json (run_id p04d:40301435501d43d6) | DONE |
| F22 | Corrected production classifier (no PREVENTED_OTHER; block needs basis; abstention supported) | aggregate.py; QA Q05-Q07 | DONE |
| F23 | Exposure audit + execution-input projection (guards get no labels/expected) | P04_HOLDOUT_EXPOSURE_AUDIT.json; arms receive project_unit() | DONE |

## Measured execution (auto-authorized after FE gates PASS)
- P04-D: 100 units × 4 arms = 400 observations (run p04d:40301435501d43d6), fairness OK.
- P04-E: 156 repetitions (36 warm-up + 120 measured), seed 42, tracemalloc = Python-traced peak alloc.
- P04-F: independent aggregation from raw (M01–M14; paired; confusion; per-family; stage).
- P04-G: manuscript handover tables/narrative/threats/reviewer/claim matrix.

Result summary (measured): A1=45/100, A1+PID=75, A1+CI=55, A2=85; identity TP=30 FP=0, CI TP=15 FP=0;
paired A1→A2: both_correct=45, A1_only=0, A2_only=40, both_incorrect=15 (G4 hidden drift shared miss), effect=0.4.