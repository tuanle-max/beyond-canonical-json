# P04 Results Narrative (measured: 100 units x 4 arms = 400 observations)

RQ: incremental assurance of A2 (identity + CI guards) beyond the identical typed-normalization baseline A1.

## Common end-to-end correctness (per arm)
- A1: 45/100 correct (0.4500)
- A1+PID: 75/100 correct (0.7500)
- A1+CI: 55/100 correct (0.5500)
- A2: 85/100 correct (0.8500)

## Paired A1 vs A2 (N=100)
- both_correct=45, A1_only=0, A2_only=40, both_incorrect=15, paired_effect=0.4

## Detectors
- identity: TP=30 FP=0 FN=0 TN=40 recall=1.0 fpr=0.0
- ci-regression: TP=15 FP=0 FN=0 TN=40 recall=1.0 fpr=0.0

## Service / safety
- unsafe_release (M10): A1=55/60, A1+PID=25/60, A1+CI=45/60, A2=15/60
- benign_service (M11): A1=40/40, A1+PID=40/40, A1+CI=40/40, A2=40/40

## Interpretation
A2 provides additional assurance beyond A1 only on faults a guard can see: manifest-visible identity mismatch
(identity guard) and CI-exercised behavioral regressions (CI guard). Hidden executable drift outside CI coverage
and identity-invisible construction drift are shared misses. Manifest identity mismatch is caught because the
active identity is recomputed from manifest content; hidden drift under an unchanged declared identity is not
detectable by identity comparison, and a finite CI suite only catches exercised regressions. No authenticated
checkpoint verification or universal semantic correctness is claimed.
