# P04 Threats to Validity

- Purposive, template-correlated synthetic corpus; no production sampling.
- Same-team Python+Go cross-check; NOT independent third-party replication.
- Finite CI vector set: regressions outside coverage are legitimate misses.
- Mutation operators frozen before corpus; new inputs are instances, not unseen mechanisms.
- No authenticated checkpoint verification (P05 scope).
- Purposive design: no population failure-probability / grouped-independent inference.
- Go cross-check executed in Docker Linux; Windows Go compile blocked by Application Control (environmental).
