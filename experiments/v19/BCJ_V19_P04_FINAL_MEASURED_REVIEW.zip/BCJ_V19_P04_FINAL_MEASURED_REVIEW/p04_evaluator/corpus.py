"""P04-C evaluator corpus generator (evaluator-only). Deterministic seed + template inventory.

Generates exactly 100 measured units (G1..G4: 15 fault + 10 benign each). Expected outcomes are
derived from the frozen normative contract + construction specification, via the frozen Python
engine AND an INDEPENDENT commitment reconstruction (this module's own leaf/root code), plus
spec-derived boundary assertions. The accepted Go engine cross-check is UNAVAILABLE in this
environment (Application Control blocks the Go compiler) and is recorded as such.
"""
import base64
import hashlib
import json
import random

import arms
import engine_adapter as ea

SEED = 20261124
GO_REFERENCE = "UNAVAILABLE (Application Control policy blocks Go compile.exe)"
FROZEN_PY = "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f"


def b64(o):
    return base64.b64encode(json.dumps(o).encode("utf-8")).decode("ascii")


def sha(b):
    return hashlib.sha256(b).hexdigest()


# ---- independent commitment reconstruction (NOT engine.leaf / engine.root) ----
def indep_leaf(canon, pid_hex, cd_hex):
    return hashlib.sha256(b"\x00\x03" + bytes.fromhex(pid_hex) + bytes.fromhex(cd_hex) + canon).digest()


def indep_root(leaves):
    n = len(leaves)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest()
    if n == 1:
        return leaves[0]
    k = 1
    while k * 2 < n:
        k *= 2
    return hashlib.sha256(b"\x01" + indep_root(leaves[:k]) + indep_root(leaves[k:])).digest()


def spec_check(eng):
    """Spec-derived boundary assertions from the normative contract examples."""
    ws = arms.make_workspace(None)
    pid, cd = arms.active_identities(ws)
    ok = True
    details = {}
    for amt, want in [("2.675", 268), ("2.674999", 267)]:
        rec = {"event_id": "spc", "timestamp": "2026-11-03T10:00:00Z", "amount": amt,
               "currency": "USD", "scale": 2, "beneficiary_code": "b"}
        r = ws["engine"].adjudicate(json.dumps(rec).encode())
        got = (r.get("typed") or {}).get("minor")
        details[amt] = got
        if r["decision"] != "ACCEPT" or got != want:
            ok = False
    # timestamp 2026-11-03T10:00:00Z -> epoch ms
    rec = {"event_id": "spc", "timestamp": "2026-11-03T10:00:00Z", "amount": "1.00",
           "currency": "USD", "scale": 2, "beneficiary_code": "b"}
    r = ws["engine"].adjudicate(json.dumps(rec).encode())
    t = (r.get("typed") or {}).get("t")
    details["t_2026_11_03T10Z"] = t
    if t != 1793700000000:
        ok = False
    return {"ok": ok, "details": details}


def oracle_record(record_b64, record_id):
    ws = arms.make_workspace(None)
    pid, cd = arms.active_identities(ws)
    eng = ws["engine"]
    res = eng.adjudicate(base64.b64decode(record_b64))
    if res["decision"] != "ACCEPT":
        return {"unit_type": "RECORD", "admission": res["decision"], "reason": res["reason_code"],
                "canonical": None, "leaf": None, "root": None, "leaf_digests": None,
                "indep_match": None, "required": "REJECT_VIA_ADMISSION"}
    canon = bytes.fromhex(res["canonical_hex"])
    leaf = eng.leaf(canon, pid, cd)
    indep = indep_leaf(canon, pid, cd)
    return {"unit_type": "RECORD", "admission": "ACCEPT", "reason": None,
            "canonical": sha(canon), "canonical_bytes_hex": canon.hex(),
            "leaf": leaf.hex(), "root": leaf.hex(), "leaf_digests": [leaf.hex()],
            "indep_match": (indep == leaf), "required": "RELEASE"}


def oracle_batch(records, expected_ids):
    ws = arms.make_workspace(None)
    pid, cd = arms.active_identities(ws)
    eng = ws["engine"]
    c = ea.commit(eng, {"batch_id": "o", "pid_sem": pid, "construction_digest": cd,
                        "records": records, "expected_ids": expected_ids})
    leaves = []
    for r in records:
        res = eng.adjudicate(base64.b64decode(r["raw_b64"]))
        if res["decision"] == "ACCEPT":
            leaves.append(indep_leaf(bytes.fromhex(res["canonical_hex"]), pid, cd))
    indep = indep_root(leaves).hex()
    return {"unit_type": "BATCH", "admission": ("ACCEPT" if c["status"] == "OK" else "BATCH_FAILED"),
            "batch_status": c["status"], "root": c["root"], "leaf_digests": c["leaf_digests"],
            "leaf_count": c["leaf_count"], "indep_match": (indep == c["root"]),
            "required": ("RELEASE" if c["status"] == "OK" else "PREVENT")}
GROUP_APP = {"G1": {"identity": True, "ci": False}, "G2": {"identity": True, "ci": False},
             "G3": {"identity": False, "ci": True}, "G4": {"identity": False, "ci": False}}


def gen_record(rng, i, sub_unit=False, force_cur=None):
    cur = force_cur or ["USD", "EUR", "VND"][i % 3]
    scale = {"USD": 2, "EUR": 2, "VND": 0}[cur]
    base = rng.randint(10, 9000)
    if sub_unit and scale == 2:
        amount = "%d.%s" % (base, rng.choice(["005", "015", "025", "125", "675"]))
    elif scale == 0:
        amount = str(base)
    else:
        amount = "%d.%02d" % (base, rng.randint(0, 99))
    off = ["Z", "+07:00", "+05:30", "-05:00"][i % 4]
    ts = "2026-%02d-%02dT%02d:%02d:%02d%s" % (rng.randint(1, 12), rng.randint(1, 28),
                                             rng.randint(0, 23), rng.randint(0, 59),
                                             rng.randint(0, 59), off)
    ben = "benef-" + rng.choice(["alpha", "beta", "gamma", "delta"]) + str(i)
    rec = {"event_id": "evt-%04d" % i, "timestamp": ts, "amount": amount, "currency": cur,
           "scale": scale, "beneficiary_code": ben}
    if i % 4 == 0:
        rec["obligation_ref"] = "ref-%04d" % i
    return rec


def entry(rec):
    return {"record_id": rec["event_id"], "raw_b64": b64(rec)}


def make_unit(uid, group, unit_type, mutation, fault, oracle_res, rec=None, records=None, expected_ids=None, template_id=None):
    u = {"unit_id": uid, "group": group, "unit_type": unit_type, "mutation_operator": mutation,
         "fault_present": fault,
         "identity_applicable": (GROUP_APP[group]["identity"] if fault else False),
         "ci_applicable": (GROUP_APP[group]["ci"] if fault else False),
         "required_behavior": ("PREVENT" if fault else oracle_res["required"]),
         "template_id": template_id or (group + "-" + unit_type),
         "expected_admission": oracle_res["admission"], "expected_reason": oracle_res.get("reason"),
         "expected_canonical": oracle_res.get("canonical"), "expected_leaf": oracle_res.get("leaf"),
         "expected_root": oracle_res.get("root"), "expected_leaf_digests": oracle_res.get("leaf_digests"),
         "expected_batch_status": oracle_res.get("batch_status"),
         "indep_match": oracle_res.get("indep_match"), "go_crosscheck": GO_REFERENCE}
    if unit_type == "RECORD":
        u["record_id"] = rec["event_id"]
        u["raw_b64"] = b64(rec)
    else:
        u["records"] = records
        u["expected_ids"] = expected_ids
    return u
_RID = [0]


def _rec(rng, sub_unit=False, force_cur=None):
    _RID[0] += 1
    return gen_record(rng, _RID[0], sub_unit=sub_unit, force_cur=force_cur)


def build_units(seed=SEED):
    rng = random.Random(seed)
    _RID[0] = 0
    units = []
    g1_ops = ["g1_normative_artifact", "g1_semantic_version", "g1_unicode_fields"]
    g2_ops = ["g2_leaf_formula", "g2_tree_policy", "g2_empty_root"]
    g3_ops = ["g3_rounding_half_down", "g3_ts_plus1ms", "g3_scale_registry"]
    g4_ops = ["g4_leaf_prefix", "g4_node_prefix", "g4_tree_topology"]

    for g, ops in [("G1", g1_ops), ("G2", g2_ops)]:
        for k in range(15):
            r = _rec(rng)
            units.append(make_unit("%s-F%02d" % (g, k + 1), g, "RECORD", ops[k % 3], True,
                                   oracle_record(b64(r), r["event_id"]), rec=r, template_id="rec-plain"))
        for k in range(10):
            r = _rec(rng)
            units.append(make_unit("%s-B%02d" % (g, k + 1), g, "RECORD", None, False,
                                   oracle_record(b64(r), r["event_id"]), rec=r, template_id="rec-plain"))

    for k in range(15):
        op = g3_ops[k % 3]
        if op == "g3_rounding_half_down":
            r = _rec(rng, sub_unit=True, force_cur="USD")
        elif op == "g3_scale_registry":
            r = _rec(rng, force_cur="USD")
        else:
            r = _rec(rng)
        units.append(make_unit("G3-F%02d" % (k + 1), "G3", "RECORD", op, True,
                               oracle_record(b64(r), r["event_id"]), rec=r, template_id=op))
    for k in range(10):
        r = _rec(rng)
        units.append(make_unit("G3-B%02d" % (k + 1), "G3", "RECORD", None, False,
                               oracle_record(b64(r), r["event_id"]), rec=r, template_id="rec-plain"))

    for k in range(15):
        op = g4_ops[k % 3]
        if op == "g4_leaf_prefix":
            r = _rec(rng)
            units.append(make_unit("G4-F%02d" % (k + 1), "G4", "RECORD", op, True,
                                   oracle_record(b64(r), r["event_id"]), rec=r, template_id=op))
        else:
            size = (2 + (k % 3)) if op == "g4_node_prefix" else (4 + (k % 3))
            ents = [entry(_rec(rng)) for _ in range(size)]
            units.append(make_unit("G4-F%02d" % (k + 1), "G4", "BATCH", op, True,
                                   oracle_batch(ents, None), records=ents, template_id=op + "-size%d" % size))
    for k in range(4):
        r = _rec(rng)
        units.append(make_unit("G4-B%02d" % (k + 1), "G4", "RECORD", None, False,
                               oracle_record(b64(r), r["event_id"]), rec=r, template_id="rec-plain"))
    for uid, size, kind in [("G4-B05", 3, "odd"), ("G4-B06", 4, "even"), ("G4-B07", 3, "dup"),
                            ("G4-B08", 3, "reorder"), ("G4-B09", 0, "empty"), ("G4-B10", 1, "singleton")]:
        recs = [_rec(rng) for _ in range(size)]
        if kind == "dup" and size >= 2:
            recs[1] = recs[0]
        ents = [entry(x) for x in recs]
        if kind == "reorder" and size >= 2:
            ents = list(reversed(ents))
        units.append(make_unit(uid, "G4", "BATCH", None, False, oracle_batch(ents, None),
                               records=ents, template_id="batch-" + kind))
    return units