"""F17 Go reference-engine cross-check via Docker Linux (evaluator-side oracle verification).

Runs the pristine frozen Go engine against all D_EVAL record occurrences and batch descriptors and
compares to the frozen Python engine across admission/reason/canonical/leaf/batch/root. Not a measured
arm run; guards are never invoked.
"""
import base64
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p04_implementation"
SRC_GO = V19 / "implementations" / "go-dev"
IMG = "golang@sha256:167053a2bb901972bf2c1611f8f52c44d5fe7e762e5cab213708d82c421614db"
WORK = pathlib.Path(r"C:\Temp\p04gox")
SRC = pathlib.Path(r"C:\Temp\p04go")
sys.path.insert(0, str(IMPL))

import arms
import engine_adapter as ea


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load_units():
    return [json.loads(l) for l in (HERE / "P04_MEASURED_CORPUS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]


def occurrences(units):
    """Return list of (unit_id, record_id, raw_b64) for every record occurrence."""
    occ = []
    for u in units:
        if u["unit_type"] == "RECORD":
            occ.append((u["unit_id"], u["record_id"], u["raw_b64"]))
        else:
            for r in u["records"]:
                occ.append((u["unit_id"], r["record_id"], r["raw_b64"]))
    return occ


def run_docker():
    if WORK.exists():
        shutil.rmtree(WORK)
    WORK.mkdir(parents=True)
    SRC.mkdir(parents=True, exist_ok=True)
    for p in SRC_GO.iterdir():
        if p.is_file():
            shutil.copy(p, SRC / p.name)
    units = load_units()
    occ = occurrences(units)
    pid = ea.PID_SEM_V2
    cd = ea.CONSTRUCTION_DIGEST
    lines = [json.dumps({"record_id": rid, "raw_b64": rb, "pid_sem": pid, "construction_digest": cd})
             for (_uid, rid, rb) in occ]
    (WORK / "in_records.jsonl").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    (WORK / "batches").mkdir(exist_ok=True)
    for u in units:
        if u["unit_type"] == "BATCH":
            batch = {"batch_id": u["unit_id"], "pid_sem": pid, "construction_digest": cd,
                     "records": [{"record_id": r["record_id"], "raw_b64": r["raw_b64"]} for r in u["records"]],
                     "expected_ids": u.get("expected_ids")}
            (WORK / "batches" / (u["unit_id"] + ".json")).write_text(json.dumps(batch) + "\n", encoding="utf-8", newline="\n")
    runsh = ("set -e\ncd /src\nCGO_ENABLED=0 go build -o /w/boo . 2>/dev/null || exit 3\n"
             "/w/boo adjudicate /w/in_records.jsonl /w/out_records.jsonl || exit 4\n"
             "for f in /w/batches/*.json; do /w/boo commit \"$f\" \"${f%.json}.out.json\" || exit 5; done\n"
             "echo DONE\n")
    (WORK / "run.sh").write_text(runsh, encoding="utf-8", newline="\n")
    cmd = ["docker", "run", "--rm", "-v", "C:/Temp/p04go:/src", "-v", "C:/Temp/p04gox:/w", IMG, "sh", "/w/run.sh"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    (HERE / "P04_GO_REFERENCE_COMMANDS.log").write_text(
        "cmd: " + " ".join(cmd) + "\nexit: " + str(r.returncode) + "\nstdout:\n" + r.stdout + "\nstderr:\n" + r.stderr,
        encoding="utf-8", newline="\n")
    return {"units": units, "occ": occ, "returncode": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
def compare(ctx):
    units = ctx["units"]
    occ = ctx["occ"]
    ws = arms.make_workspace(None)
    eng = ws["engine"]
    pid, cd = arms.active_identities(ws)
    go_out = [json.loads(l) for l in (WORK / "out_records.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    rows = []
    rec_mism = []
    for i, (uid, rid, rb) in enumerate(occ):
        raw = base64.b64decode(rb)
        res = eng.adjudicate(raw)
        py_adm = res["decision"]
        py_reason = res["reason_code"]
        py_canon = sha(bytes.fromhex(res["canonical_hex"])) if res["canonical_hex"] else None
        py_leaf = eng.leaf(bytes.fromhex(res["canonical_hex"]), pid, cd).hex() if res["canonical_hex"] else None
        g = go_out[i] if i < len(go_out) else {}
        go_adm = g.get("admission")
        go_reason = g.get("reason_code")
        go_canon = g.get("canonical_sha256")
        go_leaf = g.get("leaf_digest")
        fields = {"admission": (py_adm, go_adm), "reason": (py_reason, go_reason),
                  "canonical_sha256": (py_canon, go_canon), "leaf_digest": (py_leaf, go_leaf)}
        ok = all(a == b for a, b in fields.values())
        if not ok:
            rec_mism.append({"index": i, "unit": uid, "record_id": rid,
                             "diff": {k: {"python": v[0], "go": v[1]} for k, v in fields.items() if v[0] != v[1]}})
        rows.append({"index": i, "unit": uid, "record_id": rid,
                     "python_admission": py_adm, "go_admission": go_adm,
                     "python_canonical_sha256": py_canon, "go_canonical_sha256": go_canon,
                     "python_leaf_digest": py_leaf, "go_leaf_digest": go_leaf, "match": ok})
    # batches
    batch_mism = []
    nb = 0
    for u in units:
        if u["unit_type"] != "BATCH":
            continue
        nb += 1
        outp = WORK / "batches" / (u["unit_id"] + ".out.json")
        go_b = json.loads(outp.read_text(encoding="utf-8").strip().splitlines()[0]) if outp.exists() else {}
        py_b = ea.commit(eng, {"batch_id": u["unit_id"], "pid_sem": pid, "construction_digest": cd,
                               "records": u["records"], "expected_ids": u.get("expected_ids")})
        def _n(x):
            return [] if x is None else x  # Go nil-slice marshals to null; normalize to []
        fields = {"status": (py_b["status"], go_b.get("status")), "root": (py_b["root"], go_b.get("root")),
                  "leaf_digests": (py_b["leaf_digests"], _n(go_b.get("leaf_digests"))),
                  "admitted": (py_b["admitted"], _n(go_b.get("admitted"))),
                  "rejected": (py_b["rejected"], _n(go_b.get("rejected"))),
                  "abstained": (py_b["abstained"], _n(go_b.get("abstained")))}
        if not all(a == b for a, b in fields.values()):
            batch_mism.append({"unit": u["unit_id"],
                               "diff": {k: {"python": v[0], "go": v[1]} for k, v in fields.items() if v[0] != v[1]}})
    # environment
    gi = subprocess.run(["docker", "run", "--rm", IMG, "go", "version"], capture_output=True, text=True)
    prov = __import__("envprobe").verify() if str(IMPL) in sys.path else {}
    env = {"image_digest": IMG, "go_version_in_image": gi.stdout.strip(),
           "x_text_version": "v0.19.0", "jcs_version": "v1.0.1",
           "frozen_python_sha256": "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f",
           "frozen_go_sha256": "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa",
           "returncode": ctx["returncode"], "stdout_tail": ctx["stdout"].strip().splitlines()[-1:] if ctx["stdout"] else []}
    (HERE / "P04_GO_REFERENCE_ENVIRONMENT.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8", newline="\n")
    (HERE / "P04_GO_REFERENCE_RAW.jsonl").write_text(
        "".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8", newline="\n")
    summary = {"record_occurrences": len(occ), "unique_raw_inputs": len({rb for (_, _, rb) in occ}),
               "batch_units": nb, "record_mismatches": rec_mism, "batch_mismatches": batch_mism,
               "record_mismatch_count": len(rec_mism), "batch_mismatch_count": len(batch_mism),
               "docker_returncode": ctx["returncode"],
               "overall_pass": (ctx["returncode"] == 0 and not rec_mism and not batch_mism)}
    (HERE / "P04_GO_REFERENCE_CROSSCHECK.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
    return summary


if __name__ == "__main__":
    ctx = run_docker()
    print(json.dumps({"returncode": ctx["returncode"], "stdout": ctx["stdout"][-60:], "stderr": ctx["stderr"][-300:]}, indent=2))
    if ctx["returncode"] == 0:
        print(json.dumps(compare(ctx), indent=2))