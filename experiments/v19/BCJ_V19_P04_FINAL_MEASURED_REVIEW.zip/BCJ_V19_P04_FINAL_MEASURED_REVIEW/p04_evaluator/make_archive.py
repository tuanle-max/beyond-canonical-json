"""Build the consolidated P04 development-readiness review archive (R3)."""
import hashlib
import json
import os
import platform
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]      # BCJ-P04-R3
V19 = ROOT / "experiments" / "v19"
NAME = "BCJ_V19_P04_DEVELOPMENT_READINESS_R3_REVIEW"
OUT_ZIP = V19 / (NAME + ".zip")
META = V19 / "_p04_meta"


def sha(p):
    h = hashlib.sha256()
    h.update(p.read_bytes())
    return h.hexdigest()


def walk(d):
    for root, _, fs in os.walk(V19 / d):
        for f in sorted(fs):
            p = pathlib.Path(root) / f
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            yield p


def main():
    META.mkdir(exist_ok=True)

    # guard-source freeze attestation
    guard = sorted((V19 / "p04_implementation").glob("*.py"))
    freeze = {"frozen": True,
              "guard_source": {f.name: sha(f) for f in guard},
              "d_ci_vectors_json": sha(V19 / "p04_implementation/d_ci/vectors.json"),
              "d_dev_units_json": sha(V19 / "p04_implementation/d_dev/units.json")}
    (V19 / "p04_implementation/P04_GUARD_SOURCE_FREEZE.json").write_text(
        json.dumps(freeze, indent=2) + "\n", encoding="utf-8")

    # worktree provenance
    prov = {"worktree_path": str(ROOT), "branch": "p04-assurance-r3",
            "base_commit": "1c88fa9e4a466f70e539b0d92fc2de7598a340f9",
            "frozen_python_git_blob": "4bc829761c93be1b57a867440a160e4b3295474f",
            "frozen_go_git_blob": "e2a22d1937c60704c4d291bcede714c6939dbc03",
            "frozen_python_sha256_crlf": "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f",
            "frozen_go_sha256_crlf": "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa",
            "note": "tracked files unmodified; only new P04 deliverables added; frozen P03 sources content-identical modulo LF/CRLF"}
    (V19 / "p04_evaluator/P04_WORKTREE_PROVENANCE.json").write_text(
        json.dumps(prov, indent=2) + "\n", encoding="utf-8")

    status = {"phase": "P04", "stage": "P04-B",
              "cr0011_deliverable_recovery": "RESOLVED",
              "original_worktree_drift": "PRESERVED_PENDING_OWNER_DISPOSITION",
              "p04_worktree_isolated": True,
              "p04_a_protocol_corrections": "COMPLETE",
              "p04_b_development": "COMPLETE",
              "guard_source_frozen": True, "ci_vectors_frozen": True,
              "measured_corpus_frozen": False, "measured_execution_authorized": False,
              "measured_execution_performed": False, "measured_performance_performed": False,
              "next_stage_authorized": False}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")

    env = {"python": platform.python_version(), "platform": platform.platform(),
           "machine": platform.machine(), "processor": platform.processor(),
           "rfc8785": "0.1.3", "pyyaml_validation": "6.0.4 (metric-dictionary validation only)",
           "git_base_commit": "1c88fa9e4a466f70e539b0d92fc2de7598a340f9",
           "note": "PyYAML installed into gitignored .venv for F08 YAML validation; not a project pin; not imported by the harness runtime"}
    (META / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8")

    files = []
    for d in ["p04_prereg_r3", "p04_implementation", "p04_evaluator", "results/P04"]:
        files.extend(walk(d))
    files.extend(sorted(META.glob("*")))

    # SHA256SUMS over all members (repo-relative)
    relmap = []
    for p in files:
        rel = p.relative_to(V19).as_posix() if p.is_relative_to(V19) else "_p04_meta/" + p.name
        relmap.append((rel, p))
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sums_path = META / "SHA256SUMS"
    sums_path.write_text(sums, encoding="utf-8")
    relmap.append(("_p04_meta/SHA256SUMS", sums_path))

    # RUN_MANIFEST
    manifest = {"archive": NAME, "base_commit": status["git_base_commit"] if "git_base_commit" in status else env["git_base_commit"],
                "files": {rel: sha(p) for rel, p in relmap},
                "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p04_meta/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))

    # build zip
    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    digest = sha(OUT_ZIP)
    (V19 / (NAME + ".zip.sha256")).write_text(digest + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT_ZIP), "members": len(relmap), "sha256": digest}, indent=2))


if __name__ == "__main__":
    main()