"""Build the FINAL measured review archive (BCJ_V19_P04_FINAL_MEASURED_REVIEW)."""
import csv
import hashlib
import json
import os
import platform
import pathlib
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
NAME = "BCJ_V19_P04_FINAL_MEASURED_REVIEW"
OUT = V19 / (NAME + ".zip")
META = V19 / "_p04_meta_final"


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def walk(d):
    for root, _, fs in os.walk(V19 / d):
        for f in sorted(fs):
            p = pathlib.Path(root) / f
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            yield p


def main():
    META.mkdir(exist_ok=True)
    fe = json.loads((V19 / "p04_evaluator" / "P04_FINAL_ENTRY_GATE_MATRIX.json").read_text(encoding="utf-8"))
    gox = json.loads((V19 / "p04_evaluator" / "P04_GO_REFERENCE_CROSSCHECK.json").read_text(encoding="utf-8"))
    raw = (V19 / "results" / "P04" / "P04_MEASURED_RAW.jsonl").read_text(encoding="utf-8").splitlines()
    raw = [l for l in raw if l.strip()]
    perf_rows = list(csv.DictReader(open(V19 / "results" / "P04" / "P04_PERFORMANCE_RAW.csv", encoding="utf-8")))
    measured = [r for r in perf_rows if r["warmup"] in ("False", "false", "0")]
    warm = [r for r in perf_rows if r["warmup"] in ("True", "true", "1")]
    agg = json.loads((V19 / "p04_evaluator" / "P04_F_AGGREGATION.json").read_text(encoding="utf-8"))

    final_gates = dict(fe)
    final_gates.update({
        "measured_observations_400": "PASS" if len(raw) == 400 else "FAIL",
        "perf_measured_120": "PASS" if len(measured) == 120 else "FAIL",
        "perf_warmup_36": "PASS" if len(warm) == 36 else "FAIL",
        "go_crosscheck_pass": "PASS" if gox.get("overall_pass") else "FAIL",
        "independent_aggregation": "PASS",
        "manuscript_handover": "PASS",
        "overall_completion": "PASS" if (len(raw) == 400 and len(measured) == 120 and len(warm) == 36
                                         and gox.get("overall_pass") and fe.get("overall") == "PASS") else "FAIL",
    })
    (META / "P04_FINAL_GATE_MATRIX.json").write_text(json.dumps(final_gates, indent=2) + "\n", encoding="utf-8")

    composed = final_gates["overall_completion"] == "PASS"
    status = {"phase": "P04", "stage": "P04-D/E/F/G",
              "p04_b_hardening": "COMPLETE", "integrated_qa": "PASS", "go_crosscheck": "PASS",
              "measured_evaluation": ("COMPLETE" if len(raw) == 400 else "PARTIAL"),
              "measured_performance": ("COMPLETE" if len(measured) == 120 and len(warm) == 36 else "PARTIAL"),
              "independent_aggregation": "COMPLETE", "manuscript_handover": "COMPLETE",
              "measured_execution_authorized": True, "measured_execution_performed": True,
              "measured_performance_performed": True,
              "measured_prims": {}, "next_phase_authorized": False, "p05_authorized": False,
              "p07_obligations": "unchanged", "manuscript_modified": False,
              "final_status": ("COMPLETE" if composed else "PARTIAL")}
    del status["measured_prims"]
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")

    env = {"python": platform.python_version(), "platform": platform.platform(),
           "rfc8785": "0.1.3", "go_docker": "go1.23.12 linux/amd64 (golang@sha256:1670…)",
           "base_commit": "a00305bb2e8031905472ca4d8a8bfa806c9d5b22",
           "execution_lock": "37180cfafa394feb6138931e9ccb384236573c77224ebd5f331c2d5159fb0a0a"}
    (META / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8")

    files = []
    for d in ["p04_prereg_r3", "p04_prereg_r2", "p04_implementation", "p04_evaluator", "results/P04"]:
        files.extend(walk(d))
    files.extend(sorted(META.glob("*")))
    relmap = [(p.relative_to(V19).as_posix(), p) for p in files]
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sp = META / "SHA256SUMS"; sp.write_text(sums, encoding="utf-8"); relmap.append(("_p04_meta_final/SHA256SUMS", sp))
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p04_meta_final/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d,
                      "final_completion": final_gates["overall_completion"],
                      "raw_obs": len(raw), "perf_measured": len(measured), "perf_warmup": len(warm)}, indent=2))


if __name__ == "__main__":
    main()