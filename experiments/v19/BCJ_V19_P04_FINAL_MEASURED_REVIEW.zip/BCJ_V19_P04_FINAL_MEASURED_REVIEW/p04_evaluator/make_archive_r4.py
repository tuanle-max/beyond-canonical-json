"""Build the consolidated P04 EXECUTION-READINESS R4 archive (non-circular manifest)."""
import hashlib
import json
import os
import platform
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
NAME = "BCJ_V19_P04_EXECUTION_READINESS_R4_REVIEW"
OUT = V19 / (NAME + ".zip")
META = V19 / "_p04_meta_r4"
sys.path.insert(0, str(V19 / "p04_implementation"))


def sha(p):
    h = hashlib.sha256()
    h.update(pathlib.Path(p).read_bytes())
    return h.hexdigest()


def walk(d):
    for root, _, fs in os.walk(V19 / d):
        for f in sorted(fs):
            p = pathlib.Path(root) / f
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            yield p


def main():
    META.mkdir(exist_ok=True)
    import mutations
    guard = sorted((V19 / "p04_implementation").glob("*.py"))
    evalg = sorted((V19 / "p04_evaluator").glob("*.py"))
    freeze = {"guard_source": {f.name: sha(f) for f in guard},
              "evaluator_source": {f.name: sha(f) for f in evalg},
              "d_ci_vectors_json": sha(V19 / "p04_implementation/d_ci/vectors.json"),
              "d_dev_units_json": sha(V19 / "p04_implementation/d_dev/units.json")}
    (V19 / "p04_implementation/P04_GUARD_SOURCE_FREEZE.json").write_text(json.dumps(freeze, indent=2) + "\n", encoding="utf-8")
    (V19 / "p04_implementation/P04_MUTATION_INVENTORY.json").write_text(
        json.dumps({"operators": mutations.inventory()}, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    status = {"phase": "P04", "stage": "P04-C", "p04_b_hardening": "COMPLETE", "integrated_qa": "PASS",
              "guard_source_frozen": True, "ci_vectors_frozen": True, "mutation_inventory_frozen": True,
              "measured_corpus_frozen": True, "oracle_frozen": True,
              "planned_units": 100, "planned_fault_units": 60, "planned_benign_units": 40,
              "planned_primary_observations": 400,
              "measured_execution_authorized": False, "measured_execution_performed": False,
              "measured_performance_performed": False, "next_stage_authorized": False,
              "oracle_go_crosscheck": "UNAVAILABLE (Application Control blocks Go compile)",
              "overall": "CONDITIONAL"}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
    env = {"python": platform.python_version(), "platform": platform.platform(), "machine": platform.machine(),
           "rfc8785": "0.1.3", "pyyaml_validation": "6.0.4",
           "go": "go1.27.3 (compile BLOCKED by Application Control policy)",
           "git_base_commit": "1c88fa9e4a466f70e539b0d92fc2de7598a340f9",
           "dev_commit_r3": "f5f963bcf6a52dfd5cfc9757daffd2e260eec88c"}
    (META / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8")

    files = []
    for d in ["p04_prereg_r3", "p04_implementation", "p04_evaluator", "results/P04"]:
        files.extend(walk(d))
    files.extend(sorted(META.glob("*")))
    relmap = [(p.relative_to(V19).as_posix(), p) for p in files]

    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sp = META / "SHA256SUMS"
    sp.write_text(sums, encoding="utf-8")
    relmap.append(("_p04_meta_r4/SHA256SUMS", sp))
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p04_meta_r4/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))

    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d}, indent=2))


if __name__ == "__main__":
    main()