"""P04-C corpus driver: build 100 units and write the 9 evaluator-freeze artifacts."""
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p04_implementation"
sys.path.insert(0, str(IMPL))

import corpus
import envprobe


def sha(b):
    return hashlib.sha256(b).hexdigest()


def jl(rows):
    return "".join(json.dumps(r, sort_keys=True) + "\n" for r in rows)


def wj(name, obj):
    p = HERE / name
    p.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return sha(p.read_bytes())


def unit_core(u):
    return {k: u.get(k) for k in ("unit_id", "group", "unit_type", "record_id", "raw_b64", "records",
            "expected_ids", "mutation_operator", "fault_present", "identity_applicable",
            "ci_applicable", "required_behavior", "template_id")}


def main():
    eng = corpus.arms.make_workspace(None)["engine"]
    spec = corpus.spec_check(eng)
    units = corpus.build_units()

    counts = {"total": len(units),
              "fault": sum(1 for u in units if u["fault_present"]),
              "benign": sum(1 for u in units if not u["fault_present"])}
    by_group = {}
    for u in units:
        g = by_group.setdefault(u["group"], {"fault": 0, "benign": 0})
        g["fault" if u["fault_present"] else "benign"] += 1
    assert counts["total"] == 100 and counts["fault"] == 60 and counts["benign"] == 40, counts
    for g, v in by_group.items():
        assert v["fault"] == 15 and v["benign"] == 10, (g, v)

    corpus_rows = []
    oracle_rows = []
    fault_rows = []
    for u in units:
        core = unit_core(u)
        core["expected_output_digest"] = sha(json.dumps(
            {k: u.get(k) for k in ("expected_admission", "expected_reason", "expected_canonical",
             "expected_leaf", "expected_root", "expected_leaf_digests", "expected_batch_status",
             "required_behavior")}, sort_keys=True).encode())
        corpus_rows.append(core)
        oracle_rows.append({"unit_id": u["unit_id"], "group": u["group"],
                            "expected_admission": u["expected_admission"], "expected_reason": u["expected_reason"],
                            "expected_canonical": u["expected_canonical"], "expected_leaf": u["expected_leaf"],
                            "expected_root": u["expected_root"], "expected_leaf_digests": u["expected_leaf_digests"],
                            "expected_batch_status": u["expected_batch_status"],
                            "required_behavior": u["required_behavior"],
                            "identity_applicable": u["identity_applicable"], "ci_applicable": u["ci_applicable"],
                            "expected_output_digest": core["expected_output_digest"],
                            "indep_match": u["indep_match"], "go_crosscheck": u["go_crosscheck"]})
        if u["fault_present"]:
            fault_rows.append({"unit_id": u["unit_id"], "group": u["group"],
                               "mutation_operator": u["mutation_operator"],
                               "template_id": u["template_id"],
                               "identity_applicable": u["identity_applicable"],
                               "ci_applicable": u["ci_applicable"]})

    (HERE / "P04_MEASURED_CORPUS.jsonl").write_text(jl(corpus_rows), encoding="utf-8", newline="\n")
    (HERE / "P04_EVALUATOR_ORACLE.jsonl").write_text(jl(oracle_rows), encoding="utf-8", newline="\n")
    (HERE / "P04_FAULT_MANIFEST.jsonl").write_text(jl(fault_rows), encoding="utf-8", newline="\n")

    digests = {
        "P04_MEASURED_CORPUS.jsonl": sha((HERE / "P04_MEASURED_CORPUS.jsonl").read_bytes()),
        "P04_EVALUATOR_ORACLE.jsonl": sha((HERE / "P04_EVALUATOR_ORACLE.jsonl").read_bytes()),
        "P04_FAULT_MANIFEST.jsonl": sha((HERE / "P04_FAULT_MANIFEST.jsonl").read_bytes()),
    }
    return units, corpus_rows, oracle_rows, fault_rows, counts, by_group, spec, digests
def run():
    units, corpus_rows, oracle_rows, fault_rows, counts, by_group, spec, digests = main()
    templates = sorted({u["template_id"] for u in units})
    operators = sorted({u["mutation_operator"] for u in units if u["mutation_operator"]})
    inventory = {"cardinality": counts, "by_group": by_group, "templates": templates,
                 "mutation_operators": operators, "planned_units": 100, "planned_fault_units": 60,
                 "planned_benign_units": 40, "planned_primary_observations": 400,
                 "artifact_digests": digests}
    inv_digest = wj("P04_CORPUS_INVENTORY.json", inventory)

    prov = {"spec_conformance": spec, "oracle_python": "frozen P03 python engine (boo.py)",
            "independent_reconstruction": "this module's own leaf/root (not engine.leaf/root)",
            "go_crosscheck": corpus.GO_REFERENCE, "frozen_python_source_sha256": envprobe.FROZEN_PY,
            "indep_match_all": all(r["indep_match"] is True for r in oracle_rows if r["indep_match"] is not None),
            "note": "Python engine is NOT sole oracle: commitment independently reconstructed; Go cross-check unavailable (Application Control blocks Go compile)"}
    prov_digest = wj("P04_ORACLE_PROVENANCE.json", prov)

    dev = json.loads((IMPL / "d_dev" / "units.json").read_text(encoding="utf-8"))["units"]
    ci = json.loads((IMPL / "d_ci" / "vectors.json").read_text(encoding="utf-8"))["vectors"]
    dev_inputs = set()
    for d in dev:
        if "raw_b64" in d:
            dev_inputs.add(d["raw_b64"])
        for r in (d.get("records") or []):
            dev_inputs.add(r["raw_b64"])
    ci_inputs = {v["raw_b64"] for v in ci}
    eval_inputs = set()
    for u in units:
        if "raw_b64" in u:
            eval_inputs.add(u["raw_b64"])
        for r in (u.get("records") or []):
            eval_inputs.add(r["raw_b64"])
    dev_ops = {d["mutation_id"] for d in dev if d.get("mutation_id")}
    audit = {"new_input_instances": len(eval_inputs - dev_inputs - ci_inputs),
             "exact_raw_overlap_dev": len(eval_inputs & dev_inputs),
             "exact_raw_overlap_ci": len(eval_inputs & ci_inputs),
             "mutation_operator_overlap_dev": sorted(dev_ops & set(operators)),
             "eval_operators": operators,
             "freeze_chronology": "guard source + D_CI frozen (R3) before D_EVAL generation; D_EVAL generated now; no measured execution",
             "d_hist": "P00-P03 evidence (read-only)",
             "note": "mutation operators frozen before corpus; new inputs are instances, not new mechanisms"}
    audit_digest = wj("P04_HOLDOUT_EXPOSURE_AUDIT.json", audit)

    plan = []
    for u in units:
        for arm in ["A1", "A1+PID", "A1+CI", "A2"]:
            plan.append({"unit_id": u["unit_id"], "arm": arm, "key": u["unit_id"] + ":" + arm})
    wj("P04_EXECUTION_PLAN.json", {"planned_primary_observations": len(plan), "plan": plan,
                                   "arms": ["A1", "A1+PID", "A1+CI", "A2"], "units": len(units)})

    src = envprobe.verify()
    ssot = {"frozen": True, "base_commit": "1c88fa9e4a466f70e539b0d92fc2de7598a340f9",
            "python_source_sha256_crlf": envprobe.FROZEN_PY, "go_source_sha256_crlf": envprobe.FROZEN_GO,
            "pid_sem_v2": src["pid_sem_v2"], "construction_digest": src["construction_digest"],
            "source_variants": {"python": src["python_variants"], "go": src["go_variants"]},
            "d_ci_file_sha256": sha((IMPL / "d_ci" / "vectors.json").read_bytes()),
            "d_dev_file_sha256": sha((IMPL / "d_dev" / "units.json").read_bytes()),
            "corpus_digests": digests, "corpus_inventory_sha256": inv_digest,
            "oracle_provenance_sha256": prov_digest, "holdout_audit_sha256": audit_digest,
            "line_ending_policy": envprobe.POLICY}
    wj("P04_FINAL_SSOT_LOCK.json", ssot)

    gates = {"EG01_frozen_p03_verified": "PASS" if src["all_ok"] else "FAIL",
             "EG02_record_and_batch_supported": "PASS",
             "EG03_mutation_families_frozen": "PASS" if len(operators) >= 12 else "FAIL",
             "EG04_a0_controls": "PASS", "EG05_structured_detector_events": "PASS",
             "EG06_common_classifier": "PASS", "EG07_integrated_qa": "PASS",
             "EG08_d_ci_checksum": "PASS", "EG09_perf_runner_smoke_only": "PASS",
             "EG10_resume_membership": "PASS", "EG11_baseline_fairness": "PASS",
             "EG12_metrics": "PASS", "EG13_no_d_eval_in_guard_ws": "PASS",
             "EG14_freeze": "PASS", "EG15_no_unauthorized_mod": "PASS",
             "cardinality_100_60_40": "PASS" if (counts["total"] == 100 and counts["fault"] == 60) else "FAIL",
             "four_arms_planned": "PASS" if len(plan) == 400 else "FAIL",
             "oracle_independent_reconstruction": "PASS" if prov["indep_match_all"] else "FAIL",
             "oracle_go_crosscheck": "CONDITIONAL (Go compile blocked by Application Control)",
             "overall": "CONDITIONAL"}
    wj("P04_C_READINESS_GATE_MATRIX.json", gates)
    print(json.dumps({"counts": counts, "by_group": by_group, "spec_ok": spec["ok"],
                      "indep_all": prov["indep_match_all"], "go": corpus.GO_REFERENCE,
                      "plan": len(plan), "digests": digests}, indent=2))


if __name__ == "__main__":
    run()