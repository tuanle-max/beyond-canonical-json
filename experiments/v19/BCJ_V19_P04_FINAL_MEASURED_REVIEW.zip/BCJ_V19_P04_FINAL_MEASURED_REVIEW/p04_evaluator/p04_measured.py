"""P04-D measured execution + P04-F independent aggregation (frozen corpus, 400 observations).

Guards receive only the execution-input projection. Raw observations are persisted immediately and
bound to run_id + execution-lock + plan digests. Aggregation recomputes from raw observations.
"""
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p04_implementation"
RESULTS = V19 / "results" / "P04"
RESULTS.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(IMPL))

import aggregate
import arms
import engine_adapter as ea
import guards
import mutations
import runner


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load_revised():
    return [json.loads(l) for l in (HERE / "P04_EVALUATOR_ORACLE.R4A.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]


def project(u):
    keep = {k: u.get(k) for k in ("unit_id", "unit_type", "record_id", "raw_b64", "records",
                                  "expected_ids", "mutation_operator")}
    keep["evaluation_unit_id"] = u["unit_id"]
    return keep


def binding(units):
    lock = json.loads((HERE / "P04_FINAL_EXECUTION_LOCK.json").read_text(encoding="utf-8"))
    keys = ["%s:%s" % (u["unit_id"], a) for u in units for a in arms.PRIMARY_ARMS]
    b = {"execution_lock_digest": sha((HERE / "P04_FINAL_EXECUTION_LOCK.json").read_bytes()),
         "corpus_digest": sha((HERE / "P04_MEASURED_CORPUS.R4A.jsonl").read_bytes()),
         "oracle_digest": sha((HERE / "P04_EVALUATOR_ORACLE.R4A.jsonl").read_bytes()),
         "guard_digest": lock["production_source"].get("guards.py"),
         "mutation_inventory_digest": lock["mutation_inventory_sha256"],
         "config_digest": sha(json.dumps(lock["runtime_config"], sort_keys=True).encode()),
         "plan_digest": sha(json.dumps(sorted(keys), sort_keys=True).encode())}
    return b, "p04d:" + sha(json.dumps(b, sort_keys=True).encode())[:16]


def execute():
    units = load_revised()
    b, run_id = binding(units)
    (HERE / "P04D_RUN_METADATA.json").write_text(
        json.dumps({"run_id": run_id, **b, "units": len(units), "arms": arms.PRIMARY_ARMS}, indent=2) + "\n",
        encoding="utf-8", newline="\n")
    ci = json.loads((IMPL / "d_ci" / "vectors.json").read_text(encoding="utf-8"))["vectors"]
    gctx = {"identity": guards.IdentityGuard(ea.PID_SEM_V2, ea.CONSTRUCTION_DIGEST), "ci": guards.CIGuard(ci)}
    plan = [(u, a) for u in units for a in arms.PRIMARY_ARMS]
    out = RESULTS / "P04_MEASURED_RAW.jsonl"
    if out.exists():
        out.unlink()
    r = runner.Runner(str(out), run_id, plan, key_fn=lambda it: it[0]["unit_id"] + ":" + it[1],
                      run_meta={"binding": b}, timeout_s=120)

    def run_fn(item):
        u, a = item
        ws = arms.make_workspace(u["mutation_operator"])
        return arms.run_unit(a, project(u), ws, gctx, run_id=run_id)

    status = r.run(run_fn)
    return units, b, run_id, status, out
def aggregate_and_tables(units, b, run_id, status, out):
    raw = [json.loads(l) for l in out.read_text(encoding="utf-8").splitlines() if l.strip()]
    umap = {u["unit_id"]: u for u in units}
    agg = aggregate.summary(raw, umap)
    agg["run_status"] = status
    agg["run_binding"] = b
    (HERE / "P04_F_AGGREGATION.json").write_text(json.dumps(agg, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    pa = agg["paired_A1_vs_A2"]
    (HERE / "P04_PAIRED_COMPARISON.csv").write_text(
        "cell,count\nboth_correct,%d\nA1_only_correct,%d\nA2_only_correct,%d\nboth_incorrect,%d\npaired_effect,%s\nN,%d\n"
        % (pa["both_correct"], pa["A1_only_correct"], pa["A2_only_correct"], pa["both_incorrect"],
           str(pa["paired_effect"]), pa["N"]), encoding="utf-8", newline="\n")
    idc, cic = agg["identity_confusion"], agg["ci_confusion"]
    (HERE / "P04_CONFUSION_MATRICES.csv").write_text(
        "detector,TP,FP,TN,FN,recall,fpr,precision,f1\n"
        "identity,%d,%d,%d,%d,%s,%s,%s,%s\n"
        "ci-regression,%d,%d,%d,%d,%s,%s,%s,%s\n"
        % (idc["TP"], idc["FP"], idc["TN"], idc["FN"], idc["recall"], idc["fpr"], idc["precision"], idc["f1"],
           cic["TP"], cic["FP"], cic["TN"], cic["FN"], cic["recall"], cic["fpr"], cic["precision"], cic["f1"]),
        encoding="utf-8", newline="\n")
    # per-arm per-family correctness (from raw + classify)
    per = {}
    for u in units:
        g = u["group"]
        for a in arms.PRIMARY_ARMS:
            per.setdefault(a, {}).setdefault(g, {"correct": 0, "n": 0})
    by = {}
    for o in raw:
        by[(o["evaluation_unit_id"], o["arm"])] = o
    for u in units:
        for a in arms.PRIMARY_ARMS:
            o = by.get((u["unit_id"], a))
            if o is None:
                continue
            c = aggregate.classify(u, o)["correct"]
            per[a][u["group"]]["n"] += 1
            if c is True:
                per[a][u["group"]]["correct"] += 1
    # per-arm overall correctness
    overall = {}
    for a in arms.PRIMARY_ARMS:
        tot = sum(v["n"] for v in per[a].values())
        cor = sum(v["correct"] for v in per[a].values())
        overall[a] = {"correct": cor, "n": tot, "value": aggregate._ratio(cor, tot)}
    # write figure data
    frows = ["arm,group,n,correct,rate"]
    for a in arms.PRIMARY_ARMS:
        for g in ["G1", "G2", "G3", "G4"]:
            v = per[a][g]
            frows.append("%s,%s,%d,%d,%s" % (a, g, v["n"], v["correct"], aggregate._ratio(v["correct"], v["n"])))
    (HERE / "P04_FIGURE_DATA.csv").write_text("\n".join(frows) + "\n", encoding="utf-8", newline="\n")

    # TeX tables
    tex = ["% P04 measured tables (auto-generated)",
           "\\begin{table}[t]\\centering\\caption{Per-arm common correctness}\\begin{tabular}{lrr}\\toprule",
           "arm & correct & n \\\\\\midrule"]
    for a in arms.PRIMARY_ARMS:
        tex.append("%s & %d & %d \\\\" % (a, overall[a]["correct"], overall[a]["n"]))
    tex += ["\\bottomrule\\end{tabular}\\end{table}", "",
            "\\begin{table}[t]\\centering\\caption{Detector confusion}\\begin{tabular}{lrrrr}\\toprule",
            "detector & TP & FP & FN & TN \\\\\\midrule",
            "identity & %d & %d & %d & %d \\\\" % (idc["TP"], idc["FP"], idc["FN"], idc["TN"]),
            "ci-regression & %d & %d & %d & %d \\\\" % (cic["TP"], cic["FP"], cic["FN"], cic["TN"]),
            "\\bottomrule\\end{tabular}\\end{table}", "",
            "\\begin{table}[t]\\centering\\caption{Paired A1 vs A2}\\begin{tabular}{lr}\\toprule",
            "cell & count \\\\\\midrule",
            "both correct & %d \\\\" % pa["both_correct"],
            "A1 only correct & %d \\\\" % pa["A1_only_correct"],
            "A2 only correct & %d \\\\" % pa["A2_only_correct"],
            "both incorrect & %d \\\\" % pa["both_incorrect"],
            "paired effect & %s \\\\" % str(pa["paired_effect"]),
            "\\bottomrule\\end{tabular}\\end{table}"]
    (HERE / "P04_TABLES.tex").write_text("\n".join(tex) + "\n", encoding="utf-8", newline="\n")

    claims = ["claim,evidence,limitation"]
    claims.append("A2 improves paired end-to-end correctness vs A1,\"A2_only=%d, A1_only=%d, effect=%s\"" % (pa["A2_only_correct"], pa["A1_only_correct"], pa["paired_effect"]))
    claims.append("Identity guard detects manifest-visible identity faults,\"identity TP=%d FP=%d\"" % (idc["TP"], idc["FP"]))
    claims.append("CI guard detects CI-exercised regressions,\"ci TP=%d FP=%d\"" % (cic["TP"], cic["FP"]))
    claims.append("Benign service preserved,\"M11 per-arm\"")
    (HERE / "P04_SCIENTIFIC_CLAIM_MATRIX.csv").write_text("\n".join(claims) + "\n", encoding="utf-8", newline="\n")
    return raw, umap, agg, per, overall
def narrative(units, raw, agg, per, overall):
    pa = agg["paired_A1_vs_A2"]
    idc, cic = agg["identity_confusion"], agg["ci_confusion"]
    m11 = agg["M11_benign_service"]
    m10 = agg["M10_unsafe_release"]
    lines = ["# P04 Results Narrative (measured: 100 units x 4 arms = 400 observations)", "",
             "RQ: incremental assurance of A2 (identity + CI guards) beyond the identical typed-normalization baseline A1.", "",
             "## Common end-to-end correctness (per arm)"]
    for a in arms.PRIMARY_ARMS:
        lines.append("- %s: %d/%d correct (%.4f)" % (a, overall[a]["correct"], overall[a]["n"], overall[a]["value"] or 0))
    lines += ["", "## Paired A1 vs A2 (N=%d)" % pa["N"],
              "- both_correct=%d, A1_only=%d, A2_only=%d, both_incorrect=%d, paired_effect=%s"
              % (pa["both_correct"], pa["A1_only_correct"], pa["A2_only_correct"], pa["both_incorrect"], pa["paired_effect"]),
              "", "## Detectors",
              "- identity: TP=%d FP=%d FN=%d TN=%d recall=%s fpr=%s" % (idc["TP"], idc["FP"], idc["FN"], idc["TN"], idc["recall"], idc["fpr"]),
              "- ci-regression: TP=%d FP=%d FN=%d TN=%d recall=%s fpr=%s" % (cic["TP"], cic["FP"], cic["FN"], cic["TN"], cic["recall"], cic["fpr"]),
              "", "## Service / safety",
              "- unsafe_release (M10): " + ", ".join("%s=%d/%d" % (a, m10[a]["num"], m10[a]["den"]) for a in arms.PRIMARY_ARMS),
              "- benign_service (M11): " + ", ".join("%s=%s/%s" % (a, m11[a]["num"], m11[a]["den"]) for a in arms.PRIMARY_ARMS),
              "", "## Interpretation",
              "A2 provides additional assurance beyond A1 only on faults a guard can see: manifest-visible identity mismatch",
              "(identity guard) and CI-exercised behavioral regressions (CI guard). Hidden executable drift outside CI coverage",
              "and identity-invisible construction drift are shared misses. Manifest identity mismatch is caught because the",
              "active identity is recomputed from manifest content; hidden drift under an unchanged declared identity is not",
              "detectable by identity comparison, and a finite CI suite only catches exercised regressions. No authenticated",
              "checkpoint verification or universal semantic correctness is claimed."]
    (HERE / "P04_RESULTS_NARRATIVE.md").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    threats = ["# P04 Threats to Validity", "",
               "- Purposive, template-correlated synthetic corpus; no production sampling.",
               "- Same-team Python+Go cross-check; NOT independent third-party replication.",
               "- Finite CI vector set: regressions outside coverage are legitimate misses.",
               "- Mutation operators frozen before corpus; new inputs are instances, not unseen mechanisms.",
               "- No authenticated checkpoint verification (P05 scope).",
               "- Purposive design: no population failure-probability / grouped-independent inference.",
               "- Go cross-check executed in Docker Linux; Windows Go compile blocked by Application Control (environmental)."]
    (HERE / "P04_THREATS_TO_VALIDITY.md").write_text("\n".join(threats) + "\n", encoding="utf-8", newline="\n")
    rr = ["# P04 Reviewer Response (measured)",
          "Q: Does A2 add assurance over a same-contract typed pipeline?",
          "A: On applicable faults yes: paired A2_only=%d vs A1_only=%d (effect %s)." % (pa["A2_only_correct"], pa["A1_only_correct"], pa["paired_effect"]),
          "Q: What remains undetected?", "A: Hidden executable drift outside CI coverage and identity-invisible construction drift (shared misses).",
          "Q: Is this production-representative?", "A: No. Purposive synthetic corpus; no prevalence or unseen-mechanism generalization claimed."]
    (HERE / "P04_REVIEWER_RESPONSE.md").write_text("\n".join(rr) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    units, b, run_id, status, out = execute()
    raw, umap, agg, per, overall = aggregate_and_tables(units, b, run_id, status, out)
    narrative(units, raw, agg, per, overall)
    pa = agg["paired_A1_vs_A2"]
    print(json.dumps({"run_status": status["status"], "observations": len(raw), "run_id": run_id,
                      "overall": {a: "%d/%d" % (overall[a]["correct"], overall[a]["n"]) for a in overall},
                      "paired": pa,
                      "identity": {k: agg["identity_confusion"][k] for k in ("TP", "FP", "FN", "TN")},
                      "ci": {k: agg["ci_confusion"][k] for k in ("TP", "FP", "FN", "TN")},
                      "fairness_ok": agg["fairness"]["ok"]}, indent=2))