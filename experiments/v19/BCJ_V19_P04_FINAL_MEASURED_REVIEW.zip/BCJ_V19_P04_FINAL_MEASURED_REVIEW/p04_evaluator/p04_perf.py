"""P04-E measured performance: frozen plan (100/1000/5000 x 4 arms x [3 warmup + 10 measured]).
Persists every repetition (no silent discards). tracemalloc = Python-traced peak ALLOCATED bytes."""
import csv
import hashlib
import json
import pathlib
import statistics
import sys
import time
import tracemalloc

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p04_implementation"
RESULTS = V19 / "results" / "P04"
sys.path.insert(0, str(IMPL))

import engine_adapter as ea
import guards
import perf

_ENG = ea.load_engine()
_PID = ea.PID_SEM_V2
_CD = ea.CONSTRUCTION_DIGEST
_SEM, _CON = ea.load_manifests()
_CI = json.loads((IMPL / "d_ci" / "vectors.json").read_text(encoding="utf-8"))["vectors"]
_IG = guards.IdentityGuard(_PID, _CD)
_CG = guards.CIGuard(_CI)


def gen_records(n):
    import random
    rng = random.Random(42)
    out = []
    for i in range(n):
        rec = {"event_id": "perf-%06d" % i, "timestamp": "2026-%02d-%02dT%02d:%02d:00Z"
               % (rng.randint(1, 12), rng.randint(1, 28), rng.randint(0, 23), rng.randint(0, 59)),
               "amount": "%d.%02d" % (rng.randint(1, 9000), rng.randint(0, 99)),
               "currency": "USD", "scale": 2, "beneficiary_code": "b%d" % i}
        out.append(json.dumps(rec).encode())
    return out


def process(recs, arm):
    leaves = []
    for raw in recs:
        res = _ENG.adjudicate(raw)
        if res["decision"] == "ACCEPT":
            leaves.append(_ENG.leaf(bytes.fromhex(res["canonical_hex"]), _PID, _CD))
    root, _ = _ENG.root(leaves)
    if arm in ("A1+PID", "A2"):
        _IG.check(_SEM, _CON)
    if arm in ("A1+CI", "A2"):
        _CG.run(_ENG, "perf", "perf", "build:perf", "deploy:perf")
    return root


def measure(recs, arm):
    tracemalloc.start()
    t0 = time.perf_counter_ns()
    try:
        process(recs, arm)
    finally:
        t1 = time.perf_counter_ns()
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    return t1 - t0, peak


def main():
    plan = perf.plan()
    workloads = {n: gen_records(n) for n in perf.BATCH_SIZES}
    raw_rows = []
    for p in plan:
        dur, peak = measure(workloads[p["batch_size"]], p["arm"])
        raw_rows.append({"arm": p["arm"], "batch_size": p["batch_size"], "repetition": p["repetition"],
                         "warmup": p["warmup"], "duration_ns": dur,
                         "python_traced_peak_alloc_bytes": peak,
                         "process_startup_included": False})
    with open(RESULTS / "P04_PERFORMANCE_RAW.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(raw_rows[0].keys()))
        w.writeheader(); w.writerows(raw_rows)
    summ = []
    for arm in perf.ARMS:
        for size in perf.BATCH_SIZES:
            ds = [r["duration_ns"] for r in raw_rows if r["arm"] == arm and r["batch_size"] == size and not r["warmup"]]
            ps = [r["python_traced_peak_alloc_bytes"] for r in raw_rows if r["arm"] == arm and r["batch_size"] == size and not r["warmup"]]
            ds_sorted = sorted(ds)
            q1 = statistics.quantiles(ds, n=4)[0] if len(ds) > 1 else ds[0]
            q3 = statistics.quantiles(ds, n=4)[2] if len(ds) > 1 else ds[0]
            summ.append({"arm": arm, "batch_size": size, "measured_n": len(ds),
                         "median_ns": int(statistics.median(ds)), "q1_ns": int(q1), "q3_ns": int(q3),
                         "median_python_traced_peak_alloc_bytes": int(statistics.median(ps))})
    with open(RESULTS / "P04_PERFORMANCE_SUMMARY.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(summ[0].keys()))
        w.writeheader(); w.writerows(summ)
    meta = {"plan_total": len(plan), "measured": sum(1 for p in plan if not p["warmup"]),
            "warmup": sum(1 for p in plan if p["warmup"]), "seed": perf.SEED,
            "memory_metric": "python_traced_peak_alloc_bytes (NOT process RSS)"}
    (RESULTS / "P04_PERFORMANCE_META.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"raw_rows": len(raw_rows), **meta,
                      "summary": summ}, indent=2))


if __name__ == "__main__":
    main()