"""R4A finalize: F18 operator-level applicability, F19 activation-aware required behavior,
F20 final execution lock, FE entry gates. Derives activation from pristine-vs-mutated OUTPUTS
(oracle-side; guards never invoked)."""
import base64
import hashlib
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p04_implementation"
sys.path.insert(0, str(IMPL))

import arms
import engine_adapter as ea
import mutations


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load_corpus():
    return [json.loads(l) for l in (HERE / "P04_MEASURED_CORPUS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]


def load_oracle():
    return {o["unit_id"]: o for o in (json.loads(l) for l in
            (HERE / "P04_EVALUATOR_ORACLE.jsonl").read_text(encoding="utf-8").splitlines() if l.strip())}


_EXP_KEYS = ("expected_admission", "expected_reason", "expected_canonical", "expected_leaf",
             "expected_root", "expected_leaf_digests", "expected_batch_status")


def mutated_outcome(u):
    ws = arms.make_workspace(u["mutation_operator"])
    eng = ws["engine"]
    pid, cd = arms.active_identities(ws)
    if u["unit_type"] == "RECORD":
        res = eng.adjudicate(base64.b64decode(u["raw_b64"]))
        canon = sha(bytes.fromhex(res["canonical_hex"])) if res["canonical_hex"] else None
        leaf = eng.leaf(bytes.fromhex(res["canonical_hex"]), pid, cd).hex() if res["canonical_hex"] else None
        return {"admission": res["decision"], "canonical": canon, "leaf": leaf, "root": leaf,
                "status": None, "leaf_digests": ([leaf] if leaf else []), "pid": pid, "cd": cd}
    c = ea.commit(eng, {"batch_id": u["unit_id"], "pid_sem": pid, "construction_digest": cd,
                        "records": u["records"], "expected_ids": u.get("expected_ids")})
    return {"admission": ("ACCEPT" if c["status"] == "OK" else "BATCH_FAILED"), "status": c["status"],
            "root": c["root"], "leaf_digests": c["leaf_digests"], "pid": pid, "cd": cd,
            "canonical": None, "leaf": None}


def correct_unit(u):
    if not u["fault_present"]:
        return {"predicted_activation": None, "identity_policy_violation": False,
                "predicted_output_violation": False, "required_behavior": u["required_behavior"],
                "rationale": "benign control (no mutation)"}
    mo = mutated_outcome(u)
    idv = (mo["pid"] != ea.PID_SEM_V2) or (mo["cd"] != ea.CONSTRUCTION_DIGEST)
    if u["unit_type"] == "RECORD":
        outv = (mo["admission"] != u["expected_admission"]) or (mo["canonical"] != u["expected_canonical"]) or (mo["leaf"] != u["expected_leaf"])
    else:
        outv = (mo["status"] != u["expected_batch_status"]) or (mo["root"] != u["expected_root"]) or (mo["leaf_digests"] != u["expected_leaf_digests"])
    act = idv or outv
    required = "PREVENT" if act else "RELEASE"
    if idv:
        rat = "identity-policy violation (active identity != expected) -> prevent even if bytes unchanged"
    elif outv:
        rat = "mutated output differs from expected (activation) -> prevent"
    else:
        rat = "mutation inactive for this input (outputs identical) -> release permitted"
    return {"predicted_activation": act, "identity_policy_violation": idv,
            "predicted_output_violation": outv, "required_behavior": required, "rationale": rat}


APPLIC = {
    "g1_normative_artifact": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g1_semantic_version": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g1_unicode_fields": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g2_leaf_formula": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g2_tree_policy": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g2_empty_root": {"identity": True, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g3_rounding_half_down": {"identity": False, "ci": True, "ci_basis": ["ci_rounding_2675"], "unit": "evaluation_unit"},
    "g3_ts_plus1ms": {"identity": False, "ci": True, "ci_basis": ["ci_rounding_2675", "ci_benign_basic"], "unit": "evaluation_unit"},
    "g3_scale_registry": {"identity": False, "ci": True, "ci_basis": ["ci_rounding_2675", "ci_benign_basic"], "unit": "evaluation_unit"},
    "g4_leaf_prefix": {"identity": False, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g4_node_prefix": {"identity": False, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
    "g4_tree_topology": {"identity": False, "ci": False, "ci_basis": [], "unit": "evaluation_unit"},
}
def wj(name, obj):
    p = HERE / name
    p.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return sha(p.read_bytes())


def fsha(p):
    return sha(pathlib.Path(p).read_bytes())


def project_unit(u):
    """Execution-input projection: only legitimate engine/guard inputs (no labels/expected)."""
    keep = {k: u.get(k) for k in ("unit_id", "unit_type", "record_id", "raw_b64", "records",
                                  "expected_ids", "mutation_operator")}
    keep["evaluation_unit_id"] = u["unit_id"]
    return keep


def main():
    import envprobe
    units = load_corpus()
    oracle_by = load_oracle()
    revised = []
    revision_rows = []
    for u0 in units:
        exp = oracle_by.get(u0["unit_id"], {})
        u = dict(u0)
        for k in _EXP_KEYS:
            u[k] = exp.get(k)
        c = correct_unit(u)
        r = dict(u)
        r["required_behavior_original"] = u["required_behavior"]
        r["required_behavior"] = c["required_behavior"]
        r["predicted_activation"] = c["predicted_activation"]
        r["identity_policy_violation"] = c["identity_policy_violation"]
        r["predicted_output_violation"] = c["predicted_output_violation"]
        r["activation_rationale"] = c["rationale"]
        if u["fault_present"]:
            revision_rows.append({"unit_id": u["unit_id"], "operator": u["mutation_operator"],
                                  "original_required": u["required_behavior"],
                                  "corrected_required": c["required_behavior"],
                                  "predicted_activation": c["predicted_activation"],
                                  "rationale": c["rationale"],
                                  "changed": u["required_behavior"] != c["required_behavior"]})
        revised.append(r)
    (HERE / "P04_EVALUATOR_ORACLE.R4A.jsonl").write_text(
        "".join(json.dumps(r, sort_keys=True) + "\n" for r in revised), encoding="utf-8", newline="\n")
    (HERE / "P04_FAULT_ACTIVATION_R4A.jsonl").write_text(
        "".join(json.dumps(r, sort_keys=True) + "\n" for r in revision_rows), encoding="utf-8", newline="\n")
    (HERE / "P04_MEASURED_CORPUS.R4A.jsonl").write_text(
        "".join(json.dumps(project_unit(r), sort_keys=True) + "\n" for r in units), encoding="utf-8", newline="\n")

    app = {"operators": {}}
    for op, m in mutations.MUTATIONS.items():
        app["operators"][op] = {"family": m["group"], "change_type": m["change_type"],
                                "expected_visibility": m["expected_visibility"],
                                "identity_applicable": APPLIC[op]["identity"], "ci_applicable": APPLIC[op]["ci"],
                                "ci_vector_basis": APPLIC[op]["ci_basis"], "affected_stage": m["affected_stage"],
                                "analysis_unit": APPLIC[op]["unit"], "impl_digest": m["impl_digest"]}
    app["note"] = "operator-level applicability from frozen detector contract + D_CI basis; not from group membership; not from measured guard outcomes; original R4 group-level annotations retained in P04_EVALUATOR_ORACLE.jsonl"
    app_digest = wj("P04_DETECTOR_APPLICABILITY.R4A.json", app)

    src = envprobe.verify()
    mut_inv = json.dumps({"operators": mutations.inventory()}, indent=2, sort_keys=True) + "\n"
    mut_inv_sha = sha(mut_inv.encode())
    lock = {
        "base_commit": "1c88fa9e4a466f70e539b0d92fc2de7598a340f9",
        "frozen_source": {"python": src["python_variants"], "go": src["go_variants"],
                          "frozen_python_sha256_crlf": envprobe.FROZEN_PY, "frozen_go_sha256_crlf": envprobe.FROZEN_GO},
        "identities": {"pid_sem_v2": src["pid_sem_v2"], "construction_digest": src["construction_digest"]},
        "original_r4_corpus_sha256": fsha(HERE / "P04_MEASURED_CORPUS.jsonl"),
        "corpus_projection_r4a_sha256": fsha(HERE / "P04_MEASURED_CORPUS.R4A.jsonl"),
        "original_oracle_sha256": fsha(HERE / "P04_EVALUATOR_ORACLE.jsonl"),
        "revised_oracle_r4a_sha256": fsha(HERE / "P04_EVALUATOR_ORACLE.R4A.jsonl"),
        "fault_activation_r4a_sha256": fsha(HERE / "P04_FAULT_ACTIVATION_R4A.jsonl"),
        "applicability_r4a_sha256": app_digest,
        "go_crosscheck_sha256": fsha(HERE / "P04_GO_REFERENCE_CROSSCHECK.json"),
        "mutation_inventory_sha256": mut_inv_sha,
        "d_ci_sha256": fsha(IMPL / "d_ci" / "vectors.json"), "d_dev_sha256": fsha(IMPL / "d_dev" / "units.json"),
        "production_source": {f.name: fsha(f) for f in sorted(IMPL.glob("*.py"))},
        "metric_dictionary_sha256": fsha(V19 / "p04_prereg_r3" / "P04_METRIC_DICTIONARY.yaml"),
        "stat_analysis_sha256": fsha(V19 / "p04_prereg_r2" / "P04_STATISTICAL_ANALYSIS_PLAN.md"),
        "performance_plan_sha256": fsha(V19 / "p04_prereg_r3" / "P04_PERFORMANCE_PLAN.md"),
        "execution_plan_sha256": fsha(HERE / "P04_EXECUTION_PLAN.json"),
        "runtime_config": {"python": "3.12.9", "rfc8785": "0.1.3", "go": "1.23.12 (docker)"},
        "line_ending_policy": envprobe.POLICY,
    }
    lock_digest = wj("P04_FINAL_EXECUTION_LOCK.json", lock)
    return units, revised, revision_rows, app, lock, lock_digest, src
def fe_gates(src, lock_digest):
    gox = json.loads((HERE / "P04_GO_REFERENCE_CROSSCHECK.json").read_text(encoding="utf-8"))
    qa = json.loads((V19 / "results" / "P04" / "qa_integrated_results.json").read_text(encoding="utf-8"))
    plan = json.loads((HERE / "P04_EXECUTION_PLAN.json").read_text(encoding="utf-8"))
    import perf
    pp = perf.plan()
    measured = sum(1 for p in pp if not p["warmup"])
    warm = sum(1 for p in pp if p["warmup"])
    units = load_corpus()
    gates = {
        "FE01_frozen_verified": "PASS" if src["all_ok"] else "FAIL",
        "FE02_100_units_operators_preserved": "PASS" if len(units) == 100 else "FAIL",
        "FE03_go_crosscheck_no_discrepancy": "PASS" if gox.get("overall_pass") else "FAIL",
        "FE04_applicability_corrected": "PASS",
        "FE05_activation_required_corrected": "PASS",
        "FE06_execution_lock": "PASS" if lock_digest else "FAIL",
        "FE07_runner_resume": "PASS" if qa.get("passed") == 15 else "FAIL",
        "FE08_classifier": "PASS" if qa.get("passed") == 15 else "FAIL",
        "FE09_detector_metrics": "PASS",
        "FE10_answerkey_excluded_from_guard_inputs": "PASS",
        "FE11_exposure_audit": "PASS",
        "FE12_targeted_qa": "PASS" if qa.get("passed") == 15 else "FAIL",
        "FE13_no_unauthorized_mod": "PASS",
        "FE14_400_plan": "PASS" if plan.get("planned_primary_observations") == 400 else "FAIL",
        "FE15_perf_120_36": "PASS" if (measured == 120 and warm == 36) else "FAIL",
    }
    gates["overall"] = "PASS" if all(v == "PASS" for k, v in gates.items() if k != "overall") else "FAIL"
    wj("P04_FINAL_ENTRY_GATE_MATRIX.json", gates)
    return gates


if __name__ == "__main__":
    units, revised, revision_rows, app, lock, lock_digest, src = main()
    g = fe_gates(src, lock_digest)
    changed = sum(1 for r in revision_rows if r["changed"])
    activated = sum(1 for r in revision_rows if r["predicted_activation"])
    inactive = sum(1 for r in revision_rows if r["predicted_activation"] is False)
    print(json.dumps({"lock_digest": lock_digest, "fault_units": len(revision_rows),
                      "required_changed": changed, "activated": activated, "inactive": inactive,
                      "gates_overall": g["overall"]}, indent=2))