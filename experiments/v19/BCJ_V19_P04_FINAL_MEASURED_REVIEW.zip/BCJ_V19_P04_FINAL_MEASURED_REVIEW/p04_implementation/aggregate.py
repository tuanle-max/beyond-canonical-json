"""P04-B production aggregator: common correctness classifier (F12), metrics M01-M14,
surface = raw observations. Distinguishes normative rejection, guard prevention, crash,
timeout, and non-execution. Explicit N/A (never coerced to correct/incorrect)."""
from collections import defaultdict

REJECT_CATS = ("REJECT_MALFORMED", "REJECT_PROHIBITED")


def classify(unit, obs):
    """Return {correct: True|False|None, outcome_class, reason}. None => N/A."""
    rb = unit["required_behavior"]
    dec = obs.get("decision")
    released = obs.get("artifact_released")
    # 1) runtime error / timeout checked first (never success)
    if obs.get("runtime_error") or obs.get("timeout") or dec in ("INTERNAL_ERROR", "TIMEOUT"):
        return {"correct": False, "outcome_class": "ERROR",
                "reason": "runtime error/timeout is not success/detection/prevention"}
    if rb == "RELEASE":
        if dec != "ALLOW" or not released:
            return {"correct": False, "outcome_class": "BENIGN_NOT_RELEASED",
                    "reason": "expected release not achieved (decision=%s)" % dec}
        mism = []
        if unit.get("expected_admission") is not None and obs.get("admission_status") != unit["expected_admission"]:
            mism.append("admission")
        if unit.get("expected_canonical") is not None and obs.get("canonical_digest") != unit["expected_canonical"]:
            mism.append("canonical")
        if unit.get("expected_leaf") is not None and obs.get("leaf_digest") != unit["expected_leaf"]:
            mism.append("leaf")
        if unit.get("expected_root") is not None and obs.get("root_digest") != unit["expected_root"]:
            mism.append("root")
        if unit.get("expected_leaf_digests") is not None and obs.get("leaf_digests") != unit["expected_leaf_digests"]:
            mism.append("leaf_digests")
        if unit.get("expected_batch_status") is not None and obs.get("batch_status") != unit["expected_batch_status"]:
            mism.append("batch_status")
        if mism:
            return {"correct": False, "outcome_class": "RELEASE_MISMATCH",
                    "reason": "mismatch: " + ",".join(mism)}
        return {"correct": True, "outcome_class": "CORRECT_RELEASE", "reason": "released with expected outputs"}
    if rb == "PREVENT":
        if released:
            return {"correct": False, "outcome_class": "UNSAFE_RELEASE",
                    "reason": "artifact released although prevention required"}
        if dec in ("BLOCK", "QUARANTINE"):
            if obs.get("alarm_emitted"):
                return {"correct": True, "outcome_class": "GUARD_PREVENTED", "reason": "guard alarm blocked, no release"}
            if obs.get("admission_status") in REJECT_CATS:
                return {"correct": True, "outcome_class": "NORMATIVE_REJECTED", "reason": "admission rejected, no release"}
            return {"correct": False, "outcome_class": "BLOCK_NO_BASIS",
                    "reason": "block without alarm or normative rejection basis is not correct"}
        return {"correct": False, "outcome_class": "NOT_PREVENTED",
                "reason": "neither blocked nor released (decision=%s)" % dec}
    if rb in ("REJECT_VIA_ADMISSION", "ABSTAIN"):
        if released:
            return {"correct": False, "outcome_class": "UNSAFE_RELEASE", "reason": "invalid/underspecified input released"}
        adm = obs.get("admission_status")
        if adm in REJECT_CATS or adm == "ABSTAIN_UNDERSPECIFIED":
            if unit.get("expected_reason") and obs.get("admission_reason") != unit["expected_reason"]:
                return {"correct": False, "outcome_class": "REASON_MISMATCH",
                        "reason": "rejection/abstention reason mismatch"}
            cls = "NORMATIVE_REJECTION" if adm in REJECT_CATS else "CORRECT_ABSTENTION"
            return {"correct": True, "outcome_class": cls,
                    "reason": "correct normative " + ("rejection" if adm in REJECT_CATS else "abstention")}
        return {"correct": False, "outcome_class": "NOT_REJECTED", "reason": "input not rejected/abstained"}
    return {"correct": None, "outcome_class": "N_A", "reason": "no applicable outcome class"}


def annotate(observations, units):
    for o in observations:
        u = units.get(o["evaluation_unit_id"])
        if u is None:
            o["outcome_class"] = "MISSING_UNIT"
            continue
        r = classify(u, o)
        o["outcome_class"] = r["outcome_class"]
    return observations


def verify_fairness(observations):
    """All four primary arms must share identical inputs/identities/mutation/engine/config."""
    fields = ("input_digest", "batch_digest", "active_pid", "active_cd", "engine_digest", "mutation_instance_id")
    by_unit = defaultdict(dict)
    for o in observations:
        if o["arm"] in ("A1", "A1+PID", "A1+CI", "A2"):
            by_unit[o["evaluation_unit_id"]][o["arm"]] = o
    violations = []
    for uid, arms in by_unit.items():
        if set(arms) != {"A1", "A1+PID", "A1+CI", "A2"}:
            continue
        for f in fields:
            vals = {a: arms[a].get(f) for a in arms}
            if len({str(v) for v in vals.values()}) > 1:
                violations.append({"unit": uid, "field": f, "values": vals})
    return {"ok": len(violations) == 0, "violations": violations}
def _ratio(num, den):
    return None if den == 0 else num / den


def detector_confusion(observations, units, detector):
    seen = set()
    tp = fp = tn = fn = 0
    for o in observations:
        u = units.get(o["evaluation_unit_id"])
        if u is None:
            continue
        evs = [e for e in o.get("guard_events", [])
               if e.get("detector") == detector and e.get("executed")
               and e.get("guard_execution_id") not in seen]
        if not evs:
            continue
        ev = evs[0]
        seen.add(ev["guard_execution_id"])
        alarm = bool(ev.get("alarm_emitted"))
        fault = u.get("fault_present")
        applicable = u.get("identity_applicable") if detector == "identity" else u.get("ci_applicable")
        if fault and applicable:
            tp += 1 if alarm else 0
            fn += 0 if alarm else 1
        elif not fault:
            fp += 1 if alarm else 0
            tn += 0 if alarm else 1
    return {"detector": detector, "TP": tp, "FP": fp, "TN": tn, "FN": fn,
            "recall": _ratio(tp, tp + fn), "fpr": _ratio(fp, fp + tn),
            "precision": _ratio(tp, tp + fp), "f1": _ratio(2 * tp, 2 * tp + fp + fn)}


def paired(observations, units):
    a1 = {o["evaluation_unit_id"]: o for o in observations if o["arm"] == "A1"}
    a2 = {o["evaluation_unit_id"]: o for o in observations if o["arm"] == "A2"}
    cells = {"both_correct": 0, "A1_only_correct": 0, "A2_only_correct": 0, "both_incorrect": 0}
    n = 0
    missing = 0
    for uid, u in units.items():
        if uid not in a1 or uid not in a2:
            missing += 1
            continue
        c1 = classify(u, a1[uid])["correct"]
        c2 = classify(u, a2[uid])["correct"]
        if c1 is None or c2 is None:
            missing += 1
            continue
        n += 1
        if c1 and c2:
            cells["both_correct"] += 1
        elif c1 and not c2:
            cells["A1_only_correct"] += 1
        elif not c1 and c2:
            cells["A2_only_correct"] += 1
        else:
            cells["both_incorrect"] += 1
    effect = None if n == 0 else round((cells["A2_only_correct"] - cells["A1_only_correct"]) / n, 6)
    return {"N": n, "missing": missing, **cells, "paired_effect": effect}


def _arm_obs(observations, arm):
    return [o for o in observations if o["arm"] == arm]


def coverage(observations, units, arm):
    adm = [o for o in _arm_obs(observations, arm) if units[o["evaluation_unit_id"]].get("expected_admission") == "ACCEPT"]
    num = sum(1 for o in adm if o.get("admission_status") == "ACCEPT")
    return {"num": num, "den": len(adm), "value": _ratio(num, len(adm))}


def unsafe_admission(observations, units, arm):
    non = [o for o in _arm_obs(observations, arm) if units[o["evaluation_unit_id"]].get("required_behavior") == "REJECT_VIA_ADMISSION"]
    num = sum(1 for o in non if o.get("admission_status") == "ACCEPT")
    return {"num": num, "den": len(non), "value": _ratio(num, len(non))}


def false_non_admission(observations, units, arm):
    valid = [o for o in _arm_obs(observations, arm) if units[o["evaluation_unit_id"]].get("expected_admission") == "ACCEPT"]
    num = sum(1 for o in valid if o.get("admission_status") != "ACCEPT")
    return {"num": num, "den": len(valid), "value": _ratio(num, len(valid))}


def unsafe_release(observations, units, arm):
    obs = [o for o in _arm_obs(observations, arm) if units[o["evaluation_unit_id"]].get("required_behavior") == "PREVENT"]
    num = sum(1 for o in obs if o.get("artifact_released"))
    return {"num": num, "den": len(obs), "value": _ratio(num, len(obs))}


def benign_service(observations, units, arm):
    benign = [o for o in _arm_obs(observations, arm) if units[o["evaluation_unit_id"]].get("required_behavior") == "RELEASE"]
    num = sum(1 for o in benign if o.get("artifact_released") and o.get("decision") == "ALLOW")
    return {"num": num, "den": len(benign), "value": _ratio(num, len(benign))}
def stage_attribution(observations, units, arm):
    out = []
    for o in _arm_obs(observations, arm):
        u = units.get(o["evaluation_unit_id"])
        if u is None:
            continue
        stage = "NO_EFFECT"
        if u.get("expected_admission") is not None and o.get("admission_status") != u.get("expected_admission"):
            stage = "L0"
        elif u.get("expected_canonical") is not None and o.get("canonical_digest") != u.get("expected_canonical"):
            stage = "L3"
        elif u.get("expected_leaf") is not None and o.get("leaf_digest") != u.get("expected_leaf"):
            stage = "L5"
        elif u.get("expected_root") is not None and o.get("root_digest") != u.get("expected_root"):
            stage = "L7"
        out.append({"unit": o["evaluation_unit_id"], "stage": stage})
    return out


def summary(observations, units):
    annotate(observations, units)
    arms = ["A1", "A1+PID", "A1+CI", "A2"]
    return {
        "counts": {"observations": len(observations), "units": len(units),
                   "fault_units": sum(1 for u in units.values() if u.get("fault_present")),
                   "benign_units": sum(1 for u in units.values() if not u.get("fault_present"))},
        "fairness": verify_fairness(observations),
        "identity_confusion": detector_confusion(_arm_obs(observations, "A1+PID"), units, "identity"),
        "ci_confusion": detector_confusion(_arm_obs(observations, "A1+CI"), units, "ci-regression"),
        "paired_A1_vs_A2": paired(observations, units),
        "M01_coverage": {a: coverage(observations, units, a) for a in arms},
        "M02_unsafe_admission": {a: unsafe_admission(observations, units, a) for a in arms},
        "M03_false_non_admission": {a: false_non_admission(observations, units, a) for a in arms},
        "M10_unsafe_release": {a: unsafe_release(observations, units, a) for a in arms},
        "M11_benign_service": {a: benign_service(observations, units, a) for a in arms},
        "M04_equivalence": "N/A (no labelled pair cohort)",
        "M05_distinction": "N/A (no labelled pair cohort)",
        "M13_stage_attribution": {a: stage_attribution(observations, units, a) for a in arms},
        "M14_overhead": "N/A (no measured performance in this invocation)",
    }