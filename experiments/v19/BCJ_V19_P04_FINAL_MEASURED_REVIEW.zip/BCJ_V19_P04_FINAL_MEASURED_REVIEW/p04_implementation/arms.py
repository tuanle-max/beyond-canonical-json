"""P04-B arm orchestration (A0, A1, A1+PID, A1+CI, A2, N0, N1) with RECORD + BATCH units,
structured guard events, and a corrected A0 raw-JCS path.

Each arm processes the SAME mutated workspace (shared fault condition). A guard block records
downstream pipeline stages as NOT_EXECUTED (never fabricated outcomes).
"""
import base64
import copy
import hashlib
import json

import rfc8785

import engine_adapter as ea
import guards as guards_mod
import schema


def make_workspace(mutation_id=None):
    import mutations
    ws = {
        "engine": ea.load_engine(),
        "semantic_manifest": copy.deepcopy(ea.load_manifests()[0]),
        "construction_manifest": copy.deepcopy(ea.load_manifests()[1]),
        "mutation_id": None,
    }
    if mutation_id:
        mutations.apply_mutation(ws, mutation_id)
    return ws


def active_identities(ws):
    return ea.manifest_identity(ws["semantic_manifest"]), ea.manifest_identity(ws["construction_manifest"])


def engine_digest(ws):
    return hashlib.sha256(("engine:" + (ws.get("mutation_id") or "pristine")).encode()).hexdigest()


def _records(unit):
    if unit["unit_type"] == "BATCH":
        return unit["records"]
    return [{"record_id": unit.get("record_id", unit["evaluation_unit_id"]), "raw_b64": unit["raw_b64"]}]


def _digests(unit):
    recs = _records(unit)
    if unit["unit_type"] == "BATCH":
        desc = [{"record_id": r["record_id"], "raw_b64": r["raw_b64"]} for r in recs]
        batch_json = json.dumps(desc, sort_keys=True).encode()
        return hashlib.sha256(batch_json).hexdigest(), hashlib.sha256(batch_json).hexdigest()
    return hashlib.sha256(base64.b64decode(recs[0]["raw_b64"])).hexdigest(), None


def _a0(obs, raw):
    """Corrected A0: plain RFC-8785 JCS over the raw JSON domain (no K-v2 transform)."""
    def hook(pairs):
        d = {}
        for k, v in pairs:
            if k in d:
                raise ValueError("DUPLICATE_KEY")
            d[k] = v
        return d
    obs["downstream_executed"] = True
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError:
        obs["admission_status"] = "UNSUPPORTED"
        obs["decision"] = "NOT_APPLICABLE"
        obs["decision_reason"] = "A0 input not valid UTF-8"
        return obs
    try:
        obj = json.loads(text, object_pairs_hook=hook,
                         parse_constant=lambda c: (_ for _ in ()).throw(ValueError("CONST:" + c)))
    except ValueError as e:
        obs["admission_status"] = "REJECT_MALFORMED"
        obs["decision"] = "NOT_APPLICABLE"
        obs["decision_reason"] = "A0 malformed JSON: %s" % str(e)[:40]
        return obs
    try:
        canon = rfc8785.dumps(obj)
    except rfc8785.CanonicalizationError as e:
        obs["admission_status"] = "UNSUPPORTED"
        obs["decision"] = "NOT_APPLICABLE"
        obs["decision_reason"] = "A0 unsupported numeric/JSON domain: %s" % type(e).__name__
        return obs
    except Exception as e:  # programming error - distinct, not NOT_APPLICABLE
        obs["decision"] = "INTERNAL_ERROR"
        obs["runtime_error"] = True
        obs["decision_reason"] = "A0 programming error: %r" % (e,)
        return obs
    obs["admission_status"] = "ACCEPT"
    obs["canonical_digest"] = hashlib.sha256(canon).hexdigest()
    obs["canonical_bytes_hex"] = canon.hex()
    obs["decision"] = "ALLOW"
    obs["artifact_released"] = True
    obs["decision_reason"] = "A0 raw-JCS characterization (no semantic transform)"
    return obs
def run_unit(arm, unit, ws, guards_ctx, run_id=None):
    obs = schema.empty_observation(evaluation_unit_id=unit["evaluation_unit_id"],
                                   unit_type=unit["unit_type"], arm=arm, run_id=run_id,
                                   mutation_instance_id=ws.get("mutation_id"))
    inp, bd = _digests(unit)
    obs["input_digest"] = inp
    obs["batch_digest"] = bd
    pid, cd = active_identities(ws)
    obs["active_pid"] = pid
    obs["active_cd"] = cd
    obs["engine_digest"] = engine_digest(ws)
    eng = ws["engine"]
    mid = ws.get("mutation_id") or "benign"
    build_id = "build:%s:%s" % (unit["evaluation_unit_id"], mid)
    deploy_id = "deploy:%s:%s" % (unit["evaluation_unit_id"], mid)
    obs["build_id"] = build_id
    obs["deployment_id"] = deploy_id

    if arm == "N0":
        obs.update(decision="BLOCK", decision_reason="reject-all control", artifact_released=False,
                   admission_status="BLOCKED", downstream_executed=False)
        return obs
    if arm == "N1":
        ce = hashlib.sha256(b"constant-output").hexdigest()
        obs.update(admission_status="ACCEPT", canonical_digest=ce, leaf_digest=ce, batch_status="OK",
                   root_digest=ce, decision="ALLOW", artifact_released=True, downstream_executed=True,
                   decision_reason="constant-output control (distinction loss)")
        return obs
    if arm == "A0":
        return _a0(obs, base64.b64decode(_records(unit)[0]["raw_b64"]))

    events = []
    blocked = None
    if arm in ("A1+PID", "A2"):
        ev = guards_ctx["identity"].run(ws, unit["evaluation_unit_id"], arm, build_id, deploy_id)
        events.append(ev)
        if ev["alarm_emitted"]:
            blocked = ev
    if arm in ("A1+CI", "A2"):
        if blocked is not None:
            events.append(guards_mod.not_executed_event("ci-regression", unit["evaluation_unit_id"],
                                                         arm, build_id, deploy_id, "identity guard blocked first"))
        else:
            ev = guards_ctx["ci"].run(eng, unit["evaluation_unit_id"], arm, build_id, deploy_id)
            events.append(ev)
            if ev["alarm_emitted"]:
                blocked = ev
    obs["guard_events"] = events
    obs["guard_applicable"] = any(e["applicable"] for e in events)
    obs["alarm_emitted"] = any(e["alarm_emitted"] for e in events)
    alarm_ev = next((e for e in events if e["alarm_emitted"]), None)
    obs["alarm_type"] = alarm_ev["alarm_type"] if alarm_ev else None
    obs["alarm_stage"] = alarm_ev["alarm_stage"] if alarm_ev else None
    if blocked is not None:
        obs.update(decision="BLOCK", decision_reason=blocked["decision_reason"],
                   admission_status="NOT_EXECUTED", artifact_released=False, downstream_executed=False)
        return obs

    if unit["unit_type"] == "RECORD":
        raw = base64.b64decode(_records(unit)[0]["raw_b64"])
        res = eng.adjudicate(raw)
        obs["admission_status"] = res["decision"]
        obs["admission_reason"] = res["reason_code"]
        obs["canonical_digest"] = (hashlib.sha256(bytes.fromhex(res["canonical_hex"])).hexdigest()
                                   if res["canonical_hex"] else None)
        obs["canonical_bytes_hex"] = res["canonical_hex"]
        obs["downstream_executed"] = True
        rid = _records(unit)[0]["record_id"]
        if res["decision"] == "ACCEPT":
            leaf = eng.leaf(bytes.fromhex(res["canonical_hex"]), pid, cd)
            obs.update(leaf_digest=leaf.hex(), leaf_digests=[leaf.hex()], leaf_count=1,
                       batch_status="OK", root_digest=leaf.hex(), admitted=[rid],
                       decision="ALLOW", artifact_released=True, decision_reason="record accepted + committed")
        else:
            obs.update(leaf_digest=None, leaf_digests=[], leaf_count=0, batch_status="N/A",
                       root_digest=None, rejected=[rid],
                       decision="BLOCK", artifact_released=False, decision_reason="normative rejection")
        return obs

    batch = {"batch_id": unit["evaluation_unit_id"], "pid_sem": pid, "construction_digest": cd,
             "records": _records(unit), "expected_ids": unit.get("expected_ids")}
    c = ea.commit(eng, batch)
    obs.update(batch_status=c["status"], root_digest=c["root"], leaf_digests=c["leaf_digests"],
               internal_nodes=c["internal_nodes"], admitted=c["admitted"], rejected=c["rejected"],
               abstained=c["abstained"], leaf_count=c["leaf_count"], downstream_executed=True,
               admission_status=("ACCEPT" if c["status"] == "OK" else "BATCH_FAILED"))
    ok = c["status"] == "OK"
    obs.update(decision=("ALLOW" if ok else "BLOCK"), artifact_released=ok,
               decision_reason=("batch committed root" if ok else "batch failed (required membership)"))
    return obs


ARMS = ["A0", "A1", "A1+PID", "A1+CI", "A2", "N0", "N1"]
PRIMARY_ARMS = ["A1", "A1+PID", "A1+CI", "A2"]