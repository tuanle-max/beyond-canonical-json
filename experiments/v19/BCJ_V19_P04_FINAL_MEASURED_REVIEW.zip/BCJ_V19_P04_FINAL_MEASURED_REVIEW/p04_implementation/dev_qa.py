"""P04-B development QA (Q01-Q15). Each condition executes and reports a specific reason."""
import base64
import hashlib
import json
import pathlib
import sys

import aggregate
import arms
import engine_adapter as ea
import guards
import oracle
import runner
import schema

HERE = pathlib.Path(__file__).resolve().parent
RESULTS = HERE.parent / "results" / "P04"
RESULTS.mkdir(parents=True, exist_ok=True)

REC = {"event_id": "evt-qa-01", "timestamp": "2026-11-03T10:00:00Z", "amount": "2.675",
       "currency": "USD", "scale": 2, "beneficiary_code": "benA", "obligation_ref": "ref-qa-01"}
RAW = base64.b64encode(json.dumps(REC).encode("utf-8")).decode("ascii")


def unit(uid="qa", **kw):
    u = {"evaluation_unit_id": uid, "record_id": "evt-qa-01", "raw_b64": RAW,
         "unit_class": "benign", "required_behavior": "RELEASE", "mutation_id": None,
         "fault_present": False, "identity_applicable": False, "ci_applicable": False,
         "expected_ids": None, "expected_root": "R", "expected_canonical": "C"}
    u.update(kw)
    return u


def q01_missing_unit():
    units = {"u1": unit("u1"), "u2": unit("u2")}
    observations = [schema.empty_observation(evaluation_unit_id="u1", arm="A1")]
    have = {(o["evaluation_unit_id"], o["arm"]) for o in observations}
    missing = [(u, a) for u in units for a in ["A1"] if (u, a) not in have]
    return (len(missing) > 0, "missing unit-arm observations detected: %r" % (missing,))


def q02_duplicate_id():
    observations = [schema.empty_observation(evaluation_unit_id="u1", arm="A1"),
                    schema.empty_observation(evaluation_unit_id="u1", arm="A1")]
    seen = {}
    dups = []
    for o in observations:
        k = (o["evaluation_unit_id"], o["arm"])
        if k in seen:
            dups.append(k)
        seen[k] = True
    return (len(dups) > 0, "duplicate (unit,arm) keys detected: %r" % (dups,))


def q03_wrong_arm():
    allowed = {"A1", "A1+PID", "A1+CI", "A2"}
    observations = [schema.empty_observation(evaluation_unit_id="u1", arm="A9")]
    bad = [o["arm"] for o in observations if o["arm"] not in allowed]
    return (len(bad) > 0, "invalid arm labels detected: %r" % (bad,))


def q04_wrong_oracle_digest():
    # benign unit with a tampered expected_root: A1 engine correct but root != expected -> flagged inconsistent
    ws = arms.make_workspace(None)
    eng = ws["engine"]
    pid, cd = arms.active_identities(ws)
    res = eng.adjudicate(base64.b64decode(RAW))
    canon = hashlib.sha256(bytes.fromhex(res["canonical_hex"])).hexdigest()
    c = ea.commit(eng, {"batch_id": "q4", "pid_sem": pid, "construction_digest": cd,
                        "records": [{"record_id": "evt-qa-01", "raw_b64": RAW}]})
    u_wrong = unit("q4", expected_root="deadbeef", expected_canonical=canon)
    obs_ok = schema.empty_observation(evaluation_unit_id="q4", arm="A1", decision="ALLOW",
                                      artifact_released=True, root_digest=c["root"], canonical_digest=canon)
    flagged = not aggregate.classify_correct(u_wrong, obs_ok)
    return (flagged, "benign unit with tampered oracle root classified incorrect -> oracle label inconsistency flagged")


def q05_passive_divergence_not_alarm():
    u = unit("q5", required_behavior="PREVENT")
    obs = schema.empty_observation(evaluation_unit_id="q5", arm="A1", decision="ALLOW",
                                   artifact_released=True, alarm_emitted=False,
                                   root_digest="wrong", canonical_digest="wrong")
    correct = aggregate.classify_correct(u, obs)
    return (correct is False, "passive divergence (root!=expected) with no emitted alarm is NOT credited as prevention")


def q06_runtime_error_not_detection():
    u = unit("q6", required_behavior="PREVENT")
    obs = schema.empty_observation(evaluation_unit_id="q6", arm="A1", decision="INTERNAL_ERROR",
                                   artifact_released=False, runtime_error=True)
    correct = aggregate.classify_correct(u, obs)
    return (correct is False, "INTERNAL_ERROR not counted as successful prevention/detection")


def q07_benign_block_not_rewarded():
    u = unit("q7", required_behavior="RELEASE")
    obs = schema.empty_observation(evaluation_unit_id="q7", arm="A1", decision="BLOCK",
                                   artifact_released=False)
    correct = aggregate.classify_correct(u, obs)
    return (correct is False, "benign unit blocked is NOT correct (inappropriate blocking penalized)")
def q08_reject_all_not_optimal():
    u = unit("q8", required_behavior="RELEASE")
    obs = schema.empty_observation(evaluation_unit_id="q8", arm="N0", decision="BLOCK", artifact_released=False)
    correct = aggregate.classify_correct(u, obs)
    return (correct is False, "reject-all blocks benign units -> benign service (M11)=0; safety alone insufficient")


def q09_constant_output_loses_distinction():
    const = hashlib.sha256(b"constant-output").hexdigest()
    c1 = schema.empty_observation(evaluation_unit_id="q9a", arm="N1"); c1["canonical_digest"] = const
    c2 = schema.empty_observation(evaluation_unit_id="q9b", arm="N1"); c2["canonical_digest"] = const
    distinction_ok = c1["canonical_digest"] != c2["canonical_digest"]
    return (not distinction_ok, "constant-output yields identical canonical for distinct units -> distinction (M05) fails")


def q10_a1_a2_config_match():
    eng = ea.load_engine()
    res = eng.adjudicate(base64.b64decode(RAW))
    canon = hashlib.sha256(bytes.fromhex(res["canonical_hex"])).hexdigest()
    ig = guards.IdentityGuard(ea.PID_SEM_V2, ea.CONSTRUCTION_DIGEST)
    cg = guards.CIGuard([{"name": "x", "raw_b64": RAW, "expected_admission": res["decision"],
                          "expected_canonical_sha256": canon}])
    u = unit("q10")
    o1 = arms.run_record_unit("A1", u, arms.make_workspace(None), ig, cg)
    o2 = arms.run_record_unit("A2", u, arms.make_workspace(None), ig, cg)
    same = (o1["root_digest"] == o2["root_digest"] and o1["canonical_digest"] == o2["canonical_digest"])
    return (same, "A1 and A2 give identical canonical+root on a benign unit (guards do not alter semantics)")


def q11_holdout_not_exposed():
    bad = []
    for f in ["guards.py", "arms.py", "mutations.py", "engine_adapter.py"]:
        txt = (HERE / f).read_text(encoding="utf-8").lower()
        for token in ["d_eval", "answer_key", "expected_root", "fault_label"]:
            if token in txt:
                bad.append((f, token))
    return (len(bad) == 0, "no evaluator answer-key/exposure tokens in guard/dev modules: %r" % (bad,))


def structural_verify(obs):
    reasons = []
    d = obs.get("decision"); rel = obs.get("artifact_released")
    if d == "ALLOW" and not rel:
        reasons.append("ALLOW but not released")
    if d in ("BLOCK", "QUARANTINE") and rel:
        reasons.append("BLOCK/QUARANTINE but released")
    if obs.get("alarm_emitted") and not obs.get("alarm_type"):
        reasons.append("alarm_emitted without alarm_type")
    return reasons


def q12_structural_tamper():
    good = schema.empty_observation(evaluation_unit_id="q12", arm="A1", decision="ALLOW",
                                    artifact_released=True, root_digest="r", canonical_digest="c")
    tampered = dict(good); tampered["artifact_released"] = False
    outer_before = hashlib.sha256(json.dumps(good, sort_keys=True).encode()).hexdigest()
    outer_after = hashlib.sha256(json.dumps(tampered, sort_keys=True).encode()).hexdigest()
    reasons = structural_verify(tampered)
    return (len(reasons) > 0, "structural verifier catches tamper despite changed outer checksum (%s->%s): %r"
            % (outer_before[:8], outer_after[:8], reasons))
def q13_missing_perf_repetition():
    import perf
    arms_ = ["A1", "A1+PID", "A1+CI", "A2"]; sizes = [100, 1000, 5000]; reps = list(range(1, 11))
    rows = []
    for a in arms_:
        for s in sizes:
            for r in reps:
                row = perf.perf_schema_row(a, s, r, False); row["duration_ns"] = 1; rows.append(row)
    rows.pop(0)
    have = {(x["arm"], x["batch_size"], x["repetition"]) for x in rows}
    missing = [(a, s, r) for a in arms_ for s in sizes for r in reps if (a, s, r) not in have]
    return (len(missing) > 0, "missing measured repetition detected: %r" % (missing,))


def q14_denominator_na():
    def ratio(num, den):
        return None if den == 0 else num / den
    r = ratio(0, 0)
    return (r is None, "zero denominator -> N/A (None), not 0 or 100%")


def q15_partial_not_complete():
    out = RESULTS / "qa_partial_runner.jsonl"
    if out.exists():
        out.unlink()
    rr = runner.Runner(str(out))

    def run_fn(it):
        if it == 3:
            raise RuntimeError("injected mid-run failure")
        return {"item": it}

    res = rr.run([1, 2, 3, 4], run_fn, lambda it: str(it))
    return (res["status"] == "FAILED", "runner fails closed on mid-run error (status=%s, error=%r), not COMPLETE"
            % (res["status"], res["error"]))


CHECKS = [
    ("Q01", "missing measured unit", q01_missing_unit),
    ("Q02", "duplicate unit ID", q02_duplicate_id),
    ("Q03", "wrong arm assignment", q03_wrong_arm),
    ("Q04", "incorrect fault label / oracle digest", q04_wrong_oracle_digest),
    ("Q05", "passive divergence not an alarm", q05_passive_divergence_not_alarm),
    ("Q06", "runtime error not detection", q06_runtime_error_not_detection),
    ("Q07", "benign blocking not rewarded", q07_benign_block_not_rewarded),
    ("Q08", "reject-all not optimal", q08_reject_all_not_optimal),
    ("Q09", "constant-output distinction loss", q09_constant_output_loses_distinction),
    ("Q10", "A1/A2 config mismatch", q10_a1_a2_config_match),
    ("Q11", "holdout answer-key exposure", q11_holdout_not_exposed),
    ("Q12", "structural tamper w/ regenerated checksum", q12_structural_tamper),
    ("Q13", "missing performance repetition", q13_missing_perf_repetition),
    ("Q14", "incorrect denominator / N/A", q14_denominator_na),
    ("Q15", "partial execution not COMPLETE", q15_partial_not_complete),
]


def main():
    results = []
    for qid, name, fn in CHECKS:
        try:
            ok, reason = fn()
        except Exception as e:
            ok, reason = False, "EXCEPTION: %r" % (e,)
        results.append({"id": qid, "name": name, "pass": bool(ok), "reason": reason})
    out = RESULTS / "dev_qa_results.json"
    out.write_text(json.dumps({"checks": results,
                               "passed": sum(1 for r in results if r["pass"]),
                               "total": len(results)}, indent=2, sort_keys=True) + "\n",
                   encoding="utf-8", newline="\n")
    print(json.dumps({"passed": sum(1 for r in results if r["pass"]), "total": len(results),
                      "checks": results}, indent=2, sort_keys=True))


if __name__ == "__main__":
    sys.exit(main())