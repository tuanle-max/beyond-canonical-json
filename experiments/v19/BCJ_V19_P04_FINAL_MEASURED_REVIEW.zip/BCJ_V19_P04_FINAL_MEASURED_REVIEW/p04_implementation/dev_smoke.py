"""P04-B development smoke (D_DEV only): RECORD + BATCH units, structured guard events,
production aggregator + fairness verifier. No measured corpus, no performance runs.

Loads the FROZEN D_CI vectors (does not regenerate them) and verifies the corrected checksum (F14).
"""
import base64
import hashlib
import json
import pathlib
import sys

import aggregate
import arms
import engine_adapter as ea
import guards
import oracle
import runner

HERE = pathlib.Path(__file__).resolve().parent
D_CI = HERE / "d_ci"
D_DEV = HERE / "d_dev"
RESULTS = HERE.parent / "results" / "P04"
RESULTS.mkdir(parents=True, exist_ok=True)
D_CI_EXPECTED_SHA = "ffe1da6d368fab475640988c3e5f86fc054f8c2755755cfd9188015f3bedddeb"

A = {"event_id": "evt-rnd-01", "timestamp": "2026-11-03T10:00:00Z", "amount": "2.675", "currency": "USD",
     "scale": 2, "beneficiary_code": "benA", "obligation_ref": "ref-rnd-01"}
B = {"event_id": "evt-basic-02", "timestamp": "2026-11-04T08:30:00Z", "amount": "10.00", "currency": "USD",
     "scale": 2, "beneficiary_code": "benB", "obligation_ref": "ref-basic-02"}
C = {"event_id": "evt-c-03", "timestamp": "2026-11-05T09:15:00Z", "amount": "3.50", "currency": "USD",
     "scale": 2, "beneficiary_code": "benC", "obligation_ref": "ref-c-03"}


def b64(o):
    return base64.b64encode(json.dumps(o).encode("utf-8")).decode("ascii")


def rec(rid, o):
    return {"record_id": rid, "raw_b64": b64(o)}


def load_ci():
    raw = (D_CI / "vectors.json").read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    data = json.loads(raw.decode("utf-8"))
    return data["vectors"], sha, (sha == D_CI_EXPECTED_SHA)


def build_units():
    units = {}

    def add_record(uid, rec_id, o, mutation_id, required, fault, ident_app, ci_app):
        u = {"evaluation_unit_id": uid, "unit_type": "RECORD", "record_id": rec_id, "raw_b64": b64(o),
             "mutation_id": mutation_id, "fault_present": fault,
             "identity_applicable": ident_app, "ci_applicable": ci_app, "required_behavior": required}
        if mutation_id is None and required == "RELEASE":
            u.update(oracle.expected_record(u["raw_b64"], rec_id))
        units[uid] = u

    def add_batch(uid, records, expected_ids, mutation_id, required):
        u = {"evaluation_unit_id": uid, "unit_type": "BATCH", "records": records,
             "expected_ids": expected_ids, "mutation_id": mutation_id, "fault_present": (mutation_id is not None),
             "identity_applicable": False, "ci_applicable": False, "required_behavior": required}
        u.update(oracle.expected_batch(records, expected_ids))
        units[uid] = u

    add_record("dev-benign-01", "evt-rnd-01", A, None, "RELEASE", False, False, False)
    add_record("dev-benign-02", "evt-basic-02", B, None, "RELEASE", False, False, False)
    add_record("dev-g1", "evt-basic-02", B, "g1_normative_artifact", "PREVENT", True, True, False)
    add_record("dev-g2", "evt-basic-02", B, "g2_leaf_formula", "PREVENT", True, True, False)
    add_record("dev-g3", "evt-rnd-01", A, "g3_rounding_half_down", "PREVENT", True, False, True)
    add_record("dev-g4", "evt-basic-02", B, "g4_leaf_prefix", "PREVENT", True, False, False)

    batch_abc = [rec("evt-rnd-01", A), rec("evt-basic-02", B), rec("evt-c-03", C)]
    batch_dup = [rec("evt-rnd-01", A), rec("evt-rnd-01", A), rec("evt-basic-02", B)]
    batch_reorder = [rec("evt-basic-02", B), rec("evt-rnd-01", A), rec("evt-c-03", C)]
    add_batch("dev-batch-benign", batch_abc, None, None, "RELEASE")
    add_batch("dev-batch-dup", batch_dup, None, None, "RELEASE")
    add_batch("dev-batch-reorder", batch_reorder, None, None, "RELEASE")
    add_batch("dev-batch-missing", [rec("evt-rnd-01", A), rec("evt-basic-02", B)],
              ["evt-rnd-01", "evt-basic-02", "evt-c-03"], None, "PREVENT")
    add_batch("dev-batch-singleton", [rec("evt-rnd-01", A)], None, None, "RELEASE")
    add_batch("dev-batch-empty", [], None, None, "RELEASE")
    return units
def main():
    vectors, ci_sha, ci_ok = load_ci()
    units = build_units()
    (D_DEV / "units.json").write_text(json.dumps({"units": list(units.values())}, indent=2,
                                                 sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    ig = guards.IdentityGuard(ea.PID_SEM_V2, ea.CONSTRUCTION_DIGEST)
    cg = guards.CIGuard(vectors)
    guards_ctx = {"identity": ig, "ci": cg}

    plan = [(uid, u, arm) for uid, u in units.items() for arm in arms.PRIMARY_ARMS]
    out = RESULTS / "dev_raw_observations.jsonl"
    if out.exists():
        out.unlink()
    r = runner.Runner(str(out), run_id="dev-smoke-r3a", plan_items=plan,
                      key_fn=lambda it: it[0] + ":" + it[2],
                      run_meta={"corpus": "dev", "d_ci_sha256": ci_sha}, timeout_s=60)

    def run_fn(item):
        uid, u, arm = item
        ws = arms.make_workspace(u["mutation_id"])
        return arms.run_unit(arm, u, ws, guards_ctx, run_id="dev-smoke-r3a")

    run_status = r.run(run_fn)
    raw = [json.loads(l) for l in out.read_text(encoding="utf-8").splitlines() if l.strip()]
    s = aggregate.summary(raw, units)
    s["run_status"] = run_status
    s["d_ci_sha256"] = ci_sha
    s["d_ci_checksum_ok"] = ci_ok
    (RESULTS / "dev_smoke_summary.json").write_text(json.dumps(s, indent=2, sort_keys=True) + "\n",
                                                    encoding="utf-8", newline="\n")
    print(json.dumps({"run_status": run_status["status"], "observations": len(raw),
                      "d_ci_checksum_ok": ci_ok, "fairness_ok": s["fairness"]["ok"],
                      "identity_confusion": s["identity_confusion"],
                      "ci_confusion": s["ci_confusion"],
                      "paired": s["paired_A1_vs_A2"],
                      "M11_benign": s["M11_benign_service"]}, indent=2))


if __name__ == "__main__":
    sys.exit(main())