"""P04-B common semantic-engine adapter.

Reuses the FROZEN P03 Python engine (boo.py) read-only via path import. No modification
of the frozen implementation in place. The batch commit helper mirrors the frozen engine's
cmd_commit logic but calls the frozen primitives (adjudicate / leaf / root) directly.
"""
import base64
import hashlib
import importlib.util
import json
import pathlib
from collections import Counter

import rfc8785

V19 = pathlib.Path(__file__).resolve().parents[1]
IMPL = V19 / "implementations" / "python-dev"
FROZEN_BOO = IMPL / "boo.py"
SEM_MANIFEST_PATH = IMPL / "semantic_manifest_v2.R4.CANDIDATE.json"
CON_MANIFEST_PATH = IMPL / "construction_manifest_v3.R4.CANDIDATE.json"

PID_SEM_V2 = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CONSTRUCTION_DIGEST = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
FROZEN_BOO_SHA256 = "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f"


def load_engine():
    """Load the frozen engine as a module object (does not modify the file on disk)."""
    spec = importlib.util.spec_from_file_location("frozen_boo", str(FROZEN_BOO))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_manifests():
    return (
        json.loads(SEM_MANIFEST_PATH.read_text(encoding="utf-8")),
        json.loads(CON_MANIFEST_PATH.read_text(encoding="utf-8")),
    )


def manifest_identity(obj):
    """Recompute identity digest from manifest content via JCS (never trust a label)."""
    return hashlib.sha256(rfc8785.dumps(obj)).hexdigest()


def adjudicate(engine, raw_bytes):
    return engine.adjudicate(raw_bytes)


def commit(engine, batch):
    """Mirror the frozen engine cmd_commit: multiplicity check -> leaves -> root."""
    pid = batch["pid_sem"]
    cd = batch["construction_digest"]
    expected = batch.get("expected_ids")
    supplied = [r["record_id"] for r in batch["records"]]
    if expected is not None:
        need, have = Counter(expected), Counter(supplied)
        missing = []
        for k in need:
            d = need[k] - have.get(k, 0)
            if d > 0:
                missing += [k] * d
        if missing:
            return {"batch_id": batch.get("batch_id"), "status": "BATCH_FAILED",
                    "missing_required": missing, "admitted": [], "rejected": [],
                    "abstained": [], "leaf_count": 0, "leaf_digests": [],
                    "internal_nodes": [], "root": None,
                    "semantic_profile_digest": pid, "construction_digest": cd}

    leaves, acc, rej, abst = [], [], [], []
    for r in batch["records"]:
        res = engine.adjudicate(base64.b64decode(r["raw_b64"]))
        if res["decision"] == "ACCEPT":
            leaves.append(engine.leaf(bytes.fromhex(res["canonical_hex"]), pid, cd))
            acc.append(r["record_id"])
        elif res["decision"] == "ABSTAIN_UNDERSPECIFIED":
            abst.append(r["record_id"])
        else:
            rej.append(r["record_id"])
    root_bytes, nodes = engine.root(leaves)
    return {"batch_id": batch.get("batch_id"), "status": "OK", "admitted": acc,
            "rejected": rej, "abstained": abst, "leaf_count": len(leaves),
            "leaf_digests": [l.hex() for l in leaves], "internal_nodes": nodes,
            "root": root_bytes.hex(), "semantic_profile_digest": pid,
            "construction_digest": cd}