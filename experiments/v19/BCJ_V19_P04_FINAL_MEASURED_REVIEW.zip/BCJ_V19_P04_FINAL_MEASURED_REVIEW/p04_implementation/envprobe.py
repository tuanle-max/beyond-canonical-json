"""P04-B source/normative identity verification (F16), with an explicit frozen line-ending policy.

Line-ending policy (FROZEN): the P03 frozen source SHA-256 digests are defined over CRLF rendering
of the LF-committed blobs (per .gitattributes eol=lf). Raw, LF-normalized, and CRLF-normalized
digests are recorded separately; raw-byte hashes are never silently substituted for normalized ones.
"""
import hashlib
import json
import pathlib

import engine_adapter as ea

V19 = pathlib.Path(__file__).resolve().parents[1]
IMPL = V19 / "implementations" / "python-dev"
GO = V19 / "implementations" / "go-dev"

POLICY = ("frozen digests defined under CRLF rendering of LF-committed blobs; "
          "raw / lf / crlf digests recorded separately")

FROZEN_PY = "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f"
FROZEN_GO = "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa"


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _variants(path):
    raw = pathlib.Path(path).read_bytes()
    return {"raw": _sha(raw), "lf": _sha(raw.replace(b"\r\n", b"\n")),
            "crlf": _sha(raw.replace(b"\n", b"\r\n"))}


def verify():
    py = _variants(IMPL / "boo.py")
    go = _variants(GO / "main.go")
    py_ok = FROZEN_PY in (py["raw"], py["lf"], py["crlf"])
    go_ok = FROZEN_GO in (go["raw"], go["lf"], go["crlf"])
    sem, con = ea.load_manifests()
    pid = ea.manifest_identity(sem)
    cd = ea.manifest_identity(con)
    return {
        "line_ending_policy": POLICY,
        "python_variants": py,
        "go_variants": go,
        "frozen_python_sha256": FROZEN_PY,
        "frozen_go_sha256": FROZEN_GO,
        "python_ok": py_ok,
        "go_ok": go_ok,
        "pid_sem_v2": pid,
        "construction_digest": cd,
        "pid_ok": pid == ea.PID_SEM_V2,
        "cd_ok": cd == ea.CONSTRUCTION_DIGEST,
        "all_ok": py_ok and go_ok and pid == ea.PID_SEM_V2 and cd == ea.CONSTRUCTION_DIGEST,
    }


if __name__ == "__main__":
    out = pathlib.Path(__file__).resolve().parent / "P04_SOURCE_ATTESTATION.json"
    r = verify()
    out.write_text(json.dumps(r, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"all_ok": r["all_ok"], "python_ok": r["python_ok"], "go_ok": r["go_ok"],
                      "pid_ok": r["pid_ok"], "cd_ok": r["cd_ok"]}, indent=2))