"""P04-B assurance guards with structured per-detector events (F11).

Each guard emits a structured event (never a single overwritable result). Identity runs at
config/batch time; CI regression runs at build/deploy time against the actual (possibly mutated)
engine. For A2 both events are preserved; if identity blocks before CI, CI is recorded NOT_EXECUTED.
"""
import base64
import hashlib

import schema

import engine_adapter as ea


class IdentityGuard:
    def __init__(self, expected_pid, expected_cd):
        self.expected_pid = expected_pid
        self.expected_cd = expected_cd

    def check(self, sem_manifest, con_manifest):
        active_pid = ea.manifest_identity(sem_manifest)
        active_cd = ea.manifest_identity(con_manifest)
        pid_mm = active_pid != self.expected_pid
        cd_mm = active_cd != self.expected_cd
        return {"active_pid": active_pid, "active_cd": active_cd,
                "pid_mismatch": pid_mm, "cd_mismatch": cd_mm, "mismatch": (pid_mm or cd_mm)}

    def run(self, ws, unit_id, seq, build_id, deployment_id):
        c = self.check(ws["semantic_manifest"], ws["construction_manifest"])
        mm = c["mismatch"]
        return schema.make_guard_event(
            detector="identity",
            guard_execution_id="%s:identity:%s" % (unit_id, seq),
            build_id=build_id, deployment_id=deployment_id, evaluation_unit_id=unit_id,
            executed=True, applicable=True,
            active_pid=c["active_pid"], active_cd=c["active_cd"],
            expected_pid=self.expected_pid, expected_cd=self.expected_cd,
            alarm_emitted=mm, alarm_type=("IDENTITY_MISMATCH" if mm else None),
            alarm_stage="L4",
            decision=("BLOCK" if mm else "ALLOW"),
            decision_reason=("semantic/construction identity mismatch" if mm else "identities match expected"))


class CIGuard:
    def __init__(self, vectors):
        self.vectors = list(vectors)

    def run(self, engine, unit_id, seq, build_id, deployment_id):
        failed = []
        for v in self.vectors:
            raw = base64.b64decode(v["raw_b64"])
            res = engine.adjudicate(raw)
            got = res["decision"]
            got_canon = hashlib.sha256(bytes.fromhex(res["canonical_hex"])).hexdigest() if res["canonical_hex"] else None
            if not (got == v["expected_admission"] and got_canon == v.get("expected_canonical_sha256")):
                failed.append({"name": v["name"], "got_admission": got, "got_canonical_sha256": got_canon})
        passed = len(failed) == 0
        return schema.make_guard_event(
            detector="ci-regression",
            guard_execution_id="%s:ci:%s" % (unit_id, seq),
            build_id=build_id, deployment_id=deployment_id, evaluation_unit_id=unit_id,
            executed=True, applicable=True,
            alarm_emitted=not passed, alarm_type=("CI_REGRESSION" if not passed else None),
            alarm_stage="build/deploy",
            decision=("BLOCK" if not passed else "ALLOW"),
            decision_reason=("regression vectors failed: %d/%d" % (len(failed), len(self.vectors))
                             if not passed else "all regression vectors passed"))


def not_executed_event(detector, unit_id, seq, build_id, deployment_id, reason):
    return schema.make_guard_event(
        detector=detector, guard_execution_id="%s:%s:%s" % (unit_id, detector, seq),
        build_id=build_id, deployment_id=deployment_id, evaluation_unit_id=unit_id,
        executed=False, applicable=True, alarm_emitted=False,
        alarm_stage=("L4" if detector == "identity" else "build/deploy"),
        decision="NOT_EXECUTED", decision_reason=reason)