"""P04-B fault-injection operators (12 materially distinct, G1-G4).

Each operator mutates a fresh workspace (deep-copied manifest objects + a freshly imported engine
module) without touching frozen P03 on disk. Engine patches target the per-workspace engine module.
Each operator carries: operator_id, group, change_type, expected_visibility, activation_conditions,
affected_stage, and an implementation digest (sha256 of the operator source).
"""
import copy
import hashlib
import inspect
from decimal import Decimal, ROUND_HALF_DOWN, localcontext


# ---------------- G1 semantic-profile (config / manifest-visible) ----------------
def _g1_normative_artifact(ws):
    sm = copy.deepcopy(ws["semantic_manifest"])
    sm["normative_artifacts"]["contract"]["sha256"] = "0" * 64
    ws["semantic_manifest"] = sm


def _g1_semantic_version(ws):
    sm = copy.deepcopy(ws["semantic_manifest"])
    sm["semantic_version"] = str(sm.get("semantic_version", "2.0")) + ".9"
    ws["semantic_manifest"] = sm


def _g1_unicode_fields(ws):
    sm = copy.deepcopy(ws["semantic_manifest"])
    sm.setdefault("unicode", {})["fields"] = []
    ws["semantic_manifest"] = sm


# ---------------- G2 construction (config / manifest-visible) ----------------
def _g2_leaf_formula(ws):
    cm = copy.deepcopy(ws["construction_manifest"])
    cm["leaf"] = cm["leaf"].replace("0x03", "0x77")
    ws["construction_manifest"] = cm


def _g2_tree_policy(ws):
    cm = copy.deepcopy(ws["construction_manifest"])
    cm["tree"] = "binary_balanced_alt"
    ws["construction_manifest"] = cm


def _g2_empty_root(ws):
    cm = copy.deepcopy(ws["construction_manifest"])
    cm["empty_root"] = cm["empty_root"].replace("0x02", "0x82")
    ws["construction_manifest"] = cm


# ---------------- G3 semantic regression (behavioral) ----------------
def _g3_rounding_half_down(ws):
    eng = ws["engine"]
    AMT = eng.AMT
    MAXS = eng.MAXS

    def bad_al(lex, sc):
        if lex.startswith("-"):
            return None, "NEGATIVE_AMOUNT"
        if len(lex) > 24 or not AMT.fullmatch(lex) or len(lex.split(".")[0]) > 16:
            return None, "AMOUNT_MALFORMED"
        with localcontext() as c:
            c.prec = 60
            m = int((Decimal(lex) * (Decimal(10) ** sc)).quantize(Decimal(1), rounding=ROUND_HALF_DOWN))
        return (m, None) if 0 <= m <= MAXS else (None, "MONETARY_OVERFLOW")

    eng.al = bad_al


def _g3_ts_plus1ms(ws):
    eng = ws["engine"]
    orig = eng.ts

    def bad_ts(v):
        ms, err = orig(v)
        if ms is not None:
            ms = ms + 1
        return ms, err

    eng.ts = bad_ts


def _g3_scale_registry(ws):
    eng = ws["engine"]
    eng.REG = {"USD": 3, "EUR": 2, "VND": 0}


# ---------------- G4 encoding / batch regression (behavioral) ----------------
def _g4_leaf_prefix(ws):
    eng = ws["engine"]

    def bad_leaf(canon, pid, cd):
        return hashlib.sha256(b"\x00\x04" + bytes.fromhex(pid) + bytes.fromhex(cd) + canon).digest()

    eng.leaf = bad_leaf


def _g4_node_prefix(ws):
    eng = ws["engine"]

    def bad_node(l, r):
        return hashlib.sha256(b"\x09" + l + r).digest()

    eng.node = bad_node


def _g4_tree_topology(ws):
    eng = ws["engine"]

    def bad_root(leaves):
        n = len(leaves)
        if n == 0:
            return hashlib.sha256(b"\x02\x00").digest(), []
        if n == 1:
            return leaves[0], []
        k = n - 1
        L, ln = bad_root(leaves[:k])
        R, rn = bad_root(leaves[k:])
        nd = {"left": L.hex(), "right": R.hex(), "preimage_hex": (b"\x01" + L + R).hex(),
              "digest": eng.node(L, R).hex()}
        return eng.node(L, R), [nd] + ln + rn

    eng.root = bad_root
MUTATIONS = {}


def _reg(oid, name, group, change_type, visibility, activation, stage, fn):
    MUTATIONS[oid] = {
        "operator_id": oid, "name": name, "group": group, "change_type": change_type,
        "expected_visibility": visibility, "activation_conditions": activation,
        "affected_stage": stage,
        "impl_digest": hashlib.sha256(inspect.getsource(fn).encode()).hexdigest(),
        "apply": fn,
    }


_reg("g1_normative_artifact", "changed normative-rule artifact digest", "G1", "config", "manifest", "always", "L4", _g1_normative_artifact)
_reg("g1_semantic_version", "semantic_version bumped", "G1", "config", "manifest", "always", "L4", _g1_semantic_version)
_reg("g1_unicode_fields", "unicode fields list emptied", "G1", "config", "manifest", "always", "L4", _g1_unicode_fields)
_reg("g2_leaf_formula", "declared leaf formula changed", "G2", "config", "manifest", "always", "L4", _g2_leaf_formula)
_reg("g2_tree_policy", "declared tree policy changed", "G2", "config", "manifest", "always", "L4", _g2_tree_policy)
_reg("g2_empty_root", "declared empty_root changed", "G2", "config", "manifest", "always", "L4", _g2_empty_root)
_reg("g3_rounding_half_down", "monetary rounding half-up -> half-down", "G3", "behavioral", "hidden", "amounts with sub-unit rounding", "L1", _g3_rounding_half_down)
_reg("g3_ts_plus1ms", "timestamp +1ms", "G3", "behavioral", "hidden", "ISO/string timestamps", "L1", _g3_ts_plus1ms)
_reg("g3_scale_registry", "currency-scale registry drift (USD->3)", "G3", "behavioral", "hidden", "records with currency+scale", "L1", _g3_scale_registry)
_reg("g4_leaf_prefix", "leaf domain separator 0x0003 -> 0x0004", "G4", "behavioral", "hidden", "every admitted leaf", "L5", _g4_leaf_prefix)
_reg("g4_node_prefix", "internal-node prefix 0x01 -> 0x09", "G4", "behavioral", "hidden", "batches with >1 leaf", "L7", _g4_node_prefix)
_reg("g4_tree_topology", "tree split largest-pow2 -> left-branching", "G4", "behavioral", "hidden", "batches with >=4 leaves", "L7", _g4_tree_topology)


def apply_mutation(ws, mutation_id):
    if mutation_id not in MUTATIONS:
        raise KeyError(mutation_id)
    ws["mutation_id"] = mutation_id
    MUTATIONS[mutation_id]["apply"](ws)
    return MUTATIONS[mutation_id]


def inventory():
    return [{k: v for k, v in m.items() if k != "apply"} for m in MUTATIONS.values()]