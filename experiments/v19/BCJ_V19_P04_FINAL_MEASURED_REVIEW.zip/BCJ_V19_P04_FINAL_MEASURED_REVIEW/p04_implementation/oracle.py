"""P04-B evaluator-side oracle adapter (D_DEV only).

Expected outcomes derived from the PRISTINE frozen engine + normative contract. Development-only;
the measured evaluator oracle (D_EVAL) is produced separately (P04-C) and never exposed to guards.
"""
import base64
import hashlib

import arms
import engine_adapter as ea


def expected_record(record_b64, record_id):
    ws = arms.make_workspace(None)
    pid, cd = arms.active_identities(ws)
    eng = ws["engine"]
    res = eng.adjudicate(base64.b64decode(record_b64))
    canon = hashlib.sha256(bytes.fromhex(res["canonical_hex"])).hexdigest() if res["canonical_hex"] else None
    if res["decision"] == "ACCEPT":
        leaf = eng.leaf(bytes.fromhex(res["canonical_hex"]), pid, cd).hex()
        return {"expected_admission": "ACCEPT", "expected_reason": None, "expected_canonical": canon,
                "expected_leaf": leaf, "expected_root": leaf, "expected_batch_status": "OK",
                "required_behavior": "RELEASE", "expected_pid": pid, "expected_cd": cd}
    return {"expected_admission": res["decision"], "expected_reason": res["reason_code"],
            "expected_canonical": None, "expected_leaf": None, "expected_root": None,
            "expected_batch_status": "N/A", "required_behavior": "REJECT_VIA_ADMISSION",
            "expected_pid": pid, "expected_cd": cd}


def expected_batch(records, expected_ids):
    ws = arms.make_workspace(None)
    pid, cd = arms.active_identities(ws)
    eng = ws["engine"]
    c = ea.commit(eng, {"batch_id": "oracle", "pid_sem": pid, "construction_digest": cd,
                        "records": records, "expected_ids": expected_ids})
    status = c["status"]
    return {"expected_batch_status": status, "expected_root": c["root"],
            "expected_leaf_digests": c["leaf_digests"],
            "expected_admission": ("ACCEPT" if status == "OK" else "BATCH_FAILED"),
            "required_behavior": ("RELEASE" if status == "OK" else "PREVENT"),
            "expected_pid": pid, "expected_cd": cd}