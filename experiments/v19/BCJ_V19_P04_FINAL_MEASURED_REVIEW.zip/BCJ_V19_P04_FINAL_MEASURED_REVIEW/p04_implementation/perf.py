"""P04-B performance runner (F15). Implemented but measured repetitions NOT executed.

Workload: batch sizes 100/1000/5000, four primary arms, 3 warm-up + 10 measured per (arm,size)
=> 120 measured + 36 warm-up. Frozen ordering seed 42. Costs separated: config, CI build/deploy,
runtime identity guard, common pipeline, end-to-end. Peak memory via tracemalloc is labelled
Python-traced peak ALLOCATED memory (not process RSS).
"""
import time
import tracemalloc

SEED = 42
BATCH_SIZES = [100, 1000, 5000]
ARMS = ["A1", "A1+PID", "A1+CI", "A2"]
WARMUP = 3
MEASURED = 10


def plan():
    """Deterministic ordered plan of (arm, size, repetition, warmup) using frozen seed."""
    import random
    rng = random.Random(SEED)
    combos = [(a, s) for a in ARMS for s in BATCH_SIZES]
    rows = []
    for rep in range(WARMUP + MEASURED):
        warm = rep < WARMUP
        order = combos[:]
        rng.shuffle(order)
        for a, s in order:
            rows.append({"arm": a, "batch_size": s, "repetition": rep,
                         "warmup": warm})
    return rows


def measure(fn, *args, **kwargs):
    tracemalloc.start()
    t0 = time.perf_counter_ns()
    try:
        out = fn(*args, **kwargs)
    finally:
        t1 = time.perf_counter_ns()
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
    return out, {"duration_ns": t1 - t0, "python_traced_peak_alloc_bytes": peak}


def row_schema():
    return {"arm": None, "batch_size": None, "repetition": None, "warmup": None,
            "duration_ns": None, "python_traced_peak_alloc_bytes": None,
            "process_startup_included": False, "config_check_ns": None,
            "ci_check_ns": None, "runtime_guard_ns": None, "pipeline_ns": None}


def smoke(fn, argv):
    """D_DEV-only instrumentation smoke: one warm-up + one measured call (NOT a measured run)."""
    _, w = measure(fn, *argv)
    _, m = measure(fn, *argv)
    return {"warmup": w, "measured": m, "labelled": "python_traced_peak_alloc_bytes (not RSS)"}