"""P04-B INTEGRATED QA (F13): Q01-Q15 executed against PRODUCTION verifier/runner/aggregator.
Retains the original R3 dev QA results separately (dev_qa_results.json). Each check executes and
records a specific rejection reason. A clean valid baseline precedes mutation tests."""
import base64
import hashlib
import json
import pathlib
import sys

import aggregate
import arms
import engine_adapter as ea
import guards
import oracle
import perf
import runner
import schema
import verifier

HERE = pathlib.Path(__file__).resolve().parent
RESULTS = HERE.parent / "results" / "P04"
RESULTS.mkdir(parents=True, exist_ok=True)

REC = {"event_id": "evt-qa-01", "timestamp": "2026-11-03T10:00:00Z", "amount": "2.675",
       "currency": "USD", "scale": 2, "beneficiary_code": "benA", "obligation_ref": "ref-qa-01"}
RAW = base64.b64encode(json.dumps(REC).encode("utf-8")).decode("ascii")


def obs(**kw):
    return schema.empty_observation(**kw)


def unit(uid="u", required="RELEASE", fault=False, id_app=False, ci_app=False):
    u = {"evaluation_unit_id": uid, "unit_type": "RECORD", "record_id": "evt-qa-01", "raw_b64": RAW,
         "mutation_id": None, "fault_present": fault, "identity_applicable": id_app,
         "ci_applicable": ci_app, "required_behavior": required,
         "expected_admission": "ACCEPT", "expected_canonical": "C", "expected_leaf": "L",
         "expected_root": "R"}
    return u


def q01_remove_unit_arm():
    units = {"u1": unit("u1"), "u2": unit("u2")}
    observations = [obs(evaluation_unit_id="u1", arm="A1")]
    r = verifier.verify_membership(observations, [("u1", "A1"), ("u2", "A1")])
    return (not r["ok"] and ("u2", "A1") in r["missing"], "missing unit-arm rejected: %r" % (r["missing"],))


def q02_duplicate():
    observations = [obs(evaluation_unit_id="u1", arm="A1"), obs(evaluation_unit_id="u1", arm="A1")]
    r = verifier.verify_membership(observations, [("u1", "A1")])
    return (not r["ok"] and r["duplicates"], "duplicate observation rejected: %r" % (r["duplicates"],))


def q03_unexpected_arm():
    observations = [obs(evaluation_unit_id="u1", arm="A1"), obs(evaluation_unit_id="u1", arm="A9")]
    r = verifier.verify_membership(observations, [("u1", "A1")])
    return (not r["ok"] and ("u1", "A9") in r["unexpected"], "unexpected arm rejected: %r" % (r["unexpected"],))


def q04_oracle_digest():
    good = b"oracle-artifact-bytes"
    good_sha = hashlib.sha256(good).hexdigest()
    bad = b"tampered-oracle-artifact"
    r = verifier.verify_oracle_digest(bad, good_sha)
    return (not r["ok"], "tampered oracle artifact rejected (got %s != expected %s)" % (r["got"][:8], r["expected"][:8]))


def q05_passive_divergence():
    u = unit("q5", required="PREVENT", fault=True, id_app=True)
    o = obs(evaluation_unit_id="q5", arm="A1", decision="ALLOW", artifact_released=True,
            alarm_emitted=False, root_digest="WRONG")
    r = aggregate.classify(u, o)
    return (r["correct"] is False, "passive divergence w/o alarm not credited: %s (%s)" % (r["outcome_class"], r["reason"]))


def q06_crash_timeout():
    u = unit("q6", required="PREVENT", fault=True)
    o1 = obs(evaluation_unit_id="q6", arm="A1", decision="INTERNAL_ERROR", runtime_error=True, artifact_released=False)
    o2 = obs(evaluation_unit_id="q6", arm="A1", decision="TIMEOUT", timeout=True, artifact_released=False)
    r1 = aggregate.classify(u, o1)
    r2 = aggregate.classify(u, o2)
    return (r1["correct"] is False and r2["correct"] is False,
            "crash=%s timeout=%s not counted as prevention" % (r1["outcome_class"], r2["outcome_class"]))


def q07_benign_block():
    u = unit("q7", required="RELEASE")
    o = obs(evaluation_unit_id="q7", arm="A1", decision="BLOCK", artifact_released=False)
    r = aggregate.classify(u, o)
    return (r["correct"] is False, "benign block not rewarded: %s" % r["outcome_class"])
def _ci_vecs():
    return json.loads((HERE / "d_ci" / "vectors.json").read_text(encoding="utf-8"))["vectors"]


def _ctx():
    return {"identity": guards.IdentityGuard(ea.PID_SEM_V2, ea.CONSTRUCTION_DIGEST),
            "ci": guards.CIGuard(_ci_vecs())}


def q08_reject_all():
    units = {"b1": unit("b1", "RELEASE")}
    o = arms.run_unit("N0", units["b1"], arms.make_workspace(None), _ctx())
    m = aggregate.benign_service([o], units, "N0")
    return (m["value"] == 0.0 and m["den"] == 1, "reject-all benign_service=%r (den %d)" % (m["value"], m["den"]))


def q09_constant_output():
    ctx = _ctx()
    o1 = arms.run_unit("N1", unit("a"), arms.make_workspace(None), ctx)
    o2 = arms.run_unit("N1", unit("b"), arms.make_workspace(None), ctx)
    same = o1["canonical_digest"] == o2["canonical_digest"]
    return (bool(same), "constant-output identical canonical for distinct units (M05 distinction fails)")


def q10_fairness_mismatch():
    base = dict(input_digest="I", batch_digest=None, active_pid="P", active_cd="C", mutation_instance_id=None)
    o1 = obs(evaluation_unit_id="u1", arm="A1", engine_digest="E1", **base)
    o2 = obs(evaluation_unit_id="u1", arm="A1+PID", engine_digest="E1", **base)
    o3 = obs(evaluation_unit_id="u1", arm="A1+CI", engine_digest="E1", **base)
    o4 = obs(evaluation_unit_id="u1", arm="A2", engine_digest="E2", **base)  # mismatched engine
    r = aggregate.verify_fairness([o1, o2, o3, o4])
    return (not r["ok"], "A2 engine_digest mismatch detected: %r" % (r["violations"][:1],))


def q11_isolation():
    inv = ["guards.py", "arms.py", "d_eval/answer_key.jsonl"]
    r = verifier.verify_isolation(inv, ["d_eval/", "answer_key"])
    return (not r["ok"] and r["leaked"], "forbidden evaluator file rejected by isolation check: %r" % (r["leaked"],))


def q12_structural_tamper():
    good = obs(evaluation_unit_id="q12", arm="A1", decision="ALLOW", artifact_released=True,
               root_digest="r", canonical_digest="c")
    tampered = dict(good)
    tampered["artifact_released"] = False
    outer = hashlib.sha256(json.dumps(tampered, sort_keys=True).encode()).hexdigest()
    r = verifier.structural_verify(tampered)
    return (not r["ok"], "structural verifier rejects tamper despite regenerated checksum %s: %r" % (outer[:8], r["reasons"]))


def q13_perf_repetition():
    plan = perf.plan()
    rows = [{**perf.row_schema(), **p} for p in plan]
    rows.pop(0)
    r = verifier.verify_perf_inventory(rows, plan)
    return (not r["ok"], "missing perf repetition detected: n_missing=%d" % r["n_missing"])


def q14_denominator():
    return (aggregate._ratio(0, 0) is None and aggregate._ratio(3, 0) is None, "zero denominator -> N/A (None)")


def q15_runner_integrity():
    p = RESULTS / "qa_int_runner.jsonl"
    if p.exists():
        p.unlink()
    items = [("u1", "A1"), ("u2", "A1"), ("u3", "A1")]
    key = lambda it: it[0] + ":" + it[1]

    def rf_fail(it):
        if it[0] == "u2":
            raise RuntimeError("inject")
        return {"evaluation_unit_id": it[0], "arm": it[1], "decision": "ALLOW"}

    r1 = runner.Runner(str(p), "runX", items, key).run(rf_fail)
    interrupted = (r1["status"] == "FAILED")
    r2 = runner.Runner(str(p), "runX", items, key).run(
        lambda it: {"evaluation_unit_id": it[0], "arm": it[1], "decision": "ALLOW"})
    valid_resume = (r2["status"] == "COMPLETE" and r2["missing"] == [])
    try:
        runner.Runner(str(p), "runY", items, key)
        invalid_rejected = False
    except runner.PlanMismatch:
        invalid_rejected = True
    return (interrupted and valid_resume and invalid_rejected,
            "interrupted=%s valid_resume=%s invalid_resume_rejected=%s"
            % (interrupted, valid_resume, invalid_rejected))


CHECKS = [
    ("Q01", "remove expected unit-arm observation", q01_remove_unit_arm),
    ("Q02", "duplicate observation", q02_duplicate),
    ("Q03", "unexpected arm/unit", q03_unexpected_arm),
    ("Q04", "tampered oracle artifact rejected by frozen digest", q04_oracle_digest),
    ("Q05", "passive divergence not credited as alarm", q05_passive_divergence),
    ("Q06", "crash/timeout not credited as detection", q06_crash_timeout),
    ("Q07", "benign blocking not rewarded", q07_benign_block),
    ("Q08", "reject-all degeneracy (production M11)", q08_reject_all),
    ("Q09", "constant-output distinction failure", q09_constant_output),
    ("Q10", "A1/A2 config mismatch (fairness)", q10_fairness_mismatch),
    ("Q11", "forbidden file in guard inventory", q11_isolation),
    ("Q12", "structural tamper w/ regenerated checksum", q12_structural_tamper),
    ("Q13", "missing performance repetition", q13_perf_repetition),
    ("Q14", "zero denominator / N/A", q14_denominator),
    ("Q15", "runner interrupted/valid-resume/invalid-resume", q15_runner_integrity),
]


def main():
    results = []
    for qid, name, fn in CHECKS:
        try:
            ok, reason = fn()
        except Exception as e:
            ok, reason = False, "EXCEPTION: %r" % (e,)
        results.append({"id": qid, "name": name, "pass": bool(ok), "reason": reason})
    out = RESULTS / "qa_integrated_results.json"
    out.write_text(json.dumps({"checks": results, "passed": sum(1 for r in results if r["pass"]),
                               "total": len(results)}, indent=2, sort_keys=True) + "\n",
                   encoding="utf-8", newline="\n")
    print(json.dumps({"passed": sum(1 for r in results if r["pass"]), "total": len(results),
                      "fails": [r for r in results if not r["pass"]]}, indent=2))


if __name__ == "__main__":
    sys.exit(main())