"""P04-B resumable, fail-closed runner with integrity binding (F16).

Binds observations to run_id + plan digest. Rejects duplicate/unexpected keys and incompatible
run metadata on resume. Returns COMPLETE only when the exact expected plan is satisfied. Explicit
failed-observation records (INTERNAL_ERROR/TIMEOUT) are written, never silently dropped.
"""
import hashlib
import json
import os
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutTimeout

_OBS_REQUIRED = ("evaluation_unit_id", "arm", "decision")


class PlanMismatch(Exception):
    pass


def _plan_digest(keys):
    payload = json.dumps(sorted(keys), separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


class Runner:
    def __init__(self, out_path, run_id, plan_items, key_fn, run_meta=None, timeout_s=None):
        self.out_path = out_path
        self.run_id = run_id
        self.plan_items = list(plan_items)
        self.key_fn = key_fn
        self.keys = [key_fn(i) for i in self.plan_items]
        if len(set(self.keys)) != len(self.keys):
            raise PlanMismatch("expected plan has duplicate keys")
        self.key_set = set(self.keys)
        self.plan_digest = _plan_digest(self.keys)
        self.run_meta = run_meta or {}
        self.timeout_s = timeout_s
        self.existing = {}
        mode = "a" if os.path.exists(out_path) else "w"
        if mode == "a":
            self._load_and_validate()
        self.fh = open(out_path, mode, encoding="utf-8")

    def _load_and_validate(self):
        with open(self.out_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                key = rec.get("_key")
                if key is None:
                    raise PlanMismatch("existing record without _key")
                if key in self.existing:
                    raise PlanMismatch("duplicate key in existing: %s" % key)
                if key not in self.key_set:
                    raise PlanMismatch("unexpected key not in plan: %s" % key)
                if rec.get("_run_id") != self.run_id:
                    raise PlanMismatch("incompatible run_id for %s" % key)
                if rec.get("_plan_digest") != self.plan_digest:
                    raise PlanMismatch("incompatible plan digest for %s" % key)
                for fld in _OBS_REQUIRED:
                    if fld not in rec:
                        raise PlanMismatch("schema violation (%s) for %s" % (fld, key))
                self.existing[key] = rec

    def _invoke(self, run_fn, item):
        if self.timeout_s is None:
            return run_fn(item)
        with ThreadPoolExecutor(max_workers=1) as ex:
            fut = ex.submit(run_fn, item)
            try:
                return fut.result(timeout=self.timeout_s)
            except FutTimeout:
                return {"decision": "TIMEOUT", "timeout": True, "evaluation_unit_id":
                        item[0] if isinstance(item, (tuple, list)) else str(item), "arm":
                        item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else "UNKNOWN"}

    def run(self, run_fn):
        error = None
        failed = False
        for item in self.plan_items:
            key = self.key_fn(item)
            if key in self.existing:
                continue
            try:
                rec = self._invoke(run_fn, item)
            except Exception as exc:  # fail-closed
                failed = True
                error = "%s: %r" % (key, exc)
                rec = {"decision": "INTERNAL_ERROR", "runtime_error": True,
                       "evaluation_unit_id": item[0] if isinstance(item, (tuple, list)) else str(item),
                       "arm": item[1] if isinstance(item, (tuple, list)) and len(item) > 1 else "UNKNOWN",
                       "error": error}
            rec["_key"] = key
            rec["_run_id"] = self.run_id
            rec["_plan_digest"] = self.plan_digest
            self.fh.write(json.dumps(rec, sort_keys=True) + "\n")
            self.fh.flush()
            self.existing[key] = rec
            if failed:
                break
        self.fh.close()
        missing = [k for k in self.keys if k not in self.existing]
        status = "COMPLETE" if (not failed and not missing) else ("FAILED" if failed else "PARTIAL")
        return {"status": status, "error": error, "rows": len(self.existing),
                "expected": len(self.key_set), "missing": missing}