"""P04 raw observation schema, structured guard events, shared decision vocabulary."""

DECISION_VOCABULARY = ["ALLOW", "BLOCK", "QUARANTINE", "NOT_APPLICABLE", "INTERNAL_ERROR", "TIMEOUT"]

# Structured guard event (F11): one event per detector execution. Preserved separately for A2.
GUARD_EVENT_FIELDS = [
    "detector", "guard_execution_id", "build_id", "deployment_id", "evaluation_unit_id",
    "executed", "applicable", "active_pid", "active_cd", "expected_pid", "expected_cd",
    "alarm_emitted", "alarm_type", "alarm_stage", "decision", "decision_reason",
]


def make_guard_event(**kw):
    ev = {f: None for f in GUARD_EVENT_FIELDS}
    ev.update({"executed": False, "applicable": False, "alarm_emitted": False})
    ev.update(kw)
    return ev


OBSERVATION_FIELDS = [
    "evaluation_unit_id", "unit_type", "arm", "run_id", "mutation_instance_id",
    "input_digest", "batch_digest", "active_pid", "active_cd", "expected_pid", "expected_cd",
    "engine_digest", "build_id", "deployment_id", "guard_events", "guard_applicable",
    "admission_status", "admission_reason", "canonical_digest", "canonical_bytes_hex",
    "leaf_digest", "leaf_digests", "internal_nodes", "batch_status", "root_digest",
    "admitted", "rejected", "abstained", "leaf_count",
    "alarm_emitted", "alarm_type", "alarm_stage", "decision", "decision_reason",
    "artifact_released", "runtime_error", "timeout", "downstream_executed", "outcome_class",
]

STAGES = ["L0", "L1", "L2", "L3", "L4", "L5", "L6", "L7"]


def empty_observation(**overrides):
    obs = {f: None for f in OBSERVATION_FIELDS}
    obs.update({
        "guard_events": [], "guard_applicable": False, "alarm_emitted": False,
        "artifact_released": False, "runtime_error": False, "timeout": False,
        "downstream_executed": False, "decision": "NOT_APPLICABLE",
    })
    obs.update(overrides)
    return obs