"""P04-B production verifier primitives (F12/F13/F16). Used by the production runner and
integrated QA. Each returns {ok: bool, ...specific reasons...}."""
import hashlib


def verify_membership(observations, expected_keys):
    seen = {}
    dups = []
    unexpected = []
    expected = set(expected_keys)
    for o in observations:
        k = (o["evaluation_unit_id"], o["arm"])
        if k in seen:
            dups.append(k)
        seen[k] = True
        if k not in expected:
            unexpected.append(k)
    missing = [k for k in expected_keys if k not in seen]
    return {"ok": not dups and not unexpected and not missing,
            "missing": missing, "duplicates": dups, "unexpected": unexpected}


def verify_schema(obs, required):
    miss = [f for f in required if f not in obs]
    return {"ok": not miss, "missing_fields": miss}


def verify_oracle_digest(artifact_bytes, expected_sha):
    h = hashlib.sha256(artifact_bytes).hexdigest()
    return {"ok": h == expected_sha, "got": h, "expected": expected_sha}


def structural_verify(obs):
    r = []
    d = obs.get("decision")
    rel = obs.get("artifact_released")
    if d == "ALLOW" and rel is False:
        r.append("ALLOW but artifact_released is False")
    if d in ("BLOCK", "QUARANTINE") and rel is True:
        r.append("BLOCK/QUARANTINE but artifact released")
    if obs.get("alarm_emitted") and not obs.get("alarm_type"):
        r.append("alarm_emitted without alarm_type")
    if obs.get("runtime_error") and d == "ALLOW":
        r.append("runtime_error but decision ALLOW")
    if obs.get("timeout") and rel is True:
        r.append("timeout but artifact released")
    return {"ok": not r, "reasons": r}


def verify_isolation(inventory, forbidden):
    leaked = [f for f in inventory for x in forbidden if f == x or f.startswith(x)]
    return {"ok": not leaked, "leaked": leaked}


def verify_perf_inventory(rows, plan):
    have = {(r["arm"], r["batch_size"], r["repetition"], r["warmup"]) for r in rows}
    need = {(p["arm"], p["batch_size"], p["repetition"], p["warmup"]) for p in plan}
    missing = sorted(need - have)
    extra = sorted(have - need)
    return {"ok": (not missing and not extra), "n_missing": len(missing),
            "n_extra": len(extra), "missing_sample": missing[:8]}