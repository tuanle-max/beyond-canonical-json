# P04 Baseline Fairness (R2)

A1..A2 share: identical input bytes, contract, parser, typed transformation, JCS library, construction
algorithm, batch descriptor, fault mutation, runtime env, auxiliary inputs, resource limits. Only the
evaluated assurance mechanism(s) differ. Shared fault condition established BEFORE invoking arms; A2 never
receives a weaker mutation than A1. Guards are NOT given fault identifiers/labels/expected outcomes. Expected
identities provisioned to the identity guard are allowed configuration inputs; the evaluator answer key is not.

Machine-verifiable fairness record: per unit, assert equal (input_sha256, pid, cd, batch order, mutation id,
env hash) across applicable arms; material violation = process-gate FAIL.
