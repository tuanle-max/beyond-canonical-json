# P04 Preregistration Changelog (R2 vs R1 @3dc1dee7)

- Cardinality fixed: exactly 100 = 60 fault + 40 benign; 4 groups 15+10; benign ARE the 40 (no extra set).
- Added alarm-emission contract + decision vocabulary + guard lifecycle (identity=config/batch; CI=build/deploy, no per-record runtime credit).
- Added fault activation vs detection separation (planned vs activated denominators; inactive faults retained).
- Added prospective detector applicability; N/A for absent detectors.
- Added D_DEV/D_CI/D_HIST/D_EVAL/D_PERF separation + exposure chronology + answer-key isolation.
- Added statistical caveats (purposive/template-correlated; no population inference).
- Added performance boundary separation (3 warmup + 10 measured; 120 measured/36 warmup).
- Added source-freeze attestation + arm configuration + readiness gate matrix.
- No measured execution; no P03 rerun; P07 F01-F05 remain OPEN.
