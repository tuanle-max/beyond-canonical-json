# P04 Experimental Protocol (R2, preregistration)

RQ-P04: measurable incremental assurance from identity validation + regression guards beyond an identical
typed-normalization + JCS pipeline. Separates: semantic correctness, identity/config consistency, regression
detection, emitted alarms, blocking/quarantine, passive divergence, overhead. A manifest digest does NOT prove
code correctness; a finite CI suite is NOT universal correctness; a supplied expected identity is NOT an
authenticated checkpoint (P05).

Arms: A0 raw-JCS diagnostic; A1 strong matched baseline (=frozen P03 engine); A1+PID identity guard;
A1+CI regression guard; A2 both guards; N0 reject-all; N1 constant-output.

Measured corpus (frozen before execution): exactly 100 units = 60 fault + 40 benign; 4 groups (G1 profile,
G2 construction, G3 semantic regression, G4 encoding/batch), each 15 fault + 10 benign. The 40 benign ARE the
benign portion (no extra benign set). Purposive, not random production sampling.

Stages: P04-A protocol (this), B harness/guards (gated), C corpus freeze, D measured (gated),
E performance, F independent aggregation, G manuscript handover. Measured execution NOT authorized here.
