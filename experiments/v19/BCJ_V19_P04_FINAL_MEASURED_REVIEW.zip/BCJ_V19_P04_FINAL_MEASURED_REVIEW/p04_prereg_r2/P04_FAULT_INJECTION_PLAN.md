# P04 Fault Injection Plan (R2)

One-factor behavioral/config mutations (never expected-file edits). Per fault record: injected, activated,
divergence, identity-detector-applicable, ci-detector-applicable, alarm-emitted, release-prevented,
earliest-stage. Distinguish declared-identity changes (manifest-visible) from executable drift under an
unchanged declaration (NOT auto-detectable by identity comparison). G1 profile, G2 construction, G3 semantic
(rounding/temporal/unicode/alias/null/admission), G4 encoding+batch (serialization, leaf, order, multiplicity,
topology, inclusion/omission). Faults outside CI coverage are legitimate misses. D_EVAL answer key never
exposed to guards.
