# P04 Hypotheses (R2)

H1 guards do not change correct canonical/commitment outputs on valid unchanged context.
H2 A1+PID/A2 detect applicable semantic-profile identity inconsistencies.
H3 A1+PID/A2 detect applicable construction identity inconsistencies.
H4 A1+CI/A2 detect regressions exercised by frozen CI vectors (no claim beyond coverage).
H5 A2 improves paired end-to-end correctness / unsafe-release prevention vs A1.
H6 assurance preserves benign service (no inappropriate blocking).
H7 mechanisms add measurable cost with bounded diagnostics.
Hypothesis support is NOT a condition for process completion. Negative results retained. No statistical
equivalence/non-inferiority from zero observed benign differences.
