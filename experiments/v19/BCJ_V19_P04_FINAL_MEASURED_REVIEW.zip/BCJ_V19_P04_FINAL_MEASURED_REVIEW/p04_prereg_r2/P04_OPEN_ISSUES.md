# P04 Open Issues (R2)

- Measured execution NOT authorized (P04-B/C/D/E gated).
- Alarm contract: guards emit explicit alarm record + BLOCK/QUARANTINE; CI guard is build/deploy-time (no per-record runtime alarm claim).
- Holdout: D_EVAL answer key never exposed to guards; chronology frozen before execution.
- Performance: config/build/per-batch/end-to-end separate; no CI amortization without stated frequency.
- P07 F01-F05 OPEN_MANDATORY (transferred; NOT resolved in P04).
- A0 confined to JCS-domain characterization only (not superiority comparator).
