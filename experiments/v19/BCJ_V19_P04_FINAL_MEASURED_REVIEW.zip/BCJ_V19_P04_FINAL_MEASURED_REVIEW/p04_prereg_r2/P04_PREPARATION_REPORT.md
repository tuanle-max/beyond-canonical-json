# P04-A Preparation Report (R2)

Revised preregistration reconciling R1 ambiguities (cardinality, fairness, alarm contract, guard lifecycle,
fault activation, detector applicability, end-to-end outcomes, holdout separation, statistical assumptions,
performance boundaries, source freeze). Source digests verified unchanged. No measured execution, no perf runs,
no P03 rerun, no P07 remediation, no manuscript change. Status READY_FOR_EXPERIMENT_LEAD_REVIEW.
