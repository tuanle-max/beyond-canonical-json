# P04 Statistical Analysis Plan (R2)

Primary paired A1 vs A2 (exact discordant counts + paired effect). McNemar only with explicit assumption
caveats; workload purposive/template-correlated -> p-values exploratory, NOT population inference. No
independent-Bernoulli claim; no binomial production bounds; zero observed failures != zero failure rate.
Per-family + template sensitivity. Primary vs exploratory ablations separated. Multiplicity preregistered.
No post-hoc significance hunting; no selective reporting.
