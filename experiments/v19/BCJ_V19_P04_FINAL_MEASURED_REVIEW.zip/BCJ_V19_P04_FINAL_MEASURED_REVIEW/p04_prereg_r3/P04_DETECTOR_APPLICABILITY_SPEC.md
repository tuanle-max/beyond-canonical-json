# P04 Prospective Detector Applicability (F04)

Applicability is defined PROSPECTIVELY by the declared detector contract, before measured execution.
It is never assigned retrospectively from whether a detector happened to succeed.

## Declared detector contracts

### Identity detector (A1+PID, A2)
- Applicable iff the fault is manifest-visible: the active config-time semantic-profile identity or
  construction identity (recomputed from the manifest contents actually in effect) differs from the
  evaluator-provisioned expected identity.
- Covered classes: changed declared profile with recomputed manifest; stale/wrong profile identity;
  changed leaf domain separator, construction manifest, or tree policy when the change is
  manifest-visible.
- NOT applicable when the declared identity is unchanged but the executable behavior has drifted
  (hidden executable drift is not detected by identity comparison).

### CI regression detector (A1+CI, A2)
- Applicable iff the fault is exercised by a frozen, guard-visible CI regression vector.
- NOT applicable to regressions outside the frozen CI coverage (a legitimate miss, reported as such).

## Fault categorization matrix

| class | identity_applicable | ci_applicable | example |
|-------|---------------------|---------------|---------|
| manifest-visible semantic mismatch | yes | no | semantic manifest artifact changed + recomputed pid |
| manifest-visible construction mismatch | yes | no | leaf domain separator tainted in construction manifest |
| hidden executable drift (unchanged identity) | no | conditional | semantic transform mutated, identity reused |
| CI-exercised regression | conditional | yes | rounding/unicode/encoding mutation under a frozen CI vector |
| regression outside CI coverage | no | no | novel one-factor regression not in CI vectors |
| benign configuration | no | no | legitimate alternative representation, correct identities |

The identity detector may not be applied to hidden executable drift; the CI detector may not be
applied to unexercised regressions. A detector absent from an arm yields N/A detector-specific metrics.

## Reporting (denominators)

- Overall fault detection: detected faults / all injected faults (planned denominator).
- Activated-fault detection: detected / activated faults (activated denominator).
- Applicable detector-specific recall: TP / (TP + FN) over units where the detector is prospectively
  applicable.
- Benign false-positive rate: FP / (FP + TN) over benign units where the detector executed.
- Common end-to-end prevention: prevented incorrect releases / units requiring prevention (M10).

Inactive and unresolved mutations are retained and reported; they are never silently discarded.