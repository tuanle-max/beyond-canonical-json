# P04 Holdout and Isolation Plan (F05)

## Dataset separation

| set | contents | accessible to |
|-----|----------|---------------|
| D_DEV | development and smoke fixtures (deterministic, small) | guard/development workspace |
| D_CI | frozen, guard-visible regression vectors + expected outcomes | guard-development workspace (provisioned) |
| D_HIST | historical P00–P03 evidence (read-only, frozen) | both (read-only reference) |
| D_EVAL | the 100 primary evaluator-controlled measured units + evaluator-only answer key | evaluator workspace ONLY |
| D_PERF | performance workloads (separate from the 100 presided units) | reserved for P04-E |

## Workspace and allowlist separation

- Guard-development workspace (`p04_implementation/`): may access the normative contract, D_DEV, and
  authorized D_CI material. It MUST NOT access evaluator-only measured expected outcomes (D_EVAL answer
  key, fault labels, expected digests).
- Evaluator workspace (`p04_evaluator/`): owns D_EVAL membership, fault labels, expected outcomes; does
  not expose them to the development workspace.
- Isolation is procedural (separate directories + explicit file allowlists), not OS-enforced; it is NOT
  independent authorship and is not claimed as such.

## Freeze chronology

1. Freeze guard source and D_CI vectors BEFORE exposing any D_EVAL content to the guard workspace.
2. Freeze D_EVAL membership, fault labels, and expected behavior BEFORE executing measured arms.
3. Record actual hashes and git commit identity at each freeze point (`P04_SOURCE_BINDING.json`).

## Exposure audit

For each family, record: exact-input overlap, canonical-representation overlap, reused template overlap,
mutation-operator overlap, and exposure chronology (what was visible to the guard workspace and when).
Distinguish exact unseen records from unseen fault mechanisms.

## Leakage policy

If holdout exposure occurs, preserve it and downgrade the corresponding claim to regression evidence
(out-of-sample generalization is not claimed). The holdout is never silently regenerated after
inspecting unfavorable results.