# P04 Lifecycle and Analysis Units (F02)

## Analysis-unit identifiers

Every measured observation is annotated with the following identifiers so that the four
conceptually distinct counting units are never conflated:

- `mutation_instance_id`: identifies a single injected mutation (one-factor behavioral or
  configuration change) applied to a specific arm workspace. One mutation may be reused across
  groups but is assigned a distinct instance id per injected workspace.
- `build_id`: identifies a CI-guard build execution over a frozen (possibly mutated) implementation.
  Unique per (mutation_instance_id, arm).
- `deployment_id`: identifies one deployment action that is gated by the CI guard result. A failed
  build produces no deployment; a passed build produces at most one deployment.
- `guard_execution_id`: identifies a unique execution of the identity guard or the CI guard.
  Unique per (arm, evaluation_unit_id, guard).
- `evaluation_unit_id`: identifies a single evaluation unit (one record or one batch) in the frozen
  100-unit measured corpus.

## Guard lifecycle boundaries

- Identity guard: executes at configuration/batch time, per batch. It compares the active
  semantic-profile and construction identities (recomputed from the manifest contents in effect)
  against the evaluator-provisioned expected identities. A mismatch is an emitted alarm with an
  explicit `BLOCK`/`QUARANTINE` decision. There is one `guard_execution_id` per batch per arm.
- CI regression guard: executes at build/deployment time against the actual mutated implementation.
  A CI failure is a build-level detection: it emits a build/deployment decision (`BLOCK`) and no
  deployment occurs. It does NOT emit a per-record runtime alarm. There is one `guard_execution_id`
  per (build_id). It is not counted once per downstream record.

## Counting rules (no double counting)

- A single build-level CI detection is scored exactly once (at the build/deployment level); it is
  never multiplied by the number of downstream records or batches.
- Downstream `admission_status`, `leaf_digest`, `batch_status`, and `root_digest` for a
  deployment-blocked arm are recorded as `NOT_EXECUTED` (or `null`), never as fabricated rejection
  outcomes.
- `guard_execution_id` is the unit of analysis for detector confusion matrices (M06–M09), not the
  number of records.
- `evaluation_unit_id` is the unit of analysis for end-to-end release decisions (M01–M05, M10–M12).

## Guard execution target

The CI guard MUST execute its frozen regression vectors against the actual mutated implementation
(or mutated configuration), never against the original unmutated engine. A guard that always tests
the pristine engine would trivially "pass" every injected mutation and is recorded as a QA defect.