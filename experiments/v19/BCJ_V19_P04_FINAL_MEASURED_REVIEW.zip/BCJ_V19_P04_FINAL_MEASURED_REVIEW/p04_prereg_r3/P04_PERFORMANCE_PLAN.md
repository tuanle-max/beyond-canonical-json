# P04 Performance Plan (F06) — FROZEN SPECIFICATION

No measured performance execution is performed in this invocation. This specifies the frozen plan
for P04-E (gated).

## Workload

- Batch sizes (records per batch): `100`, `1000`, `5000`.
- Runs per (arm, size): 3 warm-up repetitions + 10 measured repetitions.
- Total measured observations: 120 (4 arms × 3 sizes × 10).
- Total warm-up observations: 36 (4 arms × 3 sizes × 3).

## Arms

`A1`, `A1+PID`, `A1+CI`, `A2` (primary matched arms). Workload is identical across arms.

## Execution protocol

- Order: randomized or balanced alternating execution with frozen seed `42`.
- Timer: `time.perf_counter_ns()` around the measured region (warm-up excluded).
- Peak memory: `tracemalloc` (Python) peak during the measured region, reported per arm/size.
- Process startup: recorded separately; cold-start and steady-state measurements are separated if
  relevant. The default measured region excludes process interpreter startup (call-level timing);
  a second cold-start run records interpreter startup where the architecture would pay it.
- Hardware/runtime: CPU model, total RAM, OS, Python version, and dependency versions are captured in
  `environment.json` at execution time.

## Cost separation

Four costs are measured and reported separately, never amortized without stating the assumed frequency:

1. One-time configuration checks (identity recomputation, manifest load).
2. Build/deployment-time regression (CI) checks.
3. Per-batch runtime guard cost.
4. Common pipeline execution (parse → typed → JCS → leaf → root).

## Raw measurement schema

One row per measured repetition: `arm, batch_size, repetition, warmup(bool), duration_ns, peak_memory_bytes,
process_startup_included(bool), config_check_ns, ci_check_ns, runtime_guard_ns, pipeline_ns`.

## Exclusion and failure policy

- No measured run is discarded without a preregistered exclusion rule.
- A run is excluded only on a documented hardware/environment fault (recorded, not silently dropped).
- A guard or pipeline failure during a measured run is recorded as a failure, not discarded.