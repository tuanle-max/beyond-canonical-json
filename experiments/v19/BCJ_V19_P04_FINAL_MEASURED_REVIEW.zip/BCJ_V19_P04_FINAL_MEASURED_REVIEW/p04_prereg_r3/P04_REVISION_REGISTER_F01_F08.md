# P04-A Targeted Correction Register (R3)

Revision register for F01–F08, produced under Experiment Lead directive (CR-0011, option b).
Base preregistration: P04-A R2 (commit `1c88fa9e4a466f70e539b0d92fc2de7598a340f9`).
R2 scientific design is ACCEPTED; protocol freeze is CONDITIONAL on the F01–F08 corrections below.

| ID | Topic | Correction | Deliverable | Status |
|----|-------|------------|-------------|--------|
| F01 | Full matched-arm coverage | Each of A1, A1+PID, A1+CI, A2 executes all 100 units (60 fault + 40 benign). Primary arm-unit observations = 400. Corpus remains exactly 100 unique units. Detector applicability is independent of arm execution coverage. A0/N0/N1 are controls excluded from the 400. | `P04_TEST_MATRIX.R3.csv` | DONE |
| F02 | CI lifecycle + analysis units | Define `mutation_instance_id`, `build_id`, `deployment_id`, `guard_execution_id`, `evaluation_unit_id`. Separate unique CI guard executions, build-level detection, deployment blocking, and downstream record/batch release prevention. A build-level detection is not multiplied by downstream records. CI guard executes against the actual mutated implementation, not the unmutated engine. | `P04_LIFECYCLE_AND_ANALYSIS_UNITS.md` | DONE |
| F03 | Common end-to-end decision oracle | Enumerate expected/observed decision combinations; single `end_to_end_correct` indicator for paired A1/A2. Alarm without prevention gets no blocking credit; crash/timeout are not successful detection/block; a deployment-blocked path records downstream stages `NOT_EXECUTED`. | `P04_DECISION_TRUTH_TABLE.csv` | DONE |
| F04 | Prospective detector applicability | Applicability from declared detector contract before execution. Distinguish manifest-visible semantic/construction mismatch, hidden executable drift, CI-exercised regression, outside-coverage regression, benign configuration. Report planned vs activated denominators. | `P04_DETECTOR_APPLICABILITY_SPEC.md` | DONE |
| F05 | Holdout + exposure control | D_DEV/D_CI/D_HIST/D_EVAL/D_PERF separation; separate guard-development and evaluator workspaces; allowlists + inventories; freeze guard source + D_CI before D_EVAL; overlap audit + exposure chronology; leakage ⇒ downgrade claim. | `P04_HOLDOUT_ISOLATION_PLAN.md` | DONE |
| F06 | Performance specification | Freeze sizes/arms/warmup/measured/counts/seed/timer/memory/startup/hardware/schema/exclusion policy. Separate one-time config, CI deploy, runtime guard, common pipeline cost. No measured runs in this invocation. | `P04_PERFORMANCE_PLAN.md` | DONE |
| F07 | Protocol artifact binding | Replace descriptive source references with immutable references (git blob SHA-1 + frozen SHA-256 + commit). Bind corrected artifacts with SHA-256. No placeholder hashes. | `P04_SOURCE_BINDING.json` | DONE |
| F08 | Structured metric dictionary | Each metric carries `metric_id/name/numerator/denominator/unit_of_analysis/applicable_arms/applicability_rule/aggregation_level/missing_policy/zero_denominator_policy`; paired effect `(A2_only − A1_only) / N`. Validated with PyYAML. | `P04_METRIC_DICTIONARY.yaml` | DONE |

Scope discipline: no measured evaluation, no measured performance runs, no P03 rerun, no P07 remediation,
no manuscript modification were performed under this register.