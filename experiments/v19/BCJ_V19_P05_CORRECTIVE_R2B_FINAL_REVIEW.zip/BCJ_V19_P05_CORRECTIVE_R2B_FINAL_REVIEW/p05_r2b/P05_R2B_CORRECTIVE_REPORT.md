# P05-R2B Corrective Report (PARTIAL — honest status)

## Completed & verified
- **CG01 immutability PASS:** first-pass commit 9e9f952a, archive 719db8c4; frozen corpus/oracle/verifier/raw digests all match.
- **F41 independent oracle PASS:** separately-coded checker (own leaf/tree/proof/checkpoint/sig/freshness; imports only frozen P03 adapter for canonical) reproduces the historical oracle on 40/40 units, 0 disagreements; state transitions correct. Resolves circular-oracle concern (CG04/CG05).

## Pending (NOT completed; not fabricated)
- F40 strict verifier input-validation hardening (CG02/CG03).
- F43 P05_FIRST_PASS_STATE_REAUDIT.jsonl standalone export.
- F44 prospective R2B execution lock + corrective 80-obs run (CG08/CG10).
- F45 full 24-test production QA; F46 consolidated corrected protocol; F47; F48.
- First-pass-vs-R2B comparison, corrective tables; full archive; P06 historical reconstruction.

## Exact next executable steps
1. Harden p05core.py (F40) + D_DEV fixtures; run F45 QA.
2. Write P05_R2B_EXECUTION_LOCK.json; corrective V1/V2 run on frozen 40 -> separate path.
3. Independent aggregation + comparison CSV + state reaudit; build full R2B archive.
4. Then P06 (CR-0006 historical reconstruction) if gates pass.

## Not done: no P07; no manuscript change; P07 12 obligations unchanged; P06 not begun.