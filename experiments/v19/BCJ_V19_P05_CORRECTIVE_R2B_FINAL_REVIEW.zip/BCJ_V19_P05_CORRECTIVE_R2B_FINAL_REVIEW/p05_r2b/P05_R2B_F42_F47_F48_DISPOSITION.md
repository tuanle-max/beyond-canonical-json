# P05-R2B Disposition: F42, F47, F48 (and F46 note)

## F42 — Restricted G3/G4 terminology (DONE)
G3 fixtures are **unauthorized declared semantic-profile identifiers**; G4 fixtures are **unauthorized declared
construction identifiers**. The structural verifier treats these full-length identifiers as commitment-bound
metadata while using the frozen K-v2/v3 engine. We do NOT claim these fixtures implement alternative normative
semantic contracts or alternative cryptographic commitment algorithms; no additional semantic engine or
construction is introduced.

## F46 — Consolidated corrected normative R2B specification (RETROSPECTIVE; PARTIAL)
The R1 specification set (p05_prereg_r1/) is preserved unchanged. The consolidated R2B set (verification
contract, checkpoint schema, trust provisioning, freshness/replay, 40-unit inventory, expected outcomes,
metric dictionary, statistical plan, oracle spec) is documented by the R1 documents plus the R2B revision
register F31–F39 and this continuation's F40–F48 closure. This is **retrospective** documentation; it was NOT
frozen before the original first-pass measured run. Not all consolidated artifacts are fully re-authored here;
the authoritative machine artifacts are the frozen corpus/oracle and the independent checker.

## F47 — Synthetic signing-key separation (DONE)
The verifier execution interface receives only public artifacts: envelopes with `signer_public_key` (public),
signatures, checkpoints, and trusted contexts. Private signing keys are **not** in the verifier corpus and are
**not** imported at verification time. Deterministic synthetic Ed25519 keys are reconstructible by a researcher
holding the fixture-generation code (`p05_evaluator/p05_corpus.py`, seed "P05-R2A-SEED-42") — this is stated
plainly. No OS-enforced isolation and no production-grade key custody is claimed.

## F48 — Reproducibility dependency closure (PARTIAL)
Frozen P03 adapter bound: `experiments/v19/implementations/python-dev/boo.py` (frozen python source SHA-256
`2b692401…`); not modified. Actual dependency versions recorded: Python 3.12.9, cryptography 50.0.2, rfc8785
0.1.3, PyYAML 6.0.4. A standalone extracted-package execution was NOT performed in this invocation; the
remaining clean-room execution requirement is carried to P07 (not silently closed).
