# P05-R2B Results Narrative (corrective: 40 units x 2 arms = 80 observations)

Label: POST_EXPOSURE_REGRESSION_VALIDATION. Hardened verifier (p05core_r2b.py), frozen corpus.

- V1 (structural) common-objective: 15/40; own structural contract 40/40.
- V2 (structural + trusted Ed25519 reference): 40/40.
- Paired: both=15, V1_only=0, V2_only=25, both_incorrect=0, effect=0.625.
- Authorized acceptance 11/11 both arms; structurally-valid-unauthorized accept V1 25 / V2 0; coordinated substitution V1 6 / V2 0.
- Exact state transitions 39/39 applicable (+1 N/A); reason agreement 80/80; errors 0.
- First-pass vs R2B: 80 keys, 0 differences (regression agreement).

Interpretation: authenticated reference verification prevents acceptance of internally consistent but unauthorized evidence that structural verification accepts. V1 acceptance of unauthorized-but-consistent evidence satisfies V1's own contract (not a defect). No universal-security / compromised-signer / production-prevalence / third-party claim.
