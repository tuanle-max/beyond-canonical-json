# P05 Normative R2B Specification (consolidated; RETROSPECTIVE)

RETROSPECTIVE: authored after the first-pass run; frozen prospectively FOR the R2B corrective run only.
R1 (p05_prereg_r1/) preserved unchanged.

## Verification contract
V1 structural (schema, v3 construction, record->leaf via frozen K-v2, RFC9162 path, root). V2 = V1 + independent TrustedVerificationContext (publisher, authorized checkpoint id, batch/pid/cd/tree_size), Ed25519 over DOMAIN_SEP||JCS(checkpoint), evidence-to-checkpoint consistency, sequence freshness. Shared structural verifier.

## Checkpoint
version '1'; fields checkpoint_version/checkpoint_id/publisher_id/semantic_profile_digest/construction_digest/root/batch_id/tree_size/checkpoint_sequence; lowercase hex; JCS; DOMAIN_SEP=b'BCJ-V19-P05-CHECKPOINT\x00\x01'.

## Trust / freshness / replay
Independent trust store; envelope key never establishes trust; seq floor + last seq/id/digest; replay = equal seq+id+digest -> idempotent ACCEPT; equal-seq conflict -> SEQUENCE_CONFLICT; lower -> STALE_SEQUENCE; state advances only on full accept.

## Inventory / metrics / oracle
40 units (11 authorized: G1 10 + G8-02 replay; 29 adverse). Common objective: accept iff authorized. M01-M13. State applicable=39, N/A=1 (missing state). Oracle = independent checker (frozen P03 adapter for canonical only); reason codes decision-level only (limitation).
