# P05-R2B Threats to Validity

- Purposive synthetic 40-unit corpus; no production attack prevalence.
- Same-team post-exposure corroboration; NOT third-party replication.
- Compromised signer/provisioning out of scope; sequence-only freshness.
- Reason codes decision-level only (not independently reconstructed).
- F48 standalone extraction deferred to P07.
