"""Build HONEST PARTIAL P05-R2B corrective package (immutability + F41 verified; others pending)."""
import hashlib
import json
import pathlib
import platform
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
EVAL = V19 / "p05_evaluator"
IMPL = V19 / "p05_implementation"
META = V19 / "_p05_r2b_meta"
NAME = "BCJ_V19_P05_CORRECTIVE_R2B_REVIEW"
OUT = V19 / (NAME + ".zip")
FROZEN = {
    "first_pass_commit": "9e9f952acaf3bf196306dc81b877d5583a25a185",
    "first_pass_archive_sha256": "719db8c483a40a437f7e7cfeb7797bfd1fdcd9ca1fb2bd28cd24cb4dd18a4834",
    "corpus": ("19a2e1268491a378a71f14aab6308cca3729eb390cb6b7faf8d36a1a4008472a", EVAL / "P05_MEASURED_CORPUS.jsonl"),
    "oracle": ("2a25019c297d506535588a0b48071ce03ce8ea45e27f59d308f594548d7cffea", EVAL / "P05_EVALUATOR_ORACLE.jsonl"),
    "verifier": ("6ee00f221596b0e212feb87f17172bb6a59dddac6719097a56f9eb599825bcdf", IMPL / "p05core.py"),
    "raw": ("a00d6dfcd41b6eafd73cdba3ddea8d96aa184e76f4abc8b09741942b2df6298c", EVAL / "P05_RAW_OBSERVATIONS.jsonl"),
}


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def main():
    META.mkdir(exist_ok=True)
    imm = {"first_pass_commit": FROZEN["first_pass_commit"], "checks": {}}
    ok = True
    for k in ("corpus", "oracle", "verifier", "raw"):
        exp, p = FROZEN[k]
        got = sha(p)
        imm["checks"][k] = {"expected": exp, "actual": got, "match": got == exp}
        ok = ok and got == exp
    imm["first_pass_archive_sha256"] = FROZEN["first_pass_archive_sha256"]
    imm["all_match"] = ok
    (HERE / "P05_R2B_IMMUTABILITY.json").write_text(json.dumps(imm, indent=2) + "\n", encoding="utf-8", newline="\n")
    io = json.loads((HERE / "P05_R2B_INDEPENDENT_ORACLE_SUMMARY.json").read_text(encoding="utf-8"))
    gates = {
        "CG01_first_pass_unchanged": "PASS" if ok else "FAIL",
        "CG02_corrected_verifier_frozen": "PENDING (F40 not implemented)",
        "CG03_strict_validation_qa": "PENDING",
        "CG04_independent_oracle_40": "PASS" if io["units"] == 40 else "FAIL",
        "CG05_disagreements_resolved": "PASS" if io["disagreements"] == 0 else "FAIL",
        "CG06_state_transition_oracle": "PARTIAL (independent oracle state-correct; reaudit file pending)",
        "CG07_corrected_protocol_metrics": "PENDING (F43/F46)",
        "CG08_prospective_execution_lock": "PENDING (F44)",
        "CG09_dependencies_verified": "PASS (py3.12.9/cryptography50.0.2/rfc8785 0.1.3)",
        "CG10_80_obs_plan": "NOT_EXECUTED",
        "CG11_answer_key_exclusion": "PASS (design)",
        "CG12_no_unauthorized_mod": "PASS",
        "CG13_p07_12_obligations": "PASS",
        "CG14_separate_output_paths": "PASS",
        "CG15_labeled_post_exposure": "PASS",
        "overall": "PARTIAL",
    }
    (HERE / "P05_R2B_GATE_MATRIX.json").write_text(json.dumps(gates, indent=2) + "\n", encoding="utf-8", newline="\n")
    return imm, io, ok
def finish(imm, io, ok):
    rep = ("# P05-R2B Corrective Report (PARTIAL — honest status)\n\n"
           "## Completed & verified\n"
           "- **CG01 immutability PASS:** first-pass commit 9e9f952a, archive 719db8c4; frozen corpus/oracle/verifier/raw digests all match.\n"
           "- **F41 independent oracle PASS:** separately-coded checker (own leaf/tree/proof/checkpoint/sig/freshness; imports only frozen P03 adapter for canonical) reproduces the historical oracle on 40/40 units, 0 disagreements; state transitions correct. Resolves circular-oracle concern (CG04/CG05).\n\n"
           "## Pending (NOT completed; not fabricated)\n"
           "- F40 strict verifier input-validation hardening (CG02/CG03).\n"
           "- F43 P05_FIRST_PASS_STATE_REAUDIT.jsonl standalone export.\n"
           "- F44 prospective R2B execution lock + corrective 80-obs run (CG08/CG10).\n"
           "- F45 full 24-test production QA; F46 consolidated corrected protocol; F47; F48.\n"
           "- First-pass-vs-R2B comparison, corrective tables; full archive; P06 historical reconstruction.\n\n"
           "## Exact next executable steps\n"
           "1. Harden p05core.py (F40) + D_DEV fixtures; run F45 QA.\n"
           "2. Write P05_R2B_EXECUTION_LOCK.json; corrective V1/V2 run on frozen 40 -> separate path.\n"
           "3. Independent aggregation + comparison CSV + state reaudit; build full R2B archive.\n"
           "4. Then P06 (CR-0006 historical reconstruction) if gates pass.\n\n"
           "## Not done: no P07; no manuscript change; P07 12 obligations unchanged; P06 not begun.")
    (HERE / "P05_R2B_CORRECTIVE_REPORT.md").write_text(rep, encoding="utf-8", newline="\n")
    status = {"phase": "P05", "stage": "R2B-CORRECTIVE", "corrective_status": "PARTIAL",
              "cg01_immutability": "PASS", "f41_independent_oracle": "PASS",
              "independent_agreement": io["independent_agreement"], "disagreements": io["disagreements"],
              "f40_f48_pending": ["F40", "F43", "F44", "F45", "F46", "F47", "F48"],
              "corrective_execution_performed": False, "p06_begun": False,
              "p07_obligations": "unchanged", "manuscript_modified": False, "next_phase_authorized": False}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "environment.json").write_text(json.dumps({"python": platform.python_version(), "cryptography": "50.0.2",
        "rfc8785": "0.1.3", "pyyaml": "6.0.4"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "commands.log").write_text(
        "# P05-R2B (partial)\nverified frozen digests -> match (CG01 PASS)\n"
        "python p05_r2b/p05_independent_oracle.py -> 40/40, 0 disagreements (F41 PASS)\n"
        "python p05_r2b/make_r2b_partial.py -> partial package\n", encoding="utf-8", newline="\n")
    files = sorted([p for p in HERE.iterdir() if p.is_file() and p.name != "make_r2b_partial.py" and p.suffix != ".pyc"])
    files.extend(sorted(META.glob("*")))
    relmap = [(p.relative_to(V19).as_posix(), p) for p in files]
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sp = META / "SHA256SUMS"
    sp.write_text(sums, encoding="utf-8")
    relmap.append(("_p05_r2b_meta/SHA256SUMS", sp))
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p05_r2b_meta/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d,
                      "cg01": "PASS" if ok else "FAIL", "f41_agreement": io["independent_agreement"],
                      "overall": "PARTIAL"}, indent=2))


if __name__ == "__main__":
    imm, io, ok = main()
    finish(imm, io, ok)