"""Build HONEST PARTIAL v2 P05-R2B package (adds F43/CG06 + F42/F47/F48 docs; preserves partial)."""
import hashlib
import json
import pathlib
import platform
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
META = V19 / "_p05_r2b_meta_v2"
NAME = "BCJ_V19_P05_CORRECTIVE_R2B_V2_PARTIAL_REVIEW"
OUT = V19 / (NAME + ".zip")


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def main():
    META.mkdir(exist_ok=True)
    rein = json.loads((HERE / "P05_FIRST_PASS_STATE_REAUDIT_SUMMARY.json").read_text(encoding="utf-8"))
    closure = {
        "F40_strict_verifier_hardening": "PENDING",
        "F41_independent_oracle": "DONE (40/40, 0 disagreements)",
        "F42_restricted_G3_G4_terminology": "DONE",
        "F43_exact_state_reaudit": "DONE (state %d/%d exact, %d N/A, 0 mismatch)" % (rein["state_match"], rein["state_applicable"], rein["state_na"]),
        "F44_prospective_execution_lock_and_corrective_run": "PENDING",
        "F45_24_condition_production_QA": "PENDING",
        "F46_consolidated_corrected_spec": "PARTIAL (retrospective)",
        "F47_synthetic_key_separation": "DONE",
        "F48_dependency_closure": "PARTIAL (bound; standalone run deferred to P07)",
        "P06_historical_reconstruction": "BLOCKED (P05 gates not all pass)",
    }
    (HERE / "P05_R2B_F40_F48_CLOSURE_MATRIX.json").write_text(json.dumps(closure, indent=2) + "\n", encoding="utf-8", newline="\n")
    cg = {
        "CG01_first_pass_unchanged": "PASS",
        "CG02_corrected_verifier_frozen": "FAIL (F40 not implemented)",
        "CG03_strict_validation_qa": "PENDING (F45)",
        "CG04_independent_oracle_40": "PASS",
        "CG05_disagreements_resolved": "PASS (0)",
        "CG06_state_transition_oracle": "PASS (exact expected-vs-observed; %d/%d applicable, %d N/A, 0 mismatch)" % (rein["state_match"], rein["state_applicable"], rein["state_na"]),
        "CG07_corrected_protocol_metrics": "PARTIAL (F46 retrospective)",
        "CG08_prospective_execution_lock": "PENDING (F44)",
        "CG09_dependencies_verified": "PASS",
        "CG10_80_obs_plan": "PENDING (corrective run not executed)",
        "CG11_answer_key_exclusion": "PASS (verifier input projection)",
        "CG12_no_unauthorized_mod": "PASS",
        "CG13_p07_12_obligations": "PASS (unchanged)",
        "CG14_separate_output_paths": "PASS (p05_r2b/)",
        "CG15_labeled_post_exposure": "PASS",
        "overall": "PARTIAL (CG02,CG03,CG08,CG10 pending; corrective measured execution NOT authorized; P06 BLOCKED)",
    }
    (HERE / "P05_R2B_GATE_MATRIX_V2.json").write_text(json.dumps(cg, indent=2) + "\n", encoding="utf-8", newline="\n")
    return rein, cg
def finish(rein, cg):
    status = {"phase": "P05", "stage": "R2B-CONT", "corrective_status": "PARTIAL",
              "cg01": "PASS", "cg04": "PASS", "cg05": "PASS", "cg06": "PASS",
              "f43_state": [rein["state_match"], rein["state_applicable"]], "f43_na": rein["state_na"],
              "corrective_execution_authorized": False, "corrective_execution_performed": False,
              "p06_status": "BLOCKED", "p07_obligations": "unchanged", "manuscript_modified": False,
              "next_phase_authorized": False}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "environment.json").write_text(json.dumps({"python": platform.python_version(), "cryptography": "50.0.2",
        "rfc8785": "0.1.3", "pyyaml": "6.0.4"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "commands.log").write_text(
        "# P05-R2B-CONT\npython p05_r2b/p05_r2b_state_reaudit.py -> state %d/%d exact, %d N/A, 0 mismatch (CG06 PASS)\n"
        "python p05_r2b/make_r2b_v2_package.py -> v2 partial package\n" % (rein["state_match"], rein["state_applicable"], rein["state_na"]),
        encoding="utf-8", newline="\n")
    (META / "REPORT.md").write_text(
        "# P05-R2B Continuation (PARTIAL, honest)\n\n## Closed\n- CG01 immutability PASS. - F41 independent oracle PASS (40/40, 0 disagreements).\n"
        "- F43/CG06 exact state reaudit PASS: observed final state == independently expected final state for all 39 applicable V2 units, 1 N/A (missing state), 0 mismatch; initial 40/40; corrects prior accounting. - F42/F47 documented.\n\n"
        "## Pending (not fabricated)\n- F40 verifier hardening (CG02/CG03); F44 prospective lock + corrective 80-obs run (CG08/CG10); F45 24-condition QA; F46 full spec; F48 standalone extraction.\n\n"
        "## Consequence\nMandatory gates CG02/CG03/CG08/CG10 pending -> corrective measured execution NOT authorized; P06 BLOCKED. No P07; no manuscript change; P07 12 obligations unchanged.\n\n"
        "## Next steps\n1. F40 hardened verifier + F45 QA. 2. P05_R2B_EXECUTION_LOCK.json + corrective V1/V2 run (80 obs). 3. Aggregation + first-pass-vs-R2B comparison + full archive. 4. Then P06.\n",
        encoding="utf-8", newline="\n")
    files = sorted([p for p in HERE.iterdir() if p.is_file() and p.name != "make_r2b_v2_package.py" and p.suffix != ".pyc"])
    files.extend(sorted(META.glob("*")))
    relmap = [(p.relative_to(V19).as_posix(), p) for p in files]
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sp = META / "SHA256SUMS"
    sp.write_text(sums, encoding="utf-8")
    relmap.append(("_p05_r2b_meta_v2/SHA256SUMS", sp))
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap),
                "preserves_partial": "BCJ_V19_P05_CORRECTIVE_R2B_REVIEW.zip 4150a108"}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p05_r2b_meta_v2/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d, "cg06": "PASS",
                      "state": "%d/%d +%d N/A" % (rein["state_match"], rein["state_applicable"], rein["state_na"]),
                      "overall": "PARTIAL"}, indent=2))


if __name__ == "__main__":
    a, b = main()
    finish(a, b)