"""F41 independent oracle checker (P05-R2B). Reimplements leaf/tree/proof/checkpoint/sig/freshness;
imports ONLY the frozen P03 semantic adapter (boo.adjudicate) plus cryptography/rfc8785. No p05core import."""
import base64
import hashlib
import importlib.util
import json
import pathlib

import rfc8785
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
EVAL = V19 / "p05_evaluator"
BOO = V19 / "implementations" / "python-dev" / "boo.py"
DOMAIN_SEP = b"BCJ-V19-P05-CHECKPOINT\x00\x01"
HEX = set("0123456789abcdef")


def _boo():
    spec = importlib.util.spec_from_file_location("frozen_boo_r2b", str(BOO))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


_ENG = _boo()


def _canon(raw):
    r = _ENG.adjudicate(raw)
    return (bytes.fromhex(r["canonical_hex"]) if r["decision"] == "ACCEPT" else None)


def _leaf(canon, pid, cd):
    return hashlib.sha256(b"\x00\x03" + bytes.fromhex(pid) + bytes.fromhex(cd) + canon).digest()


def _node(l, r):
    return hashlib.sha256(b"\x01" + l + r).digest()


def _verify_proof(leaf, index, size, path):
    if size <= 0 or index < 0 or index >= size:
        return None
    fn, sn, acc = index, size - 1, leaf
    for sib in path:
        if sn == 0:
            return None
        if (fn & 1) or fn == sn:
            acc = _node(sib, acc)
            while (fn & 1) == 0 and fn != 0:
                fn >>= 1
                sn >>= 1
        else:
            acc = _node(acc, sib)
        fn >>= 1
        sn >>= 1
    return acc if sn == 0 else None


def _pre(cp):
    return DOMAIN_SEP + rfc8785.dumps(cp)


def _sig_ok(pk_hex, sig_hex, msg):
    try:
        if len(pk_hex) != 64 or len(sig_hex) != 128:
            return False
        if any(ch not in HEX for ch in pk_hex) or any(ch not in HEX for ch in sig_hex):
            return False
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pk_hex)).verify(bytes.fromhex(sig_hex), msg)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def oracle_v1(env):
    try:
        if env.get("envelope_version") != "1" or env.get("construction") != "v3":
            return "REJECT"
        canon = _canon(base64.b64decode(env["record_b64"]))
        if canon is None:
            return "REJECT"
        leaf = _leaf(canon, env["semantic_profile_digest"], env["construction_digest"])
        if leaf.hex() != env["leaf_digest"]:
            return "REJECT"
        path = [bytes.fromhex(x) for x in env["merkle_path"]]
        if _verify_proof(leaf, env["leaf_index"], env["tree_size"], path) != bytes.fromhex(env["root"]):
            return "REJECT"
        return "ACCEPT"
    except Exception:
        return "REJECT"
def oracle_v2(env, ctx, state):
    if oracle_v1(env) != "ACCEPT":
        return "REJECT", state
    if ctx is None:
        return "REJECT", state
    cp = env.get("checkpoint")
    if not isinstance(cp, dict) or isinstance(cp.get("tree_size"), bool) or not isinstance(cp.get("tree_size"), int):
        return "REJECT", state
    try:
        if cp["publisher_id"] != ctx["publisher_id"]:
            return "REJECT", state
        if not _sig_ok(env["signer_public_key"], env["signature"], _pre(cp)):
            return "REJECT", state
        if env["signer_public_key"] not in ctx["trusted_public_keys"]:
            return "REJECT", state
        if cp["checkpoint_id"] != ctx["authorized_checkpoint_id"]:
            return "REJECT", state
        if not (cp["semantic_profile_digest"] == ctx["semantic_profile_digest"] == env["semantic_profile_digest"]):
            return "REJECT", state
        if not (cp["construction_digest"] == ctx["construction_digest"] == env["construction_digest"]):
            return "REJECT", state
        if cp["batch_id"] != ctx["batch_id"]:
            return "REJECT", state
        if cp["tree_size"] != ctx["tree_size"] or cp["tree_size"] != env["tree_size"]:
            return "REJECT", state
        if cp["root"] != env["root"]:
            return "REJECT", state
    except Exception:
        return "REJECT", state
    if state is None:
        return "REJECT", state
    seq, cid = cp["checkpoint_sequence"], cp["checkpoint_id"]
    cdg = hashlib.sha256(_pre(cp)).hexdigest()
    last = state.get("last_accepted_sequence", -1)
    if seq < state.get("min_sequence", 0) or seq < last:
        return "REJECT", state
    if seq == last:
        if cid == state.get("last_accepted_checkpoint_id") and cdg == state.get("last_accepted_checkpoint_digest"):
            return "ACCEPT", state
        return "REJECT", state
    ns = dict(state)
    ns.update({"last_accepted_sequence": seq, "last_accepted_checkpoint_id": cid, "last_accepted_checkpoint_digest": cdg})
    return "ACCEPT", ns


def main():
    units = [json.loads(l) for l in (EVAL / "P05_MEASURED_CORPUS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    orc = {json.loads(l)["unit_id"]: json.loads(l) for l in (EVAL / "P05_EVALUATOR_ORACLE.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()}
    rows, dis = [], 0
    for u in units:
        v1 = oracle_v1(u["envelope"])
        v2, ns = oracle_v2(u["envelope"], u["trusted_context"], u["initial_state"])
        o = orc[u["unit_id"]]
        agree = (v1 == o["expected_v1_decision"]) and (v2 == o["expected_v2_decision"])
        if not agree:
            dis += 1
        st_ok = None
        if u["initial_state"] is not None:
            st_ok = (v2 == "REJECT" and ns == u["initial_state"]) or (v2 == "ACCEPT")
        rows.append({"unit_id": u["unit_id"], "group": u["group"], "indep_v1": v1, "indep_v2": v2,
                     "oracle_v1": o["expected_v1_decision"], "oracle_v2": o["expected_v2_decision"],
                     "agree": agree, "state_transition_ok": st_ok})
    (HERE / "P05_R2B_INDEPENDENT_ORACLE.jsonl").write_text(
        "".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8", newline="\n")
    summary = {"units": len(rows), "independent_agreement": sum(1 for r in rows if r["agree"]),
               "disagreements": dis,
               "state_ok": sum(1 for r in rows if r["state_transition_ok"] in (True, None)),
               "state_n": sum(1 for r in rows if r["state_transition_ok"] is not None),
               "note": "independent checker reimplements leaf/tree/proof/checkpoint/sig/freshness; reuses frozen P03 adapter for canonical only"}
    (HERE / "P05_R2B_INDEPENDENT_ORACLE_SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n",
                                                                   encoding="utf-8", newline="\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()