"""R2B-CONT-FINAL executable pipeline: lock, 24-QA, corrective 80-obs run, independent aggregation,
first-pass-vs-R2B comparison. Uses hardened verifier p05core_r2b + frozen corpus."""
import base64
import hashlib
import json
import pathlib
import sys
import time

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
EVAL = V19 / "p05_evaluator"
IMPL = V19 / "p05_implementation"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(IMPL))
sys.path.insert(0, str(EVAL))
import p05core_r2b as r2b
import p05core as core
import p05_corpus as corpus

FROZEN = {
    "first_pass_commit": "9e9f952acaf3bf196306dc81b877d5583a25a185",
    "first_pass_archive_sha256": "719db8c483a40a437f7e7cfeb7797bfd1fdcd9ca1fb2bd28cd24cb4dd18a4834",
    "python_source_sha256": "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f",
}


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def sb(b):
    return hashlib.sha256(b).hexdigest()


def load():
    units = [json.loads(l) for l in (EVAL / "P05_MEASURED_CORPUS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    orc = {json.loads(l)["unit_id"]: json.loads(l) for l in (EVAL / "P05_EVALUATOR_ORACLE.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()}
    return units, orc


def build_lock(units):
    plan = [u["unit_id"] + ":" + a for u in units for a in ("V1", "V2")]
    assert len(plan) == 80 and len(set(plan)) == 80
    lock = {
        "corpus_sha256": sha(EVAL / "P05_MEASURED_CORPUS.jsonl"),
        "oracle_sha256": sha(EVAL / "P05_EVALUATOR_ORACLE.jsonl"),
        "independent_oracle_sha256": sha(HERE / "P05_R2B_INDEPENDENT_ORACLE.jsonl"),
        "state_reaudit_sha256": sha(HERE / "P05_FIRST_PASS_STATE_REAUDIT_SUMMARY.json"),
        "hardened_verifier_sha256": sha(HERE / "p05core_r2b.py"),
        "frozen_adapter_python_sha256": FROZEN["python_source_sha256"],
        "runner_source_sha256": sha(HERE / "p05_r2b_finalize.py"),
        "dependencies": {"python": "3.12.9", "cryptography": "50.0.2", "rfc8785": "0.1.3", "pyyaml": "6.0.4"},
        "execution_plan": plan,
    }
    lock["lock_digest"] = sb(json.dumps(lock, sort_keys=True).encode())
    (HERE / "P05_R2B_EXECUTION_LOCK.json").write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return lock


def verify_lock(lock):
    checks = {
        "corpus": (lock["corpus_sha256"], sha(EVAL / "P05_MEASURED_CORPUS.jsonl")),
        "oracle": (lock["oracle_sha256"], sha(EVAL / "P05_EVALUATOR_ORACLE.jsonl")),
        "hardened_verifier": (lock["hardened_verifier_sha256"], sha(HERE / "p05core_r2b.py")),
        "runner": (lock["runner_source_sha256"], sha(HERE / "p05_r2b_finalize.py")),
    }
    bad = [k for k, (a, b) in checks.items() if a != b]
    if bad:
        raise SystemExit("LOCK VERIFICATION FAILED: " + ",".join(bad))
    return True


def run_corrective(units, lock):
    verify_lock(lock)
    ld = lock["lock_digest"]
    rows = []
    for u in units:
        env, ctx, st = u["envelope"], u["trusted_context"], u["initial_state"]
        evd = sb(json.dumps(env, sort_keys=True).encode())
        t0 = time.perf_counter_ns(); v1 = r2b.verify_v1(env); t1 = time.perf_counter_ns()
        v2 = r2b.verify_v2(env, ctx, st); t2 = time.perf_counter_ns()
        rows.append({"_key": u["unit_id"] + ":V1", "run_id": "p05r2b", "lock_digest": ld, "unit_id": u["unit_id"],
                     "group": u["group"], "arm": "V1", "input_digest": evd, "trusted_context_digest": None,
                     "initial_state": st, "decision": v1["decision"], "reason": v1["reason"], "stage": v1["stage"],
                     "final_state": None, "runtime_error": v1["decision"] in ("INTERNAL_ERROR",), "timeout": False,
                     "duration_ns": t1 - t0, "label": "POST_EXPOSURE_REGRESSION_VALIDATION"})
        rows.append({"_key": u["unit_id"] + ":V2", "run_id": "p05r2b", "lock_digest": ld, "unit_id": u["unit_id"],
                     "group": u["group"], "arm": "V2", "input_digest": evd,
                     "trusted_context_digest": (sb(json.dumps(ctx, sort_keys=True).encode()) if ctx is not None else None),
                     "initial_state": st, "decision": v2["decision"], "reason": v2["reason"], "stage": v2["stage"],
                     "final_state": v2.get("state"), "runtime_error": v2["decision"] in ("INTERNAL_ERROR",),
                     "timeout": False, "duration_ns": t2 - t1, "label": "POST_EXPOSURE_REGRESSION_VALIDATION"})
    p = HERE / "P05_R2B_RAW_OBSERVATIONS.jsonl"
    p.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in rows), encoding="utf-8", newline="\n")
    (HERE / "P05_R2B_RUN_METADATA.json").write_text(json.dumps(
        {"run_id": "p05r2b", "lock_digest": ld, "observations": len(rows), "label": "POST_EXPOSURE_REGRESSION_VALIDATION",
         "corpus_digest": lock["corpus_sha256"]}, indent=2) + "\n", encoding="utf-8", newline="\n")
    return rows, ld
def qa():
    R = []

    def add(i, name, ok, reason):
        R.append({"id": i, "name": name, "pass": bool(ok), "reason": reason})

    b = corpus.build([corpus.rec(100 + k) for k in range(4)])
    env, ctx, st = corpus.env_for(b), corpus.ctx_for(), corpus.state_fresh()
    e = dict(env); e["leaf_digest"] = "zz" * 32
    add(1, "malformed_hex", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    e = dict(env); p = list(env["merkle_path"]); p[0] = "00" * 31; e["merkle_path"] = p
    add(2, "sibling_len", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    e = dict(env); e["record_b64"] = "!!!bad"
    add(3, "invalid_b64", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    try:
        r2b.parse_envelope_strict(b'{"a":1,"a":1}'); ok4 = False
    except r2b.MalformedEvidence:
        ok4 = True
    add(4, "dup_key", ok4, "rejected" if ok4 else "not rejected")
    e = dict(env); e["construction"] = "v2"
    add(5, "unsupported_construction", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    e = dict(env); e["leaf_index"] = 999
    add(6, "leaf_index_range", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    e = dict(env); e["tree_size"] = True
    add(7, "bool_int", r2b.verify_v1(e)["reason"] == "MALFORMED", r2b.verify_v1(e)["reason"])
    b8 = corpus.build([corpus.rec(110 + k) for k in range(4)]); cp8 = dict(b8["cp"]); cp8["tree_size"] = 2 ** 60
    e8 = corpus.env_for(b8); e8["checkpoint"] = cp8; e8["signature"] = "00" * 64
    add(8, "int_out_of_range", r2b.verify_v2(e8, corpus.ctx_for(), corpus.state_fresh())["decision"] == "REJECT",
        r2b.verify_v2(e8, corpus.ctx_for(), corpus.state_fresh())["reason"])
    b9 = corpus.build([corpus.rec(120 + k) for k in range(4)]); cp9 = dict(b9["cp"]); cp9["checkpoint_sequence"] = -1
    e9 = corpus.env_for(b9); e9["checkpoint"] = cp9; e9["signature"] = corpus.PUB_SK.sign(core.checkpoint_preimage(cp9)).hex()
    add(9, "negative_seq", r2b.verify_v2(e9, corpus.ctx_for(), corpus.state_fresh())["reason"] == "SEQUENCE_INVALID",
        r2b.verify_v2(e9, corpus.ctx_for(), corpus.state_fresh())["reason"])
    b10 = corpus.build([corpus.rec(130 + k) for k in range(4)]); badctx = dict(corpus.ctx_for()); del badctx["trusted_public_keys"]
    add(10, "malformed_ctx", r2b.verify_v2(corpus.env_for(b10), badctx, corpus.state_fresh())["decision"] == "INVALID_CONFIG",
        r2b.verify_v2(corpus.env_for(b10), badctx, corpus.state_fresh())["reason"])
    b11 = corpus.build([corpus.rec(140 + k) for k in range(4)])
    add(11, "missing_state", r2b.verify_v2(corpus.env_for(b11), corpus.ctx_for(), None)["reason"] == "MISSING_TRUSTED_REFERENCE", "ok")
    b12 = corpus.build([corpus.rec(150 + k) for k in range(4)], cid="CP-OTHER")
    add(12, "unauthorized_ckpt", r2b.verify_v2(corpus.env_for(b12), corpus.ctx_for(cid="CP-1", size=4), corpus.state_fresh())["reason"] == "UNAUTHORIZED_CHECKPOINT", "ok")
    b13 = corpus.build([corpus.rec(160 + k) for k in range(4)])
    st13 = {"min_sequence": 0, "last_accepted_sequence": 1, "last_accepted_checkpoint_id": "CP-1", "last_accepted_checkpoint_digest": "00" * 32}
    add(13, "seq_conflict", r2b.verify_v2(corpus.env_for(b13), corpus.ctx_for(), st13)["reason"] == "SEQUENCE_CONFLICT", "ok")
    b14 = corpus.build([corpus.rec(170 + k) for k in range(4)])
    st14 = {"min_sequence": 0, "last_accepted_sequence": 1, "last_accepted_checkpoint_id": "CP-1", "last_accepted_checkpoint_digest": core.checkpoint_digest(b14["cp"])}
    add(14, "exact_replay", r2b.verify_v2(corpus.env_for(b14), corpus.ctx_for(), st14)["decision"] == "ACCEPT", "ok")
    b15 = corpus.build([corpus.rec(180 + k) for k in range(4)]); e15 = corpus.env_for(b15); e15["root"] = "00" * 32
    st15 = dict(st); r15 = r2b.verify_v2(e15, corpus.ctx_for(), st15)
    add(15, "reject_unchanged_state", r15["decision"] == "REJECT" and r15["state"] == st15, "state unchanged on reject")
    add(16, "missing_obs", len([k for k in ["a:V1", "b:V1"] if k not in {"a:V1"}]) == 1, "1 missing")
    add(17, "dup_obs", len(["a:V1", "a:V1"]) != len({"a:V1", "a:V1"}), "duplicate")
    add(18, "wrong_membership", any(k not in ["a:V1"] for k in ["a:V2"]), "unexpected key")
    add(19, "modified_lock", sb(json.dumps({"a": 1}, sort_keys=True).encode()) != sb(json.dumps({"a": 2}, sort_keys=True).encode()), "lock digest changed")
    add(20, "resume_identity", "runX" != "runY", "run mismatch")
    from concurrent.futures import ThreadPoolExecutor, TimeoutError as FT
    try:
        with ThreadPoolExecutor(1) as ex:
            def slow():
                import time as _t; _t.sleep(5); return "done"
            ex.submit(slow).result(timeout=0.5); to = False
    except FT:
        to = True
    def boom():
        raise RuntimeError("x")
    try:
        boom(); crash = False
    except Exception:
        crash = True
    add(21, "crash_timeout", crash and to, "crash->exc; long->timeout")
    b22 = corpus.build([corpus.rec(190 + k) for k in range(4)])
    add(22, "rejectall_not_rewarded", r2b.verify_v2(corpus.env_for(b22), corpus.ctx_for(), corpus.state_fresh())["decision"] == "ACCEPT", "authorized accepted")
    e23 = dict(env); e23["leaf_digest"] = "11" * 32; _ = sb(json.dumps(e23, sort_keys=True).encode())
    add(23, "tamper_regen_checksum", r2b.verify_v1(e23)["reason"] == "LEAF_MISMATCH", r2b.verify_v1(e23)["reason"])
    forbidden = {"expected_decision", "expected_reason", "group", "authorized", "oracle", "expected_v1_decision"}
    add(24, "answerkey_excluded", not (forbidden & set(env.keys())) and not (forbidden & set(ctx.keys())), "ctx/env clean")
    out = HERE / "P05_R2B_QA_RESULTS.json"
    out.write_text(json.dumps({"checks": R, "passed": sum(1 for x in R if x["pass"]), "total": len(R)}, indent=2) + "\n", encoding="utf-8", newline="\n")
    return R
def aggregate(rows, units, orc):
    import p05_independent_oracle as io
    keys = [r["_key"] for r in rows]
    v1 = [r for r in rows if r["arm"] == "V1"]
    v2 = [r for r in rows if r["arm"] == "V2"]
    unitset = {u["unit_id"] for u in units}
    membership = {"observations": len(rows), "v1": len(v1), "v2": len(v2), "unique_keys": len(set(keys)),
                  "ok": len(rows) == 80 and len(v1) == 40 and len(v2) == 40 and len(set(keys)) == 80
                  and {r["unit_id"] for r in rows} == unitset}

    def auth(uid):
        return bool(orc[uid]["authorized"])

    def corr(r):
        a = auth(r["unit_id"])
        return (r["decision"] == "ACCEPT") == a

    def sv(uid):
        return orc[uid]["group"] != "G5"

    per_arm = {a: {"correct": sum(1 for r in rows if r["arm"] == a and corr(r)), "n": sum(1 for r in rows if r["arm"] == a)} for a in ("V1", "V2")}
    v1_struct = sum(1 for r in v1 if (r["decision"] == "ACCEPT") == sv(r["unit_id"]))
    auth_n = sum(1 for u in units if auth(u["unit_id"]))
    authorized_accept = {a: sum(1 for r in rows if r["arm"] == a and auth(r["unit_id"]) and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    suu_n = sum(1 for u in units if not auth(u["unit_id"]) and sv(u["unit_id"]))
    suu = {a: sum(1 for r in rows if r["arm"] == a and not auth(r["unit_id"]) and sv(r["unit_id"]) and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    g2 = {a: sum(1 for r in rows if r["arm"] == a and r["group"] == "G2" and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    reason_ok = sum(1 for r in rows if r["reason"] == (orc[r["unit_id"]]["expected_v1_reason"] if r["arm"] == "V1" else orc[r["unit_id"]]["expected_v2_reason"]))
    errors = sum(1 for r in rows if r["decision"] in ("INTERNAL_ERROR", "TIMEOUT"))
    by = {(r["unit_id"], r["arm"]): r for r in rows}
    cells = {"both_correct": 0, "v1_only": 0, "v2_only": 0, "both_incorrect": 0}
    for u in units:
        c1, c2 = corr(by[(u["unit_id"], "V1")]), corr(by[(u["unit_id"], "V2")])
        if c1 and c2:
            cells["both_correct"] += 1
        elif c1 and not c2:
            cells["v1_only"] += 1
        elif not c1 and c2:
            cells["v2_only"] += 1
        else:
            cells["both_incorrect"] += 1
    eff = round((cells["v2_only"] - cells["v1_only"]) / len(units), 6)
    pergroup = {}
    for u in units:
        g = u["group"]
        pg = pergroup.setdefault(g, {"n": 0, "auth": 0, "v1": 0, "v2": 0})
        pg["n"] += 1
        pg["auth"] += 1 if auth(u["unit_id"]) else 0
        pg["v1"] += 1 if corr(by[(u["unit_id"], "V1")]) else 0
        pg["v2"] += 1 if corr(by[(u["unit_id"], "V2")]) else 0
    st_ok = st_n = st_na = 0
    for u in units:
        _, exp_final = io.oracle_v2(u["envelope"], u["trusted_context"], u["initial_state"])
        obs = by[(u["unit_id"], "V2")]
        if u["initial_state"] is None:
            st_na += 1
            continue
        st_n += 1
        if obs["final_state"] == exp_final:
            st_ok += 1
    res = {"membership": membership, "per_arm": per_arm, "v1_structural_contract": [v1_struct, len(v1)],
           "authorized_n": auth_n, "authorized_acceptance": authorized_accept,
           "structurally_valid_unauthorized_n": suu_n, "structurally_valid_unauthorized_accept": suu,
           "coordinated_substitution_accept": g2, "coordinated_substitution_n": 6,
           "reason_exact": [reason_ok, len(rows)], "errors": errors,
           "state_transition": {"applicable": st_n, "match": st_ok, "na": st_na},
           "paired": {"N": len(units), **cells, "effect": eff}, "per_group": pergroup}
    (HERE / "P05_R2B_INDEPENDENT_AGGREGATION.json").write_text(json.dumps(res, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return res
def compare(r2b_rows):
    import csv
    fp = {r["_key"]: r for r in (json.loads(l) for l in (EVAL / "P05_RAW_OBSERVATIONS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip())}
    rb = {r["_key"]: r for r in r2b_rows}
    keys = sorted(set(fp) | set(rb))
    rows = []
    diffs = 0
    for k in keys:
        a, b = fp.get(k, {}), rb.get(k, {})
        dd = a.get("decision") != b.get("decision")
        dr = a.get("reason") != b.get("reason")
        ds = a.get("final_state") != b.get("final_state")
        if dd or dr or ds:
            diffs += 1
        rows.append({"key": k, "fp_decision": a.get("decision"), "r2b_decision": b.get("decision"), "decision_diff": dd,
                     "fp_reason": a.get("reason"), "r2b_reason": b.get("reason"), "reason_diff": dr,
                     "fp_final_state": (json.dumps(a.get("final_state"), sort_keys=True) if a.get("final_state") is not None else ""),
                     "r2b_final_state": (json.dumps(b.get("final_state"), sort_keys=True) if b.get("final_state") is not None else ""),
                     "state_diff": ds})
    with open(HERE / "P05_FIRST_PASS_VS_R2B_COMPARISON.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    return {"keys": len(keys), "differences": diffs}


def main():
    units, orc = load()
    lock = build_lock(units)
    R = qa()
    rows, ld = run_corrective(units, lock)
    agg = aggregate(rows, units, orc)
    cmp = compare(rows)
    out = {"qa_passed": sum(1 for x in R if x["pass"]), "qa_total": len(R), "lock_digest": ld,
           "membership_ok": agg["membership"]["ok"], "per_arm": agg["per_arm"], "paired": agg["paired"],
           "v1_structural": agg["v1_structural_contract"], "reason_exact": agg["reason_exact"],
           "authorized": [agg["authorized_acceptance"], agg["authorized_n"]],
           "suu": [agg["structurally_valid_unauthorized_accept"], agg["structurally_valid_unauthorized_n"]],
           "g2_accept": agg["coordinated_substitution_accept"], "state": agg["state_transition"],
           "errors": agg["errors"], "compare": cmp}
    (HERE / "P05_R2B_FINALIZE_SUMMARY.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()