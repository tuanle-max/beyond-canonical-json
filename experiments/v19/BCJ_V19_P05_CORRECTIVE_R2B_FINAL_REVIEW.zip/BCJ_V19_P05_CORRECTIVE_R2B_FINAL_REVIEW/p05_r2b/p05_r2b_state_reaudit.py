"""WP1 / F43 exact state re-audit. Reuses the accepted independent checker's oracle_v2 (which
returns the expected final state) — no third oracle. Joins first-pass raw V2 observations to the
frozen corpus + independent decisions by exact unit-arm key and validates EXACT state transitions.

Corrects the prior accounting defect: ACCEPT is not auto-counted as state-correct; None initial
state is treated as N/A (excluded from denominator), not counted as success.
"""
import json
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
EVAL = V19 / "p05_evaluator"
sys.path.insert(0, str(HERE))
import p05_independent_oracle as io

OUT_JSONL = HERE / "P05_FIRST_PASS_STATE_REAUDIT.jsonl"
OUT_SUM = HERE / "P05_FIRST_PASS_STATE_REAUDIT_SUMMARY.json"
OUT_ORACLE_V2 = HERE / "P05_R2B_INDEPENDENT_ORACLE_V2.jsonl"


def load_jsonl(p):
    return [json.loads(l) for l in pathlib.Path(p).read_text(encoding="utf-8").splitlines() if l.strip()]


def main():
    corpus = {u["unit_id"]: u for u in load_jsonl(EVAL / "P05_MEASURED_CORPUS.jsonl")}
    raw = load_jsonl(EVAL / "P05_RAW_OBSERVATIONS.jsonl")
    raw_v2 = {r["unit_id"]: r for r in raw if r["arm"] == "V2"}
    assert len(corpus) == 40 and len(raw_v2) == 40, (len(corpus), len(raw_v2))

    rows = []
    oracle_v2_rows = []
    applicable = n_ok = n_na = 0
    init_ok = dec_ok = 0
    mism = []
    for uid, u in corpus.items():
        exp_init = u["initial_state"]
        dec_exp, exp_final = io.oracle_v2(u["envelope"], u["trusted_context"], exp_init)
        obs = raw_v2.get(uid)
        oracle_v2_rows.append({"unit_id": uid, "expected_v1": io.oracle_v1(u["envelope"]),
                               "expected_v2": dec_exp, "expected_initial_state": exp_init,
                               "expected_final_state": exp_final,
                               "checker_status": "OK", "reason_codes": "not_independently_reconstructed"})
        if obs is None:
            rows.append({"unit_id": uid, "state_applicable": None, "missing_observation": True})
            mism.append({"unit_id": uid, "issue": "missing V2 observation"})
            continue
        obs_init, obs_final, obs_dec = obs["initial_state"], obs["final_state"], obs["decision"]
        is_init = (obs_init == exp_init)
        is_dec = (obs_dec == dec_exp)
        init_ok += 1 if is_init else 0
        dec_ok += 1 if is_dec else 0
        if exp_init is None:
            # no trusted state to transition -> state check N/A (fail-closed reject expected)
            n_na += 1
            state_applicable = False
            state_match = None
            ok = (obs_dec == "REJECT")
        else:
            applicable += 1
            state_applicable = True
            state_match = (obs_final == exp_final)
            ok = state_match
            if state_match:
                n_ok += 1
            else:
                mism.append({"unit_id": uid, "expected_final": exp_final, "observed_final": obs_final})
        rows.append({"unit_id": uid, "group": u["group"], "state_applicable": state_applicable,
                     "expected_initial_state": exp_init, "observed_initial_state": obs_init,
                     "initial_match": is_init, "expected_decision": dec_exp, "observed_decision": obs_dec,
                     "decision_match": is_dec, "expected_final_state": exp_final,
                     "observed_final_state": obs_final, "state_match": state_match, "row_ok": ok})
        if not (is_init and is_dec and ok):
            mism.append({"unit_id": uid, "initial_match": is_init, "decision_match": is_dec,
                         "state_ok": ok})
    summary = {"units": len(corpus), "v2_observations": len(raw_v2),
               "state_applicable": applicable, "state_match": n_ok, "state_na": n_na,
               "numerator_le_denominator": n_ok <= applicable,
               "initial_state_match": init_ok, "decision_match": dec_ok,
               "mismatches": mism,
               "note": "ACCEPT not auto-counted; None initial state = N/A; exact final-state equality required; "
                       "reason codes not independently reconstructed (decision-level only)"}
    OUT_JSONL.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows), encoding="utf-8", newline="\n")
    OUT_ORACLE_V2.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in oracle_v2_rows), encoding="utf-8", newline="\n")
    OUT_SUM.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()