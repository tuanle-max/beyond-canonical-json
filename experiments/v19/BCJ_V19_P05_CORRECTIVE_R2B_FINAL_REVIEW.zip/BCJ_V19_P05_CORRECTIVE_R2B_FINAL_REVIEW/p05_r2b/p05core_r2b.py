"""F40 hardened verifier (R2B). Strict validation; one shared structural verifier for V1 and V2.
Reuses only spec primitives from the frozen p05core (leaf/path/checkpoint); does NOT weaken V1.
Classifies MalformedEvidence / InvalidTrustedConfig / INTERNAL_ERROR distinctly from security REJECT.
"""
import base64
import binascii

import p05core as _c

HEX = set("0123456789abcdef")
REQ_ENV = ("envelope_version", "construction", "record_b64", "semantic_profile_digest",
           "construction_digest", "leaf_digest", "leaf_index", "tree_size", "merkle_path", "root")


class MalformedEvidence(Exception):
    pass


class InvalidTrustedConfig(Exception):
    pass


def _hexok(s, n):
    return isinstance(s, str) and len(s) == n and all(ch in HEX for ch in s)


def _b64strict(s):
    if not isinstance(s, str):
        raise MalformedEvidence("record_b64_type")
    try:
        return base64.b64decode(s.encode("utf-8"), validate=True)
    except (binascii.Error, ValueError) as e:
        raise MalformedEvidence("base64:" + str(e))


def _dup_hook(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise MalformedEvidence("duplicate_key:" + k)
        d[k] = v
    return d


def parse_envelope_strict(raw):
    if isinstance(raw, (bytes, bytearray)):
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            raise MalformedEvidence("utf8")
        import json
        try:
            return json.loads(text, object_pairs_hook=_dup_hook,
                              parse_constant=lambda c: (_ for _ in ()).throw(MalformedEvidence("const:" + c)))
        except MalformedEvidence:
            raise
        except ValueError as e:
            raise MalformedEvidence("json:" + str(e))
    return raw


def structural_verify(env):
    if not isinstance(env, dict):
        raise MalformedEvidence("not_dict")
    for k in REQ_ENV:
        if k not in env:
            raise MalformedEvidence("missing:" + k)
    if env["envelope_version"] != "1":
        raise MalformedEvidence("envelope_version")
    if env["construction"] != "v3":
        raise MalformedEvidence("unsupported_construction")
    if not _hexok(env["semantic_profile_digest"], 64) or not _hexok(env["construction_digest"], 64):
        raise MalformedEvidence("digest_hex")
    if not _hexok(env["leaf_digest"], 64) or not _hexok(env["root"], 64):
        raise MalformedEvidence("hex_field")
    idx, size = env["leaf_index"], env["tree_size"]
    if isinstance(idx, bool) or not isinstance(idx, int):
        raise MalformedEvidence("leaf_index_type")
    if isinstance(size, bool) or not isinstance(size, int) or size <= 0:
        raise MalformedEvidence("tree_size")
    if idx < 0 or idx >= size:
        raise MalformedEvidence("leaf_index_range")
    if not isinstance(env["merkle_path"], list):
        raise MalformedEvidence("path_type")
    for x in env["merkle_path"]:
        if not _hexok(x, 64):
            raise MalformedEvidence("sibling_len")
    raw = _b64strict(env["record_b64"])
    canon, _reason = _c.canonical(raw)
    if canon is None:
        return "REJECT", "RECORD_INVALID"
    leaf = _c.leaf_digest(canon, env["semantic_profile_digest"], env["construction_digest"])
    if leaf.hex() != env["leaf_digest"]:
        return "REJECT", "LEAF_MISMATCH"
    try:
        pb = [bytes.fromhex(x) for x in env["merkle_path"]]
    except ValueError:
        raise MalformedEvidence("sibling_hex")
    root = _c.verify_path(leaf, idx, size, pb)
    if root is None:
        return "REJECT", "PROOF_INVALID"
    if root.hex() != env["root"]:
        return "REJECT", "ROOT_MISMATCH"
    return "ACCEPT", {"leaf": leaf.hex(), "root": root.hex()}


def verify_v1(env):
    try:
        d, info = structural_verify(env)
        if d == "ACCEPT":
            return {"decision": "ACCEPT", "reason": "ACCEPT_STRUCTURAL", "stage": "structural", "info": info}
        return {"decision": "REJECT", "reason": info, "stage": "structural"}
    except MalformedEvidence as e:
        return {"decision": "REJECT", "reason": "MALFORMED", "detail": str(e), "stage": "structural"}
    except Exception as e:  # internal error must NOT get security-rejection credit
        return {"decision": "INTERNAL_ERROR", "reason": "INTERNAL_ERROR", "detail": repr(e), "stage": "internal"}
def _ctx_ok(ctx):
    for k in ("publisher_id", "authorized_checkpoint_id", "batch_id", "semantic_profile_digest",
              "construction_digest", "tree_size", "trusted_public_keys"):
        if k not in ctx:
            raise InvalidTrustedConfig("ctx_missing:" + k)
    if not isinstance(ctx["trusted_public_keys"], list):
        raise InvalidTrustedConfig("keys_type")
    for kk in ctx["trusted_public_keys"]:
        if not _hexok(kk, 64):
            raise InvalidTrustedConfig("key_hex")
    if isinstance(ctx["tree_size"], bool) or not isinstance(ctx["tree_size"], int):
        raise InvalidTrustedConfig("ctx_tree_size")


def _state_ok(state):
    if state is not None and not isinstance(state, dict):
        raise InvalidTrustedConfig("state_type")


def verify_v2(env, ctx, state):
    r1 = verify_v1(env)
    if r1["decision"] != "ACCEPT":
        return {"decision": r1["decision"], "reason": r1["reason"], "stage": r1["stage"],
                "state": state, "detail": r1.get("detail")}
    try:
        if ctx is None:
            return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
        _ctx_ok(ctx)
        _state_ok(state)
        cp = env.get("checkpoint")
        if not isinstance(cp, dict):
            return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
        cpp, cerr = _c.parse_checkpoint(cp)
        if cerr:
            return {"decision": "REJECT", "reason": cerr, "stage": "trust", "state": state}
        if isinstance(cpp["checkpoint_sequence"], bool) or not isinstance(cpp["checkpoint_sequence"], int) or cpp["checkpoint_sequence"] < 0:
            return {"decision": "REJECT", "reason": "SEQUENCE_INVALID", "stage": "trust", "state": state}
        if cpp["publisher_id"] != ctx["publisher_id"]:
            return {"decision": "REJECT", "reason": "UNKNOWN_PUBLISHER", "stage": "trust", "state": state}
        signer, sig = env.get("signer_public_key"), env.get("signature")
        if signer is None or sig is None:
            return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
        if not _c.verify_signature(signer, sig, _c.checkpoint_preimage(cpp)):
            return {"decision": "REJECT", "reason": "INVALID_SIGNATURE", "stage": "signature", "state": state}
        if signer not in ctx["trusted_public_keys"]:
            return {"decision": "REJECT", "reason": "UNTRUSTED_KEY", "stage": "signature", "state": state}
        if cpp["checkpoint_id"] != ctx["authorized_checkpoint_id"]:
            return {"decision": "REJECT", "reason": "UNAUTHORIZED_CHECKPOINT", "stage": "authorization", "state": state}
        if cpp["semantic_profile_digest"] != ctx["semantic_profile_digest"] or cpp["semantic_profile_digest"] != env["semantic_profile_digest"]:
            return {"decision": "REJECT", "reason": "PROFILE_MISMATCH", "stage": "context", "state": state}
        if cpp["construction_digest"] != ctx["construction_digest"] or cpp["construction_digest"] != env["construction_digest"]:
            return {"decision": "REJECT", "reason": "CONSTRUCTION_MISMATCH", "stage": "context", "state": state}
        if cpp["batch_id"] != ctx["batch_id"]:
            return {"decision": "REJECT", "reason": "BATCH_MISMATCH", "stage": "context", "state": state}
        if cpp["tree_size"] != ctx["tree_size"] or cpp["tree_size"] != env["tree_size"]:
            return {"decision": "REJECT", "reason": "TREE_SIZE_MISMATCH", "stage": "context", "state": state}
        if cpp["root"] != env["root"]:
            return {"decision": "REJECT", "reason": "EVIDENCE_INCONSISTENT", "stage": "consistency", "state": state}
        if state is None:
            return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "freshness", "state": state}
        ok, reason, ns = _c.freshness_check(state, cpp["checkpoint_sequence"], cpp["checkpoint_id"], _c.checkpoint_digest(cpp))
        if not ok:
            return {"decision": "REJECT", "reason": reason, "stage": "freshness", "state": state}
        return {"decision": "ACCEPT", "reason": "ACCEPT_AUTHORIZED", "stage": "accept", "state": ns, "info": r1.get("info")}
    except InvalidTrustedConfig as e:
        return {"decision": "INVALID_CONFIG", "reason": "INVALID_TRUSTED_CONFIG", "detail": str(e), "stage": "config", "state": state}
    except Exception as e:
        return {"decision": "INTERNAL_ERROR", "reason": "INTERNAL_ERROR", "detail": repr(e), "stage": "internal", "state": state}


def verify(arm, env, ctx=None, state=None):
    return verify_v1(env) if arm == "V1" else verify_v2(env, ctx, state)