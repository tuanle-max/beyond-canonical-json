# P05 Final Measured Report

RQ: can authenticated reference verification prevent acceptance of internally consistent but unauthorized evidence?

Result: V1 (structural) common-objective correct 15/40 (own structural contract 40/40); V2 (structural + trusted Ed25519 reference) 40/40. Paired: both=15, V1_only=0, V2_only=25, both_incorrect=0, effect +0.625. Reasons exact 80/80; state transitions 40/40; G6/G7/G8 detectors 4/4 each. F31-F39 applied; PE01-PE16 PASS.

Interpretation: authenticated reference verification rejects coordinated substitutions, wrong profile/construction contexts, invalid signatures, untrusted keys, missing references, and stale/rollback checkpoints that structural verification accepts. V1 acceptance of unauthorized-but-consistent evidence is not a V1 defect. No universal security, compromised-signer protection, production prevalence, or third-party replication claimed.
