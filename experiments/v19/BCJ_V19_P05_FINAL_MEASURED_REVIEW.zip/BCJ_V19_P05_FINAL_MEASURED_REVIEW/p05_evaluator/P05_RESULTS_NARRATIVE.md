# P05 Results Narrative (measured: 40 units x 2 arms = 80 observations)

RQ: can authenticated reference verification prevent acceptance of internally consistent but unauthorized evidence?

## Common trusted-reference objective correctness
- V1 (structural only): 15/40
- V2 (structural + trusted reference): 40/40
- V1 structural-contract correctness (its own contract): 40/40

## Paired V1 vs V2 (N=40)
- both_correct=15, V1_only=0, V2_only=25, both_incorrect=0, effect=0.625

## Detectors (V2)
- G6 signature/key rejection: 4/4
- G7 missing-reference fail-closed: 4/4
- G8 freshness correctness: 4/4

## Interpretation
Authenticated reference verification (V2) rejects internally consistent but unauthorized evidence that
structural verification (V1) accepts. V1 is a competent structural verifier: accepting structurally valid
but unauthorized evidence satisfies V1's OWN contract and is NOT a V1 defect; it is inadequacy only under
the common trusted-reference objective. Coordinated substitution is not a hash collision. A trusted signature
establishes integrity relative to an authorized key, not real-world business truth.
