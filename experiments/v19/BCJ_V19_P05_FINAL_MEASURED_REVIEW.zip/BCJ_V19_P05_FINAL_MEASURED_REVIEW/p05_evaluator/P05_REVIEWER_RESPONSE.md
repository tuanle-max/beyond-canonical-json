# P05 Reviewer Response

Q: Does authenticated reference verification add assurance over structural verification?
A: Yes, on unauthorized-but-consistent evidence: paired V2_only=25 vs V1_only=0 (effect 0.625).
Q: Is V1 defective if it accepts unauthorized consistent evidence?
A: No. Such acceptance satisfies V1's structural contract; it is inadequate only under the common reference objective.
Q: What is out of scope?
A: Compromised trusted signers/provisioning, primitive breaks, real-world truth, availability.
