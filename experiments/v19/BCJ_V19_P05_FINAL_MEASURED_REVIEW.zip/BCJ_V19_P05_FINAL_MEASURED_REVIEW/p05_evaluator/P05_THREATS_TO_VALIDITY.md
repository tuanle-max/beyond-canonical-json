# P05 Threats to Validity

- Purposive 40-unit synthetic corpus; no production attack prevalence or universal-security claim.
- Same-team implementation and oracle; NOT third-party independent replication.
- Trusted signer and trust provisioning assumed uncompromised (out of scope).
- Sequence-only freshness; no wall-clock/time-based expiry evaluated.
- Synthetic Ed25519 keys; no production keys.
- Oracle uses the frozen P03 semantic adapter within its established scope; not an independent semantic implementation.
