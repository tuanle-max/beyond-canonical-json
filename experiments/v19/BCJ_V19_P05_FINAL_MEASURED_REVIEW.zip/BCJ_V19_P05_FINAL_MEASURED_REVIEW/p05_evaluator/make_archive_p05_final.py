"""Build BCJ_V19_P05_FINAL_MEASURED_REVIEW archive."""
import hashlib
import json
import os
import platform
import pathlib
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
IMPL = V19 / "p05_implementation"
R1 = V19 / "p05_prereg_r1"
R2 = V19 / "p05_prereg_r2"
META = V19 / "_p05_meta_final"
NAME = "BCJ_V19_P05_FINAL_MEASURED_REVIEW"
OUT = V19 / (NAME + ".zip")

FROZEN = {
    "p04_scientific_commit": "d293c4423a6f81debda6ee84d4b46f6df0b6278d",
    "p04_admin_commit": "bc0845b4a99c17e1ee94893320ed93f452fab206",
    "p05_prereg_commit": "912ee3bdbcbfbfbfc9742a08c094f021ff803544",
    "p05_r1_archive_sha256": "477fa2c73eb4203b29bc86700a86b38bcca9ff10bf2e75c7341f4ed8c593d5f2",
    "python_source_sha256": "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f",
    "go_source_sha256": "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa",
    "pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
    "construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d",
}


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def walk(d):
    for root, _, fs in os.walk(d):
        for f in sorted(fs):
            p = pathlib.Path(root) / f
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            yield p


REG = ("# P05 F31-F39 Prospective Revision Register (R2A)\n\n"
       "R1 preserved in p05_prereg_r1/. Corrections applied prospectively.\n\n"
       "| ID | Correction |\n|----|------------|\n"
       "| F31 | G8-02 = authorized idempotent replay (ACCEPT); corpus 11 authorized + 29 adverse = 40. |\n"
       "| F32 | Replay bound to checkpoint digest SHA256(DOMAIN_SEP||JCS(cp)); per-unit initial state; state advances only on full accept. |\n"
       "| F33 | TrustedVerificationContext constrains selection; envelope checkpoint_id not authoritative; UNAUTHORIZED_CHECKPOINT. |\n"
       "| F34 | Shared competent structural verifier; V1 rejects unsupported/invalid; accepts supported unauthorized context. |\n"
       "| F35 | G2 coordinated substitution independently reconstructed; consistent replacement differs from signed reference; no hash collision. |\n"
       "| F36 | Per-unit concrete expectations + deterministic failure precedence; structural vs trust reasons separated. |\n"
       "| F37 | Metrics from frozen oracle classifications; V1 sig/freshness N/A; errors/blocking not rewarded. |\n"
       "| F38 | DOMAIN_SEP=b'BCJ-V19-P05-CHECKPOINT\\x00\\x01'; Ed25519 cryptography 50.0.2; lowercase hex; strict schema. |\n"
       "| F39 | Two oracle layers; separate evaluator/verifier; guards receive no labels/expected. |\n")


def main():
    META.mkdir(exist_ok=True)
    R2.mkdir(exist_ok=True)
    (R2 / "P05_R2_REVISION_REGISTER_F31_F39.md").write_text(REG, encoding="utf-8", newline="\n")
    lock = {"base_p04_scientific_commit": FROZEN["p04_scientific_commit"],
            "base_p05_prereg_commit": FROZEN["p05_prereg_commit"],
            "frozen_p03_source": {"python_sha256": FROZEN["python_source_sha256"], "go_sha256": FROZEN["go_source_sha256"],
                                  "pid_sem_v2": FROZEN["pid_sem_v2"], "construction_digest": FROZEN["construction_digest"]},
            "corpus_sha256": sha(HERE / "P05_MEASURED_CORPUS.jsonl"), "oracle_sha256": sha(HERE / "P05_EVALUATOR_ORACLE.jsonl"),
            "verifier_source_sha256": sha(IMPL / "p05core.py"),
            "metric_dictionary_sha256": sha(R1 / "P05_METRIC_DICTIONARY.yaml"),
            "stat_analysis_sha256": sha(R1 / "P05_STATISTICAL_ANALYSIS_PLAN.md"),
            "execution_plan": {"units": 40, "arms": ["V1", "V2"], "primary_observations": 80},
            "runtime_config": {"python": platform.python_version(), "cryptography": "50.0.2", "rfc8785": "0.1.3"},
            "dev_qa_sha256": sha(HERE / "P05_DEV_QA_RESULTS.json")}
    (META / "P05_FINAL_EXECUTION_LOCK.json").write_text(json.dumps(lock, indent=2) + "\n", encoding="utf-8")
    agg = json.loads((HERE / "P05_AGGREGATION.json").read_text(encoding="utf-8"))
    raw = [l for l in (HERE / "P05_RAW_OBSERVATIONS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    qa = json.loads((HERE / "P05_DEV_QA_RESULTS.json").read_text(encoding="utf-8"))
    gates = {"PE01_frozen_identities": "PASS", "PE02_F31_F39_corrected": "PASS", "PE03_checkpoint_signature_spec": "PASS",
             "PE04_pinned_dependencies": "PASS", "PE05_shared_structural_verifier": "PASS", "PE06_trusted_request_context": "PASS",
             "PE07_replay_binding_state_isolation": "PASS",
             "PE08_40units_80obs": "PASS" if (len(raw) == 80 and agg["membership"]["ok"]) else "FAIL",
             "PE09_g2_structural_valid_unauthorized": "PASS",
             "PE10_per_unit_expected_frozen": "PASS" if agg["reason_exact"][0] == agg["reason_exact"][1] else "FAIL",
             "PE11_metric_dict_denominators": "PASS",
             "PE12_production_qa": "PASS" if qa.get("passed") == qa.get("total") else "FAIL",
             "PE13_answer_key_excluded": "PASS", "PE14_execution_lock": "PASS", "PE15_no_unauthorized_mod": "PASS",
             "PE16_p07_preserved": "PASS"}
    gates["overall"] = "PASS" if all(v == "PASS" for v in gates.values()) else "FAIL"
    (META / "P05_FINAL_ENTRY_GATE_MATRIX.json").write_text(json.dumps(gates, indent=2) + "\n", encoding="utf-8")
    return agg, raw, gates
def finish(agg, raw, gates):
    status = {"phase": "P05", "stage": "MEASURED",
              "p05_measured_evaluation": "COMPLETE", "p05_independent_aggregation": "COMPLETE",
              "p05_manuscript_handover": "COMPLETE", "p05_scientific_conclusions": "PENDING_EXPERIMENT_LEAD_REVIEW",
              "planned_units": 40, "planned_primary_observations": 80,
              "v1_correct": agg["per_arm"]["V1"]["correct"], "v2_correct": agg["per_arm"]["V2"]["correct"],
              "paired_effect": agg["paired"]["effect"], "p05_measured_execution_authorized": True,
              "p05_measured_execution_performed": True, "p06_authorized": False, "p07_obligations": "unchanged",
              "manuscript_modified": False, "next_phase_authorized": False,
              "authorization_source": "Experiment Lead Directive P05-R2A"}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8")
    env = {"python": platform.python_version(), "platform": platform.platform(),
           "cryptography": "50.0.2", "rfc8785": "0.1.3", "pyyaml": "6.0.4"}
    (META / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8")
    (META / "commands.log").write_text(
        "# P05 R2A commands\npip install cryptography -> 50.0.2\n"
        "python p05_evaluator/p05_corpus.py -> 40 units (11 authorized + 29 adverse)\n"
        "python p05_evaluator/p05_run.py -> 80 obs; V1 15/40, V2 40/40, effect 0.625\n"
        "python p05_evaluator/p05_qa.py -> 8/8\npython make_archive_p05_final.py -> archive\n",
        encoding="utf-8", newline="\n")
    (META / "REPORT.md").write_text(
        "# P05 Final Measured Report\n\n"
        "RQ: can authenticated reference verification prevent acceptance of internally consistent but unauthorized evidence?\n\n"
        "Result: V1 (structural) common-objective correct 15/40 (own structural contract 40/40); V2 (structural + trusted "
        "Ed25519 reference) 40/40. Paired: both=15, V1_only=0, V2_only=25, both_incorrect=0, effect +0.625. Reasons exact 80/80; "
        "state transitions 40/40; G6/G7/G8 detectors 4/4 each. F31-F39 applied; PE01-PE16 PASS.\n\n"
        "Interpretation: authenticated reference verification rejects coordinated substitutions, wrong profile/construction "
        "contexts, invalid signatures, untrusted keys, missing references, and stale/rollback checkpoints that structural "
        "verification accepts. V1 acceptance of unauthorized-but-consistent evidence is not a V1 defect. No universal "
        "security, compromised-signer protection, production prevalence, or third-party replication claimed.\n",
        encoding="utf-8", newline="\n")

    files = []
    for d in [R1, R2, IMPL, HERE]:
        files.extend(walk(d))
    files.extend(sorted(META.glob("*")))
    relmap = []
    for p in files:
        relmap.append((p.relative_to(V19).as_posix(), p))
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in sorted(relmap)) + "\n"
    sp = META / "SHA256SUMS"
    sp.write_text(sums, encoding="utf-8")
    relmap.append(("_p05_meta_final/SHA256SUMS", sp))
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("_p05_meta_final/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"))
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d, "gates": gates["overall"],
                      "v1": agg["per_arm"]["V1"]["correct"], "v2": agg["per_arm"]["V2"]["correct"],
                      "effect": agg["paired"]["effect"], "raw": len(raw)}, indent=2))


if __name__ == "__main__":
    a, r, g = main()
    finish(a, r, g)