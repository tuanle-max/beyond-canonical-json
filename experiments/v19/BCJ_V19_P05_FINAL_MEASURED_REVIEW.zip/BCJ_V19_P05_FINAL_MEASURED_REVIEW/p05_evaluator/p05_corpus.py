"""P05-C measured corpus generator: 40 units (11 authorized + 29 adverse), synthetic Ed25519
signing, Merkle proofs, per-unit trusted context + initial state, expected V1/V2 outcomes."""
import base64
import hashlib
import json
import pathlib
import sys

IMPL = pathlib.Path(__file__).resolve().parents[1] / "p05_implementation"
sys.path.insert(0, str(IMPL))
import p05core as c
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

HERE = pathlib.Path(__file__).resolve().parent
SEED = "P05-R2A-SEED-42"


def _key(label):
    seed = hashlib.sha256(("P05-SYNTHETIC-KEY:" + SEED + ":" + label).encode()).digest()
    sk = ed25519.Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()
    return sk, pk


PUB_SK, PUB_PK = _key("publisher-1")
ATT_SK, ATT_PK = _key("attacker-1")


def rec(i, amt=None, ts=None, ben=None):
    return json.dumps({"event_id": "EV-%03d" % i, "timestamp": ts or "2026-01-0%dT00:00:00Z" % (1 + i % 9),
                       "amount": amt or "%d.00" % (100 + i), "currency": "USD", "scale": 2,
                       "beneficiary_code": ben or "B-%d" % i}).encode()


def build(records, seq=1, cid="CP-1", publisher="publisher-1", pid=None, cd=None, sk=None, batch="B-1"):
    pid = pid or c.PID_SEM
    cd = cd or c.CD
    canons = [c.canonical(r)[0] for r in records]
    leaves = [c.leaf_digest(ca, pid, cd) for ca in canons]
    root = c.mth(leaves)
    cp = {"checkpoint_version": "1", "checkpoint_id": cid, "publisher_id": publisher,
          "semantic_profile_digest": pid, "construction_digest": cd, "root": root.hex(),
          "batch_id": batch, "tree_size": len(records), "checkpoint_sequence": seq}
    sk = sk or PUB_SK
    sig = sk.sign(c.checkpoint_preimage(cp)).hex()
    return {"records": records, "leaves": leaves, "root": root, "cp": cp, "sig": sig, "pid": pid, "cd": cd}


def env_for(b, idx=0, root_hex=None, checkpoint=None, signer=None, signature=None,
            path_override=None, index_override=None, size_override=None):
    leaf = b["leaves"][idx]
    pth = path_override if path_override is not None else [x.hex() for x in c.path(b["leaves"], idx)]
    return {"envelope_version": "1", "construction": "v3",
            "record_b64": base64.b64encode(b["records"][idx]).decode(),
            "semantic_profile_digest": b["pid"], "construction_digest": b["cd"],
            "leaf_digest": leaf.hex(), "leaf_index": index_override if index_override is not None else idx,
            "tree_size": size_override if size_override is not None else len(b["records"]),
            "merkle_path": pth, "root": root_hex or b["root"].hex(),
            "checkpoint": checkpoint if checkpoint is not None else b["cp"],
            "signer_public_key": signer or PUB_PK, "signature": signature if signature is not None else b["sig"]}


def ctx_for(pid=None, cd=None, batch="B-1", size=4, cid="CP-1", keys=None, pub="publisher-1"):
    return {"publisher_id": pub, "authorized_checkpoint_id": cid, "batch_id": batch,
            "semantic_profile_digest": pid or c.PID_SEM, "construction_digest": cd or c.CD,
            "tree_size": size, "trusted_public_keys": keys if keys is not None else [PUB_PK]}


def state_fresh():
    return {"min_sequence": 0, "last_accepted_sequence": -1,
            "last_accepted_checkpoint_id": None, "last_accepted_checkpoint_digest": None}


def mk(uid, group, mech, env, ctx, state, ev1, ev2, r1, r2, auth):
    return {"unit_id": uid, "group": group, "mutation_mechanism": mech, "envelope": env,
            "trusted_context": ctx, "initial_state": state,
            "expected_v1_decision": ev1, "expected_v1_reason": r1,
            "expected_v2_decision": ev2, "expected_v2_reason": r2, "authorized": auth}
def units_G1():
    out = []
    for i in range(10):
        b = build([rec(i * 4 + k) for k in range(4)])
        out.append(mk("P05-G1-%02d" % (i + 1), "G1", "valid_authorized", env_for(b), ctx_for(),
                      state_fresh(), "ACCEPT", "ACCEPT", "ACCEPT_STRUCTURAL", "ACCEPT_AUTHORIZED", True))
    return out


def units_G2():
    mechs = ["rescale_amount", "shift_timestamp", "different_beneficiary", "alt_batch_membership",
             "duplicate_record", "reorder_records"]
    out = []
    for i, mech in enumerate(mechs):
        base = [rec(1000 + i * 10 + k) for k in range(4)]
        b_orig = build(base)
        if mech == "rescale_amount":
            rep = [rec(1000 + i * 10 + k, amt="%d.55" % (200 + k)) for k in range(4)]
        elif mech == "shift_timestamp":
            rep = [rec(1000 + i * 10 + k, ts="2026-03-1%dT05:05:05Z" % k) for k in range(4)]
        elif mech == "different_beneficiary":
            rep = [rec(1000 + i * 10 + k, ben="Z-%d" % k) for k in range(4)]
        elif mech == "alt_batch_membership":
            rep = [rec(7000 + i * 10 + k) for k in range(4)]
        elif mech == "duplicate_record":
            x = rec(1000 + i * 10)
            rep = [x, x, rec(1000 + i * 10 + 2), rec(1000 + i * 10 + 3)]
        else:
            rep = list(reversed([rec(1000 + i * 10 + k) for k in range(4)]))
        b_rep = build(rep)
        env = env_for(b_rep, checkpoint=b_orig["cp"], signature=b_orig["sig"])
        out.append(mk("P05-G2-%02d" % (i + 1), "G2", "coordinated_substitution:" + mech, env,
                      ctx_for(size=4), state_fresh(), "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL",
                      "EVIDENCE_INCONSISTENT", False))
    return out


def units_G3():
    out = []
    for i in range(4):
        pid2 = "%064x" % (0xAAAAAAAA + i)
        b = build([rec(2000 + i * 10 + k) for k in range(4)], pid=pid2)
        out.append(mk("P05-G3-%02d" % (i + 1), "G3", "wrong_profile_context", env_for(b),
                      ctx_for(pid=c.PID_SEM, size=4), state_fresh(), "ACCEPT", "REJECT",
                      "ACCEPT_STRUCTURAL", "PROFILE_MISMATCH", False))
    return out


def units_G4():
    out = []
    for i in range(4):
        cd2 = "%064x" % (0xBBBBBBBB + i)
        b = build([rec(3000 + i * 10 + k) for k in range(4)], cd=cd2)
        out.append(mk("P05-G4-%02d" % (i + 1), "G4", "wrong_construction_context", env_for(b),
                      ctx_for(cd=c.CD, size=4), state_fresh(), "ACCEPT", "REJECT",
                      "ACCEPT_STRUCTURAL", "CONSTRUCTION_MISMATCH", False))
    return out
def units_G5():
    out = []
    b = build([rec(4000 + k) for k in range(4)])
    p_bad = [x.hex() for x in c.path(b["leaves"], 0)]; p_bad[0] = "00" * 32
    out.append(mk("P05-G5-01", "G5", "invalid_proof_sibling", env_for(b, path_override=p_bad),
                  ctx_for(), state_fresh(), "REJECT", "REJECT", "ROOT_MISMATCH", "ROOT_MISMATCH", False))
    b2 = build([rec(4010 + k) for k in range(4)])
    out.append(mk("P05-G5-02", "G5", "invalid_leaf_position", env_for(b2, index_override=2),
                  ctx_for(), state_fresh(), "REJECT", "REJECT", "ROOT_MISMATCH", "ROOT_MISMATCH", False))
    b3 = build([rec(4020 + k) for k in range(4)])
    out.append(mk("P05-G5-03", "G5", "invalid_tree_size", env_for(b3, size_override=5),
                  ctx_for(), state_fresh(), "REJECT", "REJECT", "PROOF_INVALID", "PROOF_INVALID", False))
    b4 = build([rec(4030 + k) for k in range(4)])
    out.append(mk("P05-G5-04", "G5", "root_corruption", env_for(b4, root_hex="00" * 32),
                  ctx_for(), state_fresh(), "REJECT", "REJECT", "ROOT_MISMATCH", "ROOT_MISMATCH", False))
    return out


def units_G6():
    out = []
    b = build([rec(5000 + k) for k in range(4)])
    cp2 = dict(b["cp"]); cp2["checkpoint_sequence"] = 2
    out.append(mk("P05-G6-01", "G6", "modified_signed_field", env_for(b, checkpoint=cp2),
                  ctx_for(), state_fresh(), "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "INVALID_SIGNATURE", False))
    b2 = build([rec(5010 + k) for k in range(4)])
    out.append(mk("P05-G6-02", "G6", "untrusted_key",
                  env_for(b2, signer=ATT_PK, signature=ATT_SK.sign(c.checkpoint_preimage(b2["cp"])).hex()),
                  ctx_for(), state_fresh(), "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "UNTRUSTED_KEY", False))
    b3 = build([rec(5020 + k) for k in range(4)])
    out.append(mk("P05-G6-03", "G6", "malformed_signature", env_for(b3, signature="zz" * 64),
                  ctx_for(), state_fresh(), "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "INVALID_SIGNATURE", False))
    b4 = build([rec(5030 + k) for k in range(4)], publisher="publisher-X")
    out.append(mk("P05-G6-04", "G6", "unknown_publisher", env_for(b4),
                  ctx_for(), state_fresh(), "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "UNKNOWN_PUBLISHER", False))
    return out


def units_G7():
    out = []
    b = build([rec(6000 + k) for k in range(4)])
    out.append(mk("P05-G7-01", "G7", "missing_context", env_for(b), None, state_fresh(),
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "MISSING_TRUSTED_REFERENCE", False))
    b2 = build([rec(6010 + k) for k in range(4)])
    e2 = env_for(b2); del e2["checkpoint"]
    out.append(mk("P05-G7-02", "G7", "missing_checkpoint", e2, ctx_for(), state_fresh(),
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "MISSING_TRUSTED_REFERENCE", False))
    b3 = build([rec(6020 + k) for k in range(4)])
    e3 = env_for(b3); del e3["signer_public_key"]
    out.append(mk("P05-G7-03", "G7", "missing_signer_key", e3, ctx_for(), state_fresh(),
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "MISSING_TRUSTED_REFERENCE", False))
    b4 = build([rec(6030 + k) for k in range(4)])
    out.append(mk("P05-G7-04", "G7", "missing_trusted_state", env_for(b4), ctx_for(), None,
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "MISSING_TRUSTED_REFERENCE", False))
    return out
def units_G8():
    out = []
    b1 = build([rec(8000 + k) for k in range(4)])
    out.append(mk("P05-G8-01", "G8", "below_floor", env_for(b1), ctx_for(),
                  {"min_sequence": 5, "last_accepted_sequence": 0, "last_accepted_checkpoint_id": None,
                   "last_accepted_checkpoint_digest": None},
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "STALE_SEQUENCE", False))
    b2 = build([rec(8010 + k) for k in range(4)])
    out.append(mk("P05-G8-02", "G8", "exact_authorized_replay", env_for(b2), ctx_for(),
                  {"min_sequence": 0, "last_accepted_sequence": 1, "last_accepted_checkpoint_id": "CP-1",
                   "last_accepted_checkpoint_digest": c.checkpoint_digest(b2["cp"])},
                  "ACCEPT", "ACCEPT", "ACCEPT_STRUCTURAL", "ACCEPT_AUTHORIZED", True))
    b3a = build([rec(8020 + k) for k in range(4)], cid="CP-1", seq=1)
    b3b = build([rec(8030 + k) for k in range(4)], cid="CP-2", seq=1)
    out.append(mk("P05-G8-03", "G8", "equal_sequence_conflict", env_for(b3b), ctx_for(cid="CP-2"),
                  {"min_sequence": 0, "last_accepted_sequence": 1, "last_accepted_checkpoint_id": "CP-1",
                   "last_accepted_checkpoint_digest": c.checkpoint_digest(b3a["cp"])},
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "SEQUENCE_CONFLICT", False))
    b4 = build([rec(8040 + k) for k in range(4)])
    out.append(mk("P05-G8-04", "G8", "rollback_below_last", env_for(b4), ctx_for(),
                  {"min_sequence": 0, "last_accepted_sequence": 5, "last_accepted_checkpoint_id": "CP-9",
                   "last_accepted_checkpoint_digest": "00" * 32},
                  "ACCEPT", "REJECT", "ACCEPT_STRUCTURAL", "STALE_SEQUENCE", False))
    return out


def main():
    units = units_G1() + units_G2() + units_G3() + units_G4() + units_G5() + units_G6() + units_G7() + units_G8()
    assert len(units) == 40, len(units)
    assert sum(1 for u in units if u["authorized"]) == 10 + 1
    (HERE / "P05_MEASURED_CORPUS.jsonl").write_text(
        "".join(json.dumps({k: u[k] for k in ("unit_id", "group", "mutation_mechanism", "envelope",
                                               "trusted_context", "initial_state", "authorized")}, sort_keys=True) + "\n" for u in units),
        encoding="utf-8", newline="\n")
    (HERE / "P05_EVALUATOR_ORACLE.jsonl").write_text(
        "".join(json.dumps({k: u[k] for k in ("unit_id", "group", "expected_v1_decision", "expected_v1_reason",
                                               "expected_v2_decision", "expected_v2_reason", "authorized")}, sort_keys=True) + "\n" for u in units),
        encoding="utf-8", newline="\n")
    (HERE / "P05_PUBLIC_KEYS.json").write_text(json.dumps(
        {"publisher_public_key": PUB_PK, "attacker_public_key": ATT_PK,
         "note": "synthetic; private keys derived from seed and NOT shipped"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (HERE / "P05_ORACLE_PROVENANCE.json").write_text(json.dumps(
        {"seed": SEED, "synthetic_keys": True,
         "structural_oracle": "independent mth/path/verify reconstruction",
         "authorization_oracle": "independent Ed25519 verify + trusted-context/consistency/freshness",
         "units": 40, "authorized": 11, "adverse": 29,
         "note": "private signing keys not shipped; verifier receives only public envelopes + trusted contexts"},
        indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"units": len(units), "authorized": sum(1 for u in units if u["authorized"]),
                      "adverse": sum(1 for u in units if not u["authorized"])}, indent=2))


if __name__ == "__main__":
    main()