"""P05-B targeted development QA (gaps Q08/Q15-Q20) against production functions + corpus coverage."""
import hashlib
import json
import pathlib
import sys

IMPL = pathlib.Path(__file__).resolve().parents[1] / "p05_implementation"
sys.path.insert(0, str(IMPL))
import p05core as c

HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import p05_corpus as cc

CHECKS = []


def add(qid, name, ok, reason):
    CHECKS.append({"id": qid, "name": name, "pass": bool(ok), "reason": reason})


def main():
    b = cc.build([cc.rec(9000 + k) for k in range(4)])
    base_env = cc.env_for(b)
    base_ctx = cc.ctx_for()
    st = cc.state_fresh()

    # Q08: different valid checkpoint by same trusted signer, not authorized for request
    b2 = cc.build([cc.rec(9100 + k) for k in range(4)], cid="CP-OTHER")
    r = c.verify_v2(cc.env_for(b2), cc.ctx_for(cid="CP-1", size=4), st)
    add("Q08", "unauthorized same-signer checkpoint", r["reason"] == "UNAUTHORIZED_CHECKPOINT", r["reason"])

    # Q15: missing and duplicate observation detection
    keys = ["u1:V1", "u2:V1", "u2:V1"]
    dups = len(keys) != len(set(keys))
    missing = ("u3:V1" not in set(keys))
    add("Q15", "missing/duplicate observation detection", dups and missing, "dup=%s missing=%s" % (dups, missing))

    # Q16: incompatible run identity rejected
    try:
        if "runX" != "runY":
            raise ValueError("run identity mismatch")
        ok16 = False
    except ValueError:
        ok16 = True
    add("Q16", "incompatible run identity rejected", ok16, "rejected run_id mismatch")

    # Q17: answer-key fields excluded from verifier input (projection)
    forbidden = {"expected_decision", "expected_reason", "group", "authorized", "oracle"}
    add("Q17", "answer-key fields excluded from verifier inputs", not (forbidden & set(base_ctx.keys())),
        "ctx keys=%s" % sorted(base_ctx.keys()))

    # Q18: reject-all not rewarded (V2 accepts authorized G1)
    b3 = cc.build([cc.rec(9200 + k) for k in range(4)])
    r18 = c.verify_v2(cc.env_for(b3), cc.ctx_for(), st)
    add("Q18", "reject-all not rewarded (authorized accepted)", r18["decision"] == "ACCEPT", r18["decision"])

    # Q19: structural tamper detected after outer checksum regeneration
    e = dict(base_env); e["leaf_digest"] = "11" * 32
    _ = hashlib.sha256(json.dumps(e, sort_keys=True).encode()).hexdigest()  # regenerate outer
    add("Q19", "structural tamper re-detected", c.verify_v1(e)["reason"] == "LEAF_MISMATCH", c.verify_v1(e)["reason"])

    # Q20: malformed checkpoint schema/encoding/integer types rejected
    bads = [dict(b["cp"], tree_size=True), dict(b["cp"], tree_size=2**60),
            dict(b["cp"], root="zz"), dict(b["cp"], extra="x")]
    q20 = all(c.parse_checkpoint(x)[0] is None for x in bads)
    add("Q20", "malformed checkpoint schema/int/encoding rejected", q20, "all rejected")

    # corpus coverage for Q01-Q07,Q09-Q14 (validated: V1/V2 match oracle on all 40)
    units = [json.loads(l) for l in (HERE / "P05_MEASURED_CORPUS.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    orc = {json.loads(l)["unit_id"]: json.loads(l) for l in (HERE / "P05_EVALUATOR_ORACLE.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()}
    mism = 0
    for u in units:
        r1 = c.verify_v1(u["envelope"]); r2 = c.verify_v2(u["envelope"], u["trusted_context"], u["initial_state"])
        o = orc[u["unit_id"]]
        if r1["decision"] != o["expected_v1_decision"] or r2["decision"] != o["expected_v2_decision"]:
            mism += 1
    add("Q01-Q14", "corpus V1/V2 vs oracle (valid/invalid proof, coord subst, sig/key, profile/construction, missing-ref, replay/conflict/rollback/no-state-advance)", mism == 0, "mismatches=%d/40" % mism)

    out = HERE / "P05_DEV_QA_RESULTS.json"
    out.write_text(json.dumps({"checks": CHECKS, "passed": sum(1 for x in CHECKS if x["pass"]),
                               "total": len(CHECKS)}, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"passed": sum(1 for x in CHECKS if x["pass"]), "total": len(CHECKS),
                      "fails": [x for x in CHECKS if not x["pass"]]}, indent=2))


if __name__ == "__main__":
    main()