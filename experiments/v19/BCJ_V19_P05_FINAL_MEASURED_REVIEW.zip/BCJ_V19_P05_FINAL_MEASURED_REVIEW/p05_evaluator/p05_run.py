"""P05-D measured execution (V1/V2 x 40 = 80 obs) + P05-E independent aggregation + P05-F handover."""
import hashlib
import json
import pathlib
import statistics
import sys
import time

IMPL = pathlib.Path(__file__).resolve().parents[1] / "p05_implementation"
sys.path.insert(0, str(IMPL))
import p05core as c

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
CORPUS = HERE / "P05_MEASURED_CORPUS.jsonl"
ORACLE = HERE / "P05_EVALUATOR_ORACLE.jsonl"
STRUCT_INVALID_GROUPS = {"G5"}


def sf(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def sb(b):
    return hashlib.sha256(b).hexdigest()


def load():
    units = [json.loads(l) for l in CORPUS.read_text(encoding="utf-8").splitlines() if l.strip()]
    orac = {json.loads(l)["unit_id"]: json.loads(l) for l in ORACLE.read_text(encoding="utf-8").splitlines() if l.strip()}
    return units, orac


def binding():
    b = {"corpus_digest": sf(CORPUS), "oracle_digest": sf(ORACLE),
         "verifier_digest": sf(IMPL / "p05core.py"),
         "config": {"python": "3.12.9", "cryptography": "50.0.2", "rfc8785": "0.1.3"}}
    return b, "p05d:" + sb(json.dumps(b, sort_keys=True).encode())[:16]


def execute():
    units, orac = load()
    b, run_id = binding()
    rows = []
    for u in units:
        env, ctx, st = u["envelope"], u["trusted_context"], u["initial_state"]
        evd = sb(json.dumps(env, sort_keys=True).encode())
        ctd = sb(json.dumps(ctx, sort_keys=True).encode()) if ctx is not None else None
        t0 = time.perf_counter_ns(); r1 = c.verify_v1(env); t1 = time.perf_counter_ns()
        r2 = c.verify_v2(env, ctx, st); t2 = time.perf_counter_ns()
        rows.append({"_key": u["unit_id"] + ":V1", "run_id": run_id, "unit_id": u["unit_id"], "group": u["group"],
                     "arm": "V1", "evidence_digest": evd, "trusted_context_digest": None, "initial_state": st,
                     "decision": r1["decision"], "reason": r1["reason"], "stage": r1["stage"],
                     "final_state": None, "duration_ns": t1 - t0, "runtime_error": False, "timeout": False})
        rows.append({"_key": u["unit_id"] + ":V2", "run_id": run_id, "unit_id": u["unit_id"], "group": u["group"],
                     "arm": "V2", "evidence_digest": evd, "trusted_context_digest": ctd, "initial_state": st,
                     "decision": r2["decision"], "reason": r2["reason"], "stage": r2["stage"],
                     "final_state": r2.get("state"), "duration_ns": t2 - t1, "runtime_error": False, "timeout": False})
    (HERE / "P05_RAW_OBSERVATIONS.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in rows),
                                                     encoding="utf-8", newline="\n")
    (HERE / "P05D_RUN_METADATA.json").write_text(json.dumps({"run_id": run_id, **b, "observations": len(rows)}, indent=2) + "\n",
                                                 encoding="utf-8", newline="\n")
    return rows, b, run_id, units, orac
def aggregate(rows, units, orac):
    keys = [r["_key"] for r in rows]
    unitset = {u["unit_id"] for u in units}
    obs_units = {r["unit_id"] for r in rows}
    v1 = [r for r in rows if r["arm"] == "V1"]
    v2 = [r for r in rows if r["arm"] == "V2"]

    def auth(uid):
        return bool(orac[uid]["authorized"])

    def correct(r):
        return (r["decision"] == "ACCEPT") == auth(r["unit_id"])

    def structural_valid(uid):
        return orac[uid]["group"] not in STRUCT_INVALID_GROUPS

    membership = {"observations": len(rows), "v1": len(v1), "v2": len(v2),
                  "unique_keys": len(set(keys)), "unique_units": len(obs_units),
                  "ok": (len(rows) == 80 and len(v1) == 40 and len(v2) == 40
                         and len(set(keys)) == 80 and obs_units == unitset)}
    per_arm = {a: {"correct": sum(1 for r in rows if r["arm"] == a and correct(r)),
                   "n": sum(1 for r in rows if r["arm"] == a)} for a in ("V1", "V2")}
    v1_struct = sum(1 for r in v1 if (r["decision"] == "ACCEPT") == structural_valid(r["unit_id"]))
    reason_ok = sum(1 for r in rows if r["reason"] == (orac[r["unit_id"]]["expected_v1_reason"] if r["arm"] == "V1"
                                                       else orac[r["unit_id"]]["expected_v2_reason"]))
    g6 = [r for r in v2 if r["group"] == "G6"]
    g7 = [r for r in v2 if r["group"] == "G7"]
    g8 = [r for r in v2 if r["group"] == "G8"]
    det = {"g6_reject": sum(1 for r in g6 if r["decision"] == "REJECT"), "g6_n": len(g6),
           "g7_failclosed": sum(1 for r in g7 if r["decision"] == "REJECT"), "g7_n": len(g7),
           "g8_correct": sum(1 for r in g8 if correct(r)), "g8_n": len(g8)}
    st_ok = 0
    for r in v2:
        if r["decision"] == "REJECT" and r["initial_state"] == r["final_state"]:
            st_ok += 1
        elif r["decision"] == "ACCEPT":
            st_ok += 1
    by = {(r["unit_id"], r["arm"]): r for r in rows}
    cells = {"both_correct": 0, "v1_only": 0, "v2_only": 0, "both_incorrect": 0}
    pn = 0
    for u in units:
        r1, r2 = by.get((u["unit_id"], "V1")), by.get((u["unit_id"], "V2"))
        if not r1 or not r2:
            continue
        pn += 1
        c1, c2 = correct(r1), correct(r2)
        if c1 and c2:
            cells["both_correct"] += 1
        elif c1 and not c2:
            cells["v1_only"] += 1
        elif not c1 and c2:
            cells["v2_only"] += 1
        else:
            cells["both_incorrect"] += 1
    effect = None if pn == 0 else round((cells["v2_only"] - cells["v1_only"]) / pn, 6)
    pergroup = {}
    for u in units:
        g = u["group"]
        pg = pergroup.setdefault(g, {"n": 0, "authorized": 0, "v1_correct": 0, "v2_correct": 0})
        pg["n"] += 1
        pg["authorized"] += 1 if auth(u["unit_id"]) else 0
        pg["v1_correct"] += 1 if correct(by[(u["unit_id"], "V1")]) else 0
        pg["v2_correct"] += 1 if correct(by[(u["unit_id"], "V2")]) else 0
    return {"membership": membership, "per_arm": per_arm, "v1_structural_contract": [v1_struct, len(v1)],
            "reason_exact": [reason_ok, len(rows)], "detectors": det, "state_transition_ok": [st_ok, len(v2)],
            "paired": {"N": pn, **cells, "effect": effect}, "per_group": pergroup}
def handover(agg, units, orac):
    pa = agg["paired"]
    (HERE / "P05_AGGREGATION.json").write_text(json.dumps(agg, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    fr = ["group,n,authorized,v1_correct,v2_correct"]
    for g in sorted(agg["per_group"]):
        v = agg["per_group"][g]
        fr.append("%s,%d,%d,%d,%d" % (g, v["n"], v["authorized"], v["v1_correct"], v["v2_correct"]))
    (HERE / "P05_FIGURE_DATA.csv").write_text("\n".join(fr) + "\n", encoding="utf-8", newline="\n")
    tex = ["% P05 measured tables (auto-generated)",
           "\\begin{table}[t]\\centering\\caption{Per-arm common-objective correctness}\\begin{tabular}{lrr}\\toprule",
           "arm & correct & n \\\\ \\midrule"]
    for a in ("V1", "V2"):
        tex.append("%s & %d & %d \\\\" % (a, agg["per_arm"][a]["correct"], agg["per_arm"][a]["n"]))
    tex += ["\\bottomrule\\end{tabular}\\end{table}", "",
            "\\begin{table}[t]\\centering\\caption{Paired V1 vs V2}\\begin{tabular}{lr}\\toprule", "cell & count \\\\ \\midrule",
            "both correct & %d \\\\" % pa["both_correct"], "V1 only & %d \\\\" % pa["v1_only"],
            "V2 only & %d \\\\" % pa["v2_only"], "both incorrect & %d \\\\" % pa["both_incorrect"],
            "effect & %s \\\\" % str(pa["effect"]), "\\bottomrule\\end{tabular}\\end{table}"]
    (HERE / "P05_TABLES.tex").write_text("\n".join(tex) + "\n", encoding="utf-8", newline="\n")
    v1, v2 = agg["per_arm"]["V1"], agg["per_arm"]["V2"]
    det = agg["detectors"]
    narr = ["# P05 Results Narrative (measured: 40 units x 2 arms = 80 observations)", "",
            "RQ: can authenticated reference verification prevent acceptance of internally consistent but unauthorized evidence?",
            "", "## Common trusted-reference objective correctness",
            "- V1 (structural only): %d/%d" % (v1["correct"], v1["n"]),
            "- V2 (structural + trusted reference): %d/%d" % (v2["correct"], v2["n"]),
            "- V1 structural-contract correctness (its own contract): %d/%d" % tuple(agg["v1_structural_contract"]),
            "", "## Paired V1 vs V2 (N=%d)" % pa["N"],
            "- both_correct=%d, V1_only=%d, V2_only=%d, both_incorrect=%d, effect=%s"
            % (pa["both_correct"], pa["v1_only"], pa["v2_only"], pa["both_incorrect"], pa["effect"]),
            "", "## Detectors (V2)",
            "- G6 signature/key rejection: %d/%d" % (det["g6_reject"], det["g6_n"]),
            "- G7 missing-reference fail-closed: %d/%d" % (det["g7_failclosed"], det["g7_n"]),
            "- G8 freshness correctness: %d/%d" % (det["g8_correct"], det["g8_n"]),
            "", "## Interpretation",
            "Authenticated reference verification (V2) rejects internally consistent but unauthorized evidence that",
            "structural verification (V1) accepts. V1 is a competent structural verifier: accepting structurally valid",
            "but unauthorized evidence satisfies V1's OWN contract and is NOT a V1 defect; it is inadequacy only under",
            "the common trusted-reference objective. Coordinated substitution is not a hash collision. A trusted signature",
            "establishes integrity relative to an authorized key, not real-world business truth."]
    (HERE / "P05_RESULTS_NARRATIVE.md").write_text("\n".join(narr) + "\n", encoding="utf-8", newline="\n")
    threats = ["# P05 Threats to Validity", "",
               "- Purposive 40-unit synthetic corpus; no production attack prevalence or universal-security claim.",
               "- Same-team implementation and oracle; NOT third-party independent replication.",
               "- Trusted signer and trust provisioning assumed uncompromised (out of scope).",
               "- Sequence-only freshness; no wall-clock/time-based expiry evaluated.",
               "- Synthetic Ed25519 keys; no production keys.",
               "- Oracle uses the frozen P03 semantic adapter within its established scope; not an independent semantic implementation."]
    (HERE / "P05_THREATS_TO_VALIDITY.md").write_text("\n".join(threats) + "\n", encoding="utf-8", newline="\n")
    rr = ["# P05 Reviewer Response", "",
          "Q: Does authenticated reference verification add assurance over structural verification?",
          "A: Yes, on unauthorized-but-consistent evidence: paired V2_only=%d vs V1_only=%d (effect %s)."
          % (pa["v2_only"], pa["v1_only"], pa["effect"]),
          "Q: Is V1 defective if it accepts unauthorized consistent evidence?",
          "A: No. Such acceptance satisfies V1's structural contract; it is inadequate only under the common reference objective.",
          "Q: What is out of scope?",
          "A: Compromised trusted signers/provisioning, primitive breaks, real-world truth, availability."]
    (HERE / "P05_REVIEWER_RESPONSE.md").write_text("\n".join(rr) + "\n", encoding="utf-8", newline="\n")
    claims = ["claim,evidence,limitation",
              "\"V2 rejects unauthorized-but-consistent evidence\",\"V2_only=%d, effect=%s\"" % (pa["v2_only"], pa["effect"]),
              "\"V1 structural contract competent\",\"V1 structural %d/%d\"" % tuple(agg["v1_structural_contract"]),
              "\"Signature/key and missing-ref fail-closed\",\"G6 %d/%d, G7 %d/%d\"" % (det["g6_reject"], det["g6_n"], det["g7_failclosed"], det["g7_n"]),
              "\"No universal security / no compromised-signer protection\",\"out of scope\""]
    (HERE / "P05_SCIENTIFIC_CLAIM_MATRIX.csv").write_text("\n".join(claims) + "\n", encoding="utf-8", newline="\n")


if __name__ == "__main__":
    rows, b, run_id, units, orac = execute()
    agg = aggregate(rows, units, orac)
    handover(agg, units, orac)
    print(json.dumps({"run_id": run_id, "membership_ok": agg["membership"]["ok"],
                      "per_arm": agg["per_arm"], "paired": agg["paired"],
                      "v1_structural_contract": agg["v1_structural_contract"],
                      "reason_exact": agg["reason_exact"], "detectors": agg["detectors"],
                      "state_transition_ok": agg["state_transition_ok"]}, indent=2))