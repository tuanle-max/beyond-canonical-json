"""P05 core: commitment adapter (frozen P03), checkpoint codec, Ed25519, trust, freshness,
structural verifier, V1/V2 arms. Reuses frozen P03 primitives read-only; no P03/P04 modification."""
import hashlib
import importlib.util
import json
import pathlib

import rfc8785
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

V19 = pathlib.Path(__file__).resolve().parents[1]
BOO = V19 / "implementations" / "python-dev" / "boo.py"
PID_SEM = "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429"
CD = "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d"
DOMAIN_SEP = b"BCJ-V19-P05-CHECKPOINT\x00\x01"
HFIELDS = ("semantic_profile_digest", "construction_digest", "root")
INT_FIELDS = ("tree_size", "checkpoint_sequence")


def _load_boo():
    spec = importlib.util.spec_from_file_location("frozen_boo", str(BOO))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


_ENG = _load_boo()


def canonical(record_bytes):
    r = _ENG.adjudicate(record_bytes)
    if r["decision"] != "ACCEPT":
        return None, r["reason_code"]
    return bytes.fromhex(r["canonical_hex"]), None


def leaf_digest(canon, pid_hex, cd_hex):
    return hashlib.sha256(b"\x00\x03" + bytes.fromhex(pid_hex) + bytes.fromhex(cd_hex) + canon).digest()


def node(l, r):
    return hashlib.sha256(b"\x01" + l + r).digest()


def _k(n):
    k = 1
    while k * 2 < n:
        k *= 2
    return k


def mth(leaves):
    n = len(leaves)
    if n == 0:
        return hashlib.sha256(b"\x02\x00").digest()
    if n == 1:
        return leaves[0]
    k = _k(n)
    return node(mth(leaves[:k]), mth(leaves[k:]))


def path(leaves, idx):
    n = len(leaves)
    if n <= 1:
        return []
    k = _k(n)
    if idx < k:
        return path(leaves[:k], idx) + [mth(leaves[k:])]
    return path(leaves[k:], idx - k) + [mth(leaves[:k])]


def verify_path(leaf, idx, size, pth):
    """Recompute root from leaf + RFC9162 PATH; return root bytes or None."""
    if idx < 0 or idx >= size or len(pth) != _path_len(size, idx):
        return None
    fn, sn, r = idx, size - 1, leaf
    for p in pth:
        if sn == 0:
            return None
        if (fn & 1) or fn == sn:
            r = node(p, r)
            while (fn & 1) == 0 and fn != 0:
                fn >>= 1
                sn >>= 1
        else:
            r = node(r, p)
        fn >>= 1
        sn >>= 1
    return r if sn == 0 else None


def _path_len(n, idx):
    c = 0
    while n > 1:
        k = _k(n)
        if idx < k:
            n = k
        else:
            idx -= k
            n -= k
        c += 1
    return c
CP_REQUIRED = ["checkpoint_version", "checkpoint_id", "publisher_id", "semantic_profile_digest",
               "construction_digest", "root", "batch_id", "tree_size", "checkpoint_sequence"]
CP_OPTIONAL = ["issued_at"]
_HEX = set("0123456789abcdef")
_INT_MAX = 2 ** 53 - 1


def parse_checkpoint(obj):
    if not isinstance(obj, dict):
        return None, "SCHEMA_INVALID"
    allowed = set(CP_REQUIRED) | set(CP_OPTIONAL)
    if any(k not in allowed for k in obj):
        return None, "UNKNOWN_FIELD"
    if any(k not in obj for k in CP_REQUIRED):
        return None, "SCHEMA_INVALID"
    if obj["checkpoint_version"] != "1":
        return None, "UNSUPPORTED_VERSION"
    for k in ("checkpoint_id", "publisher_id", "batch_id"):
        if not isinstance(obj[k], str) or obj[k] == "":
            return None, "SCHEMA_INVALID"
    for k in HFIELDS:
        v = obj[k]
        if not isinstance(v, str) or len(v) != 64 or any(ch not in _HEX for ch in v):
            return None, "SCHEMA_INVALID"
    for k in INT_FIELDS:
        v = obj[k]
        if isinstance(v, bool) or not isinstance(v, int) or v < -_INT_MAX or v > _INT_MAX:
            return None, "SCHEMA_INVALID"
    return obj, None


def checkpoint_preimage(cp):
    return DOMAIN_SEP + rfc8785.dumps(cp)


def checkpoint_digest(cp):
    return hashlib.sha256(checkpoint_preimage(cp)).hexdigest()


def verify_signature(signer_hex, sig_hex, preimage):
    try:
        if not isinstance(signer_hex, str) or len(signer_hex) != 64 or any(c not in _HEX for c in signer_hex):
            return False
        if not isinstance(sig_hex, str) or len(sig_hex) != 128 or any(c not in _HEX for c in sig_hex):
            return False
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(signer_hex)).verify(bytes.fromhex(sig_hex), preimage)
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


def freshness_check(state, seq, cid, cdigest):
    if state is None:
        return False, "MISSING_TRUSTED_REFERENCE", state
    minseq = state.get("min_sequence", 0)
    last = state.get("last_accepted_sequence", -1)
    if seq < minseq or seq < last:
        return False, "STALE_SEQUENCE", state
    if seq == last:
        if cid == state.get("last_accepted_checkpoint_id") and cdigest == state.get("last_accepted_checkpoint_digest"):
            return True, "REPLAY", state
        return False, "SEQUENCE_CONFLICT", state
    ns = dict(state)
    ns.update({"last_accepted_sequence": seq, "last_accepted_checkpoint_id": cid,
               "last_accepted_checkpoint_digest": cdigest})
    return True, "ADVANCE", ns
REQ_ENV = ("envelope_version", "construction", "record_b64", "semantic_profile_digest",
           "construction_digest", "leaf_digest", "leaf_index", "tree_size", "merkle_path", "root")


def structural_verify(env):
    if not isinstance(env, dict):
        return "MALFORMED", None
    if any(k not in env for k in REQ_ENV):
        return "SCHEMA_INVALID", None
    if env["envelope_version"] != "1" or env["construction"] != "v3":
        return "UNSUPPORTED_VERSION", None
    import base64
    try:
        raw = base64.b64decode(env["record_b64"])
    except Exception:
        return "MALFORMED", None
    canon, err = canonical(raw)
    if canon is None:
        return "RECORD_INVALID", {"reason": err}
    pid, cdv = env["semantic_profile_digest"], env["construction_digest"]
    if not (isinstance(pid, str) and len(pid) == 64 and isinstance(cdv, str) and len(cdv) == 64):
        return "SCHEMA_INVALID", None
    leaf = leaf_digest(canon, pid, cdv)
    if leaf.hex() != env["leaf_digest"]:
        return "LEAF_MISMATCH", {"recomputed": leaf.hex()}
    idx, size, pth = env["leaf_index"], env["tree_size"], env["merkle_path"]
    if isinstance(idx, bool) or not isinstance(idx, int) or isinstance(size, bool) or not isinstance(size, int):
        return "SCHEMA_INVALID", None
    try:
        path_b = [bytes.fromhex(x) for x in pth]
    except Exception:
        return "MALFORMED", None
    root = verify_path(leaf, idx, size, path_b)
    if root is None:
        return "PROOF_INVALID", None
    if root.hex() != env["root"]:
        return "ROOT_MISMATCH", {"recomputed": root.hex()}
    return "ACCEPT", {"leaf": leaf.hex(), "root": root.hex()}


def verify_v1(env):
    d, info = structural_verify(env)
    if d == "ACCEPT":
        return {"decision": "ACCEPT", "reason": "ACCEPT_STRUCTURAL", "stage": "structural", "info": info}
    return {"decision": "REJECT", "reason": d, "stage": "structural", "info": info}


def verify_v2(env, ctx, state):
    d, info = structural_verify(env)
    if d != "ACCEPT":
        return {"decision": "REJECT", "reason": d, "stage": "structural", "info": info, "state": state}
    if ctx is None:
        return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
    cp = env.get("checkpoint")
    if not isinstance(cp, dict):
        return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
    cpp, cerr = parse_checkpoint(cp)
    if cerr:
        return {"decision": "REJECT", "reason": cerr, "stage": "trust", "state": state}
    if cpp["publisher_id"] != ctx["publisher_id"]:
        return {"decision": "REJECT", "reason": "UNKNOWN_PUBLISHER", "stage": "trust", "state": state}
    signer, sig = env.get("signer_public_key"), env.get("signature")
    if signer is None or sig is None:
        return {"decision": "REJECT", "reason": "MISSING_TRUSTED_REFERENCE", "stage": "trust", "state": state}
    pre = checkpoint_preimage(cpp)
    if not verify_signature(signer, sig, pre):
        return {"decision": "REJECT", "reason": "INVALID_SIGNATURE", "stage": "signature", "state": state}
    if signer not in ctx.get("trusted_public_keys", []):
        return {"decision": "REJECT", "reason": "UNTRUSTED_KEY", "stage": "signature", "state": state}
    if cpp["checkpoint_id"] != ctx.get("authorized_checkpoint_id"):
        return {"decision": "REJECT", "reason": "UNAUTHORIZED_CHECKPOINT", "stage": "authorization", "state": state}
    if cpp["semantic_profile_digest"] != ctx["semantic_profile_digest"] or cpp["semantic_profile_digest"] != env["semantic_profile_digest"]:
        return {"decision": "REJECT", "reason": "PROFILE_MISMATCH", "stage": "context", "state": state}
    if cpp["construction_digest"] != ctx["construction_digest"] or cpp["construction_digest"] != env["construction_digest"]:
        return {"decision": "REJECT", "reason": "CONSTRUCTION_MISMATCH", "stage": "context", "state": state}
    if cpp["batch_id"] != ctx["batch_id"]:
        return {"decision": "REJECT", "reason": "BATCH_MISMATCH", "stage": "context", "state": state}
    if cpp["tree_size"] != ctx["tree_size"] or cpp["tree_size"] != env["tree_size"]:
        return {"decision": "REJECT", "reason": "TREE_SIZE_MISMATCH", "stage": "context", "state": state}
    if cpp["root"] != env["root"]:
        return {"decision": "REJECT", "reason": "EVIDENCE_INCONSISTENT", "stage": "consistency", "state": state}
    ok, reason, ns = freshness_check(state, cpp["checkpoint_sequence"], cpp["checkpoint_id"], checkpoint_digest(cpp))
    if not ok:
        return {"decision": "REJECT", "reason": reason, "stage": "freshness", "state": state}
    return {"decision": "ACCEPT", "reason": "ACCEPT_AUTHORIZED", "stage": "accept", "state": ns, "info": info}