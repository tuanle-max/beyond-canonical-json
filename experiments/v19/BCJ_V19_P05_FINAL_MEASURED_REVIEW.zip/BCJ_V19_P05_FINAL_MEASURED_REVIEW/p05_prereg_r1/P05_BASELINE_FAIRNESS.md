# P05 Baseline Fairness (V1 vs V2)

V1 and V2 MUST share:
- identical evidence input bytes (record, profile/construction context, proof, envelope, checkpoint bytes);
- identical frozen K-v2 commitment adapter and leaf/tree reconstruction;
- identical checkpoint parser and JCS serializer;
- identical structural verifier implementation (the same module/function);
- identical runtime (Python version, dependencies) and resource limits;
- identical failure-category vocabulary for structural outcomes.

The ONLY permitted experimental difference: V2 additionally performs trusted-reference verification
(trust-store lookup, Ed25519 signature verification with trusted key, expected pid/cd/root/batch/tree_size
comparison, freshness policy).

Controls:
- V2 must not add any structural advantage V1 lacks; both call the same structural verifier first.
- V2 must not obtain trust from the envelope; V1 has no trust dependency by design.
- A machine-checkable fairness record asserts, per unit: equal input digest, equal structural-verifier
  result, equal runtime config, and single permitted differing field = `trusted_reference_verification`.

Any material fairness violation is a process-gate failure.
