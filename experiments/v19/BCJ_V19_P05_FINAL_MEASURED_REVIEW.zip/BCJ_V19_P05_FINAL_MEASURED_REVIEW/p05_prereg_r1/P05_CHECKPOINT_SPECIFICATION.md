# P05 Signed Checkpoint Specification (v1)

## Fields (signed)
Required: `checkpoint_version` (str, "1"), `checkpoint_id` (str), `publisher_id` (str),
`semantic_profile_digest` (str, 64-hex), `construction_digest` (str, 64-hex), `root` (str, 64-hex),
`batch_id` (str), `tree_size` (int), `checkpoint_sequence` (int).
Optional: `issued_at` (str, RFC3339) — INFORMATIONAL only; NOT used for P05 freshness decisions (see P05_FRESHNESS_POLICY.md).

## Serialization and signature
- Canonical serialization: **RFC 8785 (JCS)** over the checkpoint object, within its supported domain.
- Duplicate keys: REJECT. Unknown fields: REJECT. Non-canonical/ineligible values: REJECT (`MALFORMED`).
- Domain separation: `DOMAIN_SEP = b"BCJ-V19-P05-CHECKPOINT\x00\x01"` (frozen, exact bytes).
- Signature preimage: `DOMAIN_SEP || JCS(checkpoint)`.
- Algorithm: **Ed25519** (no custom scheme). Library: `cryptography` (`...asymmetric.ed25519`); exact version
  pinned at implementation freeze (PENDING; see open issues).
- Signature encoding: lowercase hex of the 64-byte signature. Public-key encoding: lowercase hex of 32 bytes.
- The verifier never receives the signing private key; fixture signing is separate from verifier execution.

## Verification order
parse → duplicate/unknown reject → required-field/type check → version/construction check →
reconstruct preimage → Ed25519 verify with trusted key → trusted-reference field comparison → freshness.

## Failure categories
`MALFORMED`, `DUPLICATE_KEY`, `UNKNOWN_FIELD`, `UNSUPPORTED_VERSION`, `INVALID_SIGNATURE`, `UNTRUSTED_KEY`,
`UNKNOWN_PUBLISHER`, `PROFILE_MISMATCH`, `CONSTRUCTION_MISMATCH`, `ROOT_MISMATCH`, `BATCH_MISMATCH`,
`TREE_SIZE_MISMATCH`, `MISSING_TRUSTED_REFERENCE`, `STALE_SEQUENCE`.

## Non-claims
The checkpoint signature establishes integrity relative to a trusted key; it does not establish real-world truth of
the underlying business event.
