# P05 Experimental Protocol (preregistration R1)

## Objective
Evaluate the distinction between (i) internal structural consistency and (ii) consistency with an
authenticated, independently provisioned trusted reference. Central question: can authenticated
reference verification prevent acceptance of internally consistent but unauthorized commitment evidence
that structural verification alone cannot distinguish from valid evidence?

P05 complements (does not duplicate) P03/P04. P05 is not a blockchain consensus experiment, not a general
cryptographic security proof, and does not establish semantic correctness independently of frozen K-v2.

## Arms (only intended difference = trusted-reference verification)
- **V1 — Structural verification**: schema, supported v3 construction, record→leaf consistency, Merkle proof
  validity, leaf position/tree size, consistency with the root in the envelope. No independent authorization state.
  V1 is a competent structural verifier (not intentionally weakened).
- **V2 — Authenticated trusted-reference verification**: same structural verifier PLUS independently provisioned
  trusted publisher identity, trusted Ed25519 public key, checkpoint signature, expected semantic-profile id,
  expected construction digest, expected root, expected batch id, expected tree size, checkpoint sequence/freshness.
  V2 never derives trust solely from the envelope and fails closed when a trust dependency is absent.

## Corpus (frozen before execution)
Exactly 40 primary units: G1 10 valid controls; G2 6 coordinated substitutions; G3 4 wrong profile contexts;
G4 4 wrong construction contexts; G5 4 invalid root/proof; G6 4 invalid-signature/untrusted-key; G7 4 missing
required reference; G8 4 stale/rollback. = 30 adverse + 10 valid. Each unit yields a V1 and a V2 observation →
**80 planned primary observations**. Purposive, synthetic; no production sampling.

## Stages
- P05-A preregistration (this package). - P05-B development/QA (gated). - P05-C evaluator corpus + oracle freeze.
- P05-D measured execution (GATED, not authorized). - P05-E/F independent aggregation + handover.

## Authorization
P05 preregistration AUTHORIZED. P05 measured execution NOT_AUTHORIZED_PENDING_PROTOCOL_APPROVAL. No P03/P04
reopen; no P07 remediation; no manuscript modification; no blockchain/hardware/network infrastructure.
Reuse frozen P03 primitives and the v3 commitment construction; do not alter historical v2 commitments.
