# P05 Freshness and Rollback Policy (prospective; G8 = 4 units)

## Trusted state
Per `(publisher_id, semantic_profile_digest)` keyed state:
- `min_checkpoint_sequence` (configured floor),
- `last_accepted_sequence` (int, initialized from trusted provisioning or empty),
- `last_accepted_checkpoint_id` (str, or empty).

## Rules (evaluated by V2)
1. **State initialization:** empty state ⇒ a checkpoint with `checkpoint_sequence >= min_checkpoint_sequence` is
   acceptable as the first observed reference; state set to it. Missing trusted state provisioning where a floor is
   required ⇒ fail closed (`MISSING_TRUSTED_REFERENCE`).
2. **Lower sequence:** `checkpoint_sequence < min_checkpoint_sequence` OR
   `< last_accepted_sequence` ⇒ REJECT (`STALE_SEQUENCE`).
3. **Equal-sequence replay:** `checkpoint_sequence == last_accepted_sequence` AND same `checkpoint_id` ⇒
   idempotent ACCEPT (replay; state unchanged).
4. **Equal-sequence conflict:** equal sequence AND different `checkpoint_id` ⇒ REJECT (`STALE_SEQUENCE`/conflict).
5. **State update:** only on accepting a checkpoint with `checkpoint_sequence > last_accepted_sequence`.
6. **No wall-clock in deterministic fixtures:** `issued_at` is informational and is NOT used for freshness decisions.
   If time-based expiry is added later, an explicit frozen evaluation clock must be specified before corpus freeze.

## G8 units (deterministic)
- G8-01 lower-than-floor ⇒ REJECT (STALE_SEQUENCE).
- G8-02 equal-sequence replay, same checkpoint_id ⇒ ACCEPT (idempotent).
- G8-03 equal-sequence, different checkpoint_id ⇒ REJECT (conflict).
- G8-04 rollback below last accepted sequence ⇒ REJECT (STALE_SEQUENCE).

If freshness cannot be specified rigorously for any unit, a documented prospective replacement is proposed before
corpus freeze; G8 is never changed after observing measured outcomes.
