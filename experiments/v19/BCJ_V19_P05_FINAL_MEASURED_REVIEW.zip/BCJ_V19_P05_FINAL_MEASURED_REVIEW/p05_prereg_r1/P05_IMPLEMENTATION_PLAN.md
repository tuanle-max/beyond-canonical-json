# P05 Minimal Implementation Plan (Python, solo-researcher feasible)

## Modules
1. `commitment_adapter` — reuse frozen P03 K-v2 primitives (canonical→leaf→tree) read-only; no new normalization.
2. `checkpoint_serializer` — strict parse + JCS canonicalization + domain-separated preimage (`P05_CHECKPOINT_SPECIFICATION.md`).
3. `ed25519_adapter` — thin wrapper over `cryptography` Ed25519 (sign for fixtures / verify for V2); exact version pinned at freeze.
4. `trust_store` — independent provisioning loader + lookup by publisher/checkpoint_id.
5. `freshness_policy` — sequence floor + state (see `P05_FRESHNESS_POLICY.md`).
6. `structural_verifier` — the single shared V1 core (schema, leaf, proof, root).
7. `v1_wrapper` — structural only.
8. `v2_wrapper` — structural + trust + freshness; fails closed on missing trust.
9. `fixture_generator` — deterministic synthetic evidence + checkpoints + trust stores (seed frozen).
10. `independent_oracle` — separately coded reconstruction (leaf/tree/proof preimage/checkpoint preimage).
11. `raw_runner` — run-bound raw observation writer (membership, resume, failure records).
12. `aggregator` — independent aggregation from raw per-unit observations.

## Constraints
- Prefer Python; reuse accepted P03 primitives; do NOT modify frozen P03/P04 source.
- No blockchain transactions, no hardware, no external network services, no new semantic-normalization engine.
- Performance measurement is SECONDARY; no large benchmark campaign unless justified.
- Synthetic experimental keys only; fixture signing separated from verifier execution; verifier never receives private keys.
