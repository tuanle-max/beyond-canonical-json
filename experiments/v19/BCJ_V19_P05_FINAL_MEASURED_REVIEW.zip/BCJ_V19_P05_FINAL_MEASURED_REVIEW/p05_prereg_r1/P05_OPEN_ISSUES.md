# P05 Open Issues (pre-freeze; resolved before measured corpus freeze)

1. **Ed25519 library exact version** — intended maintained library `cryptography` (Ed25519), exact version pin
   PENDING implementation freeze (section 6 requires a pinned version before freeze). Not yet installed in the env.
2. **Domain-separation bytes** — proposed `b"BCJ-V19-P05-CHECKPOINT\x00\x01"`; to be frozen byte-exact at P05-B.
3. **Signature/key encoding** — chosen lowercase hex (sig 128 hex, pubkey 64 hex); confirm before freeze.
4. **Freshness clock** — no wall-clock; sequence-only deterministic policy. `issued_at` informational only. If any
   time-based expiry is later desired, freeze an explicit evaluation clock before corpus freeze (none planned).
5. **Corpus seed** — deterministic synthetic generation seed to be frozen at P05-C (value pending).
6. **Trust-store contents** — synthetic keys/publishers to be frozen with the corpus (values pending).
7. **G8 replay rule** — freshness policy documents idempotent replay-accept; the 4 scored G8 units are all
   stale/rollback (reject). Confirm whether an explicit replay-accept unit should be added (currently NOT added;
   would change cardinality if added — requires prospective methodological decision, not post-hoc).
8. **Oracle independence** — procedural evaluator-session separation; NOT OS-enforced; no independent-authorship claim.

Status: none of these block preregistration review; all must be closed before P05 measured corpus freeze.
