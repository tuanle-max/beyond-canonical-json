# P05 Oracle Specification (two independent layers)

## Layer 1 — Structural validity oracle
Independently reconstruct, from frozen specifications (not the tested verifier):
- record canonical bytes via frozen K-v2 adapter;
- leaf preimage `0x0003 || pid || cd || canonical` and leaf digest;
- ordered RFC9162 recursive-split tree, internal nodes (`0x01 || L || R`), root;
- Merkle proof relationship: leaf position + sibling path recomputes the envelope root;
- record→leaf and root consistency.
Determines expected structural outcome (accept if internally consistent; reject if proof/root/leaf inconsistent).

## Layer 2 — Trusted-reference authorization oracle
Independently reconstruct the signed checkpoint preimage `DOMAIN_SEP || JCS(checkpoint)` and verify Ed25519 with the
independently provisioned trusted key; compare expected pid/cd/root/batch/tree_size and apply the freshness policy.
Determines expected authorization outcome distinct from structural validity.

## Independence controls
- Do NOT use the tested verifier as the sole oracle. Oracle uses separately coded reconstruction.
- Procedural separation: an evaluator session/workspace generates expected outcomes; the verifier workspace does not
  receive the measured answer key before verifier code is frozen.
- Freeze verifier code, checkpoint spec, trust-store schema, and freshness policy BEFORE exposing the measured key.
- Maintain separate D_DEV (development fixtures) and D_EVAL (measured) inventories with hashes.
- No claim of independent human authorship or OS-enforced isolation.
