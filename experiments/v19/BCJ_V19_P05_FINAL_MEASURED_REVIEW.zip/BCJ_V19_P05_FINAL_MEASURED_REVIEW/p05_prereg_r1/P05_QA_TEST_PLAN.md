# P05 QA Test Plan (documented for P05-B; NOT executed in preregistration)

Targeted development tests (executed against PRODUCTION validation functions during P05-B):
1. Valid proof → structural ACCEPT.
2. Invalid proof (sibling/path corruption) → structural REJECT.
3. Coordinated replacement proof + root (internally consistent, differs from trusted ref) → V1 ACCEPT, V2 REJECT.
4. Valid trusted signature → V2 signature ACCEPT.
5. Modified signed checkpoint field (root/batch/tree_size/pid/cd) after signing → V2 REJECT (INVALID_SIGNATURE).
6. Valid signature under untrusted key → V2 REJECT (UNTRUSTED_KEY).
7. Missing trusted key → V2 fail closed (MISSING_TRUSTED_REFERENCE).
8. Wrong semantic-profile identifier → V2 REJECT (PROFILE_MISMATCH).
9. Wrong construction digest → V2 REJECT (CONSTRUCTION_MISMATCH).
10. Wrong batch identifier / tree size → V2 REJECT.
11. Missing trusted reference (no trust store entry) → V2 fail closed.
12. Stale sequence / rollback → V2 REJECT (STALE_SEQUENCE); equal-sequence replay idempotent ACCEPT; conflict REJECT.
13. Invalid resume identity (run_id / lock digest mismatch) → REJECT resume.
14. Duplicate observation → detected.
15. Missing observation → detected (not N/A).
16. Oracle digest mismatch → detected.
17. Arbitrary blocking incorrectly rewarded → NOT rewarded (block needs valid basis).
18. Structural tamper with regenerated outer checksum → rejected by structural/semantic validation.

QA must exercise actual production functions during P05-B; planned tests are not counted as executed. Crash/timeout
is not successful rejection. A reject-all verifier is not rewarded (M10 false-rejection penalizes it).
