# P05 Research Questions and Hypotheses

## RQ
Can authenticated reference verification prevent acceptance of internally consistent but unauthorized
commitment evidence that structural verification alone cannot distinguish from valid evidence?

## Hypotheses (falsifiable; non-support retained)
- **H1 (coordinated substitution):** V2 rejects internally consistent replacement evidence (G2) that V1 structurally
  accepts, because the trusted reference (pid/cd/root/batch/tree_size) differs.
- **H2 (invalid signature / untrusted key):** V2 rejects mathematically-valid signatures under untrusted keys and
  invalid signatures (G6); V1 (structural only) accepts them as structurally consistent.
- **H3 (missing reference):** V2 fails closed when a required trust dependency is absent (G7); V1 accepts.
- **H4 (freshness/rollback):** V2 enforces the prospective freshness policy and rejects stale/rollback checkpoints (G8).
- **H5 (no false rejection):** V2 accepts all 10 valid controls (G1) with correct trusted reference.
- **H6 (V1 structural contract):** V1 correctly accepts structurally valid evidence and rejects structurally invalid
  evidence (G5) — its OWN contract. This is reported separately from V1's adequacy under the common security objective.

Hypothesis support is NOT a process-completion condition. Negative results are preserved. No population-level
attack probability or universal-detection claim is made from the purposive 40-unit corpus.
