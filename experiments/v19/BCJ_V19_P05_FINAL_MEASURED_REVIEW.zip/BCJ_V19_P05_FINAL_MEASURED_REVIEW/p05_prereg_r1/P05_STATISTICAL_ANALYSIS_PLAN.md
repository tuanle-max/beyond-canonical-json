# P05 Statistical Analysis Plan

## Primary analysis (exact descriptive)
- Report exact counts per group (G1–G8) and per mechanism.
- Common sanctioned-evidence objective (both arms): a unit is "correct" iff the verifier's accept/reject decision
  matches the trusted-reference authorization oracle. V2 has the trusted reference; V1 does not, so under the common
  objective V1 accepting unauthorized-but-consistent evidence is incorrect (structural-only adequacy, not a defect).
- Paired V1/V2 four cells: both_correct, V1_only_correct, V2_only_correct, both_incorrect.
- Paired descriptive effect: `(V2_only_correct − V1_only_correct) / N` with the frozen paired denominator.

## Structural-only reporting (separate)
- V1's OWN structural contract: correctly accept structurally valid, correctly reject structurally invalid (G5).
  Reported separately; never conflated with adequacy under the common objective.

## Detector-specific
- Report by adverse group and mechanism: substitution acceptance (M05), signature/key (M06/M07), missing-reference
  fail-closed (M08), freshness/rollback (M09), false rejection of valid (M10).

## Inference constraints
- Purposive 40-unit synthetic corpus: NO population-level attack-probability claim, NO universal-detection claim.
- Preserve template/mechanism dependence; do not pool correlated units into binomial confidence bounds.
- Negative/neutral results are retained. Positive measured effect is NOT a process-completion condition.
- McNemar (if reported at all) is supplementary/exploratory under the purposive design.
