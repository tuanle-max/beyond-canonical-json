# P05 Threat Model

## Adversary
An untrusted evidence producer or intermediary that can:
- modify records, semantic-profile/construction contexts, Merkle proofs, roots, and envelope metadata;
- generate internally consistent replacement commitment trees (recompute leaves/nodes/root/proofs);
- generate signatures under attacker-controlled (untrusted) keys;
- cannot forge signatures under uncompromised trusted keys (subject to standard Ed25519 assumptions).

## Explicitly excluded (out of scope)
- Compromised trusted signer (an authorized signer endorsing false evidence).
- Compromised trust provisioning / key-distribution compromise.
- Malicious or subverted trusted verifier.
- Cryptographic primitive breaks (hash or Ed25519 breaks).
- Guaranteed detection of semantically incorrect evidence endorsed by an authorized signer.
- Availability/denial-of-service attacks outside the evaluated scope.

## Security statement
Authenticated reference verification establishes consistency with an authorized reference (the trusted
provisioning), NOT the real-world truth of the underlying business event. It complements semantic correctness
(frozen K-v2) and structural integrity; it does not replace either.
