# P05 Trust Provisioning Specification

## Independent trust store
Provisioned independently of the evidence envelope. Each entry:
- `publisher_id` (str)
- `trusted_public_keys` (list of 32-byte hex Ed25519 keys; an authorized key set)
- `authorized_semantic_profile_digest` (64-hex)
- `authorized_construction_digest` (64-hex)
- `expected_batch_id` (str, optional)
- `expected_tree_size` (int, optional)
- `min_checkpoint_sequence` (int; rollback floor where applicable)

## Checkpoint selection
The evidence envelope carries `trusted_ref.checkpoint_id`. V2 fetches the checkpoint by id and resolves the
publisher + key via the INDEPENDENT trust store. An attacker-supplied key embedded in the envelope is never
consulted for trust.

## Never-accept rules
- A mathematically valid signature under a key not present in the trust store ⇒ REJECT (`UNTRUSTED_KEY`).
- A valid signature from an untrusted publisher ⇒ REJECT (`UNKNOWN_PUBLISHER`) even if the signature verifies.
- Trust-store authorized `semantic_profile_digest`/`construction_digest` must equal the checkpoint values AND the
  evidence's declared context ⇒ else `PROFILE_MISMATCH` / `CONSTRUCTION_MISMATCH`.

## Distinct properties (not equivalent)
Signature validity ≠ signer authorization ≠ reference authorization ≠ context consistency ≠ freshness.
The verifier reports which property failed, not a pooled "invalid".

## Scope
Synthetic experimental keys only. No claim of security against compromised trusted signers or compromised trust
provisioning (out of scope, see P05_THREAT_MODEL.md).
