# P05 Verification Contract (V1 / V2)

Both arms use the SAME structural verifier implementation and the SAME evidence bytes, commitment adapter,
checkpoint parser, runtime, and resource limits. The only added mechanism in V2 is trusted-reference verification.

## V1 — Structural verification (ordered steps)
1. Parse envelope strictly (UTF-8, duplicate-key reject, unknown-field reject).
2. Enforce evidence schema and supported `checkpoint_version` / commitment construction = v3.
3. Recompute record canonical bytes via the frozen K-v2 adapter; recompute leaf preimage/digest
   (`0x0003 || pid || cd || canonical`).
4. Validate leaf position and tree size; recompute Merkle path with `0x01` internal nodes and RFC9162 split.
5. Compare recomputed root with the root supplied in the envelope.
6. Result categories: ACCEPT_STRUCTURAL / REJECT_STRUCTURAL with reason (`PROOF_INVALID`,
   `ROOT_MISMATCH`, `LEAF_MISMATCH`, `SCHEMA_INVALID`, `MALFORMED`, `UNSUPPORTED_VERSION`, ...).

V1 has no authorization state; it accepts any internally consistent evidence.

## V2 — Authenticated trusted-reference verification
V2 runs all V1 steps, then ADDITIONALLY:
1. Select the checkpoint referenced by the evidence envelope's `trusted_ref.checkpoint_id`.
2. Look up the checkpoint's publisher in the INDEPENDENT trust store (never from the envelope key).
3. Verify the Ed25519 signature over `DOMAIN_SEP || JCS(checkpoint)` using a trusted public key.
4. Compare checkpoint `semantic_profile_digest`, `construction_digest`, `root`, `batch_id`, `tree_size`
   against the trust store's authorized values AND against the evidence envelope.
5. Enforce the prospective freshness/sequence policy.
6. Fail closed (`MISSING_TRUSTED_REFERENCE`) when any required trust dependency is absent.

## Failure categories (V2 superset)
`ACCEPT`, `REJECT_STRUCTURAL`, `MALFORMED`, `UNSUPPORTED_VERSION`, `INVALID_SIGNATURE`, `UNTRUSTED_KEY`,
`UNKNOWN_PUBLISHER`, `PROFILE_MISMATCH`, `CONSTRUCTION_MISMATCH`, `ROOT_MISMATCH(trusted)`, `BATCH_MISMATCH`,
`TREE_SIZE_MISMATCH`, `MISSING_TRUSTED_REFERENCE`, `STALE_SEQUENCE`.

## Fairness
Distinguish V1's OWN structural contract correctness from its adequacy under the common sanctioned-evidence
objective (accept iff authorized by the trusted reference). An expected structural acceptance is NOT a V1 defect.
