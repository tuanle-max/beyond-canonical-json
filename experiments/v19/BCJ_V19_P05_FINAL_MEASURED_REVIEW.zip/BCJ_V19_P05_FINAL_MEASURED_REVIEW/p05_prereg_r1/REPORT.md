# P05 Preregistration R1 Report

Objective: can authenticated reference verification prevent acceptance of internally consistent but unauthorized evidence that structural verification cannot distinguish from valid evidence?

Arms: V1 structural (no independent trust) vs V2 structural + trusted Ed25519 reference (independent trust store, expected pid/cd/root/batch/tree_size, sequence freshness). Only added mechanism = trusted-reference.

Corpus: exactly 40 units (G1 10 valid; G2 6 coordinated; G3 4 profile; G4 4 construction; G5 4 root/proof; G6 4 sig/key; G7 4 missing-ref; G8 4 stale/rollback) = 30 adverse + 10 valid; 80 planned V1/V2 observations.

Status: READY_FOR_EXPERIMENT_LEAD_REVIEW. Measured execution NOT authorized. P04 F24-F30 remain OPEN_MANDATORY.
