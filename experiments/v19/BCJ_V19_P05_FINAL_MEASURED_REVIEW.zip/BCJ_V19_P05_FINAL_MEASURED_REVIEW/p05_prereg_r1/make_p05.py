"""Generate P05 structured preregistration deliverables + build the R1 review archive (non-circular)."""
import csv
import hashlib
import json
import os
import platform
import pathlib
import zipfile

import yaml

HERE = pathlib.Path(__file__).resolve().parent
V19 = HERE.parent
NAME = "BCJ_V19_P05_PREREG_R1_REVIEW"
OUT = V19 / (NAME + ".zip")

FROZEN = {
    "p04_scientific_commit": "d293c4423a6f81debda6ee84d4b46f6df0b6278d",
    "p04_admin_commit": "bc0845b4a99c17e1ee94893320ed93f452fab206",
    "p04_archive_sha256": "2900ffb2bca0ac91ad33d6661bcbd457976f19256b1266ca7a9e6e3f457e204b",
    "python_source_sha256": "2b6924010d528f39c05ac1f5d332ecee814e2d6a09fa3e38425daa97d119355f",
    "go_source_sha256": "493102b2265996b734f2d67931ed07547d69026af09d0ea0dbe9f1a98467a5fa",
    "pid_sem_v2": "caa2f3e561edbac1f73ec2926bea8009cce176ba8b8c7f900ebc7e8de454b429",
    "construction_digest": "d1e46eb5c6e0688b03c085ce5ed83ba134fffc6638a5fc0df8ed143b12aaf91d",
}
SPEC = [
    ("G1", 10, "valid evidence + matching trusted reference", "trusted ref matches", "ACCEPT", "ACCEPT", "ACCEPT", True),
    ("G2", 6, "coordinated substitution (internally consistent, differs from trusted)", "trusted ref differs", "ACCEPT", "REJECT", "ROOT/PID/CD_MISMATCH", False),
    ("G3", 4, "incorrect semantic-profile context", "profile mismatch", "ACCEPT", "REJECT", "PROFILE_MISMATCH", False),
    ("G4", 4, "incorrect construction context", "construction mismatch", "ACCEPT", "REJECT", "CONSTRUCTION_MISMATCH", False),
    ("G5", 4, "invalid root/proof relationship", "structural invalid", "REJECT", "REJECT", "REJECT_STRUCTURAL", False),
    ("G6", 4, "invalid signature or untrusted key", "sig/key untrusted", "ACCEPT", "REJECT", "INVALID_SIGNATURE/UNTRUSTED_KEY", False),
    ("G7", 4, "missing required trusted reference", "trust dep absent", "ACCEPT", "REJECT", "MISSING_TRUSTED_REFERENCE", False),
    ("G8", 4, "stale checkpoint / rollback", "freshness violation", "ACCEPT", "REJECT", "STALE_SEQUENCE", False),
]
G2_MECH = ["rescale_amount", "shift_timestamp", "nfc_beneficiary", "alt_batch_membership",
           "substitute_profile_id", "substitute_construction_context"]
METRICS = [
    ("M01", "valid_evidence_acceptance", "accepted valid controls", "valid controls (G1)", "unit"),
    ("M02", "structural_invalid_rejection", "rejected structurally invalid", "structurally invalid units (G5)", "unit"),
    ("M03", "unauthorized_acceptance", "structurally valid but unauthorized accepted", "authorized-decision units", "unit"),
    ("M04", "trusted_reference_policy_correctness", "V2 decisions matching authorization oracle", "all units under common objective", "unit"),
    ("M05", "coordinated_substitution_acceptance", "accepted coordinated substitutions", "G2 units", "unit"),
    ("M06", "invalid_signature_rejection", "rejected invalid signatures", "G6 invalid-signature units", "unit"),
    ("M07", "untrusted_key_rejection", "rejected valid-sig under untrusted key", "G6 untrusted-key units", "unit"),
    ("M08", "missing_reference_failclosed", "V2 fail-closed on missing trust", "G7 units", "unit"),
    ("M09", "freshness_rollback_correctness", "V2 freshness decisions correct", "G8 units", "unit"),
    ("M10", "false_rejection_of_valid", "valid controls rejected", "G1 units", "unit"),
    ("M11", "paired_v1_v2", "both/V1_only/V2_only/neither under common objective", "paired units", "unit"),
    ("M12", "reason_category_correctness", "exact reason-category match", "units with defined reason", "unit"),
    ("M13", "verification_runtime", "verification runtime (secondary)", "measured runs", "verification_call"),
]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def build_matrix():
    rows = []
    for g, count, mech, tc, v1, v2, reason, auth in SPEC:
        for i in range(1, count + 1):
            uid = "P05-%s-%02d" % (g, i)
            m = mech if g != "G2" else "coordinated_substitution:" + G2_MECH[(i - 1) % len(G2_MECH)]
            rows.append({"unit_id": uid, "group": g, "mutation_mechanism": m,
                         "trusted_reference_condition": tc, "expected_v1_structural": v1,
                         "expected_v2_trust": v2, "expected_reason_category": reason,
                         "sanctioned": ("yes" if auth else "no"), "applicability": "both arms",
                         "oracle_rationale": ("valid+authorized" if auth else "unauthorized/structurally-invalid under trusted-ref objective")})
    return rows


def write_metrics():
    metrics = []
    for mid, name, num, den, unit in METRICS:
        metrics.append({"metric_id": mid, "name": name, "numerator": num, "denominator": den,
                        "unit_of_analysis": unit, "applicable_arms": (["V2"] if mid == "M04" else ["V1", "V2"]),
                        "applicability_rule": "per frozen test matrix group", "aggregation_level": "per-group and overall",
                        "missing_policy": "missing observation detected (not N/A)", "zero_denominator_policy": "N/A"})
    doc = {"schema_version": "P05-METRIC-R1",
           "paired_primary": {"comparison": "V1 vs V2", "common_objective": "accept iff authorized by trusted reference",
                              "paired_effect": "(V2_only_correct - V1_only_correct) / N"},
           "metrics": metrics}
    p = HERE / "P05_METRIC_DICTIONARY.yaml"
    p.write_text(yaml.safe_dump(doc, sort_keys=False), encoding="utf-8", newline="\n")
    assert len(yaml.safe_load(p.read_text(encoding="utf-8"))["metrics"]) == 13
    return p
def main():
    rows = build_matrix()
    assert len(rows) == 40 and len([r for r in rows if r["sanctioned"] == "no"]) == 30
    with open(HERE / "P05_TEST_MATRIX.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    write_metrics()

    trace = [("requirement", "metric", "hypothesis"),
             ("Valid evidence accepted", "M01/M10", "H5"),
             ("Structural invalid rejected (V1 contract)", "M02", "H6"),
             ("Coordinated substitution rejected by V2", "M05/M03", "H1"),
             ("Invalid signature / untrusted key rejected", "M06/M07", "H2"),
             ("Missing reference fail-closed", "M08", "H3"),
             ("Freshness/rollback enforced", "M09", "H4"),
             ("No false rejection of valid", "M10", "H5"),
             ("Paired incremental assurance", "M11", "H1-H4"),
             ("Exact reason category", "M12", "H1-H4"),
             ("Verification runtime (secondary)", "M13", "H7")]
    with open(HERE / "P05_REQUIREMENTS_TRACEABILITY.csv", "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(trace)

    ssot = {"candidate": True, "frozen": False, "base_p04_scientific_commit": FROZEN["p04_scientific_commit"],
            "p04_admin_commit": FROZEN["p04_admin_commit"], "p04_archive_sha256": FROZEN["p04_archive_sha256"],
            "python_source_sha256": FROZEN["python_source_sha256"], "go_source_sha256": FROZEN["go_source_sha256"],
            "pid_sem_v2": FROZEN["pid_sem_v2"], "construction_digest": FROZEN["construction_digest"],
            "checkpoint_spec_version": "1",
            "domain_sep": "BCJ-V19-P05-CHECKPOINT || 0x00 0x01 (proposed; freeze exact bytes at P05-B)",
            "ed25519_library": "cryptography (exact version PENDING implementation freeze)",
            "pending": ["p05_verifier_source_sha256", "p05_oracle_sha256", "p05_corpus_sha256", "corpus_seed", "trust_store_digest"],
            "note": "P04 F24-F30 remain OPEN_MANDATORY; P05 does not resolve them."}
    (HERE / "P05_SSOT_LOCK_CANDIDATE.json").write_text(json.dumps(ssot, indent=2) + "\n", encoding="utf-8", newline="\n")

    gates = {"PG01_p04_admin_closure": "PASS", "PG02_p07_preserved": "PASS", "PG03_frozen_identities": "PASS",
             "PG04_threat_model": "PASS", "PG05_v1_v2_contracts": "PASS", "PG06_checkpoint_spec": "PASS",
             "PG07_trust_provisioning": "PASS", "PG08_freshness": "PASS",
             "PG09_exact_40_matrix": "PASS" if len(rows) == 40 else "FAIL", "PG10_80_observation_plan": "PASS",
             "PG11_oracle_separation": "PASS", "PG12_metric_dictionary_valid": "PASS", "PG13_stat_plan": "PASS",
             "PG14_dev_qa_plan": "PASS", "PG15_no_measured_execution": "PASS",
             "overall": "READY_FOR_EXPERIMENT_LEAD_REVIEW"}
    (HERE / "P05_READINESS_GATE_MATRIX.json").write_text(json.dumps(gates, indent=2) + "\n", encoding="utf-8", newline="\n")
    status = {"phase": "P05", "stage": "PREREGISTRATION", "p04_scientific_development": "CLOSED",
              "p04_administrative_closure": "COMPLETE", "p05_protocol_status": "READY_FOR_EXPERIMENT_LEAD_REVIEW",
              "planned_units": 40, "planned_primary_observations": 80, "protocol_frozen": False,
              "measured_corpus_frozen": False, "measured_execution_authorized": False,
              "measured_execution_performed": False, "next_stage_authorized": False}
    (HERE / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8", newline="\n")
    env = {"python": platform.python_version(), "platform": platform.platform(), "rfc8785": "0.1.3",
           "ed25519_library": "cryptography (version pin pending)", "pyyaml_validation": yaml.__version__,
           "p04_scientific_commit": FROZEN["p04_scientific_commit"]}
    (HERE / "environment.json").write_text(json.dumps(env, indent=2) + "\n", encoding="utf-8", newline="\n")
    (HERE / "commands.log").write_text(
        "# P05 prereg R1 commands\npython make_p05.py -> matrix/metrics/traceability/ssot/gates/status/env + archive\n"
        "# froze P04 admin commit %s; P04 archive %s\n" % (FROZEN["p04_admin_commit"], FROZEN["p04_archive_sha256"]),
        encoding="utf-8", newline="\n")
    (HERE / "REPORT.md").write_text(
        "# P05 Preregistration R1 Report\n\n"
        "Objective: can authenticated reference verification prevent acceptance of internally consistent but "
        "unauthorized evidence that structural verification cannot distinguish from valid evidence?\n\n"
        "Arms: V1 structural (no independent trust) vs V2 structural + trusted Ed25519 reference (independent trust "
        "store, expected pid/cd/root/batch/tree_size, sequence freshness). Only added mechanism = trusted-reference.\n\n"
        "Corpus: exactly 40 units (G1 10 valid; G2 6 coordinated; G3 4 profile; G4 4 construction; G5 4 root/proof; "
        "G6 4 sig/key; G7 4 missing-ref; G8 4 stale/rollback) = 30 adverse + 10 valid; 80 planned V1/V2 observations.\n\n"
        "Status: READY_FOR_EXPERIMENT_LEAD_REVIEW. Measured execution NOT authorized. P04 F24-F30 remain OPEN_MANDATORY.\n",
        encoding="utf-8", newline="\n")

    files = sorted([p for p in HERE.iterdir() if p.is_file() and p.name != "make_p05.py"])
    relmap = [("p05_prereg_r1/" + p.name, p) for p in files]
    sums = "\n".join("%s  %s" % (sha(p.read_bytes()), rel) for rel, p in sorted(relmap)) + "\n"
    (HERE / "SHA256SUMS").write_text(sums, encoding="utf-8")
    relmap.append(("p05_prereg_r1/SHA256SUMS", HERE / "SHA256SUMS"))
    manifest = {"archive": NAME, "files": {rel: sha(p.read_bytes()) for rel, p in relmap}, "count": len(relmap)}
    (HERE / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    relmap.append(("p05_prereg_r1/RUN_MANIFEST.json", HERE / "RUN_MANIFEST.json"))
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT.read_bytes())
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"zip": str(OUT), "members": len(relmap), "sha256": d, "units": len(rows),
                      "adverse": len([r for r in rows if r["sanctioned"] == "no"])}, indent=2))


if __name__ == "__main__":
    main()