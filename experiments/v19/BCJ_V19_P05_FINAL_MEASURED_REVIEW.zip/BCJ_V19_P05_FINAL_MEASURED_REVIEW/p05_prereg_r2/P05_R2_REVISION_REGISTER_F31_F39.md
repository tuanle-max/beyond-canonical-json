# P05 F31-F39 Prospective Revision Register (R2A)

R1 preserved in p05_prereg_r1/. Corrections applied prospectively.

| ID | Correction |
|----|------------|
| F31 | G8-02 = authorized idempotent replay (ACCEPT); corpus 11 authorized + 29 adverse = 40. |
| F32 | Replay bound to checkpoint digest SHA256(DOMAIN_SEP||JCS(cp)); per-unit initial state; state advances only on full accept. |
| F33 | TrustedVerificationContext constrains selection; envelope checkpoint_id not authoritative; UNAUTHORIZED_CHECKPOINT. |
| F34 | Shared competent structural verifier; V1 rejects unsupported/invalid; accepts supported unauthorized context. |
| F35 | G2 coordinated substitution independently reconstructed; consistent replacement differs from signed reference; no hash collision. |
| F36 | Per-unit concrete expectations + deterministic failure precedence; structural vs trust reasons separated. |
| F37 | Metrics from frozen oracle classifications; V1 sig/freshness N/A; errors/blocking not rewarded. |
| F38 | DOMAIN_SEP=b'BCJ-V19-P05-CHECKPOINT\x00\x01'; Ed25519 cryptography 50.0.2; lowercase hex; strict schema. |
| F39 | Two oracle layers; separate evaluator/verifier; guards receive no labels/expected. |
