# P07 Approved Results Narrative (actual verified results)

Scope: frozen V19 corpora only. Same-team evidence. No universal-security, production-prevalence, or third-party claims.

## RQ1 (P03)
Go and Python implementations agree on pair-level business semantics: **12/12** frozen E2 pairs (5 business-equal, 6 business-distinct, 1 admission-differs), independently reaggregated in P07.

## RQ2 (P04)
Frozen 100-unit x 4-arm corpus; independent P07 reaggregation confirms exact membership (100x4, no dup). Common-objective correctness:
A1 **94/100**, A1+CI **84/100**, A1+PID **64/100**, A2 **54/100**. Paired A1 vs A1+CI: both 84, A1-only 10, A1+CI-only 0, both-incorrect 6.
Guard-vs-semantic separation, per-detector confusion, and performance component isolation are NOT fully re-derived here (see P07-C).

## RQ3 (P05)
Authenticated-reference verification dominates structural verification on the shared objective over 40 units / 80 observations:
V1 **15/40**, V2 **40/40**; paired both 15, V1-only 0, V2-only 25, both-incorrect 0 (descriptive effect +0.625).
V1 accepts 25 structurally-valid but unauthorized units (satisfies V1's own structural contract, not a defect). Authorized acceptance 11/11 both arms.
Exact state transitions **39/39** applicable (+1 N/A missing-state control). Re-executed from a fresh extracted package: V1C 15 / V2C 40.

## RQ4 (P06)
CR-0006 recovered and freshly re-executed: artifact Eq.6 reproduces **30/30** published roots; campaign 0x02-frame reproduces **0/30**; first divergence at j=0.
This is a REPRODUCTION of historical evidence, not a new independent finding.

## RQ5 (P07)
14/14 integration/mutation tests pass; execution lock verified; fresh extracted-package reproduction succeeds (deps from host venv).
Docker clean-room NOT executed (documented blocker); reproducibility claim limited accordingly.
