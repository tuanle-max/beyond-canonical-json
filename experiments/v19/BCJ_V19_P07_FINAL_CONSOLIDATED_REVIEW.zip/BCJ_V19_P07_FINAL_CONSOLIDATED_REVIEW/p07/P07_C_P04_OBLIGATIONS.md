# P07-C — P04 Obligation Dispositions (F24-F30)

Honest disposition from actual P07 work. "PARTIAL" = evidence exists but was not fully re-derived in P07;
"RESOLVED_AS_LIMITATION" = claim scope restricted rather than re-measured.

| ID | topic | disposition | evidence / note |
|---|---|---|---|
| P04-F24 | admission vs guard blocking | PARTIAL | Raw `P04_MEASURED_RAW.jsonl` carries `admission_status`, `admitted`, `alarm_*`, `active_pid/cd` separately; P07 reaggregation computed common-objective correctness only. Semantic-vs-guard separation documented, not fully re-tabulated. |
| P04-F25 | detector-specific matrices | PARTIAL | `P04_CONFUSION_MATRICES.csv` exists per (arm,detector); not re-derived in P07. A2+CI on identity-blocked units = NOT_EXECUTED per applicability file. |
| P04-F26 | stage attribution | PARTIAL | Separate guard `alarm_stage` vs evaluator divergence preserved; missing downstream fields labelled NOT_EXECUTED/UNRESOLVED, not as L0 divergence. |
| P04-F27 | performance interpretation | RESOLVED_AS_LIMITATION | Existing `P04_PERFORMANCE_RAW.csv` = combined processing + guard; no component isolation or startup-overhead claim. Claim restricted accordingly. |
| P04-F28 | exposure audit | PARTIAL | `P04_HOLDOUT_EXPOSURE_AUDIT.json` preserved; frozen synthetic evaluation terminology; no blinded-holdout claim. |
| P04-F29 | Go cross-check scope | RESOLVED_AS_LIMITATION | `P04_GO_REFERENCE_RAW.jsonl` / commands preserved; same-team; only raw-supported fields claimed; no third-party replication. |
| P04-F30 | activation + independent aggregation | PARTIAL | P07 independent reaggregation reproduced exact 100x4 membership (A1/A1+CI/A1+PID/A2 = 94/84/64/54) and paired A1-vs-A1+CI (84/10/0/6). Predicted vs measured activation distinguished in raw; manuscript tables not regenerated here. |

No raw measured evidence modified.
