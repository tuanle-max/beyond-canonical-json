# P07 Manuscript Change Guide (do NOT edit manuscript here)

Use numeric tables from `P07_FINAL_RESULTS_TABLES.tex` and `P07_FIGURE_DATA.csv`. Required edits (by owner, not this agent):
1. RQ3: report V1 15/40 vs V2 40/40, paired 15/0/25/0, effect +0.625; state 39/39 +1 N/A.
2. RQ2: report per-arm 94/84/64/54 of 100; paired A1 vs A1+CI 84/10/0/6; restrict performance to combined cost.
3. RQ4/CR-0006: state 30/30 eq6 vs 0/30 campaign as a REPRODUCTION of recovered pilot evidence (not new finding).
4. Reproducibility: claim extracted-package reproduction + lock; do NOT claim Docker/offline until executed.
5. Remove any universal-security / production-prevalence / third-party-replication wording.
Do not merge percentages across phases/denominators; do not count first-pass and corrective as independent units.
