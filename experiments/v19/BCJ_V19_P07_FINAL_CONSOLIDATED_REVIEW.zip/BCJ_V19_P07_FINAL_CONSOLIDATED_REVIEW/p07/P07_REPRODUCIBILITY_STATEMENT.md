# P07 Reproducibility Statement

- Execution lock: `p07/P07_EXECUTION_LOCK.json` (read+verified from disk; every bound digest checked; modified lock/bound files rejected).
- Integration/mutation: 14/14 pass via `p07/p07_integration.py` (strict entry, exact membership, internal-error/timeout not credited, bounded subprocess timeout, fail-closed entry gate).
- Extracted package: fresh temp extraction of exact source + corpus + boo adapter reproduces V1 15 / V2 40 (`P07_EXTRACTED_PACKAGE_REPRO.json`).
- Docker: Dockerfile + `p07_targets.ps1` provided; actual container build/run NOT executed (network+cost). NOT claimed.
- Determinism: dependency pins (python 3.12.9, cryptography 50.0.2, rfc8785 0.1.3, PyYAML 6.0.4).
- This rerun is a reproducibility check, not a new scientific sample.
