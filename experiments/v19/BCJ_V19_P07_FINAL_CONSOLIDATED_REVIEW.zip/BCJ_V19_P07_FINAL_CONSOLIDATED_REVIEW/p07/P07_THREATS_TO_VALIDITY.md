# P07 Threats to Validity

- Purposive synthetic frozen corpora (P03/P04/P05); no production attack prevalence.
- Same-team evidence throughout; NOT independent third-party replication.
- P05 is post-exposure regression validation; reason codes decision-level only.
- P04 guard/semantic separation, detector confusion, and component cost isolation NOT fully re-derived (P07-C PARTIAL).
- Docker clean-room not executed; dependency closure demonstrated only via host-venv extracted package.
- P06 reconstruction is a reproduction of recovered historical evidence.
- P03 F05 referenced logs (runall_stdout.log, resume_stdout.log) unrecovered; limitation recorded, not fabricated.
