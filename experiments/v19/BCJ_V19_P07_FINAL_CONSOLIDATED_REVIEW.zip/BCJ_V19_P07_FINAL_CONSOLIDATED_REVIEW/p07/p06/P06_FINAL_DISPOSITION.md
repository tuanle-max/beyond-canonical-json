# P06 - CR-0006 Final Disposition

**Status: RECOVERED** (fresh reproduction executed, not merely re-asserted).

- 30-batch real manifest recovered (`docs/drtea_mainnet_manifest_REAL.json`, sha256 `f5dbc2fe037db808885d35648c4e2dd84df32e684c3e98b9056a41da181e9e3b`).
- Both exact byte-level formulas recovered: artifact Eq.6 and campaign 0x02 frame.
- Fresh re-execution: artifact Eq.6 **30/30**, campaign **0/30**; fresh run reproduces the historical derived CSV **30/30**.
- First campaign divergence j=0: manifest `6860e20e18c2ca15c0c4c8e15c50fe6655f45e05a98449108bb2386dd80b1b48` vs campaign `243b7c29a7ad371aa040374b0603f37bdbf5432420e21169aa61feadd8f14a32`.

Evidence level = REPRODUCTION_OF_HISTORICAL. The 30/30 and 0/30 are reproduced from recovered evidence and are NOT reported as new scientific findings. No historical input or formula was invented; no synthetic substitute created.
