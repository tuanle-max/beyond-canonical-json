"""P05 administrative closure + P07 register update to 19 unique obligations."""
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"

CLOSURE = """# P05 Experiment Lead Final Disposition

Authoritative review record (separate from, and does not modify, the original Agent gate report).

| field | value |
|---|---|
| scientific_development | CLOSED |
| scientific_results | ACCEPTED |
| first_pass_evidence | ACCEPTED |
| corrective_evidence | ACCEPTED |
| independent_decision_oracle | ACCEPTED_WITH_SCOPE |
| state_reaudit | ACCEPTED |
| qa | ACCEPTED_WITH_MANDATORY_CARRYOVER |
| archive_integrity | VERIFIED |
| standalone_corrective_revision | NOT_REQUIRED |
| new_measured_corpus | NOT_REQUIRED |

Accepted corrective commit: `8ad0afa5b124eee9fbcfa1a3e021fd6011b68030`
Accepted corrective archive: `BCJ_V19_P05_CORRECTIVE_R2B_FINAL_REVIEW.zip`
SHA-256: `9abff431c6ec5d1887596ebf86de2d9ad694f536cb2842b3018b785e597f576f`

Preserved immutable archives: first-pass `719db8c4...`; R2B partial `4150a108...`; R2B V2 partial `93aaade3...`.

## CAVEAT (recorded, not resolved by this disposition)
Complete CG01-CG15 enforcement and all 24 production integration tests were **NOT independently established by source
inspection**. They remain mandatory carryover (P07 F49-F55). The accepted P05 results stand; the enforcement/QA claims
are carried forward rather than certified here.

## Carried-forward obligations
F40/F44/F45/F48 residuals map to P07 F49-F55 (see P07_QA_CARRYOVER_REGISTER.json). No standalone R2C/R3 authorized.
"""

SEVEN = [
    {"id": "F49", "title": "Complete strict input validation integration", "issue": "F40 strict validation exists in p05core_r2b.py but is not wired into a single acceptance entry point covering all fields/bounds/context/state/checkpoint.", "required_in_p07": "Integrate strict raw parsing into the actual verification entry point; validate required/permitted fields, integer bounds, digest encoding, trusted context, trusted state, checkpoint schema; preserve accepted P05 verifier as historical evidence and use a separate P07 wrapper.", "maps_from": "F40", "mandatory": True},
    {"id": "F50", "title": "Complete execution-lock binding and enforcement", "issue": "F44 lock binds files but enforcement (read-from-disk verification of every digest, resume identity, rejection of modified lock/bound files) is not fully exercised as a gate.", "required_in_p07": "Create prospective P07 execution lock binding artifact bytes/source/deps/spec/metrics/QA/plan; read and verify lock from disk; verify every digest; reject modified lock, modified bound files, incompatible execution identity.", "maps_from": "F44", "mandatory": True},
    {"id": "F51", "title": "Replace standalone QA assertions with actual integration tests", "issue": "F45 24-condition QA used standalone assertions rather than exercising real runner/aggregation production paths.", "required_in_p07": "Exercise missing/duplicate observations, wrong membership, modified lock, incompatible resume, answer-key exclusion through real production runner+aggregation paths.", "maps_from": "F45", "mandatory": True},
]
SEVEN += [
    {"id": "F52", "title": "Actual bounded timeout and internal-error handling", "issue": "Timeout/crash handling was simulated in-thread, not via a genuinely enforced bounded subprocess wrapper used by the pipeline.", "required_in_p07": "Use bounded subprocess execution with worker termination for timeout; record TIMEOUT separately from REJECT; exercise crash/timeout through the same wrapper as the integration pipeline.", "maps_from": "F45", "mandatory": True},
    {"id": "F53", "title": "Exact aggregation membership and failure accounting", "issue": "Aggregation requires exact unique unit-arm membership and must not credit INTERNAL_ERROR/TIMEOUT/INVALID_CONFIG/missing as successful rejection.", "required_in_p07": "Reject duplicates before dict construction; require exact planned membership; test mutated observations; validate exact expected/observed state values; N/A reported separately.", "maps_from": "F45", "mandatory": True},
    {"id": "F54", "title": "Executable fail-closed pre-entry gate enforcement", "issue": "Entry gates were documented/reported but not demonstrably enforced by an executable gate that halts before measured execution.", "required_in_p07": "Implement executable entry gate; if any mandatory dev QA or lock verification fails, halt before measured execution; demonstrate with actual negative tests.", "maps_from": "F44", "mandatory": True},
    {"id": "F55", "title": "Complete dependency closure and extracted-package reproduction", "issue": "F48 bound the adapter and deps but standalone extraction/execution from a fresh package was not demonstrated.", "required_in_p07": "Package exact P03 adapter, original P05 primitives, hardened verifier, frozen corpus, historical oracle, independent checker, deps; verify digests; execute from fresh extracted package or Docker; do not claim reproducibility until demonstrated.", "maps_from": "F48", "mandatory": True},
]


def main():
    reg_path = V19 / "P07_QA_CARRYOVER_REGISTER.json"
    reg = json.loads(reg_path.read_text(encoding="utf-8"))
    have = {o["id"] for o in reg["obligations"]}
    assert len(reg["obligations"]) == 12, len(reg["obligations"])
    for o in SEVEN:
        assert o["id"] not in have
        reg["obligations"].append(o)
    reg["total_obligations"] = len(reg["obligations"])
    reg["p05_carryover"] = {
        "source_commit": "8ad0afa5b124eee9fbcfa1a3e021fd6011b68030",
        "source_archive_sha256": "9abff431c6ec5d1887596ebf86de2d9ad694f536cb2842b3018b785e597f576f",
        "note": "P05 residual F40/F44/F45/F48 mapped to F49-F55. NOT resolved. QA ACCEPTED_WITH_MANDATORY_CARRYOVER.",
    }
    ids = [o["id"] for o in reg["obligations"]]
    assert len(ids) == 19 and len(set(ids)) == 19, ids
    reg_path.write_text(json.dumps(reg, indent=2) + "\n", encoding="utf-8", newline="\n")
    (V19 / "P05_EXPERIMENT_LEAD_FINAL_DISPOSITION.md").write_text(CLOSURE, encoding="utf-8", newline="\n")
    print(json.dumps({"obligations": len(ids), "new": [o["id"] for o in SEVEN],
                      "register_sha256": hashlib.sha256(reg_path.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()