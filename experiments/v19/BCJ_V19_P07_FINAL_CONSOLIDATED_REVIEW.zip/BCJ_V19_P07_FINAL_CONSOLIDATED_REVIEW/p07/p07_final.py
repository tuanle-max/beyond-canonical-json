"""P07 F55 extracted-package reproduction + Docker config + P07-C dispositions."""
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"
PY = sys.executable

PKG_FILES = [
    "p05_implementation/p05core.py",
    "p05_r2b/p05core_r2b.py",
    "p05_evaluator/p05_corpus.py",
    "p05_evaluator/P05_MEASURED_CORPUS.jsonl",
    "p05_evaluator/P05_EVALUATOR_ORACLE.jsonl",
    "implementations/python-dev/boo.py",
]

RUNNER = r'''
import json, sys
sys.path[:0] = ["p05_r2b", "p05_implementation", "p05_evaluator"]
import p05core_r2b as r
units = [json.loads(l) for l in open("p05_evaluator/P05_MEASURED_CORPUS.jsonl", encoding="utf-8") if l.strip()]
orc = {x["unit_id"]: x for x in (json.loads(l) for l in open("p05_evaluator/P05_EVALUATOR_ORACLE.jsonl", encoding="utf-8") if l.strip())}
c1 = c2 = 0
for u in units:
    a = bool(orc[u["unit_id"]]["authorized"])
    d1 = r.verify_v1(u["envelope"])["decision"]
    d2 = r.verify_v2(u["envelope"], u["trusted_context"], u["initial_state"])["decision"]
    c1 += (d1 == "ACCEPT") == a
    c2 += (d2 == "ACCEPT") == a
print("V1C", c1, "V2C", c2, "N", len(units))
'''


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def f55_extract():
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="p07_extract_"))
    try:
        for rel in PKG_FILES:
            dst = tmp / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(V19 / rel, dst)
        (tmp / "runner.py").write_text(RUNNER, encoding="utf-8")
        env = dict(os.environ)
        env["PYTHONPATH"] = ""
        p = subprocess.run([PY, "runner.py"], cwd=str(tmp), capture_output=True, text=True, timeout=120, env=env)
        out = (p.stdout or "").strip()
        ok = p.returncode == 0 and "V1C 15" in out and "V2C 40" in out
        # extracted package digest (deterministic over file digests)
        dig = hashlib.sha256("".join("%s:%s" % (r, sha(tmp / r)) for r in PKG_FILES + ["runner.py"]).encode()).hexdigest()
        res = {"status": "EXTRACTED_PACKAGE_REPRODUCED" if ok else "FAILED",
               "fresh_dir": "temp (deleted)", "returncode": p.returncode, "stdout": out,
               "stderr_tail": (p.stderr or "")[-300:], "package_digest": dig,
               "deps": "host venv python+cryptography+rfc8785 (documented; not bundled)",
               "note": "Fresh extraction of exact source + corpus + boo adapter; no reliance on original tree layout."}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    (P07 / "P07_EXTRACTED_PACKAGE_REPRO.json").write_text(json.dumps(res, indent=2) + "\n", encoding="utf-8", newline="\n")
    return res
DOCKERFILE = """FROM python:3.12-slim
WORKDIR /pkg
COPY . /pkg
RUN pip install --no-cache-dir cryptography==50.0.2 rfc8785==0.1.3 PyYAML==6.0.4
# Targets (see p07/p07_targets.ps1 / Makefile equivalent):
#   verify-inputs: python experiments/v19/p07/p07_inventory.py
#   reproduce-legacy: PYTHONPATH=py python scripts/drtea_eq6_repro.py --manifest docs/drtea_mainnet_manifest_REAL.json --csv /tmp/eq6.csv
#   reproduce-v19: python experiments/v19/p07/p07_integration.py
#   verify-results: python experiments/v19/p07/p07_reaggregate.py
#   regenerate-tables: python experiments/v19/p07/p07_handover.py
#   package-review: python experiments/v19/p07/p07_package.py
ENTRYPOINT ["python", "experiments/v19/p07/p07_integration.py"]
"""

TARGETS = """# P07 executable targets (PowerShell). Pinned deps: python 3.12.9, cryptography 50.0.2, rfc8785 0.1.3, PyYAML 6.0.4
param([string]$t="test",[string]$py="python")
switch ($t) {
  "verify-inputs"     { & $py experiments/v19/p07/p07_inventory.py }
  "build"             { Write-Host "pure-python; no build step" }
  "test"              { & $py experiments/v19/p07/p07_integration.py }
  "reproduce-legacy"  { $env:PYTHONPATH="py"; & $py scripts/drtea_eq6_repro.py --manifest docs/drtea_mainnet_manifest_REAL.json --csv experiments/v19/p07/p06/repro_eq6_fresh.csv }
  "reproduce-v19"     { & $py experiments/v19/p07/p07_integration.py }
  "regenerate-tables" { & $py experiments/v19/p07/p07_handover.py }
  "verify-results"    { & $py experiments/v19/p07/p07_reaggregate.py }
  "package-review"    { & $py experiments/v19/p07/p07_package.py }
  default { Write-Error "unknown target" }
}
"""

P07C = """# P07-C — P04 Obligation Dispositions (F24-F30)

Honest disposition from actual P07 work. "PARTIAL" = evidence exists but was not fully re-derived in P07;
"RESOLVED_AS_LIMITATION" = claim scope restricted rather than re-measured.

| ID | topic | disposition | evidence / note |
|---|---|---|---|
| P04-F24 | admission vs guard blocking | PARTIAL | Raw `P04_MEASURED_RAW.jsonl` carries `admission_status`, `admitted`, `alarm_*`, `active_pid/cd` separately; P07 reaggregation computed common-objective correctness only. Semantic-vs-guard separation documented, not fully re-tabulated. |
| P04-F25 | detector-specific matrices | PARTIAL | `P04_CONFUSION_MATRICES.csv` exists per (arm,detector); not re-derived in P07. A2+CI on identity-blocked units = NOT_EXECUTED per applicability file. |
| P04-F26 | stage attribution | PARTIAL | Separate guard `alarm_stage` vs evaluator divergence preserved; missing downstream fields labelled NOT_EXECUTED/UNRESOLVED, not as L0 divergence. |
| P04-F27 | performance interpretation | RESOLVED_AS_LIMITATION | Existing `P04_PERFORMANCE_RAW.csv` = combined processing + guard; no component isolation or startup-overhead claim. Claim restricted accordingly. |
| P04-F28 | exposure audit | PARTIAL | `P04_HOLDOUT_EXPOSURE_AUDIT.json` preserved; frozen synthetic evaluation terminology; no blinded-holdout claim. |
| P04-F29 | Go cross-check scope | RESOLVED_AS_LIMITATION | `P04_GO_REFERENCE_RAW.jsonl` / commands preserved; same-team; only raw-supported fields claimed; no third-party replication. |
| P04-F30 | activation + independent aggregation | PARTIAL | P07 independent reaggregation reproduced exact 100x4 membership (A1/A1+CI/A1+PID/A2 = 94/84/64/54) and paired A1-vs-A1+CI (84/10/0/6). Predicted vs measured activation distinguished in raw; manuscript tables not regenerated here. |

No raw measured evidence modified.
"""


def main():
    res = f55_extract()
    (P07 / "Dockerfile").write_text(DOCKERFILE, encoding="utf-8", newline="\n")
    (P07 / "p07_targets.ps1").write_text(TARGETS, encoding="utf-8", newline="\n")
    (P07 / "P07_C_P04_OBLIGATIONS.md").write_text(P07C, encoding="utf-8", newline="\n")
    docker = {"status": "NOT_EXECUTED_CLEANROOM", "docker_version": "29.8.2",
              "blocker": "Actual container build/run not performed (network image pull + time budget); Dockerfile+targets provided; extracted-package reproduction executed instead.",
              "extracted_package": res["status"]}
    (P07 / "P07_CLEANROOM_STATUS.json").write_text(json.dumps(docker, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"extracted_package": res["status"], "stdout": res["stdout"],
                      "package_digest": res["package_digest"][:16], "docker": docker["status"]}, indent=2))


if __name__ == "__main__":
    main()