"""P07-G claim matrix + P07-H manuscript handover artifacts (actual final results)."""
import csv
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"

CLAIMS = [
    dict(claim_id="C1", rq="RQ1 semantic equivalence", contribution="spec-level oracle", claim="Go and Python implementations agree on pair-level business semantics on the frozen E2 corpus",
         phase="P03", artifact="results/P03/P03_E2_PAIR_RESULTS.jsonl", num="12", den="12", scope="frozen 12-pair E2 corpus",
         evidence_level="CROSS_LANGUAGE_IMPLEMENTATION_AGREEMENT (same team)", limitations="same-team; not third-party; small pair corpus",
         repro="REAGGREGATED (12/12)", approved="12/12 pair-level semantic agreement on the frozen E2 corpus", prohibited="do not claim universal equivalence or third-party replication"),
    dict(claim_id="C2", rq="RQ2 admission/guard", contribution="layered guard", claim="Common-objective admission correctness per arm on the 100-unit x 4-arm P04 corpus",
         phase="P04", artifact="results/P04/P04_MEASURED_RAW.jsonl + p04_evaluator/P04_EVALUATOR_ORACLE.jsonl", num="A1 94; A1+CI 84; A1+PID 64; A2 54", den="100 each",
         scope="frozen 100-unit P04 corpus, 4 arms", evidence_level="SIMULATOR (same-team)", limitations="guard vs semantic engine not fully re-tabulated; frozen synthetic corpus",
         repro="REAGGREGATED (membership exact 100x4)", approved="per-arm common-objective correctness 94/84/64/54 of 100", prohibited="do not claim production prevalence or component cost isolation"),
    dict(claim_id="C3", rq="RQ3 structural vs authenticated reference", contribution="authenticated reference verification", claim="Authenticated-reference V2 exceeds structural V1 on shared objective",
         phase="P05", artifact="p05_r2b/P05_R2B_RAW_OBSERVATIONS.jsonl", num="V2 40 vs V1 15", den="40 units", scope="frozen 40-unit P05 corpus; 80 obs",
         evidence_level="SAME_TEAM_POST_EXPOSURE_CORROBORATION", limitations="post-exposure; reason codes decision-level only",
         repro="REAGGREGATED + EXTRACTED_PACKAGE (V1C 15 V2C 40)", approved="V1 15/40; V2 40/40; paired 15/0/25/0; descriptive effect +0.625", prohibited="do not claim universal security or compromised-signer coverage"),
    dict(claim_id="C4", rq="RQ3 state transitions", contribution="replay/freshness", claim="Exact final-state transitions match on applicable units",
         phase="P05", artifact="p05_r2b/P05_FIRST_PASS_STATE_REAUDIT_SUMMARY.json", num="39", den="39 applicable (+1 N/A)",
         scope="P05 V2 observations", evidence_level="SAME_TEAM_POST_EXPOSURE_CORROBORATION", limitations="one missing-state control N/A",
         repro="ACCEPTED (not re-executed to avoid repeating same result)", approved="39/39 applicable exact transitions; 1 N/A missing-state control", prohibited="do not count N/A as success"),
]
CLAIMS += [
    dict(claim_id="C5", rq="RQ4 legacy divergence", contribution="CR-0006 finding", claim="Campaign 0x02-frame formula reproduces 0/30; artifact Eq.6 reproduces 30/30 on the recovered pilot manifest",
         phase="P06", artifact="docs/drtea_mainnet_manifest_REAL.json (f5dbc2fe) + derived/legacy_validation_real_eq6.csv", num="30/30 eq6; 0/30 campaign", den="30 batches",
         scope="recovered 30-batch DR-TEA pilot manifest", evidence_level="HISTORICAL_REPRODUCTION (fresh re-execution)", limitations="reproduction of historical evidence, not a new independent verification",
         repro="REPRODUCED (fresh run reproduces historical CSV 30/30)", approved="formula-level divergence; artifact self-reproducible 30/30; campaign 0/30 (reproduction)", prohibited="do not report as newly discovered finding or independent third-party verification"),
    dict(claim_id="C6", rq="RQ5 reproducibility", contribution="locked reproducible pipeline", claim="Frozen V19 experiments reproduce from a fresh extracted package under a verified execution lock",
         phase="P07", artifact="p07/P07_EXECUTION_LOCK.json + P07_EXTRACTED_PACKAGE_REPRO.json", num="14/14 integration tests", den="14 conditions",
         scope="P05 frozen corpus reproduction", evidence_level="CLEAN_ROOM_EXTRACTED (not Docker; deps from host venv)", limitations="Docker clean-room not executed; deps not bundled",
         repro="EXTRACTED_PACKAGE_REPRODUCED", approved="14/14 integration/mutation tests pass; extracted package reproduces V1 15 / V2 40", prohibited="do not claim Docker/offline reproduction until demonstrated"),
    dict(claim_id="C7", rq="scope", contribution="threats", claim="No universal security or production prevalence claim",
         phase="P03-P07", artifact="P07_THREATS_TO_VALIDITY.md", num="-", den="-", scope="all phases", evidence_level="SCOPE_STATEMENT",
         limitations="purposive synthetic corpora", repro="N/A", approved="claims limited to frozen corpora and same-team evidence", prohibited="do not claim zero population risk from zero observed failures"),
    dict(claim_id="C8", rq="scope", contribution="independence", claim="No independent third-party replication",
         phase="P03-P07", artifact="P07_CLAIM_EVIDENCE_LIMITATION_MATRIX.csv", num="-", den="-", scope="all phases", evidence_level="SELF_DECLARED_LIMITATION",
         limitations="same-team throughout", repro="N/A", approved="same-team post-exposure corroboration and cross-language agreement only", prohibited="do not claim third-party replication"),
]


def write_claims():
    cols = ["claim_id", "rq", "contribution", "claim", "phase", "artifact", "num", "den", "scope",
            "evidence_level", "limitations", "repro", "approved", "prohibited"]
    with open(P07 / "P07_CLAIM_EVIDENCE_LIMITATION_MATRIX.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for c in CLAIMS:
            w.writerow({k: c[k] for k in cols})


def write_tables():
    tex = [
        "% P07 final results tables (auto; actual verified results)",
        "\\begin{table}[t]\\centering\\caption{P05 common-objective correctness (40 units)}\\begin{tabular}{lrr}\\toprule",
        "arm & correct & n \\\\ \\midrule", "V1 (structural) & 15 & 40 \\\\", "V2 (authenticated ref) & 40 & 40 \\\\",
        "\\bottomrule\\end{tabular}\\end{table}", "",
        "\\begin{table}[t]\\centering\\caption{P05 paired four-cell}\\begin{tabular}{lr}\\toprule", "cell & count \\\\ \\midrule",
        "both correct & 15 \\\\", "V1 only & 0 \\\\", "V2 only & 25 \\\\", "both incorrect & 0 \\\\",
        "\\bottomrule\\end{tabular}\\end{table}", "",
        "\\begin{table}[t]\\centering\\caption{P04 common-objective correctness (100 per arm)}\\begin{tabular}{lr}\\toprule",
        "arm & correct \\\\ \\midrule", "A1 & 94 \\\\", "A1+CI & 84 \\\\", "A1+PID & 64 \\\\", "A2 & 54 \\\\",
        "\\bottomrule\\end{tabular}\\end{table}", "",
        "\\begin{table}[t]\\centering\\caption{CR-0006 reproduction (30 batches)}\\begin{tabular}{lr}\\toprule",
        "construction & match \\\\ \\midrule", "artifact Eq.6 & 30/30 \\\\", "campaign 0x02-frame & 0/30 \\\\",
        "\\bottomrule\\end{tabular}\\end{table}",
    ]
    (P07 / "P07_FINAL_RESULTS_TABLES.tex").write_text("\n".join(tex) + "\n", encoding="utf-8", newline="\n")
    fig = ["figure,x,y,series",
           "p05_v1_correct,15,40,common_objective", "p05_v2_correct,40,40,common_objective",
           "p05_paired_both,15,40,paired", "p05_paired_v2only,25,40,paired",
           "p04_a1,94,100,common_objective", "p04_a1ci,84,100,common_objective",
           "p04_a1pid,64,100,common_objective", "p04_a2,54,100,common_objective",
           "p06_eq6,30,30,reproduction", "p06_campaign,0,30,reproduction"]
    (P07 / "P07_FIGURE_DATA.csv").write_text("\n".join(fig) + "\n", encoding="utf-8", newline="\n")
RQ = """rq_id,question,evidence_phase,status,claim_ids
RQ1,Do Go and Python implementations agree on pair-level business semantics?,P03,SUPPORTED (12/12 pairs),C1
RQ2,How do layered admission/guard arms trade off correctness on the frozen corpus?,P04,SUPPORTED (100x4; 94/84/64/54),C2
RQ3,Does authenticated-reference verification exceed structural verification on the shared objective?,P05,SUPPORTED (V2 40 vs V1 15),C3,C4
RQ4,Is the campaign legacy construction consistent with the deployed DR-TEA artifact?,P06,DIVERGENCE CONFIRMED (reproduction: eq6 30/30 campaign 0/30),C5
RQ5,Are the frozen experiments reproducible from locked/extracted artifacts?,P07,PARTIAL (extracted OK; Docker not executed),C6
"""

CONTRIB = """contribution,phase,evidence,claim_ids,evidence_level
Spec-level typed oracle (Go+Python),P03,12/12 pair semantic agreement,C1,cross-language same-team
Layered admission + guard evaluation,P04,100x4 exact membership; 94/84/64/54,C2,simulator same-team
Authenticated reference verification (V2),P05,V2 40/40 vs V1 15/40; paired 15/0/25/0,C3,same-team post-exposure
Replay/freshness state machine,P05,39/39 applicable +1 N/A,C4,same-team post-exposure
CR-0006 divergence finding,P06,fresh reproduction eq6 30/30 campaign 0/30,C5,historical reproduction
Locked/extracted reproducibility,P07,14/14 integration tests; extracted V1C 15 V2C 40,C6,clean-room extracted
"""

NARRATIVE = """# P07 Approved Results Narrative (actual verified results)

Scope: frozen V19 corpora only. Same-team evidence. No universal-security, production-prevalence, or third-party claims.

## RQ1 (P03)
Go and Python implementations agree on pair-level business semantics: **12/12** frozen E2 pairs (5 business-equal, 6 business-distinct, 1 admission-differs), independently reaggregated in P07.

## RQ2 (P04)
Frozen 100-unit x 4-arm corpus; independent P07 reaggregation confirms exact membership (100x4, no dup). Common-objective correctness:
A1 **94/100**, A1+CI **84/100**, A1+PID **64/100**, A2 **54/100**. Paired A1 vs A1+CI: both 84, A1-only 10, A1+CI-only 0, both-incorrect 6.
Guard-vs-semantic separation, per-detector confusion, and performance component isolation are NOT fully re-derived here (see P07-C).

## RQ3 (P05)
Authenticated-reference verification dominates structural verification on the shared objective over 40 units / 80 observations:
V1 **15/40**, V2 **40/40**; paired both 15, V1-only 0, V2-only 25, both-incorrect 0 (descriptive effect +0.625).
V1 accepts 25 structurally-valid but unauthorized units (satisfies V1's own structural contract, not a defect). Authorized acceptance 11/11 both arms.
Exact state transitions **39/39** applicable (+1 N/A missing-state control). Re-executed from a fresh extracted package: V1C 15 / V2C 40.

## RQ4 (P06)
CR-0006 recovered and freshly re-executed: artifact Eq.6 reproduces **30/30** published roots; campaign 0x02-frame reproduces **0/30**; first divergence at j=0.
This is a REPRODUCTION of historical evidence, not a new independent finding.

## RQ5 (P07)
14/14 integration/mutation tests pass; execution lock verified; fresh extracted-package reproduction succeeds (deps from host venv).
Docker clean-room NOT executed (documented blocker); reproducibility claim limited accordingly.
"""
THREATS = """# P07 Threats to Validity

- Purposive synthetic frozen corpora (P03/P04/P05); no production attack prevalence.
- Same-team evidence throughout; NOT independent third-party replication.
- P05 is post-exposure regression validation; reason codes decision-level only.
- P04 guard/semantic separation, detector confusion, and component cost isolation NOT fully re-derived (P07-C PARTIAL).
- Docker clean-room not executed; dependency closure demonstrated only via host-venv extracted package.
- P06 reconstruction is a reproduction of recovered historical evidence.
- P03 F05 referenced logs (runall_stdout.log, resume_stdout.log) unrecovered; limitation recorded, not fabricated.
"""

REPRO = """# P07 Reproducibility Statement

- Execution lock: `p07/P07_EXECUTION_LOCK.json` (read+verified from disk; every bound digest checked; modified lock/bound files rejected).
- Integration/mutation: 14/14 pass via `p07/p07_integration.py` (strict entry, exact membership, internal-error/timeout not credited, bounded subprocess timeout, fail-closed entry gate).
- Extracted package: fresh temp extraction of exact source + corpus + boo adapter reproduces V1 15 / V2 40 (`P07_EXTRACTED_PACKAGE_REPRO.json`).
- Docker: Dockerfile + `p07_targets.ps1` provided; actual container build/run NOT executed (network+cost). NOT claimed.
- Determinism: dependency pins (python 3.12.9, cryptography 50.0.2, rfc8785 0.1.3, PyYAML 6.0.4).
- This rerun is a reproducibility check, not a new scientific sample.
"""

GUIDE = """# P07 Manuscript Change Guide (do NOT edit manuscript here)

Use numeric tables from `P07_FINAL_RESULTS_TABLES.tex` and `P07_FIGURE_DATA.csv`. Required edits (by owner, not this agent):
1. RQ3: report V1 15/40 vs V2 40/40, paired 15/0/25/0, effect +0.625; state 39/39 +1 N/A.
2. RQ2: report per-arm 94/84/64/54 of 100; paired A1 vs A1+CI 84/10/0/6; restrict performance to combined cost.
3. RQ4/CR-0006: state 30/30 eq6 vs 0/30 campaign as a REPRODUCTION of recovered pilot evidence (not new finding).
4. Reproducibility: claim extracted-package reproduction + lock; do NOT claim Docker/offline until executed.
5. Remove any universal-security / production-prevalence / third-party-replication wording.
Do not merge percentages across phases/denominators; do not count first-pass and corrective as independent units.
"""

REVIEW = """reviewer_point,response,evidence
Is V1 vs V2 difference statistically established?,Descriptive paired effect reported; no inferential population claim,P07_INDEPENDENT_AGGREGATION.json
Are reason codes independently verified?,No - decision-level only; limitation disclosed,P05_R2B_THREATS_TO_VALIDITY.md
Is CR-0006 a new finding?,No - reproduction of recovered historical evidence,P06_FINAL_DISPOSITION.md
Is reproduction independent of team?,No - same-team; no third-party claim,P07_CLAIM_EVIDENCE_LIMITATION_MATRIX.csv
Is offline/Docker reproduction shown?,No - extracted package only; blocker documented,P07_CLEANROOM_STATUS.json
"""


def main():
    write_claims()
    write_tables()
    (P07 / "P07_RQ_EVIDENCE_MATRIX.csv").write_text(RQ, encoding="utf-8", newline="\n")
    (P07 / "P07_CONTRIBUTION_MATRIX.csv").write_text(CONTRIB, encoding="utf-8", newline="\n")
    (P07 / "P07_APPROVED_RESULTS_NARRATIVE.md").write_text(NARRATIVE, encoding="utf-8", newline="\n")
    (P07 / "P07_THREATS_TO_VALIDITY.md").write_text(THREATS, encoding="utf-8", newline="\n")
    (P07 / "P07_REPRODUCIBILITY_STATEMENT.md").write_text(REPRO, encoding="utf-8", newline="\n")
    (P07 / "P07_MANUSCRIPT_CHANGE_GUIDE.md").write_text(GUIDE, encoding="utf-8", newline="\n")
    (P07 / "P07_REVIEWER_RESPONSE_MATRIX.csv").write_text(REVIEW, encoding="utf-8", newline="\n")
    print(json.dumps({"claims": len(CLAIMS), "handover_files": 9}, indent=2))


if __name__ == "__main__":
    main()