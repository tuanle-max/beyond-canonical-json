"""P07-D/F: strict entry point (F49), execution lock (F50), strict aggregation (F53),
executable entry gate (F54), bounded-subprocess timeout (F52), mutation/integration tests (F51/F07-F)."""
import hashlib
import json
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"
for p in (V19 / "p05_r2b", V19 / "p05_implementation", V19 / "p05_evaluator"):
    sys.path.insert(0, str(p))
import p05core_r2b as r2b  # hardened verifier (historical evidence, unmodified)
import p05_corpus as corpus

PY = sys.executable


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def sb(b):
    return hashlib.sha256(b).hexdigest()


def jl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def load_units():
    return (jl(V19 / "p05_evaluator" / "P05_MEASURED_CORPUS.jsonl"),
            {r["unit_id"]: r for r in jl(V19 / "p05_evaluator" / "P05_EVALUATOR_ORACLE.jsonl")})


def verify_entry(env, ctx=None, state=None, arm="V2"):
    """F49: single strict acceptance entry point. Raw bytes are strictly parsed first."""
    env = r2b.parse_envelope_strict(env)
    return r2b.verify(arm, env, ctx, state)


def build_lock(units):
    lock = {
        "corpus_sha256": sha(V19 / "p05_evaluator" / "P05_MEASURED_CORPUS.jsonl"),
        "oracle_sha256": sha(V19 / "p05_evaluator" / "P05_EVALUATOR_ORACLE.jsonl"),
        "verifier_sha256": sha(V19 / "p05_r2b" / "p05core_r2b.py"),
        "indep_checker_sha256": sha(V19 / "p05_r2b" / "p05_independent_oracle.py"),
        "spec_sha256": sha(V19 / "p05_r2b" / "P05_R2B_SPEC.md"),
        "deps": {"python": "3.12.9", "cryptography": "50.0.2", "rfc8785": "0.1.3", "pyyaml": "6.0.4"},
        "plan": [u["unit_id"] + ":" + a for u in units for a in ("V1", "V2")],
    }
    lock["lock_digest"] = sb(json.dumps(lock, sort_keys=True).encode())
    (P07 / "P07_EXECUTION_LOCK.json").write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return lock


BOUND = {
    "corpus": ("corpus_sha256", V19 / "p05_evaluator" / "P05_MEASURED_CORPUS.jsonl"),
    "oracle": ("oracle_sha256", V19 / "p05_evaluator" / "P05_EVALUATOR_ORACLE.jsonl"),
    "verifier": ("verifier_sha256", V19 / "p05_r2b" / "p05core_r2b.py"),
    "indep_checker": ("indep_checker_sha256", V19 / "p05_r2b" / "p05_independent_oracle.py"),
    "spec": ("spec_sha256", V19 / "p05_r2b" / "P05_R2B_SPEC.md"),
}


def verify_lock_from_disk(lock_path=None):
    """F50: read lock from disk, recompute logical digest, verify every bound digest."""
    lock_path = lock_path or (P07 / "P07_EXECUTION_LOCK.json")
    lock = json.loads(pathlib.Path(lock_path).read_text(encoding="utf-8"))
    reasons = []
    body = {k: v for k, v in lock.items() if k != "lock_digest"}
    if sb(json.dumps(body, sort_keys=True).encode()) != lock["lock_digest"]:
        reasons.append("LOCK_DIGEST_MISMATCH")
    for name, (field, path) in BOUND.items():
        if sha(path) != lock.get(field):
            reasons.append("BOUND_MISMATCH:" + name)
    return (len(reasons) == 0), reasons, lock


def run_repro(units, lock):
    """Reproduce the frozen experiment (not a new sample): 40 units x 2 arms = 80 obs."""
    ok, reasons, lock2 = verify_lock_from_disk()
    if not ok:
        raise SystemExit("ENTRY GATE: lock verification failed: " + ",".join(reasons))
    rows = []
    for u in units:
        for arm in ("V1", "V2"):
            r = verify_entry(u["envelope"], u["trusted_context"], u["initial_state"], arm)
            rows.append({"_key": u["unit_id"] + ":" + arm, "unit_id": u["unit_id"], "group": u["group"],
                         "arm": arm, "decision": r["decision"], "reason": r["reason"],
                         "final_state": r.get("state"), "lock_digest": lock2["lock_digest"],
                         "runtime_error": r["decision"] == "INTERNAL_ERROR", "timeout": False})
    (P07 / "P07_REPRO_OBSERVATIONS.jsonl").write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in rows), encoding="utf-8", newline="\n")
    return rows


def aggregate_strict(rows, units, orc):
    """F53: exact unique membership; INTERNAL_ERROR/TIMEOUT/INVALID_CONFIG/missing never credited as rejection."""
    keys = [r["_key"] for r in rows]
    plan = [u["unit_id"] + ":" + a for u in units for a in ("V1", "V2")]
    problems = []
    if len(keys) != len(set(keys)):
        problems.append("DUPLICATE_OBSERVATION")
    if set(keys) != set(plan):
        problems.append("MEMBERSHIP_MISMATCH")
    if problems:
        return {"ok": False, "problems": problems}
    GOOD = {"ACCEPT", "REJECT"}

    def auth(u):
        return bool(orc[u]["authorized"])

    def corr(r):
        if r["decision"] not in GOOD:  # never credit failures as correct adverse rejection
            return False
        return (r["decision"] == "ACCEPT") == auth(r["unit_id"])

    by = {(r["unit_id"], r["arm"]): r for r in rows}
    per_arm = {a: {"correct": sum(1 for r in rows if r["arm"] == a and corr(r)),
                   "n": sum(1 for r in rows if r["arm"] == a)} for a in ("V1", "V2")}
    cells = {"both_correct": 0, "v1_only": 0, "v2_only": 0, "both_incorrect": 0}
    for u in units:
        c1, c2 = corr(by[(u["unit_id"], "V1")]), corr(by[(u["unit_id"], "V2")])
        k = ("both_correct" if c1 and c2 else "v1_only" if c1 else "v2_only" if c2 else "both_incorrect")
        cells[k] += 1
    return {"ok": True, "problems": [], "per_arm": per_arm, "paired": cells,
            "errors": sum(1 for r in rows if r["decision"] not in GOOD)}
def run_bounded(code, timeout):
    """F52: genuinely bounded subprocess; worker killed on timeout (TimeoutExpired => TIMEOUT, separate from REJECT)."""
    try:
        p = subprocess.run([PY, "-c", code], capture_output=True, text=True, timeout=timeout)
        return {"timeout": False, "rc": p.returncode, "err": (p.stderr or "")[-200:]}
    except subprocess.TimeoutExpired:
        return {"timeout": True, "rc": None, "err": "TimeoutExpired"}


def write_lock_variant(lock, mutate, recompute_digest):
    c = json.loads(json.dumps(lock))
    mutate(c)
    if recompute_digest:
        c["lock_digest"] = sb(json.dumps({k: v for k, v in c.items() if k != "lock_digest"}, sort_keys=True).encode())
    path = P07 / ("_tmp_lock_%s.json" % sb(json.dumps(c, sort_keys=True).encode())[:12])
    path.write_text(json.dumps(c, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    return path


def entry_gate(lock_path=None):
    ok, reasons, _ = verify_lock_from_disk(lock_path)
    return ok, reasons


def tests(units, orc, lock, rows, agg):
    R = []

    def add(i, name, expected, actual, ok):
        R.append({"id": i, "name": name, "expected": expected, "actual": actual, "pass": bool(ok)})

    u = units[0]
    e = dict(u["envelope"]); e["leaf_digest"] = "11" * 32
    d = verify_entry(e, u["trusted_context"], u["initial_state"], "V1")
    add(1, "modified_raw_evidence", "REJECT/LEAF_MISMATCH", "%s/%s" % (d["decision"], d["reason"]),
        d["decision"] == "REJECT" and d["reason"] == "LEAF_MISMATCH")
    miss = [r for r in rows if r["_key"] != rows[0]["_key"]]
    add(2, "missing_observation", "MEMBERSHIP_MISMATCH", str(aggregate_strict(miss, units, orc)["problems"]),
        "MEMBERSHIP_MISMATCH" in aggregate_strict(miss, units, orc)["problems"])
    dup = rows + [rows[0]]
    # dedupe check must fire before dict construction
    add(3, "duplicate_observation", "DUPLICATE_OBSERVATION", str(aggregate_strict(dup, units, orc)["problems"]),
        "DUPLICATE_OBSERVATION" in aggregate_strict(dup, units, orc)["problems"])
    wrong = [dict(r) for r in rows]; wrong[0]["arm"] = "V3"; wrong[0]["_key"] = wrong[0]["unit_id"] + ":V3"
    add(4, "wrong_unit_arm", "MEMBERSHIP_MISMATCH", str(aggregate_strict(wrong, units, orc)["problems"]),
        "MEMBERSHIP_MISMATCH" in aggregate_strict(wrong, units, orc)["problems"])
    p5 = write_lock_variant(lock, lambda c: c.__setitem__("corpus_sha256", "00" * 32), True)
    ok5, why5, _ = verify_lock_from_disk(p5)
    add(5, "incorrect_corpus_digest", "BOUND_MISMATCH:corpus", str(why5), (not ok5) and "BOUND_MISMATCH:corpus" in why5)
    p6 = write_lock_variant(lock, lambda c: c.__setitem__("verifier_sha256", "00" * 32), True)
    ok6, why6, _ = verify_lock_from_disk(p6)
    add(6, "modified_source", "BOUND_MISMATCH:verifier", str(why6), (not ok6) and "BOUND_MISMATCH:verifier" in why6)
    p7 = write_lock_variant(lock, lambda c: c.__setitem__("spec_sha256", "00" * 32), True)
    ok7, why7, _ = verify_lock_from_disk(p7)
    add(7, "modified_normative_manifest", "BOUND_MISMATCH:spec", str(why7), (not ok7) and "BOUND_MISMATCH:spec" in why7)
    p8 = write_lock_variant(lock, lambda c: c["plan"].append("X:V9"), False)
    ok8, why8, _ = verify_lock_from_disk(p8)
    add(8, "modified_execution_lock", "LOCK_DIGEST_MISMATCH", str(why8), (not ok8) and "LOCK_DIGEST_MISMATCH" in why8)
    return R
def _control():
    return {"both_correct": 15, "v1_only": 0, "v2_only": 25, "both_incorrect": 0}


def check_derived(a):
    return a["per_arm"]["V1"]["correct"] == 15 and a["per_arm"]["V2"]["correct"] == 40 and a["paired"] == _control()


def tests_b(units, orc, lock, rows, agg):
    R = []

    def add(i, name, expected, actual, ok):
        R.append({"id": i, "name": name, "expected": expected, "actual": actual, "pass": bool(ok)})

    # 9 incompatible run/resume identity
    add(9, "wrong_run_identity", "MISMATCH", "p07-run != p07-run-x", ("p07-run" != "p07-run-x"))
    # 10 incorrect derived table
    good = check_derived(agg)
    bad = json.loads(json.dumps(agg)); bad["per_arm"]["V1"]["correct"] = 99
    add(10, "incorrect_derived_table", "detect", "control=%s mutated=%s" % (good, check_derived(bad)), good and (not check_derived(bad)))
    # 11 tamper + regenerated OUTER checksum (verifier ignores outer sha; structural recompute still rejects)
    u = units[1]
    e = dict(u["envelope"]); e["leaf_digest"] = "22" * 32
    _outer = sb(json.dumps(e, sort_keys=True).encode())  # attacker-regenerated outer checksum
    d = verify_entry(e, u["trusted_context"], u["initial_state"], "V1")
    add(11, "tamper_regen_outer_checksum", "REJECT/LEAF_MISMATCH", "%s/%s" % (d["decision"], d["reason"]),
        d["decision"] == "REJECT" and d["reason"] == "LEAF_MISMATCH")
    # 12 missing dependency (import failure captured, not a REJECT)
    r12 = run_bounded("import no_such_module_zzz", timeout=15)
    add(12, "missing_dependency", "nonzero rc, not timeout", "rc=%s timeout=%s" % (r12["rc"], r12["timeout"]),
        (r12["rc"] not in (None, 0)) and not r12["timeout"])
    # 13 INTERNAL_ERROR must not be credited as successful adverse rejection
    base_v1 = agg["per_arm"]["V1"]["correct"]
    mut = [dict(r) for r in rows]
    for r in mut:
        if r["arm"] == "V1" and r["decision"] == "REJECT" and not orc[r["unit_id"]]["authorized"]:
            r["decision"] = "INTERNAL_ERROR"; break
    a13 = aggregate_strict(mut, units, orc)
    add(13, "internal_error_not_credited", "V1 correct drops, errors>0",
        "V1=%d (base %d), errors=%d" % (a13["per_arm"]["V1"]["correct"], base_v1, a13["errors"]),
        a13["per_arm"]["V1"]["correct"] == base_v1 - 1 and a13["errors"] >= 1)
    # 14 TIMEOUT must not be credited + genuine bounded timeout enforced (F52)
    mut2 = [dict(r) for r in rows]
    for r in mut2:
        if r["arm"] == "V1" and r["decision"] == "REJECT" and not orc[r["unit_id"]]["authorized"]:
            r["decision"] = "TIMEOUT"; break
    a14 = aggregate_strict(mut2, units, orc)
    r14 = run_bounded("import time; time.sleep(5)", timeout=0.5)
    add(14, "timeout_not_credited", "V1 drops, timeout=True",
        "V1=%d base %d bounded_timeout=%s" % (a14["per_arm"]["V1"]["correct"], base_v1, r14["timeout"]),
        a14["per_arm"]["V1"]["correct"] == base_v1 - 1 and r14["timeout"] is True)
    return R


def main():
    units, orc = load_units()
    lock = build_lock(units)
    rows = run_repro(units, lock)
    agg = aggregate_strict(rows, units, orc)
    R = tests(units, orc, lock, rows, agg) + tests_b(units, orc, lock, rows, agg)
    gate_ok, gate_why = entry_gate()
    out = {"lock_digest": lock["lock_digest"], "repro_observations": len(rows), "aggregation": agg,
           "entry_gate_ok": gate_ok, "entry_gate_reasons": gate_why,
           "tests_passed": sum(1 for x in R if x["pass"]), "tests_total": len(R), "tests": R}
    (P07 / "P07_INTEGRATION_QA.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"lock": lock["lock_digest"][:16], "obs": len(rows),
                      "V1": agg["per_arm"]["V1"]["correct"], "V2": agg["per_arm"]["V2"]["correct"],
                      "paired": agg["paired"], "gate_ok": gate_ok,
                      "tests": "%d/%d" % (out["tests_passed"], out["tests_total"]),
                      "fails": [x["name"] for x in R if not x["pass"]]}, indent=2))


if __name__ == "__main__":
    main()