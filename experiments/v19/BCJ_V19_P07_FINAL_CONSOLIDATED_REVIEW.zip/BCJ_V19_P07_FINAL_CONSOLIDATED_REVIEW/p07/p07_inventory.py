"""P07-A consolidated immutable artifact inventory (real sha256, P00-P07) + F04/F05 resolution."""
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"

PHASE_COMMIT = {
    "P00": "see experiments/v19/results/P00 provenance",
    "P01": "see experiments/v19/results/P01 provenance",
    "P02": "see experiments/v19/results/P02 provenance",
    "P03": "deac7e74b643adac229e877a5a20c723909b9ba0",
    "P04": "d293c4423a6f81debda6ee84d4b46f6df0b6278d",
    "P05H": "9e9f952acaf3bf196306dc81b877d5583a25a185",
    "P05C": "8ad0afa5b124eee9fbcfa1a3e021fd6011b68030",
    "P06": "P07 worktree (committed with P07)",
    "P07": "P07 worktree (this package)",
    "SSOT": "frozen SSOT (read-only)",
    "CR6": "P00.6 (docs/CR-0006-OPEN.md)",
}

ROOTS = [
    ("P00", "experiments/v19/results/P00", "P00 prereg/spec artifacts", "historical", "*"),
    ("P01", "experiments/v19/results/P01", "P01 artifacts", "historical", "*"),
    ("P02", "experiments/v19/results/P02", "P02 artifacts", "historical", "*"),
    ("P03", "experiments/v19/results/P03", "P03 evidence", "historical", "*"),
    ("P04", "experiments/v19/results/P04", "P04 evidence", "historical", "*"),
    ("P03", "experiments/v19/implementations", "P03 implementations", "historical", "*"),
    ("P04", "experiments/v19/p04_implementation", "P04 impl", "historical", "*"),
    ("P04", "experiments/v19/p04_evaluator", "P04 evaluator", "historical", "*"),
    ("P03", "experiments/v19/scripts", "P0x scripts", "historical", "*.py"),
    ("P04", "experiments/v19/contracts", "contracts", "historical", "*"),
    ("P03", "experiments/v19/fixtures", "fixtures", "historical", "*"),
    ("P05H", "experiments/v19/p05_prereg_r1", "P05 prereg R1", "historical", "*"),
    ("P05H", "experiments/v19/p05_implementation", "P05 frozen verifier", "historical", "*"),
    ("P05H", "experiments/v19/p05_evaluator", "P05 first-pass", "historical-accepted", "*"),
    ("P05C", "experiments/v19/p05_r2b", "P05 corrective", "corrective-accepted", "*"),
    ("P06", "experiments/v19/p07/p06", "CR-0006 recovery", "historical-recovery", "*"),
    ("P07", "experiments/v19/p07", "P07 integration", "integration", "*"),
    ("SSOT", "docs", "SSOT/CR docs", "frozen", "*.md"),
    ("SSOT", "docs", "real manifest", "frozen", "*.json"),
    ("CR6", "py/canon/hashing.py", "campaign formula", "frozen", "*"),
    ("CR6", "scripts/drtea_eq6_repro.py", "CR-0006 repro", "frozen", "*"),
    ("CR6", "derived", "legacy validation CSV", "historical", "legacy*"),
]


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def collect():
    recs = []
    for phase, rel, purpose, status, pat in ROOTS:
        base = ROOT / rel
        if base.is_file():
            files = [base]
        elif base.is_dir():
            files = sorted(base.rglob(pat)) if pat != "*" else sorted(p for p in base.rglob("*") if p.is_file())
        else:
            files = []
        for f in files:
            if not f.is_file():
                continue
            r = f.relative_to(ROOT).as_posix()
            if "P07_ARTIFACT_INVENTORY" in r or "_p07_meta" in r or r.endswith(".zip"):
                continue
            recs.append({"phase": phase, "path": r, "scientific_purpose": purpose,
                         "sha256": sha(f), "source_commit": PHASE_COMMIT[phase], "status": status,
                         "availability": "PRESENT", "limitations": ""})
    # archives at v19 root
    for z in sorted(V19.glob("*.zip")):
        recs.append({"phase": "ARCHIVE", "path": z.relative_to(ROOT).as_posix(), "scientific_purpose": "accepted archive",
                     "sha256": sha(z), "source_commit": "n/a (archive)", "status": "accepted", "availability": "PRESENT", "limitations": ""})
    return recs


def main():
    recs = collect()
    seen = set()
    uniq = []
    for r in recs:
        if r["path"] in seen:
            continue
        seen.add(r["path"])
        uniq.append(r)
    recs = uniq
    # F05: referenced logs
    f05 = {name: (ROOT / name).is_file() for name in
           ["experiments/v19/results/P03/runall_stdout.log", "experiments/v19/results/P03/resume_stdout.log"]}
    f05_any = list((V19 / "results" / "P03").rglob("runall_stdout.log")) + list((V19 / "results" / "P03").rglob("resume_stdout.log"))
    f04 = {k: PHASE_COMMIT[k] for k in ("P03", "P04", "P05H", "P05C")}
    inv = {"artifact_count": len(recs), "phase_commits": PHASE_COMMIT, "F04_exact_commits": f04,
           "F05_referenced_logs": {"expected": list(f05), "found_exact": f05,
                                   "found_anywhere_in_P03": [p.relative_to(ROOT).as_posix() for p in f05_any],
                                   "resolution": "PRESENT" if f05_any else "NOT_RECOVERED (limitation recorded; not fabricated)"},
           "artifacts": recs}
    (P07 / "P07_ARTIFACT_INVENTORY.json").write_text(json.dumps(inv, indent=2) + "\n", encoding="utf-8", newline="\n")
    lines = ["phase,path,purpose,sha256,source_commit,status,availability"]
    for r in recs:
        lines.append("%s,%s,%s,%s,%s,%s,%s" % (r["phase"], r["path"], r["scientific_purpose"].replace(",", ";"),
                                                r["sha256"], r["source_commit"], r["status"], r["availability"]))
    (P07 / "P07_ARTIFACT_INVENTORY.csv").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
    from collections import Counter
    print(json.dumps({"artifacts": len(recs), "by_phase": dict(Counter(r["phase"] for r in recs)),
                      "F05_logs_found": len(f05_any)}, indent=2))


if __name__ == "__main__":
    main()