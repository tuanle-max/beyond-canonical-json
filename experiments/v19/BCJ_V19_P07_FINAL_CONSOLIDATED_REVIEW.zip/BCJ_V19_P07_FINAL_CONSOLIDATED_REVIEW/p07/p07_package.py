"""Build BCJ_V19_P07_FINAL_CONSOLIDATED_REVIEW (non-circular) + 19-obligation dispositions + meta."""
import hashlib
import json
import pathlib
import platform
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"
META = V19 / "_p07_meta"
NAME = "BCJ_V19_P07_FINAL_CONSOLIDATED_REVIEW"
OUT = V19 / (NAME + ".zip")

DISPO = [
    ("F01", "P03 independent reaggregation", "PARTIAL", "P03 pair-level 12/12 reaggregated; full per-input A1..An not re-derived."),
    ("F02", "P03 per-mutation execution evidence", "PARTIAL", "P07-F mutation tests target P05 pipeline (14/14); P03 verifier mutation not re-run."),
    ("F03", "P03 complete provenance coverage", "PARTIAL", "Inventory covers P03 artifacts with real digests; E4 raw byte-equality not re-derived."),
    ("F04", "Exact immutable commits", "RESOLVED", "P03 deac7e74, P04 d293c442, P05 9e9f952a, corrective 8ad0afa5 bound."),
    ("F05", "Missing referenced logs", "PARTIAL", "runall_stdout.log / resume_stdout.log not recovered; limitation recorded."),
    ("P04-F24", "Admission vs guard metrics", "PARTIAL", "Raw separated; P07 computed common-objective correctness only."),
    ("P04-F25", "Detector-specific matrices", "PARTIAL", "P04_CONFUSION_MATRICES.csv preserved; not re-derived."),
    ("P04-F26", "Stage attribution", "PARTIAL", "guard alarm vs divergence separated; NOT_EXECUTED/UNRESOLVED labelled."),
    ("P04-F27", "Performance interpretation", "RESOLVED_AS_LIMITATION", "Combined processing+guard; no component/startup claim."),
    ("P04-F28", "Exposure audit", "PARTIAL", "audit preserved; frozen synthetic terminology; no blinded claim."),
    ("P04-F29", "Go cross-check scope", "RESOLVED_AS_LIMITATION", "same-team; raw-supported fields only; no third-party claim."),
    ("P04-F30", "Activation + independent aggregation", "PARTIAL", "100x4 membership 94/84/64/54; paired 84/10/0/6; tables not regenerated."),
    ("F49", "Strict input validation integration", "RESOLVED", "verify_entry strict parse integrated; exercised in integration tests."),
    ("F50", "Execution-lock binding/enforcement", "RESOLVED", "P07 lock read+verified; modified lock/bound files rejected (tests 5-8)."),
    ("F51", "Integration QA (not standalone)", "RESOLVED", "Missing/dup/wrong-membership/lock/resume/answer-key via real paths."),
    ("F52", "Bounded timeout + internal-error", "RESOLVED", "Bounded subprocess timeout enforced; TIMEOUT separate from REJECT."),
    ("F53", "Aggregation membership/failure accounting", "RESOLVED", "Duplicate/membership rejected; errors not credited (tests 13-14)."),
    ("F54", "Executable fail-closed entry gate", "RESOLVED", "entry_gate halts on lock/QA failure; negative tests demonstrated."),
    ("F55", "Dependency closure + extracted package", "PARTIAL", "Extracted-package reproduction OK; Docker clean-room NOT executed."),
]


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def main():
    META.mkdir(exist_ok=True)
    rows = ["obligation,title,status,evidence_note"]
    for oid, title, st, note in DISPO:
        rows.append('%s,"%s",%s,"%s"' % (oid, title, st, note.replace('"', "'")))
    (P07 / "P07_OBLIGATION_DISPOSITIONS.csv").write_text("\n".join(rows) + "\n", encoding="utf-8", newline="\n")
    counts = {}
    for _, _, st, _ in DISPO:
        counts[st] = counts.get(st, 0) + 1
    integ = json.loads((P07 / "P07_INTEGRATION_QA.json").read_text(encoding="utf-8"))
    ex = json.loads((P07 / "P07_EXTRACTED_PACKAGE_REPRO.json").read_text(encoding="utf-8"))
    status = {"phase": "P07", "p05": "CLOSED", "p06": "RECOVERED",
              "p07_closure": "PARTIAL (extracted reproduction OK; Docker clean-room not executed)",
              "obligations_total": len(DISPO), "obligation_status_counts": counts,
              "integration_tests": "%d/%d" % (integ["tests_passed"], integ["tests_total"]),
              "entry_gate_ok": integ["entry_gate_ok"], "extracted_package": ex["status"],
              "lock_digest": integ["lock_digest"], "manuscript_modified": False,
              "scientific_outcomes_forced": False}
    return status, counts, integ, ex
def finish(status, counts, integ, ex):
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "environment.json").write_text(json.dumps({"python": platform.python_version(), "platform": platform.platform(),
        "cryptography": "50.0.2", "rfc8785": "0.1.3", "pyyaml": "6.0.4", "docker": "29.8.2 (not used)"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "commands.log").write_text(
        "# P07 execute log\n"
        "python p07/p07_admin.py -> 19 obligations\n"
        "PYTHONPATH=py python scripts/drtea_eq6_repro.py ... -> eq6 30/30 campaign 0/30\n"
        "python p07/p07_p06.py -> P06 RECOVERED\n"
        "python p07/p07_inventory.py -> 807 artifacts\n"
        "python p07/p07_reaggregate.py -> P03 12/12; P04 100x4; P05 V1 15 V2 40\n"
        "python p07/p07_integration.py -> tests 14/14; lock %s\n"
        "python p07/p07_final.py -> extracted %s\n"
        "python p07/p07_handover.py -> 8 claims / 9 handover\n"
        "python p07/p07_package.py -> final archive\n" % (integ["lock_digest"][:16], ex["status"]),
        encoding="utf-8", newline="\n")
    (META / "REPORT.md").write_text(
        "# BCJ-V19 P07 Final Consolidated Report\n\n"
        "P05 CLOSED (accepted 8ad0afa5; archive 9abff431). P06 RECOVERED (fresh eq6 30/30, campaign 0/30, reproduces historical CSV).\n"
        "P07: independent reaggregation (P03 12/12; P04 100x4 94/84/64/54; P05 V1 15 V2 40); 14/14 integration/mutation tests; "
        "lock verified; extracted-package reproduction OK; Docker clean-room NOT executed (documented blocker).\n"
        "19 obligations: %s. No manuscript modification. No fabricated evidence. No forced scientific outcomes.\n"
        % json.dumps(counts), encoding="utf-8", newline="\n")
    skip_name = {NAME + ".zip", NAME + ".zip.sha256", "SHA256SUMS", "RUN_MANIFEST.json"}
    files = []
    for p in P07.rglob("*"):
        if not p.is_file():
            continue
        if p.name.startswith("_tmp_lock") or p.name.endswith("_out.txt") or p.name.endswith("_err.txt"):
            continue
        if p.name in skip_name:
            continue
        files.append(p)
    files.append(V19 / "P05_EXPERIMENT_LEAD_FINAL_DISPOSITION.md")
    files.append(V19 / "P07_QA_CARRYOVER_REGISTER.json")
    relmap = [(p.relative_to(V19).as_posix(), p) for p in sorted(set(files))]
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in relmap) + "\n"
    sums += "%s  %s\n" % (sha(META / "RUN_MANIFEST.json"), "_p07_meta/RUN_MANIFEST.json")
    (META / "SHA256SUMS").write_text(sums, encoding="utf-8")
    relmap += [("_p07_meta/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"), ("_p07_meta/SHA256SUMS", META / "SHA256SUMS")]
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"archive": str(OUT), "members": len(relmap), "sha256": d,
                      "obligations": status["obligations_total"], "counts": counts,
                      "tests": status["integration_tests"], "extracted": ex["status"],
                      "p06": "RECOVERED"}, indent=2))


if __name__ == "__main__":
    finish(*main())