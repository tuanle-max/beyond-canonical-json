"""P07-B independent reaggregation from raw evidence (no production correctness classifier imports)."""
import json
import pathlib
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07"


def jl(p):
    with open(p, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def j(p):
    return json.loads(pathlib.Path(p).read_text(encoding="utf-8"))


def p05():
    raw = jl(V19 / "p05_r2b" / "P05_R2B_RAW_OBSERVATIONS.jsonl")
    orc = {r["unit_id"]: r for r in jl(V19 / "p05_evaluator" / "P05_EVALUATOR_ORACLE.jsonl")}
    keys = [r["_key"] for r in raw]
    units = set(r["unit_id"] for r in raw)
    dup = len(keys) - len(set(keys))

    def auth(u):
        return bool(orc[u]["authorized"])

    def corr(r):
        return (r["decision"] == "ACCEPT") == auth(r["unit_id"])

    by = {(r["unit_id"], r["arm"]): r for r in raw}
    per_arm = {a: {"correct": sum(1 for r in raw if r["arm"] == a and corr(r)),
                   "n": sum(1 for r in raw if r["arm"] == a)} for a in ("V1", "V2")}
    cells = {"both_correct": 0, "v1_only": 0, "v2_only": 0, "both_incorrect": 0}
    for u in units:
        c1, c2 = corr(by[(u, "V1")]), corr(by[(u, "V2")])
        k = ("both_correct" if c1 and c2 else "v1_only" if c1 else "v2_only" if c2 else "both_incorrect")
        cells[k] += 1
    auth_n = sum(1 for u in units if auth(u))
    authorized = {a: sum(1 for r in raw if r["arm"] == a and auth(r["unit_id"]) and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    suu_n = sum(1 for u in units if not auth(u) and orc[u]["group"] != "G5")
    suu = {a: sum(1 for r in raw if r["arm"] == a and not auth(r["unit_id"]) and orc[r["unit_id"]]["group"] != "G5" and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    g2 = {a: sum(1 for r in raw if r["arm"] == a and r["group"] == "G2" and r["decision"] == "ACCEPT") for a in ("V1", "V2")}
    errors = sum(1 for r in raw if r["decision"] in ("INTERNAL_ERROR", "TIMEOUT", "INVALID_CONFIG") or r.get("runtime_error") or r.get("timeout"))
    reason = sum(1 for r in raw if r["reason"] == (orc[r["unit_id"]]["expected_v1_reason"] if r["arm"] == "V1" else orc[r["unit_id"]]["expected_v2_reason"]))
    pub = j(V19 / "p05_r2b" / "P05_R2B_INDEPENDENT_AGGREGATION.json")
    res = {"observations": len(raw), "duplicates": dup, "units": len(units), "per_arm": per_arm,
           "paired": cells, "authorized_n": auth_n, "authorized": authorized,
           "structurally_valid_unauthorized_n": suu_n, "structurally_valid_unauthorized": suu,
           "g2": g2, "errors_not_credited": errors, "reason_exact": [reason, len(raw)]}
    res["agrees_with_published"] = (per_arm["V1"]["correct"] == pub["per_arm"]["V1"]["correct"]
                                    and per_arm["V2"]["correct"] == pub["per_arm"]["V2"]["correct"]
                                    and cells == {k: pub["paired"][k] for k in cells})
    return res


def p04():
    raw = jl(V19 / "results" / "P04" / "P04_MEASURED_RAW.jsonl")
    orc = {r["unit_id"]: r for r in jl(V19 / "p04_evaluator" / "P04_EVALUATOR_ORACLE.jsonl")}

    def unit_of(r):
        return r.get("unit_id") or r["_key"].split(":")[0]

    def arm_of(r):
        return r.get("arm") or r["_key"].split(":")[1]

    keys = [r["_key"] for r in raw]
    units = set(unit_of(r) for r in raw)
    arms = sorted(set(arm_of(r) for r in raw))

    def act(r):
        if r.get("admitted") is not None:
            return bool(r["admitted"])
        return r.get("admission_status") == "ACCEPT" or r.get("decision") == "ACCEPT"

    def corr(r):
        return act(r) == (orc[unit_of(r)]["expected_admission"] == "ACCEPT")

    per_arm = {a: {"correct": sum(1 for r in raw if arm_of(r) == a and corr(r)),
                   "n": sum(1 for r in raw if arm_of(r) == a)} for a in arms}
    by = {(unit_of(r), arm_of(r)): r for r in raw}
    paired = None
    if len(arms) >= 2:
        a, b = arms[0], arms[1]
        cells = {"both_correct": 0, "a_only": 0, "b_only": 0, "both_incorrect": 0}
        for u in units:
            ca, cb = corr(by[(u, a)]), corr(by[(u, b)])
            k = ("both_correct" if ca and cb else "a_only" if ca else "b_only" if cb else "both_incorrect")
            cells[k] += 1
        paired = {"arms": [a, b], "cells": cells}
    return {"observations": len(raw), "duplicates": len(keys) - len(set(keys)), "units": len(units),
            "arms": arms, "expected_membership": "%d units x %d arms = %d" % (len(units), len(arms), len(units) * len(arms)),
            "membership_exact": len(raw) == len(units) * len(arms) and len(keys) == len(set(keys)),
            "per_arm": per_arm, "paired": paired}


def p03():
    pairs = jl(V19 / "results" / "P03" / "P03_E2_PAIR_RESULTS.jsonl")
    ok = sum(1 for p in pairs if p.get("pass"))
    return {"pairs": len(pairs), "pair_semantic_pass": "%d/%d" % (ok, len(pairs)),
            "by_expectation": dict(Counter(p.get("expected") for p in pairs))}


def main():
    out = {"P03": p03(), "P04": p04(), "P05": p05()}
    (P07 / "P07_INDEPENDENT_AGGREGATION.json").write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"P03_pairs": out["P03"]["pair_semantic_pass"],
                      "P04_membership_exact": out["P04"]["membership_exact"],
                      "P04_arms": out["P04"]["arms"],
                      "P04_per_arm": {a: v["correct"] for a, v in out["P04"]["per_arm"].items()},
                      "P05_per_arm": {a: v["correct"] for a, v in out["P05"]["per_arm"].items()},
                      "P05_paired": out["P05"]["paired"], "P05_agrees_published": out["P05"]["agrees_with_published"]}, indent=2))


if __name__ == "__main__":
    main()