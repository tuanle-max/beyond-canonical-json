# P07 executable targets (PowerShell). Pinned deps: python 3.12.9, cryptography 50.0.2, rfc8785 0.1.3, PyYAML 6.0.4
param([string]$t="test",[string]$py="python")
switch ($t) {
  "verify-inputs"     { & $py experiments/v19/p07/p07_inventory.py }
  "build"             { Write-Host "pure-python; no build step" }
  "test"              { & $py experiments/v19/p07/p07_integration.py }
  "reproduce-legacy"  { $env:PYTHONPATH="py"; & $py scripts/drtea_eq6_repro.py --manifest docs/drtea_mainnet_manifest_REAL.json --csv experiments/v19/p07/p06/repro_eq6_fresh.csv }
  "reproduce-v19"     { & $py experiments/v19/p07/p07_integration.py }
  "regenerate-tables" { & $py experiments/v19/p07/p07_handover.py }
  "verify-results"    { & $py experiments/v19/p07/p07_reaggregate.py }
  "package-review"    { & $py experiments/v19/p07/p07_package.py }
  default { Write-Error "unknown target" }
}
