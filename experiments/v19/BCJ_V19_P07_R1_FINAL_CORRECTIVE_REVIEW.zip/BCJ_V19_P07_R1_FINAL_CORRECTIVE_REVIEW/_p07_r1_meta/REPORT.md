# BCJ-V19 P07-R1 Final Corrective Report

P04 metric reconciled: prior 94/84/64/54 used the wrong (semantic-admission) objective. Corrected to the accepted safe end-to-end metric: A1 45 / A1+PID 75 / A1+CI 55 / A2 85; paired A1 vs A2 45/0/40/15 (agrees with accepted reference).
P05 corrected accounting: V1 15/40, V2 40/40 (INTERNAL_ERROR/TIMEOUT never credited). P06 provenance: reproduction, no on-chain.
Register: {"PARTIAL": 4, "RESOLVED": 11, "RESOLVED_AS_LIMITATION": 4}. P03 deep reconstruction PARTIAL. Docker clean-room NOT executed. Manuscript NOT modified.
