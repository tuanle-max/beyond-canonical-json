# P07-R1 Approved Results Narrative (corrected P04 metric)

Scope: frozen corpora; same-team. No universal-security/prevalence/third-party claim.

## RQ2 (P04) - CORRECTED common end-to-end (safe release)
A1 45, A1+PID 75, A1+CI 55, A2 85 of 100. Paired A1 vs A2: both 45, A1_only 0, A2_only 40, both_incorrect 15. Unsafe-release A1 55/A1+PID 25/A1+CI 45/A2 15 of 60; benign service 40/40 each.
Definition: fault=>correct iff not released; benign=>released and canonical==expected; runtime failure never correct.

## RQ3 (P05)
V1 15/40, V2 40/40; paired 15/0/25/0.

## RQ4 (P06)
Reproduction of recovered pilot: artifact Eq.6 30/30; campaign 0/30; batch 0 divergence. Not an on-chain verification.

## RQ5 (P07)
Extracted-package reproduction OK; Docker clean-room not executed (blocker documented).
