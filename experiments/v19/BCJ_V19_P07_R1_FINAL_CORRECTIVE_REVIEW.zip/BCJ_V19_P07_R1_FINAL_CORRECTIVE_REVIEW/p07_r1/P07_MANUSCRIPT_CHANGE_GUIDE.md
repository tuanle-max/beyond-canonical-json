# P07-R1 Manuscript Change Guide (do NOT edit manuscript here)

1. RQ2: REPLACE prior 94/84/64/54 with A1 45 / A1+PID 75 / A1+CI 55 / A2 85; paired A1 vs A2 45/0/40/15.
2. RQ3: V1 15/40, V2 40/40, paired 15/0/25/0, effect +0.625; state 39/39 +1 N/A.
3. RQ4: 30/30 eq6 vs 0/30 campaign as REPRODUCTION (no on-chain claim).
4. Reproducibility: extracted only; do NOT claim Docker/offline.
5. Remove universal-security/prevalence/third-party wording. Do not merge denominators.
