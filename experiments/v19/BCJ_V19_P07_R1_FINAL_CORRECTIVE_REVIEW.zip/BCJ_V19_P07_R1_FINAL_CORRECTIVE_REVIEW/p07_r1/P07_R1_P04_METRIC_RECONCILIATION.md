# P07-R1 P04 Metric Reconciliation

**Root cause:** prior P07 reaggregation (94/84/64/54) measured *observed admission vs expected semantic admission*, which is NOT the P04 common end-to-end objective.

**Recovered normative definition (safe end-to-end release):**
- fault unit: correct iff NOT artifact_released (any release of a fault unit is unsafe); runtime failure never correct.
- benign unit: correct iff released AND canonical_digest == expected_canonical; runtime failure never correct.

## Recomputed vs accepted
| arm | recomputed | accepted | unsafe_release | benign |
|---|---|---|---|---|
| A1 | 45/100 | 45/100 | 55/60 | 40/40 |
| A1+PID | 75/100 | 75/100 | 25/60 | 40/40 |
| A1+CI | 55/100 | 55/100 | 45/60 | 40/40 |
| A2 | 85/100 | 85/100 | 15/60 | 40/40 |

**Paired A1 vs A2:** both=45, A1_only=0, A2_only=40, both_incorrect=15 (accepted 45/0/40/15).

**Agreement with accepted reference:** True. No unresolved metric discrepancy; manuscript handover permitted.

F24-F27 computed in `P07_R1_P04_F24_F30.json`. Runtime failures: 0.
