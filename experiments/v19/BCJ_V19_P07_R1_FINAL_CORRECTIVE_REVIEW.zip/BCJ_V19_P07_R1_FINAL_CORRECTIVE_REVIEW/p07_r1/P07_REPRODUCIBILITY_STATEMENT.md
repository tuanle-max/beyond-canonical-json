# P07-R1 Reproducibility Statement

- Lock verified from disk (plan membership + digests).
- Integration/mutation tests executed; bounded subprocess timeout.
- Extracted-package reproduction OK; consolidated multi-phase run logged.
- Docker NOT executed (documented blocker). Pins: python 3.12.9, cryptography 50.0.2, rfc8785 0.1.3, PyYAML 6.0.4.
