# P07-R1 Threats to Validity

- Frozen synthetic corpora; same-team; not third-party.
- P04 metric = safe end-to-end release (runtime failure never credited).
- P05 post-exposure; reason codes decision-level only.
- P06 is reproduction of recovered historical evidence; no on-chain verification (tx_id/block empty).
- P03 deep reconstruction PARTIAL; F05 logs unrecovered.
- Docker clean-room not executed.
