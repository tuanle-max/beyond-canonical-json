"""Build BCJ_V19_P07_R1_FINAL_CORRECTIVE_REVIEW (non-circular) + meta."""
import hashlib
import json
import pathlib
import platform
import zipfile

ROOT = pathlib.Path(__file__).resolve().parents[3]
V19 = ROOT / "experiments" / "v19"
P07 = V19 / "p07_r1"
META = V19 / "_p07_r1_meta"
NAME = "BCJ_V19_P07_R1_FINAL_CORRECTIVE_REVIEW"
OUT = V19 / (NAME + ".zip")


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def main():
    META.mkdir(exist_ok=True)
    reg = json.loads((P07 / "P07_R1_19_OBLIGATION_REGISTER.json").read_text(encoding="utf-8"))
    integ = json.loads((P07 / "P07_R1_INTEGRATION_QA.json").read_text(encoding="utf-8"))
    cons = json.loads((P07 / "P07_R1_CONSOLIDATED_REPRO.json").read_text(encoding="utf-8"))
    p4 = json.loads((P07 / "P07_R1_P04_INDEPENDENT_AGGREGATION.json").read_text(encoding="utf-8"))
    status = {"phase": "P07-R1", "p04_metric": "RECONCILED (safe end-to-end)",
              "p04_per_arm": {a: p4["per_arm"][a]["correct"] for a in ("A1", "A1+PID", "A1+CI", "A2")},
              "p04_paired": p4["paired"], "p04_agrees_accepted": p4["agrees_with_accepted"],
              "p05_corrective": "V1 15/40 V2 40/40 (corrected accounting)",
              "p05_first_pass": "RECONFIRMED", "p06": "ACCEPTED (reproduction; no on-chain)", "p03": "PARTIAL (deep recon)",
              "register": reg["counts"], "integration_all_pass": integ["all_pass"],
              "consolidated": cons["status"], "docker": "NOT_EXECUTED", "manuscript_modified": False,
              "preserves_p07_archive": "ec0e5448be666ace8ac63aa12102e18da53603230b78993077d3c2d7a1beed09"}
    (META / "status.json").write_text(json.dumps(status, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "environment.json").write_text(json.dumps({"python": platform.python_version(), "platform": platform.platform(),
        "cryptography": "50.0.2", "rfc8785": "0.1.3", "pyyaml": "6.0.4", "docker": "29.8.2 (not used)"}, indent=2) + "\n", encoding="utf-8", newline="\n")
    (META / "commands.log").write_text(
        "# P07-R1\npython p07_r1/p07_r1.py -> P04 45/75/55/85; paired 45/0/40/15; agrees=true; P05 15/40,40/40; P06 reproduced\n"
        "python p07_r1/p07_r1_finish.py -> register 19 (%s); handover regenerated; integration all_pass=%s; consolidated=%s\n"
        "python p07_r1/p07_r1_package.py -> final archive\n"
        % (json.dumps(reg["counts"]), integ["all_pass"], cons["status"]), encoding="utf-8", newline="\n")
    (META / "REPORT.md").write_text(
        "# BCJ-V19 P07-R1 Final Corrective Report\n\n"
        "P04 metric reconciled: prior 94/84/64/54 used the wrong (semantic-admission) objective. Corrected to the accepted "
        "safe end-to-end metric: A1 45 / A1+PID 75 / A1+CI 55 / A2 85; paired A1 vs A2 45/0/40/15 (agrees with accepted reference).\n"
        "P05 corrected accounting: V1 15/40, V2 40/40 (INTERNAL_ERROR/TIMEOUT never credited). P06 provenance: reproduction, no on-chain.\n"
        "Register: %s. P03 deep reconstruction PARTIAL. Docker clean-room NOT executed. Manuscript NOT modified.\n"
        % json.dumps(reg["counts"]), encoding="utf-8", newline="\n")
    skip = {NAME + ".zip", NAME + ".zip.sha256", "SHA256SUMS", "RUN_MANIFEST.json"}
    files = [p for p in P07.rglob("*") if p.is_file() and p.name not in skip and "__pycache__" not in p.as_posix()]
    relmap = [(p.relative_to(V19).as_posix(), p) for p in sorted(files)]
    manifest = {"archive": NAME, "files": {rel: sha(p) for rel, p in relmap}, "count": len(relmap)}
    (META / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    relmap.append(("_p07_r1_meta/status.json", META / "status.json"))
    relmap.append(("_p07_r1_meta/environment.json", META / "environment.json"))
    relmap.append(("_p07_r1_meta/commands.log", META / "commands.log"))
    relmap.append(("_p07_r1_meta/REPORT.md", META / "REPORT.md"))
    sums = "\n".join("%s  %s" % (sha(p), rel) for rel, p in relmap) + "\n"
    sums += "%s  %s\n" % (sha(META / "RUN_MANIFEST.json"), "_p07_r1_meta/RUN_MANIFEST.json")
    (META / "SHA256SUMS").write_text(sums, encoding="utf-8")
    relmap += [("_p07_r1_meta/RUN_MANIFEST.json", META / "RUN_MANIFEST.json"), ("_p07_r1_meta/SHA256SUMS", META / "SHA256SUMS")]
    if OUT.exists():
        OUT.unlink()
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        for rel, p in sorted(relmap):
            z.write(p, NAME + "/" + rel)
    d = sha(OUT)
    (V19 / (NAME + ".zip.sha256")).write_text(d + "  " + NAME + ".zip\n", encoding="utf-8", newline="\n")
    print(json.dumps({"archive": str(OUT), "members": len(relmap), "sha256": d,
                      "p04": status["p04_per_arm"], "p04_paired": status["p04_paired"],
                      "agrees": p4["agrees_with_accepted"], "register": reg["counts"]}, indent=2))


if __name__ == "__main__":
    main()